﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mrap.Mars.Common;
using Newtonsoft.Json;
using System.Data;
using System.Diagnostics;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class SynonymsQueryTests
    {
        [TestClass]
        public class when_handler_processes_datatable
        {
            [TestMethod]
            public void should_populate_to_schema_dictionary()
            {
                //Arrange
                var db = new Mock<IMarsDb>();
                var data =
                    @"[{""name"":""OptionPosition"",""base_object_name"":""[target].[vOptionPosition]""},
                   {""name"":""Blah"",""base_object_name"":""[blip].[vBlah]""}]";
                var dt = JsonConvert.DeserializeObject<DataTable>(data);

                var sut = new SynonymsQuery(db.Object);
                //Act
                sut.handler(dt.Rows[0]);
                //Assert

                var expectedBaseObjectName = "vOptionPosition";
                var expectedBaseObjectSchema = "target";
                
                var item = sut.data["OptionPosition"];

                Debug.Print(item.baseObjectName);
                Debug.Print(item.baseObjSchema);

                Assert.AreEqual(expectedBaseObjectName, item.baseObjectName);
                Assert.AreEqual(expectedBaseObjectSchema, item.baseObjSchema);
            }
        }
    }
}
