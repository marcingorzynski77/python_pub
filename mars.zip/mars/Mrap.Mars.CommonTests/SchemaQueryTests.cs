﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mrap.Mars.Common;
using Newtonsoft.Json;
using System.Data;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class SchemaQueryTests
    {
        [TestClass]
        public class when_query_called
        {
            [TestMethod]
            public void should_get_data_and_run_handler()
            {
                //Arrange
                var marsDb = new Mock<IMarsDb>();
                var synDto = SynonymInfoDTO.Default();
                var sut = new Mock<SynonymSchemaQuery>(marsDb.Object, synDto);
                sut.Setup(x => x.handler(It.IsAny<DataRow>()));
                var data =
                    @"[{""DATA_TYPE"":""data.type.1"",""COLUMN_NAME"":""column.Name.1""},
                       {""DATA_TYPE"":""data.type.2"",""COLUMN_NAME"":""column.Name.2""},
                       {""DATA_TYPE"":""data.type.3"",""COLUMN_NAME"":""column.Name.3""}]";
                var dt = JsonConvert.DeserializeObject<DataTable>(data);
                marsDb.Setup(x => x.query(It.IsAny<IInlineSqlQuery>())).Returns(dt);

                //Act
                sut.Object.query();
                
                //Assert
                marsDb.Verify(db => db.query(sut.Object));
                sut.Verify(x => x.handler(It.IsAny<DataRow>()), Times.Exactly(3));

            }
        }
        [TestClass]
        public class when_flex_fact_query_called
        {
            [TestMethod]
            public void should_get_data_and_run_handler()
            {
                //Arrange
                var marsDb = new Mock<IMarsDb>();
                var flexFact = "Some.Feed";
                var sut = new Mock<FlexFactSchemaQuery>(marsDb.Object, flexFact);
                sut.Setup(x => x.handler(It.IsAny<DataRow>()));
                var data =
                    @"[{""DATA_TYPE"":""data.type.1"",""COLUMN_NAME"":""column.Name.1""},
                       {""DATA_TYPE"":""data.type.2"",""COLUMN_NAME"":""column.Name.2""},
                       {""DATA_TYPE"":""data.type.3"",""COLUMN_NAME"":""column.Name.3""}]";
                var dt = JsonConvert.DeserializeObject<DataTable>(data);

                marsDb.Setup(x => x.query(sut.Object)).Returns(dt);

                //Act
                sut.Object.query();
                //Assert
                marsDb.Verify(db => db.query(sut.Object));
                sut.Verify(x => x.handler(It.IsAny<DataRow>()), Times.Exactly(3));


            }
        }
    }
}
