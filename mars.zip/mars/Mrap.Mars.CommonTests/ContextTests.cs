﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mrap.Mars.Common;
using System;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class ContextTests
    {
        [TestClass]
        public class when_GetTimeTravelDateTimeAsString
        {
            [TestMethod]
            public void should_returnWorkbookContext()
            {
                WorkbookContext.SetContextValue(Context.TimeTravelDate, "abc");
                var res = Context.GetTimeTravelDateTimeAsString;

                Assert.AreEqual("abc", res);
            }
        }

        [TestClass]
        public class when_GetTimeTravelDateTime_withValidDate
        {
            [TestMethod]
            public void should_returnDateTimeFromContext()
            {
                WorkbookContext.SetContextValue(Context.TimeTravelDate, "12-Mar-2018");
                var res = Context.GetTimeTravelDateTime();

                Assert.AreEqual(DateTime.Parse("12-Mar-2018"), res);

            }
        }
        [TestClass]
        public class when_GetTimeTravelDateTime_withInvalidDate
        {
            [TestMethod]
            public void shouldHaveJustReturned()
            {
                WorkbookContext.SetContextValue(Context.TimeTravelDate, "12-Minin-2018");
                var res = Context.GetTimeTravelDateTime();
                var diff = DateTime.UtcNow - res;
                Assert.IsTrue( diff < TimeSpan.FromMilliseconds(100));
            }
        }
        [TestClass]
        public class when_getHierarchy
        {
            [TestMethod]
            public void shouldReturnContext()
            {
                WorkbookContext.SetContextValue(Context.Hierarchy, "1");
                var res = WorkbookContext.GetContextValue(Context.Hierarchy);
                Assert.AreEqual("1",res);
            }
        }
    }
}
