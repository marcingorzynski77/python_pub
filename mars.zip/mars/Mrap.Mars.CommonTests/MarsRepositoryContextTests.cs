﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mrap.Mars.Common;
using Newtonsoft.Json;
using System.Data;
using System.Diagnostics;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class MarsRepositoryContextTests
    { 
        [TestClass]
        public class whenSetTargetDate
        {
            [TestMethod]
            public void shouldUseContextDate()
            {
                //Arrange
                var db = new Mock<IMarsDb>();
                WorkbookContext.SetContextValue(Context.TimeTravelDate, "21-Jun-2018");
                WorkbookContext.SetContextValue(Context.BusinessDate, "23-Jun-2022");

                //Act
                MarsRepositoryContext.SetTargetDate(db.Object);
                //Assert
                db.Verify(x => x.execute(It.Is<SetTargetDateQuery>(
                    y => y.Params[0].Value.Equals("21-Jun-2018")
                      && y.Params[1].Value.Equals("23-Jun-2022"))));
            }
        }

        [TestClass]
        public class whenSetHierarchyMode
        {
            [TestMethod]
            public void shouldUseContextHierarchy()
            {
                //Arrange
                var db = new Mock<IMarsDb>();
                var data = @"[{""value"":""1""}]";
                var dt = JsonConvert.DeserializeObject<DataTable>(data);

                db.Setup(x => x.query(It.IsAny<HierarchyEnumQuery>())).Returns(dt);
                WorkbookContext.SetContextValue(Context.Hierarchy,"1");
                //Act
                MarsRepositoryContext.SetHierarchyMode(db.Object);
                //Assert
                db.Verify(x => x.query(It.IsAny<HierarchyEnumQuery>()));
            }
        }
    }
}
