﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mrap.Mars.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class SetTargetDateQueryTests
    {
        [TestClass]
        public class when_queryCalled
        {
            [TestMethod]
            public void db_should_execute_with_2_params()
            {
                //Arrange
                var db = new Mock<IMarsDb>();
                var sDate = "21-Jan-2018";
                var busDate = "22-Jan-2018";
                var sut = SetTargetDateQuery.Default(db.Object,sDate,busDate);
                //Act
                sut.query();
                //Assert
                Assert.AreEqual(2, sut.Params.Count());
                Assert.AreEqual("21-Jan-2018", sut.Params[0].Value.ToString());
                Assert.AreEqual("22-Jan-2018", sut.Params[1].Value.ToString());

                db.Verify(x => x.execute(sut));

            }
        }
    }
}
