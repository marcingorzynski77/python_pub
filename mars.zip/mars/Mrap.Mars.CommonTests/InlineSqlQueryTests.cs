﻿using Mrap.Mars.Common;
using System.Data;
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class InlineSqlQueryTests
    {

        static string someQuery = "some query";
        public class SUT : InlineSqlQuery
        {
            public int counter = 0;
            public SUT(IMarsDb db) : base(db, someQuery) { }
            public override void handler(DataRow row) { counter++; }
        }

        [TestClass]
        public class when_query_called
        {
            [TestMethod]
            public void should_run_db_query_with_queryString()
            {
                //Arrange
                var marsDB = new Mock<IMarsDb>();
                var dt = new DataTable();
                dt.Columns.Add("name");
                dt.Rows.Add(new[] { "abc" });
                dt.Rows.Add(new[] { "def" });

                var sut = new SUT(marsDB.Object);

                marsDB.Setup(x => x.query(sut)).Returns(dt);
                //Act
                sut.query();
                //Assert
                Assert.AreEqual(2, sut.counter, "Handler should have been called twice");
            }
        }
    }
}
