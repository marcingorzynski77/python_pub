﻿using log4net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mrap.Mars.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class MarsDbTests
    {
        [TestClass]
        public class when_SynonymsQuery_runs
        {
            [TestMethod]
            public void should_query_database_and_return_some_data()
            {
                //Arrange
                const string connString = @"Data Source=FMD-D8-3076\BRIDGED01;Initial Catalog=MaRS;Trusted_Connection=Yes";
                var log = new Mock<ILog>();

                var db = new MarsDb(log.Object, connString);
                var sut = new SynonymsQuery(db);

                //Act
                sut.query();

                //Assert
                sut.data.Keys.ToList().ForEach(x => Trace.WriteLine(x));
                Assert.IsTrue(sut.data.Keys.Count() > 0);

            }
        }
        [TestClass]
        public class when_query_runs
        {
            [TestMethod]
            public void should_query_database_and_return_some_data()
            {
                //Arrange
                const string connString = @"Data Source=FMU-D8-3076\BRIDGEU01;Initial Catalog=MaRS;Trusted_Connection=Yes";
                var log = new Mock<ILog>();
                var d = new List<object[]>();
                var sqlParams = new List<SqlParameter>().ToArray();
                Action<object[]> readdata = (row) =>
                {
                    d.Add(row);
                    var sRow = string.Join(",", row.ToList().Select(x => x.ToString()));
                    Debug.Print(sRow);
                };
                var query = "select top 10 start, hierarchykey, null ac from target.hierarchy";
                var maxCells = 2000;

                //Act
                Action<IDataReader> processor = (dataReader) => MarsRepository.process(maxCells, readdata, dataReader);
                MarsRepository.runSqlDataReader(connString, query, 400, CommandType.Text, sqlParams, processor);


                //Assert
                Assert.AreEqual(11,d.Count());
            }
        }
    }
}
