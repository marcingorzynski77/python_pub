﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mrap.Mars.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mrap.Mars.CommonTests
{
    [TestClass]
    public class HierarchyEnumQueryTests
    {
        [TestClass]
        public class whenCalled_withHierarhcyAsRandom
        {
            [TestMethod]
            public void shouldMapContextHierarchyToDefaultOfficial()
            {
                //TODO: AAAHHHH magic numbers. To Enum please.
                var db = new Mock<IMarsDb>();

                //Act
                var sut = HierarchyEnumQuery.Default(db.Object, "54");

                var queryString = sut.queryString;

                Assert.IsTrue(queryString.Contains("'Official'"));

            }
        }
        [TestClass]
        public class whenCalled_withHierarhcyBlank
        {
            [TestMethod]
            public void shouldMapContextHierarchyToDefaultOfficial()
            {
                //TODO: AAAHHHH magic numbers. To Enum please.
                var db = new Mock<IMarsDb>();

                //Act
                var sut = HierarchyEnumQuery.Default(db.Object, "");

                var queryString = sut.queryString;

                Assert.IsTrue(queryString.Contains("'Official'"));

            }
        }
        [TestClass]
        public class whenCalled_withHierarhcy0
        {
            [TestMethod]
            public void shouldMapContextHierarchyToOfficial()
            {
                //TODO: AAAHHHH magic numbers. To Enum please.
                var db = new Mock<IMarsDb>();

                //Act
                var sut = HierarchyEnumQuery.Default(db.Object, "0");

                var queryString = sut.queryString;

                Assert.IsTrue(queryString.Contains("'Official'"));

            }
        }
        [TestClass]
        public class whenCalled_withHierarhcy1
        {
            [TestMethod]
            public void shouldGetKnownHierarchyAdhoc()
            {
                var db = new Mock<IMarsDb>();
                var hierarchy = "1";

                //Act
                var sut = HierarchyEnumQuery.Default(db.Object, hierarchy);

                var queryString = sut.queryString;

                Assert.IsTrue(queryString.Contains("'Adhoc'"));

            }
        }
    }
}
