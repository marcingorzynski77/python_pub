﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using static System.Configuration.ConfigurationManager;
using System.Linq;
using Mrap.Common.Util;


namespace Mrap.Mars.Service
{
    [RunInstaller(true)]
    public partial class ServiceInstaller : ProjectInstaller
    {
        public ServiceInstaller()
        {
            InitializeComponent();
            var serviceName = AppSettings["ServiceName"];
            var displayName = serviceName.Replace('.', ' ');
            this.serviceInstaller.ServiceName = $"{serviceName}";
            this.serviceInstaller.Description = $"{displayName}";
            this.serviceInstaller.DisplayName = $"{displayName}";
        }
    }
}
