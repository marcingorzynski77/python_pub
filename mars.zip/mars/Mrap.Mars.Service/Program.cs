﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mrap.Common.Util.Service;

namespace Mrap.Mars.Service
{
    class Program
    {
        static void Main(string[] args)
        {
            Host.SetUpHost(new ApplicationService { ApplicationName = "Mars" });

            Host.Start(args);
        }
    }
}
