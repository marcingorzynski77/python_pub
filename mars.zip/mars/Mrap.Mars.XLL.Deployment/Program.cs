﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using log4net;

namespace Mrap.Mars.XLL.Deployment
{
    class Program
    {
        private static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);

        private const string AddIn = "Mrap.Mars.XLL.Ribbon-AddIn.xll";
        private const string AddInPacked = "Mrap.Mars.XLL.Ribbon-AddIn-packed.xll";
        private const string AddIn64 = "Mrap.Mars.XLL.Ribbon-AddIn64.xll";
        private const string AddIn64Packed = "Mrap.Mars.XLL.Ribbon-AddIn64-packed.xll";
        private const string MarsVBA = "Mrap.Mars.XLL.VBA.xlam";
        private const string Config = "Mrap.Mars.XLL.Ribbon-AddIn.xll.config";

        private static string Destination { get; set; }

        static void Main(string[] args)
        {
            try
            {
                log.InfoFormat("*** Starting Mars XLL Deployment ***");

                string logFilePath = AppDomain.CurrentDomain.BaseDirectory + "\\log4net.config";
                var finfo = new FileInfo(logFilePath);
                log4net.Config.XmlConfigurator.ConfigureAndWatch(finfo);

                log.InfoFormat($"** Connected user: {Environment.UserName} from {Environment.MachineName} machine");

                var pathWithEnv = ConfigurationManager.AppSettings["AddInSource"];
                Destination = Environment.ExpandEnvironmentVariables(pathWithEnv);
                log.InfoFormat($"** Destination resolved to: {Destination}");
                OpenExcelWorkBook();
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
           
        }

        private static void OpenExcelWorkBook()
        {
            if ( !(Prepare(AddInPacked) &&
                Prepare(AddIn64Packed) &&
                Prepare(MarsVBA)))
            {
                Console.WriteLine("There were errors detected please make sure that all your excel workbooks are closed and try again !");
                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
                return;
            }

            Prepare(Config);

            var task = Task.Factory.StartNew(
                  () =>
                  {
                      var process = new System.Diagnostics.Process
                      {
                          StartInfo =
                          {
                              FileName = Path.Combine(Directory.GetCurrentDirectory(), "Registration.xlsm" ),
                              Verb = "Open",
                              WindowStyle = System.Diagnostics.ProcessWindowStyle.Maximized
                          }
                      };
                      process.Start();
                  });

            task.Wait();
        }

        private static bool Prepare(string xllAddin)
        {
            var xll = Path.Combine(Directory.GetCurrentDirectory(), xllAddin);

            log.InfoFormat($"Checking {xll}");
            // copy files
            if (File.Exists(xll))
            {
                var dest = Path.Combine(Destination, xllAddin);

                if (File.Exists(dest))
                {
                    log.InfoFormat($"Deleting old file {xllAddin}");
                    try
                    {
                        File.Delete(dest);
                    }
                    catch (Exception ex)
                    {
                        log.Error(ex);
                        return false;
                    }
                }
                log.InfoFormat($"Copying file {xllAddin} to {dest}");
                File.Copy(xll, dest);
            }
            else
            {
                log.Error("File not found " + xll);
                return false;
            }

            return true;
        }
    }
}
