# Create a ClickOnce package, based on program binaries.

function New-ClickOncePackage {
    param($app_name, $version, $output_dir, $cert, $deployment_url, $mageExe, $dnaPackage, $rootFolder) 
    $files = $args[0]

    Write-Host "App Name: $app_name"
    Write-Host "Version: $version"
    Write-Host "Output_Dir: $output_dir"
    Write-Host "Cert: $cert"
    Write-Host "Deployment url: $deployment_url"
    Write-Host "Mage path: $mageExe"
	Write-Host "Dna Package path: $dnaPackage"
	Write-Host "Root: $rootFolder"
    
    $version_dir = "$output_dir\$app_name_$($version.Replace(".", "_"))"
    mkdir $version_dir
    $relative_version_dir = [System.IO.Path]::GetFileName($version_dir)
	
	Write-Host "Version Dir: $version_dir"
	Write-Host "Relative Version Dir: $relative_version_dir"

    #Copy files into the output folder and generate the .manifest and .application files.
    Copy-Item $files -Destination $version_dir

	
	$arg1="$rootFolder\Mrap.Mars.XLL.Ribbon-AddIn.dna"
	$arg2='/Y'

	Write-Output "Arguments $arg1 $arg2"

	$ps = new-object System.Diagnostics.Process
	$ps.StartInfo.Filename = $dnaPackage
	$ps.StartInfo.Arguments = "$arg1 $arg2"
	$ps.StartInfo.RedirectStandardOutput = $True
	$ps.StartInfo.UseShellExecute = $false
	#$ps.start()
	#$ps.WaitForExit()
	#[string] $out = $ps.StandardOutput.ReadToEnd();

	#Write-Output $out


    & $mageExe -New Application -ToFile "$version_dir\$app_name.exe.manifest" -Name $app_name -Version $version -Processor msil -FromDirectory $version_dir -TrustLevel FullTrust
    & $mageExe -New Deployment -Install false -Publisher "Lloyds" -ToFile "$output_dir\$app_name.application" -Name $app_name -Version $version -Processor msil -AppManifest "$version_dir\$app_name.exe.manifest" -AppCodeBase "$relative_version_dir\$app_name.exe.manifest" -IncludeProviderURL false -ProviderURL "$deployment_url/$app_name.application"

    #Append .deploy to files for web server deployment, then re-sign the manifest. No idea why mage can't do this.
    Get-ChildItem $version_dir | Foreach-Object { if (-not $_.FullName.EndsWith(".manifest")) { Rename-Item $_.FullName "$($_.FullName).deploy" } } 
    #& $mageExe -Sign "$version_dir\$app_name.exe.manifest" -CertFile $cert

    #Set parameters in deployment xml, then re-sign the deployment. Why can't we do this from the command line, Microsoft?
    $xml = [xml](Get-Content "$output_dir\$app_name.application")
    $deployment_node = $xml.SelectSingleNode("//*[local-name() = 'deployment']")
    #$deployment_node.SetAttribute("minimumRequiredVersion", $version)
    $deployment_node.SetAttribute("mapFileExtensions", "true")
    $xml.Save("$output_dir\$app_name.application")
    #& $mageExe -Sign "$output_dir\$app_name.application" -CertFile $cert
}

function Get-AssemblyVersion{
    param($file)
    return [System.Diagnostics.FileVersionInfo]::GetVersionInfo($file).FileVersion
}

function New-PublishHtm{
    param($version, $template, $output_dir)
	Write-Host "Version: $version"
	Write-Host "Output_Dir: $output_dir"
    Get-Content "$template\publish_template.htm" | % {$_.Replace('#Version#',$version)} | Out-File "$output_dir\publish.htm"
}

Export-ModuleMember -function * -alias *
Write-Host 'Imported deployModule.psm1'
