$mageExe="C:\Development\mars\Mrap.Mars.XLL.Deployment\deploy\mage.exe"
$dnaExe="C:\Development\mars\Mrap.Mars.XLL.Deployment\tools\ExcelDnaPack.exe"

#& $mageExe -New Application

& $dnaExe -New Application