$mageExe="C:\Development\mars\Mrap.Mars.XLL.Deployment\deploy\mage.exe"
$dnaExe="C:\Development\mars\Mrap.Mars.XLL.Deployment\tools\ExcelDnaPack.exe"

$arg1="C:\Development\mars\Mrap.Mars.XLL.Deployment\bin\Debug\Mrap.Mars.XLL.Ribbon-AddIn.dna"
$arg2='/Y'

$output = cmd /c $dnaExe $arg1 $arg2 2`>`&1

#[Diagnostics.Process]::Start($dnaExe,$arg1, $arg2)

$ps = new-object System.Diagnostics.Process
$ps.StartInfo.Filename = $dnaExe
$ps.StartInfo.Arguments = "$arg1 $arg2"
$ps.StartInfo.RedirectStandardOutput = $True
$ps.StartInfo.UseShellExecute = $false
$ps.start()
$ps.WaitForExit()
[string] $Out = $ps.StandardOutput.ReadToEnd();

#& "C:\Development\mars\Mrap.Mars.XLL.Deployment\tools\ExcelDnaPack.exe C:\Development\mars\Mrap.Mars.XLL.Deployment\bin\Debug\Mrap.Mars.XLL.Ribbon-AddIn.dna"

#$output = & $dnaExe $args

#Write-Output $output
Write-Output $Out
#& $mageExe -New Application

#& $dnaExe /DNAPATH=$config