﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using Mrap.Limits.DataAccess;
using Mrap.Limits.Domain;
using Mrap.Limits.Domain.DTO;
using Mrap.Mars.Common;
using Mrap.Mars.XLL.Limit.ViewModels;

namespace Mrap.Mars.XLL.Limit
{
    public class LimitRepository
    {
        private static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);
        public List<LimitViewModel> Get()
        {
            return Get(null);
        }

        public List<LimitViewModel> Get(int? riskNodeId)
        {
            var limitDate = Context.GetLimitEffectiveDate();
            var busdate = Context.GetTiemTRavelDateTime();
            log.Info($"Getting limits for bus date {busdate}, limit date {limitDate}");
            var repository = new LimitNavigationRepository(new LimitsContext(Environment.UserName, WorkbookContext.GetContextValue(Context.DbLimits), busdate));

            var limits = repository.LimitHierarchyForActiveNodes(riskNodeId, limitDate).Select(x => new LimitViewModel
            {
                Name = x.Name,
                LimitName = x.LimitDetail?.Limit.LimitNode.LimitNodeDetail.Name,
                LimitCategory = x.LimitDetail?.Limit.LimitCategory?.Name,
                UniqueId = x.UniqueId,
                ParentUniqueId = x.ParentUniqueId,
                Value = x.Value,
                Type = x.Type.ToString(),
                DisplayStatus = x.DisplayStatus,
                IsOverride = x.LimitDetail?.IsOverride ?? false,
                Priority = x.LimitCategory?.Priority ?? null,
                RiskNodeId = x.RiskNodeId,
                Path = x.Path,
                LimitId = x.LimitDetail?.LimitId.ToString() ?? String.Empty,
                RiskMeasureName = x.LimitDetail?.Limit.LimitNode.LimitNodeDetail.RiskMeasureType.RiskMeasureTypeDetail.Name,
            });

            var limitViewModels = limits as LimitViewModel[] ?? limits.ToArray();
            foreach (var limit in limitViewModels)
            {
                var pathArray = limit.Path.Split(new char[] {'/'});
                limit.HierarchyNodeName = pathArray[pathArray.Length - 2];
                limit.Path = NormalizePath(limit.Path);
                limit.FullPath = String.Concat(NormalizePathSeperator(limit.Path), NormalizePathSeperator(limit.RiskMeasureName), NormalizePathSeperator(limit.LimitName), NormalizePathSeperator(limit.LimitCategory));
            }

            return limitViewModels.ToList();
        }

        private static readonly char[] ForwardSlash = new char[] {'/'};
        public static string NormalizePath(string path)
        {
            string result = path;
            if (result.StartsWith("/"))
            {
                result = result.TrimStart(ForwardSlash);
            }

            if (result.EndsWith("/"))
            {
                result = result.TrimEnd(ForwardSlash);
            }
            return result;
        }

        public static string NormalizePathSeperator(string item)
        {
            if (!String.IsNullOrEmpty(item))
            {
                if (!item.EndsWith("/"))
                {
                    return String.Concat(item, "/");
                }
            }
            return item;
        }

        //private class LimitViewModelComparer : IComparer<LimitViewModel>
        //{
        //    public int Compare(LimitViewModel current, LimitViewModel other)
        //    {
        //        int result;

        //        //compare against null object
        //        if (other == null)
        //            return 1;

        //        //compare against null object
        //        if (other == null)
        //            return 1;

        //        //compare risk factor dim type
        //        if ((other.Type == LimitModel.ModelType.RiskHierarchyNode.ToString()) && (current.Type != null))
        //            return 1;

        //        if ((current.RiskFactorDimItem == null) && (other.RiskFactorDimItem != null))
        //            return -1;

        //        if ((current.RiskFactorDimItem != null) && (other.RiskFactorDimItem != null))
        //            result = current.RiskFactorDimItem.RiskFactorDimTypeID.CompareTo(other.RiskFactorDimItem.RiskFactorDimTypeID);
        //        else
        //            result = 0;

        //        //compare ordinals
        //        if ((other.CalculatedOrdinal == null) && (current.CalculatedOrdinal != null))
        //            return 1;

        //        if ((current.CalculatedOrdinal == null) && (other.CalculatedOrdinal != null))
        //            return -1;

        //        if ((current.CalculatedOrdinal != null) && (other.CalculatedOrdinal != null))
        //            result = current.CalculatedOrdinal.Value.CompareTo(other.CalculatedOrdinal.Value);
        //        else
        //            result = 0;

        //        if (result != 0)
        //            return result;

        //        //return comparison of names
        //        return current.Name.CompareTo(other.Name);
        //    }
        //}
    }
}
