﻿using System;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm;

namespace Mrap.Mars.XLL.Limit.ViewModels
{
    [POCOViewModel]
    public class LimitViewModel
    {
        public string Name { get; set; }

        public string LimitName { get; set; }

        public string LimitCategory { get; set; }
        public int UniqueId { get; set; }
        public int? ParentUniqueId { get; set; }
        public decimal? Value { get; set; }

        public string DisplayStatus { get; set; }
        public string Type { get; set; }

        public int? Priority { get; set; }
        public bool IsOverride { get; set; }

        public int? RiskNodeId { get; set; }
        public string Path { get; set; }

        public string LimitId { get; set; }

        public string RiskMeasureName { get; set; }
        public string HierarchyNodeName { get; set; }
        public string FullPath { get; set; }

    }
}