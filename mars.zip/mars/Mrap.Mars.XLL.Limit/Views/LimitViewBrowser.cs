﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using DevExpress.Data.Filtering;
using DevExpress.XtraEditors;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using ExcelDna.Integration;
using log4net;
using Mrap.Limits.DataAccess;
using Mrap.Limits.Domain;
using Mrap.Limits.Domain.DTO;
using Mrap.Mars.Common;
using Mrap.Mars.XLL.Limit.ViewModels;


namespace Mrap.Mars.XLL.Limit.Views
{
    public partial class LimitViewBrowser : DevExpress.XtraEditors.XtraUserControl
    {
        private const string RiskHierarchyNode = "RiskHierarchyNode";
        private const string RiskMeasure = "RiskMeasure";
        private const string LimitNameConst = "LimitName";
        private const string Limit = "Limit";
        private static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);

        public XtraForm Window { get; set; }

        public LimitViewBrowser()
        {
            InitializeComponent();
        }

        public void Initialize()
        {
            var limits = Context.GetLimitCache() as List<LimitViewModel>;
            if (limits == null)
            {
                limits = new LimitRepository().Get();
                Context.SetLimitCache(limits);
            }

            //treeList.FilterNode += TreeListView_OnCustomNodeFilter;
            treeList.KeyDown += TreeList_KeyDown;
            treeList.ParentFieldName = "ParentUniqueId";
            treeList.KeyFieldName = "UniqueId";
            treeList.DataSource = limits;
            treeList.ForceInitialize();
            treeList.ExpandAll();
            treeList.BestFitColumns();
        }

        private void TreeList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.C)
            {
                TreeList treeList = (TreeList)sender;
                Clipboard.SetText(treeList.FocusedNode.GetDisplayText(treeList.FocusedColumn));
                e.Handled = true;
            }
        }

        //private void TreeListView_OnCustomNodeFilter(object sender, FilterNodeEventArgs e)
        //{
        //    CriteriaOperator filter = ((TreeList)sender).ActiveFilterCriteria;
        //    if (ReferenceEquals(filter, null))
        //    {
        //        e.Node.Visible = true;
        //        e.Handled = true;
        //        return;
        //    }
        //    if (IsNodeVisible(e.Node, filter) || IsChildNodeVisible(e.Node, filter))
        //    {
        //        MakeNodeVisible(e.Node);
        //        e.Node.Visible = true;
        //    }
        //    else
        //    {
        //        e.Node.Visible = false;
        //        if (e.Node != null &&
        //           e.Node.GetValue("Type") == LimitModel.ModelType.RiskMeasure.ToString()) 
        //        {
        //            // if all childs are hidden then show everything underneath 
        //            if (IsNodeVisible(e.Node, filter))
        //                e.Node.Visible = true; // make this node visible
        //        }
        //        else if (e.Node != null &&
        //            e.Node.GetValue("Type") == LimitModel.ModelType.LimitName.ToString()) 
        //        {
        //            // if all childs are hidden then show everything underneath 
        //            if (IsNodeVisible(e.Node.ParentNode, filter))
        //                e.Node.Visible = true;  
        //        }
        //    }
        //    e.Handled = true;
        //}
        //public bool IsChildNodeVisible(TreeListNode node, CriteriaOperator filter)
        //{
        //    foreach (TreeListNode n in node.Nodes)
        //    {
        //        if (IsNodeVisible(n, filter))
        //        {
        //            return true;
        //        }
        //        else if (IsChildNodeVisible(n, filter))
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        //public bool IsNodeVisible(TreeListNode node, CriteriaOperator filter)
        //{
        //    foreach (TreeListColumn col in node.TreeList.Columns)
        //    {
        //       var column = node.GetValue(col);
        //        if (column != null && column.ToString().Contains(filter.ToString()))
        //            return true;
        //    }

        //    return false;
        //    //DevExpress.Data.Filtering.Helpers.ExpressionEvaluator ee = new DevExpress.Data.Filtering.Helpers.ExpressionEvaluator(TypeDescriptor.GetProperties(node.Content.GetType()), filter, false);
        //    // return ee.Fit(node);
        //    //return true
        //}
        //public void MakeNodeVisible(TreeListNode node)
        //{
        //    if (node.ParentNode == null)
        //        return;
        //    node.ParentNode.Expanded = true;
        //    MakeNodeVisible(node.ParentNode);
        //}

        //private void TreeListOnFilterNode(object sender, FilterNodeEventArgs e)
        //{
        //    var node = e.Node;           

        //    var filter = ((TreeList)sender).ActiveFilterString;
        //    if (ReferenceEquals(filter, null))
        //    {
        //        e.Handled = true;
        //        return;
        //    }

        //    if (NodeContainsPattern(node, filter))
        //    {
        //        node.Visible = true;
        //        if (node.ParentNode != null)
        //            node.ParentNode.Visible = true;
        //    }
        //    else
        //        node.Visible = false;
        //}


        //bool NodeContainsPattern(TreeListNode node, string pattern)
        //{
        //    foreach (TreeListColumn col in node.TreeList.Columns)
        //        if (node.GetValue(col).ToString().Contains(pattern))
        //            return true;
        //    return false;
        //}

        private void btnClose_Click(object sender, EventArgs e)
        {
            Window.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            var limits = new LimitRepository().Get();
            Context.SetLimitCache(limits);
            //WorkbookContext.SetObject(Context.LimitCache, limits);

            Initialize();
        }

        private void treeList_GetStateImage(object sender, GetStateImageEventArgs e)
        {
            //var images = new string[] {"category-1.png",
            //                    "category-2.png",
            //                    "category-3.png",
            //                    "category-4.png",
            //                    "category-5.png",
            //                    "hierarchy-node.png",
            //                    "limit.png",
            //                    "risk-measure.png",
            //                    "sad.png",
            //                    "category-1-override.png",
            //                    "category-2-override.png",
            //                    "category-3-override.png",
            //                    "category-4-override.png",
            //                    "category-5-override.png",
            //                    "override.png" };

            var model = treeList.GetDataRecordByNode(e.Node) as LimitViewModel;

            if (model == null)
                return;

            switch (model.Type)
            {
                case RiskHierarchyNode:
                    e.NodeImageIndex = 5;
                    break;
                case RiskMeasure:
                    e.NodeImageIndex = 7;
                    break;
                case LimitNameConst:
                    e.NodeImageIndex = 6;
                    break;
                case Limit:
                    if (model.Priority != null && model.IsOverride)
                    {
                        int priority = (model.Priority.Value < 1) ? 1 : model.Priority.Value;
                        priority = (priority > 5) ? 5 : model.Priority.Value;

                        e.NodeImageIndex = 8 + priority;
                    }
                    else if (model.Priority != null && !model.IsOverride)
                    {
                        int priority = (model.Priority.Value < 1) ? 1 : model.Priority.Value;
                        priority = (priority > 5) ? 5 : model.Priority.Value;

                        e.NodeImageIndex = -1 + priority;
                    }
                    break;
                default:
                    e.NodeImageIndex = 8;
                    break;
            }

        }

        private void treeList_DoubleClick(object sender, EventArgs e)
        {
            TreeList tree = sender as TreeList;
            TreeListHitInfo hi = tree.CalcHitInfo(tree.PointToClient(Control.MousePosition));
            if (hi.Node != null)
            {
                var model = treeList.GetDataRecordByNode(hi.Node) as LimitViewModel;
                ExcelProxy p = new ExcelProxy();

                if (model != null && model.Type == RiskHierarchyNode)
                {
                    p.SetFormulaInActiveCell($"=Limit({model.RiskNodeId})");
                }
                if (model != null && model.Type == Limit)
                {
                    p.SetFormulaInActiveCell($"=SingleLimit(\"{model.Path}\",\"{model.RiskMeasureName}\",\"{model.LimitName}\",\"{model.Name}\")");
                }
            }
        }

        private void btnBringFormula_Click(object sender, EventArgs e)
        {
            List<TreeListNode> nodes = treeList.GetNodeList();
            ExcelProxy p = new ExcelProxy();

            int index = 0;
            foreach (TreeListNode node in nodes)
            {
                if (node.Visible)
                {
                    var model = treeList.GetDataRecordByNode(node) as LimitViewModel;

                    if (model != null && model.Type == Limit)
                    {
                        p.SetFormulaInActiveCell($"=SingleLimit(\"{model.Path}\",\"{model.RiskMeasureName}\",\"{model.LimitName}\",\"{model.Name}\")", index++);
                    }
                }
            }
        }
    }
}
