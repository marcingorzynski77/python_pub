﻿using DevExpress.Utils;

namespace Mrap.Mars.XLL.Limit.Views
{
    partial class LimitViewBrowser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LimitViewBrowser));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.treeList = new DevExpress.XtraTreeList.TreeList();
            this.LimitName = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.Value = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.DisplayStatus = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.Type = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.LimitId = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.FullPath = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.btnBringFormula = new DevExpress.XtraEditors.SimpleButton();
            this.btnClose = new DevExpress.XtraEditors.SimpleButton();
            this.btnRefresh = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treeList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.splitContainer1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(614, 333);
            this.panelControl1.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(2, 2);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panelControl3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panelControl2);
            this.splitContainer1.Size = new System.Drawing.Size(610, 329);
            this.splitContainer1.SplitterDistance = 302;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 0;
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.treeList);
            this.panelControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl3.Location = new System.Drawing.Point(0, 0);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(610, 302);
            this.panelControl3.TabIndex = 0;
            // 
            // treeList
            // 
            this.treeList.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.LimitName,
            this.Value,
            this.DisplayStatus,
            this.Type,
            this.LimitId,
            this.FullPath});
            this.treeList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeList.Location = new System.Drawing.Point(2, 2);
            this.treeList.Name = "treeList";
            this.treeList.OptionsBehavior.EnableFiltering = true;
            this.treeList.OptionsBehavior.ExpandNodesOnFiltering = true;
            this.treeList.OptionsBehavior.ExpandNodesOnIncrementalSearch = true;
            this.treeList.OptionsClipboard.AllowCopy = DevExpress.Utils.DefaultBoolean.True;
            this.treeList.OptionsClipboard.CopyNodeHierarchy = DevExpress.Utils.DefaultBoolean.True;
            this.treeList.OptionsFilter.FilterMode = DevExpress.XtraTreeList.FilterMode.Extended;
            this.treeList.OptionsFind.AllowFindPanel = true;
            this.treeList.OptionsFind.AlwaysVisible = true;
            this.treeList.OptionsView.EnableAppearanceOddRow = true;
            this.treeList.OptionsView.ShowAutoFilterRow = true;
            this.treeList.OptionsView.ShowSummaryFooter = true;
            this.treeList.Size = new System.Drawing.Size(606, 298);
            this.treeList.StateImageList = this.imageCollection1;
            this.treeList.TabIndex = 1;
            this.treeList.GetStateImage += new DevExpress.XtraTreeList.GetStateImageEventHandler(this.treeList_GetStateImage);
            this.treeList.DoubleClick += new System.EventHandler(this.treeList_DoubleClick);
            // 
            // LimitName
            // 
            this.LimitName.AllNodesSummary = true;
            this.LimitName.Caption = "Limit Name";
            this.LimitName.FieldName = "Name";
            this.LimitName.MinWidth = 33;
            this.LimitName.Name = "LimitName";
            this.LimitName.OptionsColumn.AllowEdit = false;
            this.LimitName.OptionsFilter.FilterPopupMode = DevExpress.XtraTreeList.FilterPopupMode.CheckedList;
            this.LimitName.SortOrder = System.Windows.Forms.SortOrder.Ascending;
            this.LimitName.SummaryFooter = DevExpress.XtraTreeList.SummaryItemType.Count;
            this.LimitName.Visible = true;
            this.LimitName.VisibleIndex = 0;
            this.LimitName.Width = 134;
            // 
            // Value
            // 
            this.Value.Caption = "Value";
            this.Value.FieldName = "Value";
            this.Value.Format.FormatString = "#,#.00";
            this.Value.Format.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.Value.MinWidth = 33;
            this.Value.Name = "Value";
            this.Value.OptionsColumn.AllowEdit = false;
            // 
            // DisplayStatus
            // 
            this.DisplayStatus.Caption = "Status";
            this.DisplayStatus.FieldName = "DisplayStatus";
            this.DisplayStatus.Name = "DisplayStatus";
            this.DisplayStatus.OptionsColumn.AllowEdit = false;
            // 
            // Type
            // 
            this.Type.Caption = "Type";
            this.Type.FieldName = "Type";
            this.Type.Name = "Type";
            this.Type.OptionsColumn.AllowEdit = false;
            // 
            // LimitId
            // 
            this.LimitId.Caption = "LimitId";
            this.LimitId.FieldName = "LimitId";
            this.LimitId.Name = "LimitId";
            this.LimitId.OptionsColumn.AllowEdit = false;
            // 
            // FullPath
            // 
            this.FullPath.Caption = "Path";
            this.FullPath.FieldName = "FullPath";
            this.FullPath.Name = "FullPath";
            this.FullPath.OptionsColumn.AllowEdit = false;
            this.FullPath.Visible = true;
            this.FullPath.VisibleIndex = 1;
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "category-1.png");
            this.imageCollection1.Images.SetKeyName(1, "category-2.png");
            this.imageCollection1.Images.SetKeyName(2, "category-3.png");
            this.imageCollection1.Images.SetKeyName(3, "category-4.png");
            this.imageCollection1.Images.SetKeyName(4, "category-5.png");
            this.imageCollection1.Images.SetKeyName(5, "hierarchy-node.png");
            this.imageCollection1.Images.SetKeyName(6, "limit.png");
            this.imageCollection1.Images.SetKeyName(7, "risk-measure.png");
            this.imageCollection1.Images.SetKeyName(8, "sad.png");
            this.imageCollection1.Images.SetKeyName(9, "category-1-override.png");
            this.imageCollection1.Images.SetKeyName(10, "category-2-override.png");
            this.imageCollection1.Images.SetKeyName(11, "category-3-override.png");
            this.imageCollection1.Images.SetKeyName(12, "category-4-override.png");
            this.imageCollection1.Images.SetKeyName(13, "category-5-override.png");
            this.imageCollection1.Images.SetKeyName(14, "override.png");
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.btnBringFormula);
            this.panelControl2.Controls.Add(this.btnClose);
            this.panelControl2.Controls.Add(this.btnRefresh);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl2.Location = new System.Drawing.Point(0, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(610, 26);
            this.panelControl2.TabIndex = 0;
            // 
            // btnBringFormula
            // 
            this.btnBringFormula.Location = new System.Drawing.Point(181, 3);
            this.btnBringFormula.Name = "btnBringFormula";
            this.btnBringFormula.Size = new System.Drawing.Size(133, 26);
            this.btnBringFormula.TabIndex = 4;
            this.btnBringFormula.Text = "Export Search Results";
            this.btnBringFormula.Click += new System.EventHandler(this.btnBringFormula_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(86, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(89, 26);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(5, 3);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 26);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // LimitViewBrowser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelControl1);
            this.Name = "LimitViewBrowser";
            this.Size = new System.Drawing.Size(614, 333);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.treeList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton btnClose;
        private DevExpress.XtraEditors.SimpleButton btnRefresh;
        private DevExpress.XtraTreeList.TreeList treeList;
        private DevExpress.XtraTreeList.Columns.TreeListColumn LimitName;
        private DevExpress.XtraTreeList.Columns.TreeListColumn Value;
        private DevExpress.XtraTreeList.Columns.TreeListColumn DisplayStatus;
        private DevExpress.XtraTreeList.Columns.TreeListColumn Type;
        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn LimitId;
        private DevExpress.XtraTreeList.Columns.TreeListColumn FullPath;
        private DevExpress.XtraEditors.SimpleButton btnBringFormula;
    }
}
