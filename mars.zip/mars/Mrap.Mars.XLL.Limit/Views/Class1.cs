﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraTreeList.Nodes.Operations;

namespace Mrap.Mars.XLL.Limit.Views
{
    public class FilterNodeOperation : TreeListOperation
    {
        string pattern;
        TreeListColumn col;
        List<TreeListNode> visNodes;


        /// <summary>
        /// Initializes a new instance of the <see cref="FilterNodeOperation"/> class.
        /// </summary>
        /// <param name="_pattern">The _pattern.</param>
        /// <param name="_column">The _column.</param>
        /// by mishu at 9/4/2012 3:31 PM
        public FilterNodeOperation(string _pattern, TreeListColumn _column)
        {
            pattern = _pattern;
            col = _column;
            visNodes = new List<TreeListNode>();
        }


        /// <summary>
        /// Gets the visible nodes.
        /// </summary>
        /// by mishu at 9/4/2012 3:31 PM
        public List<TreeListNode> VisibleNodes
        {
            get { return visNodes; }
        }


        /// <summary>
        /// Must be implemented to perform an operation on the visited node.
        /// </summary>
        /// <param name="node">A <see cref="T:DevExpress.XtraTreeList.Nodes.TreeListNode"/> object representing the node against which the operation is to be performed.</param>
        /// by mishu at 9/4/2012 3:32 PM
        public override void Execute(TreeListNode node)
        {
            if (NodeContainsPattern(node, pattern))
            {
                node.Visible = true;
                if (node.ParentNode != null)
                {
                    node.ParentNode.Visible = true;
                    if (!visNodes.Contains(node.ParentNode))
                        visNodes.Add(node.ParentNode);
                    node.ParentNode.ExpandAll();
                    TreeListNode n = node.ParentNode;
                    while (n != null)
                    {
                        n.Visible = true;
                        if (!visNodes.Contains(n))
                            visNodes.Add(n);
                        n = n.ParentNode;
                    }
                }
                if (node.HasChildren)
                {
                    foreach (TreeListNode child in node.Nodes)
                    {
                        child.Visible = true;
                        if (!visNodes.Contains(child))
                            visNodes.Add(child);
                    }
                }
            }
            else
                node.Visible = false;
        }


        /// <summary>
        /// Nodes the contains pattern.
        /// </summary>
        /// <param name="node">The node.</param>
        /// <param name="pattern">The pattern.</param>
        /// <returns></returns>
        /// by mishu at 9/4/2012 3:32 PM
        bool NodeContainsPattern(TreeListNode node, string pattern)
        {
            if (node.GetValue(col).ToString().ToLowerInvariant().Contains(pattern.ToLowerInvariant()) || visNodes.Contains(node))
                return true;
            return false;
        }
    }
}
