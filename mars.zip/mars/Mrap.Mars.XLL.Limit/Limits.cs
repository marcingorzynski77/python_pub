﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.Skins;
using DevExpress.LookAndFeel;
using DevExpress.UserSkins;


namespace Mrap.Mars.XLL.Limit
{
    public partial class Limits : XtraForm
    {
        public Limits()
        {
            InitializeComponent();
            this.limitBrowser.Window = this;
            this.limitBrowser.Initialize();
        }
    }
}