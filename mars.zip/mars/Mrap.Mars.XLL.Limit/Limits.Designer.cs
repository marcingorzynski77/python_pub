﻿namespace Mrap.Mars.XLL.Limit
{
    partial class Limits
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Limits));
            this.limitBrowser = new Mrap.Mars.XLL.Limit.Views.LimitViewBrowser();
            this.SuspendLayout();
            // 
            // limitBrowser
            // 
            this.limitBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.limitBrowser.Location = new System.Drawing.Point(0, 0);
            this.limitBrowser.Name = "limitBrowser";
            this.limitBrowser.Size = new System.Drawing.Size(1100, 700);
            this.limitBrowser.TabIndex = 0;
            this.limitBrowser.Window = null;
            // 
            // Limits
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 700);
            this.Controls.Add(this.limitBrowser);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Limits";
            this.Text = "Limit  Browser";
            this.ResumeLayout(false);

        }

        #endregion

        private Views.LimitViewBrowser limitBrowser;
    }
}
