﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mrap.Mars.Common;

namespace Mrap.Mars.XLL.Limit
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            WorkbookContext.CreateContextItem(Context.DbLimits,
                ConfigurationManager.ConnectionStrings["Limits"].ConnectionString);
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Limits());
        }
    }
}
