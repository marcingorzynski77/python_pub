﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mrap.Mars.Domain
{
    public class MarsRepository
    {
        //public ObservableCollection<RiskFactorTypeDetail> RiskFactorTypeDetails()
        //{
        //    List<RiskFactorTypeDetail> list;
        //    if (Context.ReadOnlyView)
        //    {
        //        list = Context.RiskFactorTypeDetails
        //               .Include("RiskFactorType")
        //               .Include("RiskFactorType.RiskFactorTypeDimensions")
        //               .Include("RiskFactorType.RiskFactorTypeDimensions.RiskFactorDimension")
        //               .Where(t => t.RiskFactorType.IsSystem == false).ToList().ReadyToConsume();
        //    }
        //    else
        //    {
        //        list = Context.RiskFactorTypeDetails
        //                  .Include("RiskFactorType")
        //                  .Include("RiskFactorType.RiskFactorTypeDimensions")
        //                  .Include("RiskFactorType.RiskFactorTypeDimensions.RiskFactorDimension")
        //                  .Where(t => t.Latest && t.RiskFactorType.IsSystem == false).ToList().ReadyToConsume();
        //    }
        //    return new ObservableCollection<RiskFactorTypeDetail>(list.OrderBy(f => f.Name));
        //}
    }
}
