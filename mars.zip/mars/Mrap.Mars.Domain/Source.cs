namespace Mrap.Mars.Domain
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    
    [Serializable]
    [Table("Source", Schema="target")]
    public class Source : MarsBase
    {

        [Key]
        public long SourceKey { get; set; }
      
        public string InterfaceName { get; set; }
        public string Environment { get; set; }
        [Column("Source")]
        public string DataSource { get; set; }
        public string Origin { get; set; }
        public string AppliedRules { get; set; }
    }
}
