namespace Mrap.Mars.Domain
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Linq;

    using Common.Validation;

    [Table("FlexFact", Schema = "target")]
    [Serializable]
    public class FlexFact : MarsBase
    {
        private ICollection<FlexFactInstance> _taxonomyFactInstance;

        [Key]
        public long FactKey { get; set; }

        public long FlexFactHierarchyKey { get; set; }

        [ForeignKey("FlexFactHierarchyKey"), InverseProperty("FlexFacts")]
        public virtual FlexFactHierarchy FlexFactHierarchy { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<FlexFactInstance> FlexFactInstances
        {
            get
            {
                return _taxonomyFactInstance ?? (_taxonomyFactInstance = new HashSet<FlexFactInstance>());
            }
            set
            {
                _taxonomyFactInstance = value;
            }
        }

        public long? RiskFactorKey { get; set; }
        public long? RiskFactorTypeKey { get; set; }
        public long? RiskMeasureTypeKey { get; set; }
        public long? ScenarioHierarchyKey { get; set; }
        public long? HierarchyKey { get; set; }
        public long? InstrumentKey { get; set; }
        public long? InstrumentTypeKey { get; set; }
        public long? LimitsKey { get; set; }
        public long? SourceKey { get; set; }
        public long? TenorKey { get; set; }

        public DateTime BusDate { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]

        public string Representation => $"FactKey <{FactKey}>";

    }
}
