using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Validation;
using System.Text;
using EntityFramework.DynamicFilters;
using log4net;

namespace Mrap.Mars.Domain
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Linq;

    using Common.Validation;


    public partial class MarsDbContext : DbContext
    {
        public static DateTime EndDate = new DateTime(9999,12,31);
        private static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);
        public const string AsOfFilter = "AsOfFilter";
        private DateTime? AsOfDate;

        public MarsDbContext(string connection, DateTime? asOfDate) : base(connection)
        {
            AsOfDate = asOfDate;
            if(AsOfDate == null)
                AsOfDate = DateTime.UtcNow;
            SetCommandTimeout();
        }

        private void SetCommandTimeout()
        {
#if DEBUG
            this.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);
#endif

            // Get the ObjectContext related to this DbContext
            var objectContext = this.Database;

            var commandTimeout = ConfigurationManager.AppSettings["CommandTimeout"];
            if (!String.IsNullOrEmpty(commandTimeout))
            {
                objectContext.CommandTimeout = int.Parse(commandTimeout);
            }
            else
            {
                // Sets the command timeout for all the commands
                objectContext.CommandTimeout = 180;
            }
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //default schema - core
            modelBuilder.HasDefaultSchema("target");
            //We use only singular form for table names
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            //We do not delete, so it is safe to remove - convention creates problems with ScenarioUnit
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();

            //default date time is datetime2 to be compatible with .NET
            modelBuilder.Properties<DateTime>()
                .Configure(config => config.HasColumnType("datetime2"));

            //default string type is varchar, so unicode is not supported
            modelBuilder.Properties<String>()
                .Configure(config => config.HasColumnType("varchar"));

            //filter for the given date data - always on
            modelBuilder.Filter(AsOfFilter, (MarsBase ta, DateTime dt) => (ta.Finish > dt && ta.Start <= dt), AsOfDate.Value);
        }

        public override int SaveChanges()
        {
            try
            {
                return base.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                var sb = new StringBuilder();
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    sb.AppendFormat("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:", validationErrors.Entry.Entity.GetType().Name, validationErrors.Entry.State);
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        sb.AppendFormat("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                log.Error(sb.ToString());
                throw;
            }
        }

        public virtual DbSet<Hierarchy> Hierarchy { get; set; }
        public virtual DbSet<FlexFact> FlexFact { get; set; }
        public virtual DbSet<FlexFactHierarchy> FlexFactHierarchy { get; set; }
        public virtual DbSet<FlexFactInstance> FlexFactInstance { get; set; }

        public virtual DbSet<Source> Source { get; set; }

        public virtual DbSet<RiskMeasureType> RiskMeasureType { get; set; }
    }
}
