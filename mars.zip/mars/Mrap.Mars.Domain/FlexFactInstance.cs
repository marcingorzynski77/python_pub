namespace Mrap.Mars.Domain
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Linq;

    using Common.Validation;

    [Table("FlexFactInstance", Schema = "target")]
    [Serializable]
    public class FlexFactInstance
    {
        [Key]
        public long FlexFactInstanceKey { get; set; }

        public long FactKey { get; set; }

        [ForeignKey("FlexFactInstanceKey"), InverseProperty("FlexFactInstances")]
        public virtual FlexFact FlexFact { get; set; }

        public string Key { get; set; }
        public string Value { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]

        public string Representation => $"FactKey <{FlexFactInstanceKey}>";

    }
}
