namespace Mrap.Mars.Domain
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("FlexFactHierarchy", Schema = "target")]
    [Serializable]
    public class FlexFactHierarchy : MarsBase
    {
        private ICollection<FlexFactHierarchy> _flexFactHierarchyChildren;
        private ICollection<FlexFact> _flexFacts;

        [Key]
        public long FlexFactHierarchyKey { get; set; }

        public long? ParentFlexFactHierarchyKey { get; set; }

        public string Description { get; set; }

        public string Name { get; set; }

        [ForeignKey("ParentFlexFactHierarchyKey"), InverseProperty("FlexFactHierarchyChildren")]
        public FlexFactHierarchy ParentFlexFactHierarchy { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<FlexFactHierarchy> FlexFactHierarchyChildren
        {
            get
            {
                return _flexFactHierarchyChildren ?? (_flexFactHierarchyChildren = new HashSet<FlexFactHierarchy>());
            }
            set
            {
                _flexFactHierarchyChildren = value;
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<FlexFact> FlexFacts
        {
            get
            {
                return _flexFacts ?? (_flexFacts = new HashSet<FlexFact>());
            }
            set
            {
                _flexFacts = value;
            }
        }

        public string Representation => $"TaxonomyKey <{FlexFactHierarchyKey}>";
    }
}
