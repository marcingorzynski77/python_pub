﻿namespace Mrap.Mars.Domain
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Serializable]
    [Table("RiskMeasureType", Schema = "target")]
    public class RiskMeasureType : MarsBase
    {

        [Key]
        public long RiskMeasureTypeKey { get; set; }
        [Required,StringLength(255)]
        public string RiskMeasureTypeName { get; set; }
        [Required, StringLength(255)]
        public string RiskMeasureFamily { get; set; }
        public long SourceKey { get; set; }
        public string AppliedRules { get; set; }
    }
}
