namespace Mrap.Mars.Domain
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Linq;

    using Common.Validation;

    [Serializable]
    public partial class Hierarchy : MarsBase
    {
        [Key]
        public long HierarchyKey { get; set; }
        public long? NodeId { get; set; }
        public long? NodeParentID { get; set; }
        public string NodeName { get; set; }
        public string NodeType { get; set; }
        public long SourceKey { get; set; }
        public string BookLegalEntity { get; set; }
        public bool? BookCad2 { get; set; }
        public int? Ordinality { get; set; }
        public bool? Reporting { get; set; }
        public bool? Trading { get; set; }
        public string Group { get; set; }
        public string Business { get; set; }
        public string BusinessArea { get; set; }
        public string Division { get; set; }
        public string Desk { get; set; }
        public string SubDesk { get; set; }
        public string Book { get; set; }
        public string BookSystem { get; set; }
        public string HierarchyString { get; set; }
        public string AppliedRules { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public string Representation => $"HierarchyKey <{HierarchyKey}>";
    }
}
