namespace Mrap.ScenarioVault.Domain
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;

    using Common.Validation;

    [Serializable]
    public partial class CurveDetail : TemporalAndAudit, IDataErrorInfo, IValidationItem
    {
        public static Dictionary<string, IEntityValidationRule<TemporalAndAudit>> ValidationRules = new Dictionary<string, IEntityValidationRule<TemporalAndAudit>>();

        private ICollection<CurveDimension> _CurveDimensions;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CurveDetail()
        {
        }

        static CurveDetail()
        {
            ValidationRules.Add("Curve", new ValidationRuleObjectRequired<TemporalAndAudit>("Curve is not provided"));
        }

        [Key]
        public int CurveDetailID { get; set; }

        [Required]
        public int CurveID { get; set; }

        [Required, ForeignKey("CurveID"), InverseProperty("CurveDetails")]
        public virtual Curve Curve { get; set; }

        [StringLength(255),Required]
        public string Name { get; set; }
        

        [NotMapped]
        public string ShortName
        {
            get
            {
                return Name.Split('-')[0].Trim();
            }
        }


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CurveDimension> CurveDimensions
        {
            get
            {
                return _CurveDimensions ?? (_CurveDimensions = new HashSet<CurveDimension>());
            }
            set
            {
                _CurveDimensions = value;
            }
        }
        
        public string Representation => $"CurveDetail <{CurveDetailID}: Status='{DisplayStatus}'>";

        private List<string> _properties;
        public List<string> Properties
        {
            get
            {
                if (_properties == null)
                {
                    _properties = new List<string>();
                    _properties.AddRange(ValidationRules.Keys);
                }

                return _properties;
            }
        }

        public string Error => string.Empty;

        public string this[string columnName]
        {
            get
            {
                try
                {
                    System.Windows.Controls.ValidationResult result;
                    switch (columnName)
                    {
                        case "Curve":
                            result = ValidationRules["Curve"].Validate(Curve, CultureInfo.InvariantCulture);

                            if (!result.IsValid)
                                return result.ErrorContent as String;

                            return null;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    ValidationClient.PublishError(ex);
                    return null;
                }
            }
        }

    }
}
