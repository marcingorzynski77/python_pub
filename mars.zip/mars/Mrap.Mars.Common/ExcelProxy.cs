﻿using System;
using System.Windows.Forms;
using log4net;

namespace Mrap.Mars.Common
{
    using ExcelDna.Integration;

    public class ExcelProxy
    {
        private static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);
        public void SetFormulaInActiveCell(string value)
        {
            ExcelAsyncUtil.QueueAsMacro(() =>
                {
                    ExcelReference reference = XlCall.Excel(XlCall.xlfActiveCell) as ExcelReference;
                    if (reference != null)
                    {
                        try
                        {
                            XlCall.Excel(XlCall.xlcFormulaFill, new object[] { value, reference });
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Array formula can not be placed over existing one , please clear the worksheet first", "Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            log.Error(ex);
                        }

                    }
                });
        }

        public void SetFormulaInActiveCell(string value, int index)
        {
            ExcelAsyncUtil.QueueAsMacro(() =>
            {
                ExcelReference reference = XlCall.Excel(XlCall.xlfActiveCell) as ExcelReference;
                if (reference != null)
                {
                    try
                    {
                        ExcelReference next = new ExcelReference(reference.RowFirst + index, reference.ColumnFirst);
                        XlCall.Excel(XlCall.xlcFormulaFill, new object[] { value, next });
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Array formula can not be placed over existing one , please clear the worksheet first", "Info", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        log.Error(ex);
                    }

                }
            });
        }
    }
}