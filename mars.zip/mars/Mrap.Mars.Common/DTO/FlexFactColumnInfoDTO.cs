﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mrap.Mars.Common
{
    public class FlexFactColumnInfoDTO : ColumnInfoDTO
    {
        public new static FlexFactColumnInfoDTO Default()
            => new FlexFactColumnInfoDTO();
    }
}
