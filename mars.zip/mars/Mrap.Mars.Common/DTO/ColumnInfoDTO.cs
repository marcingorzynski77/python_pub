﻿using System;
using System.Data;
using System.Diagnostics;

namespace Mrap.Mars.Common
{
    [DebuggerDisplay("Name: {Name}, Type: {Type}, ClrType: {nameof(ClrType)}")]
    public class ColumnInfoDTO : IDto
    {
        public string Name { get; set; }
        public SqlDbType SqlType { get; set; }


        /* not used : only populated and then tested */
        public string Type { get; set; }
        public Type ClrType { get; set; }
        
        public static ColumnInfoDTO Default() 
            => new ColumnInfoDTO();
    }
}
