﻿using System.Diagnostics;

namespace Mrap.Mars.Common
{
    public interface IDto { }

    [DebuggerDisplay("{name}, {baseObjectName}, {baseObjSchema}")]
    public class SynonymInfoDTO : IDto
    {
        public string Name { get; set; }
        public string baseObjectName { get ; set; }
        public string baseObjSchema { get; set; }
        
        public static SynonymInfoDTO Default() 
            => new SynonymInfoDTO();
        
    }
}
