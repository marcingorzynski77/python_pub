﻿using System;

namespace Mrap.Mars.Common.Util
{
    public static class F
    {
        public static void If(Func<bool> condition, Action @true, Action @false) {
            if (condition()) {
                @true();
            } else {
                @false();
            }
        }
        
    }
}
