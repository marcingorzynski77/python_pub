﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Mrap.Mars.Common.Util
{
    public static class Helper
    {

        public static object[,] CreateArray(IList<string> errors)
        {
            var result = new object[errors.Count, 1];

            for (int index = 0; index < errors.Count; index++)
            {
                result[index, 0] = errors[index];
            }
            return result;
        }
        public static SqlParameter SqlParameter(this string paramName, object value, ParameterDirection direction, DbType type)
            => new SqlParameter("@"+paramName, value) { Direction = direction, DbType = type };

        public static SqlParameter SqlParameterInStr(this string paramName, object value)
            => paramName.SqlParameter(value, ParameterDirection.Input, DbType.String);
    }
}
