﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
//using Microsoft.SqlServer.TransactSql.ScriptDom;
using System.IO;
using System.Linq.Expressions;

namespace Mrap.Mars.Common
{
    public class SqlParser
    {
        public class SqlParserResponse
        {
            public string Sql { get; set; }
            public IList<string> Messages { get; set; } = new List<string>();
            public MarsFunctionParser MarsFunctionParser { get; set; } = new MarsFunctionParser();
        }

        //public void ValidateSyntaxt(SqlParserResponse input)
        //{
        //    TSql100Parser parser = new TSql100Parser(false);
        //    IList<ParseError> errors;
        //    parser.Parse(new StringReader(input.Sql),out errors);

        //    if (errors.Count > 0)
        //    {
        //        foreach (var error in errors)
        //            input.Messages.Add(error.Message);
        //    }
        //} 

        public SqlParserResponse ParseString(string input, string fact, Dictionary<string, ColumnInfoDTO> schema)
        {
            if (input != null)
                input = input.Trim();

            if (String.IsNullOrEmpty(fact))
            {
                throw new ArgumentNullException("Fact can not be null");
            }

            // replace % in text with special value ~~ and later replace it back
            input = input.Replace("%", "~~");

            if (String.IsNullOrEmpty(input))
            {
                StringBuilder columns = new StringBuilder();

                foreach (var key in schema.Keys)
                {
                    columns.Append(key);
                    columns.Append(",");
                }

                input = columns.ToString();
                if (input.EndsWith(","))
                    input = input.Remove(input.Length - 1, 1);
            }

            var result = new SqlParserResponse();
            result.MarsFunctionParser.Fact.Add(fact);
            var inputs = input.Split(',');
            StringBuilder sqlSelect = new StringBuilder();
            StringBuilder sqlWhere = new StringBuilder();

            foreach (var item in inputs)
            {
                var oper = GetSupportedOperator(item);

                Regex regEx = new Regex($@"(.*?)\s*{oper}\s*([^\s]+)");

                string parser = item;
                if (oper != null && regEx.IsMatch(item))
                {
                    var res = RemoveOperator(item.Replace("(", "").Replace(")", ""));
                    //var res = item.Replace("(", "").Replace(")", "").Replace("&", " ").Replace("|", " ");
                    var splits = res.Split(new char[] { }, StringSplitOptions.None).ToList();

                    for (int index = splits.Count - 1; index >= 0; index--)
                    {
                        if (String.IsNullOrEmpty(splits[index]))
                        {
                            if (splits.Count > index - 1 && index - 1 >= 0)
                            {
                                splits[index - 1] = splits[index - 1] + " ";
                                splits.RemoveAt(index);
                            }
                            continue;
                        }

                        var op = GetSupportedOperator(splits[index]);


                        // check if next item do not have operator or }
                        if (index - 1 >= 0)
                        {
                            var opNext = GetSupportedOperator(splits[index-1]);
                            if (opNext == null && !splits[index - 1].EndsWith("}"))
                            {
                                splits[index - 1] = splits[index - 1] + " " + splits[index];
                                splits.RemoveAt(index);
                                continue;
                            }
                            else if (op == null || splits[index].Trim().StartsWith(op))
                            {
                                if (splits.Count > index - 1 && index - 1 >= 0)
                                {
                                    // merge with previous index
                                    splits[index - 1] = splits[index - 1] + " " + splits[index];
                                    splits.RemoveAt(index);
                                    continue;
                                }
                            }
                        }

                        // try to join seperated consition like Key=value } & key=value {
                        if (splits[index].Contains("}") && splits[index].Contains("{"))
                        {
                            if (splits[index].IndexOf("}", StringComparison.Ordinal) < splits[index].IndexOf("{", StringComparison.Ordinal))
                            {
                                if (splits.Count > index - 1 && index - 1 >= 0)
                                {
                                    var position = splits[index].IndexOf("}");
                                    var text = splits[index].Substring(0, position + 1);
                                    splits[index] = splits[index].Substring(position + 1);
                                    // merge with previous index
                                    splits[index - 1] = splits[index - 1] + " " + text;
                                    //splits.RemoveAt(index);
                                }
                            }
                        }
                    }

                   // HashSet<string> safeColumnList = new HashSet<string>();
                    foreach (var split in splits)
                    {
                        var splitTemp = split;
                        var op = GetSupportedOperator(split);

                        if (op == null)
                            continue;

                        var seperator = new string[] {op};
                        var kv = split.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
                       

                        if (kv.Length == 2)
                        {
                            var columnName = kv[0].ToUpper().Trim().Replace("{","");

                            var columnNameOriginal = kv[0].Trim().Replace("{", ""); ;
                            var columnNameSafe = $"[{columnNameOriginal.Trim()}]";
                            result.MarsFunctionParser.WhereFields.Add(columnNameSafe);
                            if (!schema.ContainsKey(columnName))
                            {
                                result.Messages.Add($"Column {IsColumnEmpty(kv[0])} not found. Suggested columns: {String.Join(",", GetSuggestions(schema, columnName))}");
                            }
                            else
                            {
                                var value = kv[1];
                                var info = schema[columnName];

                                if (!String.IsNullOrEmpty(value))
                                {
                                    var tempvalue = value.Replace("'", "");

                                    bool isValid = true;

                                    if (op == "->")
                                    {
                                        var items = tempvalue.Replace("{", "").Replace("}", "");
                                        var toValidate = items.Split(new char[] {';'});

                                        foreach (var itemToValidate in toValidate)
                                        {
                                            if (!DataRowExt.TryParse(info.SqlType, itemToValidate))
                                            {
                                                result.Messages.Add($"Unable to parse argument {itemToValidate} for column {kv[0]}. Required type is {info.SqlType}");
                                                isValid = false;
                                            }
                                        }
                                    }
                                    else if (op == "==")
                                    {
                                        //Special case for nulls and so don't try to parse
                                    }
                                    else if (!DataRowExt.TryParse(info.SqlType, tempvalue.Replace("}", "")))
                                    {
                                        result.Messages.Add($"Unable to parse argument {tempvalue} for column {kv[0]}. Required type is {info.SqlType}");
                                        isValid = false;
                                    }

                                    if (isValid)
                                    {
                                        if (DataRowExt.RequiresQuotes(info.SqlType))
                                        {
                                            if (tempvalue.Contains('{') && tempvalue.Contains('}'))
                                            {
                                                var origin = tempvalue;
                                                var sp = tempvalue.Replace("{", "").Replace("}", "").Split(new char[] { ';' });
                                                tempvalue = String.Empty;
                                                foreach (string s in sp)
                                                {
                                                    tempvalue += $"'{s.Trim()}';";
                                                }

                                                if (tempvalue.EndsWith(";"))
                                                    tempvalue = tempvalue.Remove(tempvalue.Length - 1, 1);


                                                tempvalue = new String('{', CountSymbolAtStartPosition('{', origin)) + $"{tempvalue}" + new String('}', CountSymbolAtEndPosition('}', origin));

                                                splitTemp = split.Trim();
                                                value = value.Trim();
                                            }
                                            else if (tempvalue.Contains('{'))
                                            {
                                                var origin = tempvalue;
                                                tempvalue = tempvalue.Replace("{", "");
                                                tempvalue = new String('{', CountSymbolAtStartPosition('{', origin)) + $"'{tempvalue}'";
                                                splitTemp = split.Trim();
                                                value = value.Trim();
                                            }
                                            else if (tempvalue.Contains('}'))
                                            {
                                                var origin = tempvalue;
                                                tempvalue = tempvalue.Replace("}", "");
                                                tempvalue = $"'{tempvalue}'" + new String('}', CountSymbolAtEndPosition('}', origin));
                                                splitTemp = split.Trim();
                                                value = value.Trim();
                                            }
                                            else
                                            {
                                                // tempvalue = tempvalue.Replace("{", "").Replace("}", "");
                                                tempvalue = $"'{tempvalue.Trim()}'";
                                                splitTemp = split.Trim();
                                                value = value.Trim();
                                            }
                                        }

                                        if (tempvalue.Contains("*"))
                                        {
                                            // replcae * with %
                                            tempvalue = tempvalue.Replace("*", "%");
                                        }

                                        if (value.ToUpper().Contains("BLANK") && op == "==")
                                        {
                                            var newcomparison = splitTemp.Replace(columnNameOriginal, columnNameSafe);


                                            if (tempvalue.Contains("'BLANK'"))
                                                newcomparison = newcomparison.ToUpper().Replace("==BLANK", "IS NULL OR " + columnNameSafe + " = ''");
                                            else
                                                newcomparison = newcomparison.ToUpper().Replace("==BLANK", "IS NULL");

                                            
                                            //Handle null and blank values
                                            //parser = parser.ToUpper().Replace("==BLANK", "IS NULL");
                                            parser = parser.ToUpper().Replace(splitTemp.ToUpper().Trim(), newcomparison.ToUpper().Trim());
                                        }
                                        else if (value != tempvalue)
                                        {
                                            string newcomparison;
                                            // split two sides by operator a= b
                                            var splitOperator = GetSupportedOperator(splitTemp);
                                            var splitArray = splitTemp.Split(new string[] { splitOperator }, StringSplitOptions.None);
                                            if (splitArray.Length == 2)
                                            {
                                                splitArray[1] = splitArray[1].Replace(value, tempvalue);
                                                newcomparison = (splitArray[0] + splitOperator + splitArray[1]).Replace(columnNameOriginal, columnNameSafe);
                                            }
                                            else
                                            {
                                                newcomparison = splitTemp.Replace(value, tempvalue).Replace(columnNameOriginal, columnNameSafe);
                                            }

                                            parser = parser.ToUpper().Replace(splitTemp.ToUpper().Trim(), newcomparison.Trim());
                                        }
                                        else
                                        {
                                            var newcomparison = splitTemp.Replace(columnNameOriginal, columnNameSafe);

                                            parser = parser.ToUpper().Replace(splitTemp.ToUpper().Trim(), newcomparison.Trim());
                                        }
                                                                                                            
                                        //parser = parser.Replace(columnNameOriginal, columnNameSafe);
                                    }
                                }
                            }
                        }
                    }

                    var characters = parser.ToCharArray().ToList();
                    bool replaceSign = false;

                    for (int index = characters.Count - 1; index >= 0; index--)
                    {
                        if (replaceSign == false)
                            replaceSign = characters[index] == '%';

                        if (characters[index] == '=' && replaceSign)
                        {
                            characters[index] = '^';
                            replaceSign = false;
                        }

                        if (characters[index] == '>' && characters[index - 1] == '<' && replaceSign)
                        {
                            characters[index] = '`';
                            replaceSign = false;
                            characters.RemoveAt(index - 1);
                        }
                    }

                    parser = new String(characters.ToArray()).Replace("^", " LIKE ");
                    parser = parser.Replace("`", " NOT LIKE ");
                    parser = parser.Replace(";", ",");
                    parser = parser.Replace("{", "(");
                    parser = parser.Replace("}", ")");
                    parser = parser.Replace("~~", "%");

                    sqlWhere.Append(ReplaceOperator(parser));
                    result.MarsFunctionParser.Filter.Add(ReplaceOperator(parser));
                    sqlWhere.Append(" AND ");
                }
                else
                {
                    if (!schema.ContainsKey(item.Trim().ToUpper()))
                    {
                        result.Messages.Add($"Column {IsColumnEmpty(item)} not found. Suggested columns: {String.Join(",", GetSuggestions(schema, item.ToUpper()))}");
                    }

                    result.MarsFunctionParser.Fields.Add($"[{item.Trim()}]");
                }
            }

            if (result.MarsFunctionParser.Fields.Count > 0)
            {
                foreach (var item in result.MarsFunctionParser.Fields)
                {
                    sqlSelect.Append(item);
                    sqlSelect.Append(",");
                }
            }
            else
            {
                foreach (var item in result.MarsFunctionParser.WhereFields)
                {
                    result.MarsFunctionParser.Fields.Add(item);
                    sqlSelect.Append(item);
                    sqlSelect.Append(",");
                }
            }

            if (sqlSelect.Length == 0)
            {
                sqlSelect.Append("*");
            }

            var sql = $"SELECT {sqlSelect}";
            if (sql.EndsWith(","))
                sql = sql.Remove(sql.Length - 1, 1);

            sql += $" FROM {fact} ";

            if (sqlWhere.Length > 0)
                sql += $"WHERE {sqlWhere}";

            if (sql.EndsWith(" AND "))
                sql = sql.Remove(sql.Length - 5, 5);

            result.Sql = sql;
            return result;

        }

        public int CountSymbolAtStartPosition(char c, string item)
        {
            int count = 1;
            for (int index = 0; index < item.Length; index++)
            {
                if (index == 0 && item[index] == c)
                {
                    count = 1;
                }
                else if (item[index] == c)
                {
                    count++;
                }
                else
                {
                    return count;
                }
            }

            return count;
        }

        public int CountSymbolAtEndPosition(char c, string item)
        {
            int count = 1;
            for (int index = item.Length -1; index >=0; index--)
            {
                if (index == item.Length - 1 && item[index] == c)
                {
                    count = 1;
                }
                else if (item[index] == c)
                {
                    count++;
                }
                else
                {
                    return count;
                }
            }

            return count;
        }

        private readonly HashSet<string> _operators = new HashSet<string>() { "<>", ">=", "=<", "->","==", ">", "<", "=" };
        private readonly List<string> _operatorsOrdered = new List<string>() { "<>", ">=", "<=", "->","==", ">", "<", "=" };
        public bool ContainsSupportedOperator(string op)
        {
            return _operators.Contains(op.ToUpper());
        }

        public string IsColumnEmpty(string column)
        {
            if (String.IsNullOrEmpty(column?.Trim()))
            {
                return "N/A";
            }

            return column;
        }

        public string GetSupportedOperator(string value)
        {
            foreach (var op in _operatorsOrdered)
            {
                if (value.Contains(op.ToUpper()))
                    return op;
            }

            return null;
        }

        public List<string> GetSuggestions(Dictionary<string, ColumnInfoDTO> schema, string column)
        {
            var res = new List<string>();

            var col = column.Trim();

            foreach (var key in schema.Keys)
            {
                if (key.ToUpper().Contains(col.ToUpper()))
                {
                    res.Add(schema[key].Name);
                }
                else if (col.ToUpper().Contains(key.ToUpper()))
                {
                    res.Add(schema[key].Name);
                }
            }

            return res;
        }

        private string ReplaceOperator(string item)
        {
            string filter = item;
            int i = 0;
            int iOpen = 0;
            int iClose = 0;

            //Get next operators 
            int iOR = filter.IndexOf("|", 0);
            int iAND = filter.IndexOf("&", 0);
                       
            while(iOR > 0 || iAND > 0)
            {
                //Get next operator
                i = iOR;
                if ((iAND < i || i <=0) && iAND > 0) i = iAND;

                //Get next bracket operator                
                iOpen = filter.IndexOf("(", i);
                iClose = filter.IndexOf(")", i);

                //Only replace the operator if outside of brackets
                if (iOpen < iClose && iOpen > 0)
                {
                    if (iOR < iAND && iOR > 0)
                        filter = string.Concat(filter.Substring(0, i-1), " OR ", filter.Substring(i+1));
                    else
                        filter = string.Concat(filter.Substring(0, i-1), " AND ", filter.Substring(i+1));
                }

                //reassess next operators
                i++;
                iOR = filter.IndexOf("|", i);
                iAND = filter.IndexOf("&", i);
            }
            
            //Replace any IN filters
            return filter.Replace("->"," IN ");
        }

        private string RemoveOperator(string item)
        {
            string filter = item;
            int i = 0;
            int iOpen = 0;
            int iClose = 0;

            //Get next operators 
            int iOR = filter.IndexOf("|", 0);
            int iAND = filter.IndexOf("&", 0);

            while (iOR > 0 || iAND > 0)
            {
                //Get next operator
                i = iOR;
                if ((iAND < i || i <= 0) && iAND > 0) i = iAND;

                //Get next bracket operator                
                iOpen = filter.IndexOf("{", i);
                iClose = filter.IndexOf("}", i);

                //Only remove the operator if outside of brackets
                if (iOpen < iClose && iOpen > 0)
                {
                    if (iOR < iAND && iOR > 0)
                        filter = string.Concat(filter.Substring(0, i - 1), " ", filter.Substring(i + 1));
                    else
                        filter = string.Concat(filter.Substring(0, i - 1), " ", filter.Substring(i + 1));
                }

                //reassess next operators
                i++;
                iOR = filter.IndexOf("|", i);
                iAND = filter.IndexOf("&", i);
            }

            return filter;                 
        }
    }
}

