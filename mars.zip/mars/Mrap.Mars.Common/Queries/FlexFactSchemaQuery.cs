﻿using Mrap.Mars.Common.Util;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Mrap.Mars.Common
{
    public class FlexFactSchemaQuery : StoredProcQuery, ISchemaQuery
    {
        public const string PROC = "[target].[p_Get_FlexFactSchema]";
        public Dictionary<string, ColumnInfoDTO> ColumnDefs { get; set; }
        
        public FlexFactSchemaQuery(IMarsDb db, string table) : base(db, PROC)
        {
            ColumnDefs = new Dictionary<string, ColumnInfoDTO>();
            var flexFact = "FlexFact".SqlParameter("v" + table, ParameterDirection.Input, DbType.String);
            Params.Add(flexFact);            
        }

        public override void handler(DataRow row)
        {
            var column = row.To(FlexFactColumnInfoDTO.Default());
            ColumnDefs.Add(column.Name.ToUpper(), column);
        }

        public static ISchemaQuery Default(IMarsDb db, string table)
            => new FlexFactSchemaQuery(db, table);
        
    }
}
