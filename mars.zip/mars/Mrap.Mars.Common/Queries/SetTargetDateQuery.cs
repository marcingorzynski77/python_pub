﻿using Mrap.Mars.Common.Util;
using System.Collections.Generic;
using System.Data;

namespace Mrap.Mars.Common
{
    public class SetTargetDateQuery : ExecuteProcQuery
    {
        
        public const string PROC = "[target].[p_Get_FlexFactSchema]";
        public int result;

        public SetTargetDateQuery(IMarsDb db, string sDate, string busDate) : base(db, PROC)
        {

            var targetParam = "TargetDate".SqlParameter(sDate, ParameterDirection.Input, DbType.DateTime2);
            var busDateParam = "BusDate".SqlParameter(busDate, ParameterDirection.Input, DbType.Date);

            if (sDate == "Latest" || string.IsNullOrEmpty(sDate))
            {
                targetParam.Value = null;
            }

            Params.Add(targetParam);
            Params.Add(busDateParam);
        }

        public SetTargetDateQuery(IMarsDb db, string table) : base(db, PROC) { }

        public static IExecuteProcQuery Default(IMarsDb db, string sDate, string busDate)
            => new SetTargetDateQuery(db, sDate, busDate);

    }
}
