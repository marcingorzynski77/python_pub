﻿using System.Collections.Generic;

namespace Mrap.Mars.Common
{
    public interface ISynonymsQuery
    {
        Dictionary<string, SynonymInfoDTO> data { get; }
    }
}
