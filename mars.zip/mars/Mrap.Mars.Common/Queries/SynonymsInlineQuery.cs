﻿using System.Collections.Generic;
using System.Data;

namespace Mrap.Mars.Common
{
    public class SynonymsQuery : InlineSqlQuery, ISynonymsQuery
    {
        public const string QUERY = "SELECT name, base_object_name FROM sys.synonyms";
        public Dictionary<string, SynonymInfoDTO> data { get; set; }
        public SynonymsQuery(IMarsDb db) : base(db, QUERY)
        {
            data = new Dictionary<string, SynonymInfoDTO>();            
        }

        public override void handler(DataRow row)
        {
            var info = row.To(SynonymInfoDTO.Default());
            data.Add(info.Name, info);
        }
    }
}
