﻿using System.Collections.Generic;
using System.Data;

namespace Mrap.Mars.Common
{
    public class SynonymSchemaQuery : InlineSqlQuery, ISchemaQuery
    {

        public const string QUERY = 
"select s.[name] [SCHEMA_NAME], tb.[name] [OBJECT_NAME], c.[name] [COLUMN_NAME], tp.[name] [DATA_TYPE] " +
"from (" +
"select object_id, schema_id, name from sys.views " +
"union select object_id, schema_id, name from sys.tables) tb " +
"join sys.schemas s on s.schema_id = tb.schema_id " +
"join sys.columns c on c.object_id = tb.object_id " +
"join sys.types tp on c.system_type_id = tp.system_type_id " + 
"where 1 = 1 " +
"and tb.[name] = '{0}' " +
"and s.[name] = '{1}'";

        public Dictionary<string, ColumnInfoDTO> ColumnDefs {get;set;}

        public SynonymSchemaQuery(IMarsDb marsDb, SynonymInfoDTO schemaForSynonym) :
            base(marsDb, string.Format(QUERY,schemaForSynonym.baseObjectName,schemaForSynonym.baseObjSchema))
        {
            ColumnDefs = new Dictionary<string, ColumnInfoDTO>();
        }
        
        public override void handler(DataRow row)
        {
            var column = row.To(ColumnInfoDTO.Default());
            ColumnDefs.Add(column.Name.ToUpper(), column);            
        }
        
        public static ISchemaQuery Default(IMarsDb marsDb, SynonymInfoDTO schemaForSynonym)
            => new SynonymSchemaQuery(marsDb, schemaForSynonym);


    }
}