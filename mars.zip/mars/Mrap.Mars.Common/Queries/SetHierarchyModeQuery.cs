﻿using Mrap.Mars.Common.Util;
using System;
using System.Data;

namespace Mrap.Mars.Common
{
    public class SetHierarchyModeQuery : ExecuteProcQuery
    {
        public const string PROC = "[target].[p_Set_HierarchyMode]";

        public SetHierarchyModeQuery(IMarsDb db, string hierarchyEnum) : base(db, PROC)
        {
            var hierachyId = Convert.ToInt16(hierarchyEnum);
            var param = "Hierarchy".SqlParameter(hierarchyEnum, ParameterDirection.Input, DbType.Int16);
            Params.Add(param);
        }

        public static IExecuteProcQuery Default(IMarsDb db, string hierarchyEnum)
            => new SetHierarchyModeQuery(db, hierarchyEnum);

    }
}
