﻿using System;
using System.Collections.Generic;
using System.Data;

namespace Mrap.Mars.Common
{
    public class HierarchyEnumQuery : InlineSqlQuery
    {
        public const string QUERY = "select isnull(Value,'') as value from "
                                  + "target.FlexFactInstance I "
                                  + "join target.FlexFact F "
                                  + "on F.FlexFactKey = I.FlexFactKey "
                                  + "join target.FlexFactHierarchy H "
                                  + "on H.FlexFactHierarchyKey = F.FlexFactHierarchyKey "
                                  + "where H.[Description] = 'RingFencing.Hierarchy.Data' "
                                  + "AND [Key] = '{hierarchy}'";

        public string hierarchyEnum { get; set; }
        public static HierarchyEnumQuery Default(IMarsDb db, string hierarchy)
            => new HierarchyEnumQuery(db, hierarchy);

        static Func<string, string> getQuery =
            (hierarchyContext) =>
            {
                var sHierarchy = (hierarchyContext == "1") ? Context.Adhoc : Context.Official;
                return QUERY.Replace("{hierarchy}", sHierarchy);
            };

        public HierarchyEnumQuery(IMarsDb db, string hierarchy) : base(db, getQuery(hierarchy)){}

        public override void handler(DataRow row)
        {
            hierarchyEnum = row["value"].ToString();
        }
    }
}
