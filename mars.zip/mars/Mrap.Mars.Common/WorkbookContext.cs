﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;

namespace Mrap.Mars.Common
{
    public class WorkbookContext
    {
        private static readonly Dictionary<string, object> _context = new Dictionary<string, object>();

        [ExcelFunction(Description = "Retrive value from the workbbok context for the given key", Name = "MARS.SYS.GETCONTEXT")]
        public static string GetContextValue([ExcelArgument(Description = "Get key value like BusinessDate, LimitDate ")]string key)
        {
            if (!_context.ContainsKey(key))
            {
                return String.Empty;
            }
            else
            {
                return _context[key].ToString();
            }
        }

        public static object GetObject(string key)
        {
            if (!_context.ContainsKey(key))
            {
                return null;
            }
            else
            {
                return _context[key];
            }
        }

        public static void SetObject(string key, object value)
        {
            _context[key] = value;
        }

        [ExcelFunction(Description = "set value for the workbbok context for the given key", Name = "MARS.SYS.SETCONTEXT")]
        public static void SetContextValue([ExcelArgument(Description = "Set key value like BusinessDate, LimitDate ")]string key, string value)
        {
            _context[key] = value;
        }

        [ExcelFunction(Description = "Create new key value combination", Name = "MARS.SYS.CREATECONTEXTITEM")]
        public static bool CreateContextItem(string key, string value)
        {
            if (_context.ContainsKey(key))
            {
                return false;
            }
            else
            {
                _context.Add(key,value);
                return true;
            }
        }

        [ExcelFunction(Description = "Create new key value combination", Name = "MARS.SYS.REPLACECONTEXTITEM")]
        public static void ReplaceContextItem(string key, string value)
        {
            if (!_context.ContainsKey(key))
            {
                _context.Add(key, value);
            }
            else
            {
                _context[key] = value;
            }
        }
    }
}
