﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using log4net;
using Mrap.Mars.Common.Util;

namespace Mrap.Mars.Common
{

    public struct DimValidatorResult
    {
        public string DimensionName;
        public string DimensionValues;
        public string InsertSql;
        public string StartSql;
        public string FinishSql;
        public string ParamSql;
    }

    public static class FlexFactStorage
    {

        private static readonly ILog Logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType?.Name);

        const string FlexBuildInsertStatment = "[target].[p_Flex_BuildInsertStatement]";
        const string FlexValidateDimensionData = "[target].[p_Flex_ValidateDimensionData]";
        const string FlexInsertData = "[target].[p_Flex_InsertData]";
        const string FlexGetSchemaDefinition = "[target].[p_Flex_GetSchemaDefinition]";

        public static IList<Tuple<string, SqlDbType>> GetSchemaDefinition(string schema)
        {

            var defintion = new List<Tuple<string, SqlDbType>>();

            try
            {
                Logger.Info($"Getting Flex Schema Defition for '{schema}' ");

                using (SqlConnection conn = new SqlConnection(WorkbookContext.GetContextValue(Context.Flex)))
                {

                    using (SqlCommand command = new SqlCommand())
                    {

                        conn.Open();

                        command.Connection = conn;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = FlexGetSchemaDefinition;
                        command.Parameters.AddWithValue("Schema", schema);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                SqlDbType type;
                                if (Enum.TryParse((string)reader["DataType"], true, out type))
                                    defintion.Add(new Tuple<string, SqlDbType>((string)reader["ColumnName"], type));
                                else
                                    throw new FormatException($"Cannot parse {(string)reader["DataType"]} to SqlDbType");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }

            return defintion;
        }

        public static object[,] PopulateStorage(IList<Tuple<string, SqlDbType>> schemaDefiniton, IList<object[]> data, string schema, string env, DateTime minBusDate, DateTime maxBusDate, bool patchingEnabled)
        {
            try
            {
                Logger.Info($"Preparation of Storage for {schema} ");

                using (SqlConnection conn = new SqlConnection(WorkbookContext.GetContextValue(Context.Flex)))
                {

                    string sqlCreateTempTable = "";
                    string sqlInsertData = "";

                    using (SqlCommand command = new SqlCommand())
                    {

                        conn.Open();

                        command.Connection = conn;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = FlexBuildInsertStatment;
                        command.Parameters.AddWithValue("Schema", schema);
                        command.Parameters.AddWithValue("Env", env);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (reader["SqlName"].ToString() == "TempTable")
                                    sqlCreateTempTable = reader["SqlValue"].ToString();
                                else if (reader["SqlName"].ToString() == "InsertSql")
                                    sqlInsertData = reader["SqlValue"].ToString();
                            }
                        }
                    }

                    if (sqlCreateTempTable == "")
                        return Helper.CreateArray(new List<string> { "SQL query for Temp table is empty" });

                    if (sqlInsertData == "")
                        return Helper.CreateArray(new List<string> { "SQL query for data insert to the temp table is empty" });

                    Logger.Info($"Populating temp data for {schema}");

                    using (SqlCommand command = new SqlCommand())
                    {
                        Logger.Debug("Create temp table");
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;
                        command.CommandText = sqlCreateTempTable;
                        Logger.Debug(sqlCreateTempTable);
                        command.ExecuteNonQuery();
                    }

                    string comparisonSqlTemp = String.Empty;
                    string comparisonSql = String.Empty;

                    // find  duplicates
                    foreach (var record in schemaDefiniton)
                    {
                        comparisonSqlTemp = comparisonSqlTemp + record.Item1 + ",";
                    }
                    comparisonSqlTemp = comparisonSqlTemp.Remove(comparisonSqlTemp.Length-1);

                    comparisonSql = $"exec[target].[p_Get_DenormalisedSQLForFlexFacts] '{schema}','','{comparisonSqlTemp} from {schema}'";

                    using (SqlCommand command = new SqlCommand())
                    {
                        Logger.Debug("Prepare delta");
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;
                        command.CommandText = comparisonSql;
                        Logger.Debug(comparisonSql);
                        var resultSql = command.ExecuteScalar();

                        if (resultSql != null)
                        {
                            command.CommandText = resultSql.ToString();
                            Logger.Debug(resultSql);

                            using (var reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    for (int index = 0; index < reader.FieldCount; index++)
                                    {
                                        // loop through the records
                                        for (int recordIndex = data.Count - 1; recordIndex >= 0; recordIndex--)
                                        {
                                            var item = data[recordIndex];
                                            bool foundmatch = true;
                                            // compare columns in the record
                                            var position = 0;
                                            foreach (var record in item)
                                            {
                                                if (String.CompareOrdinal(reader[position++].ToString(), record.ToString()) != 0)
                                                {
                                                    foundmatch = false;
                                                    break;
                                                }
                                            }

                                            if (foundmatch)
                                            {
                                                data.RemoveAt(recordIndex);
                                                Logger.Debug("Found matching record in the database , ignoring input:" + String.Concat(data));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    using (SqlCommand command = new SqlCommand())
                    {
                        Logger.Debug("Insert data into the temp table");
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;
                        command.CommandText = sqlInsertData;
                        Logger.Debug(sqlInsertData);

                        foreach (var tuple in schemaDefiniton)
                        {
                            var param = command.Parameters.Add(tuple.Item1, tuple.Item2);
                            if (tuple.Item2 == SqlDbType.Decimal)
                            {
                                param.Precision = 22;
                                param.Scale = 6;
                            }
                        }

                        foreach (var record in data)
                        {
                            for (int j = 0; j < record.Length; j++)
                            {
                                command.Parameters[schemaDefiniton[j].Item1].Value = record[j];
                            }

                            var debugSql = sqlInsertData;

                            foreach (SqlParameter par in command.Parameters)
                            {
                                debugSql = debugSql.Replace("@" + par.ParameterName, "'" + par.Value?.ToString() + "'");
                            }

                            Logger.Debug(debugSql);

                            command.ExecuteNonQuery();
                        }
                    }

                    var validationResult = ValidateDimensionData(conn, schema, env, minBusDate, maxBusDate);

                    if (validationResult.Count != 0)
                    {
                        if (!patchingEnabled) return ParseDimensionResult(validationResult);

                        foreach (DimValidatorResult result in validationResult)
                        {
                            var paramNames = result.ParamSql.Split(',');
                            var paramValues = result.DimensionValues.Split(',');

                            DateTime start = DateTime.MinValue;
                            DateTime finish = DateTime.MaxValue;

                            using (SqlCommand command = new SqlCommand())
                            {
                                command.Connection = conn;
                                command.CommandType = CommandType.Text;
                                command.CommandText = result.StartSql;
                                command.Parameters.AddRange(paramNames.Select((t, i) => new SqlParameter(t, SqlDbType.VarChar) { Value = paramValues[i] }).ToArray());
                                var paramMinBusDate = new SqlParameter("StartTime", SqlDbType.DateTime2) { Value = minBusDate };
                                command.Parameters.Add(paramMinBusDate);
                                var paramMaxBusDate = new SqlParameter("EndTime", SqlDbType.DateTime2) { Value = maxBusDate };
                                command.Parameters.Add(paramMaxBusDate);

                                using (var reader = command.ExecuteReader())
                                {
                                    if (reader.Read())
                                    {
                                        start = (DateTime)reader["Start"];
                                    }
                                }
                            }

                            using (SqlCommand command = new SqlCommand())
                            {
                                command.Connection = conn;
                                command.CommandType = CommandType.Text;
                                command.CommandText = result.FinishSql;
                                command.Parameters.AddRange(paramNames.Select((t, i) => new SqlParameter(t, SqlDbType.VarChar) { Value = paramValues[i] }).ToArray());
                                var paramMaxBusDate = new SqlParameter("EndTime", SqlDbType.DateTime2) { Value = maxBusDate };
                                command.Parameters.Add(paramMaxBusDate);

                                using (var reader = command.ExecuteReader())
                                {
                                    if (reader.Read())
                                    {
                                        finish = (DateTime)reader["Finish"];
                                    }
                                }
                            }

                            using (SqlCommand command = new SqlCommand())
                            {
                                command.Connection = conn;
                                command.CommandType = CommandType.Text;
                                command.CommandText = result.InsertSql;
                                command.Parameters.AddRange(paramNames.Select((t, i) => new SqlParameter(t, SqlDbType.VarChar) { Value = paramValues[i] }).ToArray());
                                var paramStart = new SqlParameter("Start", SqlDbType.DateTime2) { Value = start };
                                command.Parameters.Add(paramStart);
                                var paramFinish = new SqlParameter("Finish", SqlDbType.DateTime2) { Value = finish };
                                command.Parameters.Add(paramFinish);

                                var debugSql = result.InsertSql;

                                foreach (SqlParameter par in command.Parameters)
                                {
                                    debugSql = debugSql.Replace(par.ParameterName, par.Value?.ToString());
                                }

                                Logger.Debug(debugSql);

                                command.ExecuteNonQuery();
                            }

                            //re-run of dimension validation to populate Keys
                            var validationAfterPatchingResults = ValidateDimensionData(conn, schema, env, minBusDate, maxBusDate);

                            if (validationAfterPatchingResults.Count != 0)
                            {
                                return ParseDimensionResult(validationAfterPatchingResults);
                            }
                        }
                    }

                    using (SqlCommand command = new SqlCommand())
                    {
                        Logger.Debug("Run population routine");
                        command.Connection = conn;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = FlexInsertData;
                        command.CommandTimeout = 180;

                        command.Parameters.AddWithValue("Schema", schema);
                        command.Parameters.AddWithValue("Env", env);

                        Logger.Debug(FlexInsertData + $" '{schema}', '{env}'");
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                return Helper.CreateArray(new List<string>() { ex.Message });
            }

            return null;
        }


        private static IList<DimValidatorResult> ValidateDimensionData(SqlConnection conn, string schema, string env, DateTime minBusDate, DateTime maxBusDate)
        {

            IList<DimValidatorResult> validationResult = new List<DimValidatorResult>();

            using (SqlCommand command = new SqlCommand())
            {
                Logger.Debug("Validate dimensions");
                command.Connection = conn;
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = FlexValidateDimensionData;

                Logger.Info(command.CommandText + $" '{schema}', '{env}', '{minBusDate}', '{maxBusDate}'");

                var param = new SqlParameter("Schema", SqlDbType.VarChar) { Value = schema };
                command.Parameters.Add(param);

                param = new SqlParameter("Env", SqlDbType.VarChar) { Value = env };
                command.Parameters.Add(param);

                param = new SqlParameter("MinBusDate", SqlDbType.DateTime2) { Value = minBusDate };
                command.Parameters.Add(param);

                param = new SqlParameter("MaxBusDate", SqlDbType.DateTime2) { Value = maxBusDate };
                command.Parameters.Add(param);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        validationResult.Add(new DimValidatorResult
                        {
                            DimensionName = reader["DimensionName"].ToString(),
                            DimensionValues = reader["DimensionValues"].ToString(),
                            ParamSql = reader["ParamSql"].ToString(),
                            StartSql = reader["StartSql"].ToString(),
                            FinishSql = reader["FinishSql"].ToString(),
                            InsertSql = reader["InsertSql"].ToString()
                        });
                    }
                }
            }

            return validationResult;
        }

        private static object[,] ParseDimensionResult(IList<DimValidatorResult> validationResult)
        {
            var retVal = new List<string> { "Validation of dimensions failed." };
            retVal.AddRange(validationResult.Select(result => $"Dimension Key '{result.DimensionName}' does not exist for '{result.DimensionValues}'"));
            return Helper.CreateArray(retVal);
        }

        public static object[,] PopulateDimensions(IList<DimValidatorResult> dimensions)
        {
            try
            {

                using (SqlConnection conn = new SqlConnection(WorkbookContext.GetContextValue(Context.Db)))
                {
                    conn.Open();

                    foreach (var dim in dimensions)
                    {
                        using (SqlCommand command = new SqlCommand())
                        {
                            command.Connection = conn;
                            command.CommandType = CommandType.Text;
                            command.CommandText = dim.InsertSql;

                            var values = dim.DimensionValues.Split(',');
                            var parameters = dim.DimensionValues.Split(',');

                            for (int i = 0; i < values.Length; i++)
                            {
                                command.Parameters[parameters[i]].Value = values[i];
                            }
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                return Helper.CreateArray(new List<string>() { ex.Message });
            }

            return null;
        }
    }
}