﻿using Mrap.Mars.Common.Util;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mrap.Mars.Common
{
    public static class MarsRepositoryContext
    {
        public static void SetTargetDate(IMarsDb db)
        {
            var sDate = Context.GetTimeTravelDateTimeAsString;
            var busDate = Context.GetBusDateTimeAsString();

            var setTargetDate = SetTargetDateQuery.Default(db, sDate, busDate);
            setTargetDate.query();


        }

        public static void SetHierarchyMode(IMarsDb db)
        {
            var hierarchyContext = WorkbookContext.GetContextValue(Context.Hierarchy);
            var hierarchyQuery = HierarchyEnumQuery.Default(db, hierarchyContext);
            hierarchyQuery.query();
            var hierarchyEnum = hierarchyQuery.hierarchyEnum;
            
            var setMode = SetHierarchyModeQuery.Default(db, hierarchyEnum);
            setMode.query();

        }
    }
}
