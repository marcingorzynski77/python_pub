﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Mrap.Mars.Common
{
    public static class DataRowExt
    {
        
        public static SynonymInfoDTO To(this DataRow row, SynonymInfoDTO @default) { 
            var name = row["name"].ToString();
            var schemaInfo = row["base_object_name"].ToString().Split(new char[] { '.' })
                        .Reverse().Take(2).ToList();


            @default.Name = name;
            @default.baseObjectName = schemaInfo[0].Replace("[", "").Replace("]", "");
            @default.baseObjSchema = schemaInfo[1].Replace("[", "").Replace("]", "");

            return @default;
        }

        public static FlexFactColumnInfoDTO To(this DataRow row, FlexFactColumnInfoDTO @default)
        {
            SqlDbType sql;
            Enum.TryParse(row[1].ToString(), true, out sql);

            @default.Name = row[0].ToString();
            @default.Type = row[1].ToString();
            @default.ClrType = GetClrType(sql);
            @default.SqlType = sql;

            return @default;
        }
        public static ColumnInfoDTO To(this DataRow row, ColumnInfoDTO @default)
        {

            SqlDbType sql;
            Enum.TryParse(row["DATA_TYPE"].ToString(), true, out sql);

            @default.Name = row["COLUMN_NAME"].ToString();
            @default.Type = row["DATA_TYPE"].ToString();
            @default.ClrType = GetClrType(sql);
            @default.SqlType = sql;

            return @default;
        }
        

        public static Type GetClrType(SqlDbType sqlType)
        {
            switch (sqlType)
            {
                case SqlDbType.BigInt:
                    return typeof(long?);

                case SqlDbType.Binary:
                case SqlDbType.Image:
                case SqlDbType.Timestamp:
                case SqlDbType.VarBinary:
                    return typeof(byte[]);

                case SqlDbType.Bit:
                    return typeof(int?);

                case SqlDbType.Char:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                    return typeof(string);

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                    return typeof(DateTime?);

                case SqlDbType.Decimal:
                case SqlDbType.Money:
                case SqlDbType.SmallMoney:
                    return typeof(decimal?);

                case SqlDbType.Float:
                    return typeof(double?);

                case SqlDbType.Int:
                    return typeof(int?);

                case SqlDbType.Real:
                    return typeof(float?);

                case SqlDbType.UniqueIdentifier:
                    return typeof(Guid?);

                case SqlDbType.SmallInt:
                    return typeof(short?);

                case SqlDbType.TinyInt:
                    return typeof(byte?);

                case SqlDbType.Variant:
                case SqlDbType.Udt:
                    return typeof(object);

                case SqlDbType.Structured:
                    return typeof(DataTable);

                case SqlDbType.DateTimeOffset:
                    return typeof(DateTimeOffset?);

                default:
                    throw new ArgumentOutOfRangeException("sqlType");
            }
        }

        public static bool TryParse(SqlDbType sqlType, string value)
        {
            value = value.Replace("{", "").Replace("}", "");
            switch (sqlType)
            {
                case SqlDbType.BigInt:
                    long result1;
                    return long.TryParse(value, out result1);

                case SqlDbType.Binary:
                case SqlDbType.Image:
                case SqlDbType.Timestamp:
                case SqlDbType.VarBinary:

                    return false;

                case SqlDbType.Bit:
                    int result2;
                    return Int32.TryParse(value, out result2);

                case SqlDbType.Char:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                    return true;

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                    DateTime result3;
                    return DateTime.TryParse(value, out result3);

                case SqlDbType.Decimal:
                case SqlDbType.Money:
                case SqlDbType.SmallMoney:
                    decimal result4;
                    return decimal.TryParse(value, out result4);

                case SqlDbType.Float:
                    double result5;
                    return double.TryParse(value, out result5);

                case SqlDbType.Int:
                    int result6;
                    return int.TryParse(value, out result6);

                case SqlDbType.Real:
                    float result7;
                    return float.TryParse(value, out result7);

                case SqlDbType.UniqueIdentifier:
                    Guid result8;
                    return Guid.TryParse(value, out result8);

                case SqlDbType.SmallInt:
                    short result9;
                    return short.TryParse(value, out result9);

                case SqlDbType.TinyInt:
                    byte result10;
                    return byte.TryParse(value, out result10);

                case SqlDbType.Variant:
                case SqlDbType.Udt:
                    return true;

                case SqlDbType.Structured:
                    return false;

                case SqlDbType.DateTimeOffset:
                    return false;

                default:
                    throw new ArgumentOutOfRangeException("sqlType");
            }
        }

        public static bool RequiresQuotes(SqlDbType sqlType)
        {
            switch (sqlType)
            {
                case SqlDbType.BigInt:
                    return false;

                case SqlDbType.Binary:
                case SqlDbType.Image:
                case SqlDbType.Timestamp:
                case SqlDbType.VarBinary:

                    return true;

                case SqlDbType.Bit:
                    return false;

                case SqlDbType.Char:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                    return true;

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                    return true;

                case SqlDbType.Decimal:
                case SqlDbType.Money:
                case SqlDbType.SmallMoney:
                    return false;

                case SqlDbType.Float:
                    return false;

                case SqlDbType.Int:
                    return false;

                case SqlDbType.Real:
                    return false;

                case SqlDbType.UniqueIdentifier:
                    return false;

                case SqlDbType.SmallInt:
                    return false;

                case SqlDbType.TinyInt:
                    return false;

                case SqlDbType.Variant:
                case SqlDbType.Udt:
                    return true;

                case SqlDbType.Structured:
                    return true;

                case SqlDbType.DateTimeOffset:
                    return true;

                default:
                    throw new ArgumentOutOfRangeException("sqlType");
            }
        }
    }
}
