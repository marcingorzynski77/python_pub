﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace Mrap.Mars.Common
{
    public class MarsFunctionParser
    {
        public IList<string> Fact { get; set; } = new List<string>();
        //public IList<string> Fields { get; set; } = new List<string>();
        public IList<string> Filter { get; set; } = new List<string>();
        public HashSet<string> Fields { get; set; } = new HashSet<string>();
        public HashSet<string> WhereFields { get; set; } = new HashSet<string>();
    }
}
