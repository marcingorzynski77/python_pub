﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using log4net;
using Mrap.Mars.Common.Util;

namespace Mrap.Mars.Common
{
    public class MarsRepository
    {
        private static ILog Logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);

        protected static Object[] getHeaderRow(IDataReader reader)
        {
            var headers = new Object[reader.FieldCount];
            for (int index = 0; index < headers.Length; index++)
            {
                headers[index] = reader.GetName(index);
            }

            return headers;
        }

        protected static object[] removeNulls(object[] row)
        {
            for (int i = 0; i < row.Length; i++)
            {
                if (row[i] is DBNull)
                {
                    row[i] = "";
                }
            }
            return row;
        }

        public static void process(int maxCells, Action<object[]> rowActor, IDataReader reader)
        {
            int count = 0;
            int maxRows = 0;
            int columnCount = 0;
            Object[] row = null;

            while (reader.Read())
            {
                if (count == 0)
                {
                    columnCount = reader.FieldCount;
                    row = getHeaderRow(reader);
                    rowActor(row);
                    maxRows = maxCells / reader.FieldCount;
                }

                reader.GetValues(row);
                rowActor(row);
                count++;

                if (count >= maxRows)
                {
                    break;
                }
            }
        }
        public static void runSqlDataReader(string connection, string commandText, int timeout, CommandType commandType, IEnumerable<SqlParameter> sqlParamList, Action<IDataReader> processor)
        {
            var sqlParamsArray = sqlParamList.ToArray();
            
            using (var sqlConn = new SqlConnection(connection))
            using (SqlCommand command = new SqlCommand(commandText, sqlConn))
            {
                sqlConn.Open();
                command.CommandTimeout = timeout;
                command.CommandType = commandType;
                command.CommandText = commandText;
                command.Parameters.AddRange(sqlParamsArray);

                using (var reader = command.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    processor(reader);
                }
            }
        }

        public static object[,] GetDataWithTimeout(string query, int commandTimeout)
        {
            return QueryWithContext(query, commandTimeout, CommandType.Text, new List<SqlParameter>());
        }

        public static object[,] GetAggregatedDataWithTimeout(string dataSet, string sqlSelect, string sqlFromWhere, string pivotExpr, string valueExpr, string function, string pivotCols, string sliceFilter, string rankOrder, string rowOrder, string partitionCols, int commandTimeout)
        {
            var paramValueList = new Dictionary<string, string>(){
                { "tableSpec",      String.Empty},
                { "sqlSelect",      string.Concat("SELECT ", sqlSelect) },
                { "sqlFromWhere",   sqlFromWhere },
                { "pivotExpr",      pivotExpr },
                { "valueExpr",      valueExpr },
                { "function",       function },
                { "sortLookup",     String.Empty },
                { "pivotCols",      pivotCols },
                { "sliceFilter",    sliceFilter },
                { "rankOrder",      rankOrder },
                { "rowOrder",       rowOrder },
                { "partitionCols",  partitionCols }};

            var sqlParamList = paramValueList.Select(x => x.Key.SqlParameterInStr(x.Value));
            return QueryWithContext("[target].[p_Run_AggregateQuery]", commandTimeout, CommandType.StoredProcedure, sqlParamList);
        }

        protected static object[,] QueryWithContext(string commandText, int commandTimeout, CommandType commandType, IEnumerable<SqlParameter> sqlParamList)
        {
            try
            {
                var db = MarsDb.Default;

                MarsRepositoryContext.SetTargetDate(db);
                MarsRepositoryContext.SetHierarchyMode(db);

                var connection = Context.GetConnectionString;
                var data = new List<object[]>();
                var maxCells = 400000;

                Action<object[]> addRow =
                    (row) =>
                    {
                        var cleanedRow = removeNulls(row);
                        data.Add(cleanedRow);
                    };

                Action<IDataReader> processor = (dataReader) => process(maxCells, addRow, dataReader);
                runSqlDataReader(connection, commandText, commandTimeout, CommandType.StoredProcedure, sqlParamList, processor);

                return data.To2DArray();

            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                return Helper.CreateArray(new List<string>() { ex.Message });
            }
        }

        public static object[,] GetSnapshotId(string sSnapshotID, int commandTimeout)
        {
            var query = "SELECT MAX(Start) FROM[MaRS].[target].[TimeTravellingInstance] where[ExternalReference] = '{sSnapshotID}'";
            return QueryWithContext(query, commandTimeout, CommandType.Text, null);
        }
    }
}
