﻿using System.Collections.Generic;

namespace Mrap.Mars.Common
{
    public interface ISchemaQuery : IMarsQuery
    {
        Dictionary<string, ColumnInfoDTO> ColumnDefs { get; }
    }
}

