﻿using System.Collections.Generic;
using System.Data.SqlClient;

namespace Mrap.Mars.Common
{
    public interface IExecuteProcQuery : IMarsQuery
    {
        string ProcText { get; }
        List<SqlParameter> Params { get; }
        int returnValue { get; set; }
    }
}
