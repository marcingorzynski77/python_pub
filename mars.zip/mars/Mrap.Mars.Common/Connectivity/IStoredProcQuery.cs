﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Mrap.Mars.Common
{
    public interface IStoredProcQuery : IMarsQuery
    {
        string ProcText { get; }
        List<SqlParameter> Params { get; }
        
    }
}