﻿using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Mrap.Mars.Common
{
    public class MarsDb : IMarsDb
    {
        private ILog _log;
        private string _connectionString;

        public MarsDb() : this(
            LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name), 
            WorkbookContext.GetContextValue(Context.Db)) { }
        
        public MarsDb(ILog log, string connectionString)
        {
            _connectionString = connectionString;
            _log = log;
        }

        public static MarsDb Default 
            => new MarsDb();

        public DataTable query(IInlineSqlQuery inlineQuery)
        {
            var dt = new DataTable();
            try
            {
                _log.Info($"Inline Query :{inlineQuery.queryString}");
                using (var da = new SqlDataAdapter(inlineQuery.queryString, _connectionString))
                {
                    da.Fill(dt);                    
                }
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }
            return dt;
        }

        public DataTable query(IStoredProcQuery procQuery)
        {
            var dt = new DataTable();
            _log.Info($"stored proc query {nameof(procQuery)}");
            using (var command = new SqlCommand(procQuery.ProcText, new SqlConnection(_connectionString)))
            {
                try
                {                    
                    foreach (var item in procQuery.Params)
                    {
                        command.Parameters.Add(item);                        
                    }
                    var dataReader = command.ExecuteReader();
                    dt.Load(dataReader);                    
                }
                catch (Exception ex)
                {
                    _log.Error(ex);
                }
            }
            return dt;

        }

        public void execute(IExecuteProcQuery procQuery)
        {
            _log.Info($"execute query {nameof(procQuery)}");
            using (var command = new SqlCommand(procQuery.ProcText, new SqlConnection(_connectionString)))
            {
                try
                {
                    foreach (var item in procQuery.Params)
                    {
                        command.Parameters.Add(item);
                    }
                    command.ExecuteNonQuery();
                    
                }
                catch (Exception ex)
                {
                    _log.Error(ex);
                }
            }
        }
        
        public static Type GetClrType(SqlDbType sqlType)
        {
            switch (sqlType)
            {
                case SqlDbType.BigInt:
                    return typeof(long?);

                case SqlDbType.Binary:
                case SqlDbType.Image:
                case SqlDbType.Timestamp:
                case SqlDbType.VarBinary:
                    return typeof(byte[]);

                case SqlDbType.Bit:
                    return typeof(int?);

                case SqlDbType.Char:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                    return typeof(string);

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                    return typeof(DateTime?);

                case SqlDbType.Decimal:
                case SqlDbType.Money:
                case SqlDbType.SmallMoney:
                    return typeof(decimal?);

                case SqlDbType.Float:
                    return typeof(double?);

                case SqlDbType.Int:
                    return typeof(int?);

                case SqlDbType.Real:
                    return typeof(float?);

                case SqlDbType.UniqueIdentifier:
                    return typeof(Guid?);

                case SqlDbType.SmallInt:
                    return typeof(short?);

                case SqlDbType.TinyInt:
                    return typeof(byte?);

                case SqlDbType.Variant:
                case SqlDbType.Udt:
                    return typeof(object);

                case SqlDbType.Structured:
                    return typeof(DataTable);

                case SqlDbType.DateTimeOffset:
                    return typeof(DateTimeOffset?);

                default:
                    throw new ArgumentOutOfRangeException("sqlType");
            }
        }

        public static bool TryParse(SqlDbType sqlType, string value)
        {
            value = value.Replace("{", "").Replace("}", "");
            switch (sqlType)
            {
                case SqlDbType.BigInt:
                    long result1;
                    return long.TryParse(value, out result1);

                case SqlDbType.Binary:
                case SqlDbType.Image:
                case SqlDbType.Timestamp:
                case SqlDbType.VarBinary:

                    return false;

                case SqlDbType.Bit:
                    int result2;
                    return Int32.TryParse(value, out result2);

                case SqlDbType.Char:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                    return true;

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                    DateTime result3;
                    return DateTime.TryParse(value, out result3);

                case SqlDbType.Decimal:
                case SqlDbType.Money:
                case SqlDbType.SmallMoney:
                    decimal result4;
                    return decimal.TryParse(value, out result4);

                case SqlDbType.Float:
                    double result5;
                    return double.TryParse(value, out result5);

                case SqlDbType.Int:
                    int result6;
                    return int.TryParse(value, out result6);

                case SqlDbType.Real:
                    float result7;
                    return float.TryParse(value, out result7);

                case SqlDbType.UniqueIdentifier:
                    Guid result8;
                    return Guid.TryParse(value, out result8);

                case SqlDbType.SmallInt:
                    short result9;
                    return short.TryParse(value, out result9);

                case SqlDbType.TinyInt:
                    byte result10;
                    return byte.TryParse(value, out result10);

                case SqlDbType.Variant:
                case SqlDbType.Udt:
                    return true;

                case SqlDbType.Structured:
                    return false;

                case SqlDbType.DateTimeOffset:
                    return false;

                default:
                    throw new ArgumentOutOfRangeException("sqlType");
            }
        }

        public static bool RequiresQuotes(SqlDbType sqlType)
        {
            switch (sqlType)
            {
                case SqlDbType.BigInt:
                    return false;

                case SqlDbType.Binary:
                case SqlDbType.Image:
                case SqlDbType.Timestamp:
                case SqlDbType.VarBinary:

                    return true;

                case SqlDbType.Bit:
                    return false;

                case SqlDbType.Char:
                case SqlDbType.NChar:
                case SqlDbType.NText:
                case SqlDbType.NVarChar:
                case SqlDbType.Text:
                case SqlDbType.VarChar:
                case SqlDbType.Xml:
                    return true;

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                case SqlDbType.Date:
                case SqlDbType.Time:
                case SqlDbType.DateTime2:
                    return true;

                case SqlDbType.Decimal:
                case SqlDbType.Money:
                case SqlDbType.SmallMoney:
                    return false;

                case SqlDbType.Float:
                    return false;

                case SqlDbType.Int:
                    return false;

                case SqlDbType.Real:
                    return false;

                case SqlDbType.UniqueIdentifier:
                    return false;

                case SqlDbType.SmallInt:
                    return false;

                case SqlDbType.TinyInt:
                    return false;

                case SqlDbType.Variant:
                case SqlDbType.Udt:
                    return true;

                case SqlDbType.Structured:
                    return true;

                case SqlDbType.DateTimeOffset:
                    return true;

                default:
                    throw new ArgumentOutOfRangeException("sqlType");
            }
        }
    }
}