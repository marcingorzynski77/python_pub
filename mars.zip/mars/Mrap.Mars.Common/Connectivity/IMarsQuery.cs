﻿using System.Data;

namespace Mrap.Mars.Common
{
    public interface IMarsQuery
    {
        void query();
    }
}