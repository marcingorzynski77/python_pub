﻿using System;
using System.Data;

namespace Mrap.Mars.Common
{
    public interface IInlineSqlQuery : IMarsQuery
    {
        string queryString { get; }        
    }
}
