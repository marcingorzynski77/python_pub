﻿using System;
using System.Data;

namespace Mrap.Mars.Common
{
    public abstract class InlineSqlQuery : IInlineSqlQuery
    {
        private IMarsDb _db;

        public string queryString { get; private set; }
        
        public InlineSqlQuery(IMarsDb db, string query)
        {
            _db = db;
            queryString = query;
        }

        public void query()
        {
            var dt = _db.query(this);
            foreach (DataRow row in dt.Rows)
            {
                handler(row);
            }
        }

        public virtual void handler(DataRow row)
            => throw new NotImplementedException();
    }
}
