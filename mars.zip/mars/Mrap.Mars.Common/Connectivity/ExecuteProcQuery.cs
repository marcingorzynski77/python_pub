﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Mrap.Mars.Common
{
    public abstract class ExecuteProcQuery : IExecuteProcQuery
    {
        private IMarsDb _db;
        public int returnValue { get; set; }
        public string ProcText { get; private set; }
        public List<SqlParameter> Params { get; private set; }

        public ExecuteProcQuery(IMarsDb db, string procText)
        {
            _db = db;
            ProcText = procText;
            Params = new List<SqlParameter>();
        }

        public void query()
        {
            _db.execute(this);
        }
        
    }
}
