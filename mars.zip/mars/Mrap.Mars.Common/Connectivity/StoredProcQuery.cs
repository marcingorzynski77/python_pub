﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Mrap.Mars.Common
{
    public abstract class StoredProcQuery : IStoredProcQuery
    {
        private IMarsDb _db;
        public string ProcText { get; private set; }
        public List<SqlParameter> Params {get; private set; }

        public StoredProcQuery(IMarsDb db, string procText)
        {
            _db = db;
            ProcText = procText;
            Params = new List<SqlParameter>();
        }

        public void query()
        {
            var dt = _db.query(this);
            foreach (DataRow row in dt.Rows)
            {
                handler(row);
            }

        }

        public virtual void handler(DataRow row)
        {
            throw new NotImplementedException();
        }
        
    }
}
