﻿using System.Data;

namespace Mrap.Mars.Common
{
    public interface IMarsDb
    {
        DataTable query(IInlineSqlQuery inlineQuery);
        DataTable query(IStoredProcQuery storedProcQuery);
        void execute(IExecuteProcQuery executeQuery);
    }
}
