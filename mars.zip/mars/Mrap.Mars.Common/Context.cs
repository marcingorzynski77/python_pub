﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using log4net;

namespace Mrap.Mars.Common
{
    public class LimitCache : IEqualityComparer<LimitCache>
    {
        public DateTime BusinessDate { get; set; }
        public DateTime EffectiveDate { get; set; }

        public LimitCache()
        {
        }

        public LimitCache(DateTime businessDate, DateTime effectiveDate)
        {
            BusinessDate = businessDate;
            EffectiveDate = effectiveDate;
        }

        public bool Equals(LimitCache x, LimitCache y)
        {
            if (x == null || y == null) return false;
            if (object.ReferenceEquals(x, y)) return true;
            return x.BusinessDate.Date == y.BusinessDate.Date && x.EffectiveDate.Date == y.EffectiveDate.Date;
        }

        public int GetHashCode(LimitCache obj)
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 23 + obj.BusinessDate.Date.GetHashCode();
                hash = hash * 23 + obj.EffectiveDate.Date.GetHashCode();
                return hash;
            }
        }

        public override int GetHashCode()
        {
            return GetHashCode(this);
        }

        public override bool Equals(object obj)
        {
            return Equals(this, obj as LimitCache);
        }
    }

    public class Context
    {
        public const string Environment = "ENVIRONMENT";
        public const string Local = "LOCAL";
        public const string Dev = "DEV";
        public const string Uat = "UAT";
        public const string Par = "PAR";
        public const string Prod = "PROD";
        public const string Rrr = "RRR";
        public const string Dr = "DR";
        public const string Db = "DB";
        public const string Flex = "FLEX";
        public const string DbLimits = "Limits";
        public const string WorkbookFilePath = "WorkbookFilePath";
        public const string WorkbookFileName = "WorkbookFileName";
        public const string UserName = "UserName";
        public const string LimitCache = "LimitCache";
        public const string BusinessDate = "BusinessDate";
        public const string LimitEffectiveDate = "LimitDate";
        public const string BusinessDateVersion = "BusinessDateVersion";
        public const string SqlSelect = "SqlSelect ";
        public const string PivotExpr = "PivotExpr";
        public const string ValueExpr = "ValueExpr";
        public const string GroupBy = "GroupBy ";
        public const string TimeTravelDate = "TimeTravelDate";
        public const string Schema = "Schema";
        public const string Hierarchy = "Hierarchy";
        public const string Official = "Official";
        public const string Adhoc = "Adhoc";
        public const string RingFencing = "RingFencing";
        public const string AddinVersion = "AddinVersion";

        private static readonly ILog Logger = LogManager.GetLogger("Mrap.Mars.Common.Context");

        public static DateTime GetBusDateTime()
        {
            var business = WorkbookContext.GetContextValue(Context.BusinessDate);
            DateTime businessDate = DateTime.Today;
            try
            {
                businessDate = business == String.Empty ? businessDate : DateTime.Parse(business);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to parse business date {business}",ex);
            }
           
            return businessDate;
        }

        public static string GetBusDateTimeAsString()
        {
            return GetBusDateTime().ToString("dd-MMM-yyyy");
        }

        public static string GetTimeTravelDateTimeAsString
            => WorkbookContext.GetContextValue(Context.TimeTravelDate);

        public static DateTime GetTimeTravelDateTime()
        { 
            var dt = GetTimeTravelDateTimeAsString;
            
            var res = DateTime.UtcNow;
            try
            {
                if (!string.IsNullOrWhiteSpace(dt))
                {
                    res = DateTime.Parse(dt);
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Failded to parse time travel date {dt}", ex);
            }

            return res;
        }
        
        public static string GetConnectionString =>
            WorkbookContext.GetContextValue(Context.Db);

        public static object GetLimitCache()
        {
            var cache = new LimitCache(GetTimeTravelDateTime(), GetLimitEffectiveDate());
            var result = WorkbookContext.GetObject(Context.LimitCache) as Dictionary<LimitCache, object>;

            if (result != null && result.ContainsKey(cache))
            {
                Logger.Info($"Getting limits from cache for time travel date {GetTimeTravelDateTime()}, limit date {GetLimitEffectiveDate()}");
                return result[cache];
            }

            Logger.Info($"Limit cache is empty for time travel date {GetTimeTravelDateTime()}, limit date {GetLimitEffectiveDate()}");

            return null;
        }

        public static object GetLimitCache(LimitCache cache)
        {
            var result = WorkbookContext.GetObject(Context.LimitCache) as Dictionary<LimitCache, object>;

            if (result != null && result.ContainsKey(cache))
            {
                return result[cache];
            }

            return null;
        }

        public static void SetLimitCache(object value)
        {
            bool exists = !String.IsNullOrEmpty(WorkbookContext.GetContextValue(Context.TimeTravelDate));
            if (exists)
            {
                Logger.Info($"Setting Limit cache for TimeTravelDate {GetTimeTravelDateTime()} and LimitDate {GetLimitEffectiveDate()}");
                var cache = new LimitCache(GetTimeTravelDateTime(), GetLimitEffectiveDate());
                SetLimitCache(cache, value);
            }
        }

        public static void SetLimitCache(LimitCache cache, object value)
        {
            var result = WorkbookContext.GetObject(Context.LimitCache) as Dictionary<LimitCache, object>;
            if (result == null)
            {
                var item = new Dictionary<LimitCache,object>();
                item.Add(cache, value);
                WorkbookContext.SetObject(Context.LimitCache, item);
            }
            else
            {
                result[cache] = value;
            }
        }

        public static DateTime GetLimitEffectiveDate()
        {
            var business = WorkbookContext.GetContextValue(Context.LimitEffectiveDate);
            DateTime businessDate = DateTime.Today;
            try
            {
                businessDate = business == String.Empty ? DateTime.Today : DateTime.Parse(business);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failded to parse limit effective date {business}", ex);
            }

            return businessDate;
        }
    }
}