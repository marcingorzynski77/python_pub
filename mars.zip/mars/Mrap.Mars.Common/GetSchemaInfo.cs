﻿using System;
using System.Collections.Generic;
using log4net;
using static Mrap.Mars.Common.Util.F;

namespace Mrap.Mars.Common
{

    public class GetSchemaInfo
    {

        private static Func<ILog> Getlogger = () => LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);
        private static Func<string> GetConnectionString = () => WorkbookContext.GetContextValue(Context.Db);
        private ILog Logger = null;
        private static Dictionary<string, Dictionary<string, ColumnInfoDTO>> _cache = null;
        private static Dictionary<string, SynonymInfoDTO> _synonymCache = null;
        private IMarsDb _marsDb = null;

        public static GetSchemaInfo Default 
            => new GetSchemaInfo();

        public GetSchemaInfo() : this(Getlogger(), MarsDb.Default) { }
        public GetSchemaInfo(ILog logger, IMarsDb marsDb)
        {
            Logger = logger;
            _marsDb = marsDb;
            _cache = new Dictionary<string, Dictionary<string, ColumnInfoDTO>>();
            RefreshSynonyms();
        }


        public void RefreshSynonyms()
        {

            IInlineSqlQuery sq = new SynonymsQuery(_marsDb);
            sq.query();
            _synonymCache = ((ISynonymsQuery)sq).data;
        }

        public bool IsAFlexDataSet(string dataSet)
        {
            return !_synonymCache.ContainsKey(dataSet);
        }
        public bool IsNotAFlexDataSet(string dataSet)
        {
            return !IsAFlexDataSet(dataSet);
        }

        public Dictionary<string, ColumnInfoDTO> Build(string table)
        {
            var isCached = _cache.ContainsKey(table.ToUpper());
            If(() => isCached,
                () => Logger.Info($"schema for {table} found in cache"),
                () => Logger.Info($"{table} not found in cache, retriving from db")
                );

            if (!isCached)
            {

                SynonymInfoDTO schemaForSynonym = null;

                var hasSynonym = _synonymCache.TryGetValue(table, out schemaForSynonym);

                ISchemaQuery query = hasSynonym ?
                    SynonymSchemaQuery.Default(_marsDb, schemaForSynonym) :
                    FlexFactSchemaQuery.Default(_marsDb, table);

                query.query();
                var schema = query.ColumnDefs;

                _cache[table.ToUpper()] = schema;

            }


            return _cache[table.ToUpper()];
        }





    }
}
