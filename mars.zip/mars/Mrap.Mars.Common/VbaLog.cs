﻿using ExcelDna.Integration;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mrap.Mars.Common
{
    public static class VbaLog
    {
        private static readonly ILog Logger = LogManager.GetLogger("Mrap.Mars.XLL.VBA");

        [ExcelFunction(Description = "Excel-DNA: Send debug details to the Log")]
        public static void VbaDebug(string msg)
        {
            Logger.Debug(msg);
        }

        [ExcelFunction(Description = "Excel-DNA: Send information to the Log")]
        public static void VbaInfo(string msg)
        {
            Logger.Info(msg);
        }

        [ExcelFunction(Description = "Excel-DNA: Send warnings to the Log")]
        public static void VbaWarn(string msg)
        {
            Logger.Warn(msg);
        }

        [ExcelFunction(Description = "Excel-DNA: Send error details to the Log")]
        public static void VbaError(string msg)
        {
            Logger.Error(msg);
        }
    }
}