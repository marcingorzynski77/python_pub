﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using DevExpress.XtraEditors;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using Mrap.Limits.DataAccess;
using Mrap.Limits.Domain;
using Mrap.Limits.Domain.DTO;

namespace Mrap.Mars.XLL.Ribbon.Views
{
    public partial class LimitView : DevExpress.XtraEditors.XtraUserControl
    {
        public XtraForm Window { get; set; }

        public LimitView()
        {
            InitializeComponent();
        }

        public void Initialize()
        {
            //var repository = new LimitNavigationRepository(new LimitsContext(Environment.UserName, WorkbookContext.GetContextValue(Context.DbLimits)));
            //var limits = repository.LimitHierarchy(true);

            List<LimitModel> limits = new List<LimitModel>();

            limits.Add(new LimitModel() {Name = "Parent_1", UniqueId = 1});
            limits.Add(new LimitModel() { Name = "Child_1.1", UniqueId = 3, Value = 100, ParentUniqueId = 1});

            limits.Add(new LimitModel() { Name = "Parent_2", UniqueId = 2});
            limits.Add(new LimitModel() { Name = "Child_2.1", UniqueId = 4, Value = 50, ParentUniqueId = 2});
            limits.Add(new LimitModel() { Name = "Child_2.2", UniqueId = 5, Value = 20, ParentUniqueId = 2 });

            treeList.ParentFieldName = "ParentUniqueId";
            treeList.KeyFieldName = "UniqueId";
            treeList.DataSource = limits;
            treeList.ForceInitialize();
            treeList.ExpandAll();
            treeList.BestFitColumns();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Window.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {

        }
    }
}
