﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ExcelDna.Integration;
using log4net;
//using Mrap.Limits.DataAccess;
//using Mrap.Limits.Domain;
//using Mrap.Limits.Domain.DTO;
using Mrap.Mars.Common;
using Mrap.Mars.Common.Util;
//using Mrap.Mars.XLL.Limit.ViewModels;
//using LimitRepository = Mrap.Mars.XLL.Limit.LimitRepository;

namespace Mrap.Mars.XLL.Ribbon
{
    public class UserFunc
    {
        private static ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);

        [ExcelFunction(Description = "Get the data from query catalogue", Name = "MARS.PREDEFINED")]
        public static object MarsPredefined([ExcelArgument(Description = "Query Alias")]string queryAlias, [ExcelArgument(Description = "Hierarchy Version")]string queryVersion)
        {
            var result = GetDataWithTimeout(queryAlias, queryVersion, 360);

            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return ArrayResizer.Resize(result);
            }
        }

        [ExcelFunction(Description = "Decode MaRS query to Sql", Name = "MARS.DECODEDATASET")]
        public static object DecodeMarsDataSet([ExcelArgument(Description = "Data set")]string dataSet, [ExcelArgument(Description = "Query defined in MaRs query syntax")]string query)
        {
            return ArrayResizer.Resize(DecodeMarsDataSetHelper(dataSet, query));
        }

        [ExcelFunction(Description = "Get the data from MaRS named data set", Name = "MARS.DATASET")]
        public static object MarsDataSet([ExcelArgument(Description = "Data set")]string dataSet, [ExcelArgument(Description = "Query defined in MaRs query syntax")]string query, [ExcelArgument(Description = "Which column to order to rows by")]string rowOrder)
        {
            object[,] result = null;

            string pattern = @"^[A-Z_A-Z_A-Z]*$";
            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection matches = rgx.Matches(query);
            if (matches.Count == 0)
            {                
                //if (query.IndexOf("A_A_A") < 0 && query.IndexOf("B_B_B") < 0 && query.IndexOf("C_C_C") < 0 && query.IndexOf("D_D_D") < 0 && query.IndexOf("E_E_E") < 0 && query.IndexOf("F_F_F") < 0)
            
                log.Info($"Executing MarsDataSet {dataSet} and query {query}");
                var schema = new GetSchemaInfo().Build(dataSet);
                var sql = new SqlParser();
                string dates = string.Empty;
                string parsedSql = string.Empty;

                //Handle brackets, functions, cell references
                query = CleanQueryBeforeParsing(query, ref dates);

                //Parse into SQL
                var parser = sql.ParseString(query, String.Concat(WorkbookContext.GetContextValue(Context.Schema), ".", dataSet), schema);
                parser.Sql = parser.Sql.Replace("[[", "(");
                parser.Sql = parser.Sql.Replace("]]", ")");

                //Add Order by  
                if (rowOrder != string.Empty) parser.Sql = string.Concat(parser.Sql, " ORDER BY ", rowOrder);

                //Change to denormailsed SQL, handle recycled dimensions
                parsedSql = CleanQueryAfterParsing(parser.Sql, dates, dataSet);

                if (parsedSql.Trim().Substring(0, 7) == "SELECT ")
                {
                    parsedSql = string.Concat("SELECT TOP 100000 ", parsedSql.Trim().Substring(6));
                }//parser.Sql = parser.Sql.Replace("SELECT ", "SELECT TOP 100000 ");

                //Run the query
                if (parser.Messages.Count == 0 || dataSet.IndexOf(".") > 0)
                {
                    if (!Runtime.Ensure())
                    {
                        result = new object[0, 0];
                    }
                    else
                    {
                        result = MarsRepository.GetDataWithTimeout(parsedSql, 360);
                    }
                }
                else
                {
                    result = Helper.CreateArray(parser.Messages);
                }
            }
            else
            {
                result = new object[0, 0];
            }

            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result;
            }
        }
        
        [ExcelFunction(Description = "Get the data from MaRS named data set", Name = "MARS.SUMMARISE")]
        public static object MarsAggregate([ExcelArgument(Description = "Data Set")]string dataSet,
                                           [ExcelArgument(Description = "Select SQL")]string sqlSelect,
                                           [ExcelArgument(Description = "What to filter the query by")]string sqlWhere,
                                           [ExcelArgument(Description = "Which field to pivot")]string pivotExpr,
                                           [ExcelArgument(Description = "Which operator to apply")]string function,
                                           [ExcelArgument(Description = "Which field to apply function to")]string valueExpr,
                                           [ExcelArgument(Description = "Specific pivoted fields to return")]string pivotCols,
                                           [ExcelArgument(Description = "Post processing filter")]string sliceFilter,
                                           [ExcelArgument(Description = "Direction of rank order")]string rankOrder,
                                           [ExcelArgument(Description = "Which columns to order rows by")]string rowOrder,
                                           [ExcelArgument(Description = "Which columns to partition rank by")]string partitionCols)
        {
            object[,] result = null;

            string pattern = @"^[A-Z_A-Z_A-Z]*$";
            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection matches = rgx.Matches(sqlSelect);
            if (matches.Count == 0)
            {
                MatchCollection whereMatches = rgx.Matches(sqlWhere);
                if (whereMatches.Count == 0 || string.IsNullOrEmpty(sqlWhere) == true)                    
                //if (sqlSelect.IndexOf("A_A_A") < 0 && sqlSelect.IndexOf("B_B_B") < 0 && sqlSelect.IndexOf("C_C_C") < 0 && sqlWhere.IndexOf("D_D_D") < 0 && sqlWhere.IndexOf("E_E_E") < 0 && sqlWhere.IndexOf("F_F_F") < 0)
                {

                    //log.Info($"Executing MarsDataSet {dataSet} and query {query}");
                    var schema = new GetSchemaInfo().Build(dataSet);
                    var sql = new SqlParser();
                    if (sqlWhere != string.Empty)
                    {
                        //Handle column reference
                        ParseFilterColumnNames(ref sqlSelect, ref sqlWhere);

                        string query = sqlWhere;
                        string dates = string.Empty;
                        string parsedSql = string.Empty;

                        //Handle CalendarOffset function
                        if (query.IndexOf("CalendarValues") > 0)
                        {
                            //Handle filter strings which contain brackets
                            ParseCalendarOffsetFunction(ref query, ref dates);
                        }

                        //Handle filter strings which contain brackets
                        query = CleanQueryBeforeParsing(query, ref dates);

                        var parser = sql.ParseString(query, String.Concat(WorkbookContext.GetContextValue(Context.Schema), ".", dataSet), schema);
                        parser.Sql = parser.Sql.Replace("[[", "(");
                        parser.Sql = parser.Sql.Replace("]]", ")");

                        //Handle CalendarOffset function
                        if (dates != string.Empty)
                        {
                            //Change query to point at denormalised SQL instead of the view
                            parsedSql = GetDenormalisedSQLForDateOffsetting(dataSet, dates);
                            sqlSelect = HandleRecycledDimensionFields(String.Concat("[", sqlSelect.Replace(",", "],["), "]"), "SELECT", dataSet);
                            sqlWhere = HandleRecycledDimensionFields(String.Concat(" FROM ", parsedSql, parser.Sql.Substring(parser.Sql.IndexOf(" WHERE"))), "WHERE", dataSet);
                        }
                        else
                        {
                            sqlWhere = String.Concat(" FROM dbo.", dataSet, parser.Sql.Substring(parser.Sql.IndexOf(" WHERE")));
                        }

                        // sqlWhere = parsedSql.Substring(parsedSql.IndexOf("FROM"));
                    }
                    else
                    {
                        sqlWhere = String.Concat(" FROM dbo.", dataSet);
                    }

                    //strip the pivotexpr and valueexpr out of the 

                    //parser.Sql = parser.Sql.Replace("SELECT ", "SELECT TOP 100000 ");
                    //sql.ValidateSyntaxt(parser);

                    if (!Runtime.Ensure())
                    {
                        result = new object[0, 0];
                    }
                    else
                    {
                        result = MarsRepository.GetAggregatedDataWithTimeout(dataSet, sqlSelect, sqlWhere, pivotExpr, valueExpr, function, pivotCols, sliceFilter, rankOrder, rowOrder, partitionCols, 360);
                    }
                }
                else
                {
                    result = new object[0, 0];
                }

                if (result == null || result.Length == 0)
                {
                    return new string[] { "No Data Returned" };
                }
                else
                {
                    return result;
                }
            }
            else
            {
                return result;
            }
        }

        internal static object[,] DecodeMarsDataSetHelper(string dataSet, string query)
        {
            log.Info($"Executing DecodeMarsDataSetHelper {dataSet} and query {query}");
            var schema = new GetSchemaInfo().Build(dataSet);
            var sql = new SqlParser();
            string dates = string.Empty;
            string parsedSql = string.Empty;

            //Handle filter strings which contain brackets
            query = CleanQueryBeforeParsing(query, ref dates);

            var parser = sql.ParseString(query, String.Concat(WorkbookContext.GetContextValue(Context.Schema), ".", dataSet), schema);
            parser.Sql = parser.Sql.Replace("[[", "(");
            parser.Sql = parser.Sql.Replace("]]", ")");
            

            //Change to denormalised SQL, handle recycled dimesnions
            parsedSql = CleanQueryAfterParsing(parser.Sql, dates, dataSet);

            object[,] result = null;

            if (parser.Messages.Count == 0 || dataSet.IndexOf(".") > 0)
            {
                result = Helper.CreateArray(new List<string>() { parsedSql });
            }
            else
            {
                parser.Messages.Add(parsedSql);
                result = Helper.CreateArray(parser.Messages);
            }


            return ArrayResizer.EnsureNonEmpty(result);
        }


        internal static string CleanQueryBeforeParsing(string query, ref string dates)
        {
            string selectFields = string.Empty;
            string filter = string.Empty;

            //Handle column reference
            if (query.IndexOf("(") > 0)
            {
                selectFields = query.Substring(0, query.IndexOf("("));
                filter = query.Substring(selectFields.Length);
                ParseFilterColumnNames(ref selectFields, ref filter);
                query = string.Concat(selectFields, filter);
            }

            //Handle CalendarOffset function
            if (filter.IndexOf("CalendarValues") > 0)
            {
                //Handle filter strings which contain brackets
                ParseCalendarOffsetFunction(ref query, ref dates);
            }
            else if(filter.IndexOf("BusDate")>0)
            {
                int functionStart = filter.IndexOf("{BusDate");
                string function = filter.Substring(functionStart, filter.IndexOf("}", functionStart) - functionStart );
                dates = function.Substring(function.IndexOf("{",2) + 1);
                dates = dates.Replace(";", ",");
            }


            //Handle filter strings which contain brackets
            if (query.IndexOf("(") > 0)
            {
                if (query.LastIndexOf(")") > query.IndexOf("("))
                {
                    string leftPart = query.Substring(0, query.IndexOf("(") + 1);
                    string rightPart = query.Substring(query.LastIndexOf(")"));
                    filter = query.Substring(query.IndexOf("(") + 1, query.LastIndexOf(")") - query.IndexOf("(") - 1);
                    filter = filter.Replace("(", "[[");
                    filter = filter.Replace(")", "]]");
                    query = String.Concat(leftPart, filter, rightPart);
                }
            }

            return query;
        }

        internal static string CleanQueryAfterParsing(string query, string dates, string dataSet)
        {
            string parsedSql = string.Empty;
            var isAFlexDataSet = new GetSchemaInfo().IsAFlexDataSet(dataSet);
            //if (dataSet.IndexOf(".") >0)
            if (isAFlexDataSet)
            {
                if (dates == "")
                {
                    DateTime thedate;
                        DateTime.TryParse(WorkbookContext.GetContextValue(Context.BusinessDate).ToString(),out thedate);
                    dates = thedate.ToString("yyyyMMdd");
                }

                //Change query to point at denormalised SQL instead of the view
                parsedSql = GetDenormalisedSQLForFlexFacts(dataSet, dates, query);
                parsedSql = query.Replace("dbo." + dataSet, "(" + parsedSql + ")a");

                //Handle recycled dimensions
                string fields = parsedSql.Substring(0, parsedSql.IndexOf(" FROM"));
                string rest = parsedSql.Substring(parsedSql.IndexOf(" FROM"), parsedSql.Length - fields.Length);
                parsedSql = string.Concat(HandleRecycledDimensionFields(fields, "SELECT", dataSet), HandleRecycledDimensionFields(rest, "WHERE", dataSet));
                                
            }
            else if (dates != string.Empty)
            {
                //Handle CalendarOffset function
                //Change query to point at denormalised SQL instead of the view
                parsedSql = GetDenormalisedSQLForDateOffsetting(dataSet, dates);
                parsedSql = query.Replace("dbo." + dataSet, parsedSql);

                //Handle recycled dimensions
                string fields = parsedSql.Substring(0, parsedSql.IndexOf(" FROM"));
                string rest = parsedSql.Substring(parsedSql.IndexOf(" FROM"), parsedSql.Length - fields.Length);
                parsedSql = string.Concat(HandleRecycledDimensionFields(fields, "SELECT", dataSet), HandleRecycledDimensionFields(rest, "WHERE", dataSet));
            }
            else
            {
                parsedSql = query;
            }

            return parsedSql;
        }

        public static SqlParser.SqlParserResponse FormulaBreakDown(string dataSet, string query)
        {
            log.Info($"Executing FormulaBreakDown {dataSet} and query {query}");
            var schema = new GetSchemaInfo().Build(dataSet);
            var sql = new SqlParser();

            string dates = string.Empty;
            string parsedSql = string.Empty;

            //Handle filter strings which contain brackets
            query = CleanQueryBeforeParsing(query, ref dates);

            var parser = sql.ParseString(query, String.Concat(WorkbookContext.GetContextValue(Context.Schema), ".", dataSet), schema);
            parser.Sql = parser.Sql.Replace("[[", "(");
            parser.Sql = parser.Sql.Replace("]]", ")");

            //Change to denormailsed SQL, handle recycled dimesnions
            parser.Sql = CleanQueryAfterParsing(parser.Sql, dates, dataSet);

            //sql.ValidateSyntaxt(parser);

            return parser;
        }


        //arg is an array with a header, which contains list of columns as in the flex defition
        [ExcelFunction(Description = "Save data to flex storage", Name = "MARS.SAVEFLEXDATA")]
        public static object[,] SaveFlexData(object[,] data, string schema, bool patchingEnabled)
        {

            string env = WorkbookContext.GetContextValue(Context.Environment);

            if (data == null)
                return Helper.CreateArray(new List<string> { "Data array is null" });

            int rowCount = data.GetLength(0);

            if (rowCount == 0)
                return Helper.CreateArray(new List<string> {"Data array is empty"});

            try
            {
                var schemaDefinition = FlexFactStorage.GetSchemaDefinition(schema);
                var flexData = new List<object[]>();
                var minBusDate = DateTime.MaxValue;
                var maxBusDate = DateTime.MinValue;

                int columnCount = data.GetLength(1);
                if (schemaDefinition.Count != columnCount)
                    return Helper.CreateArray(new List<string> { "Supplied number of columns does not match schema definition" });

                //map supplied header and schema defitions - order of columns can be different
                var mapping = new int[schemaDefinition.Count];
                for (int schemaColumn = 0; schemaColumn < schemaDefinition.Count; schemaColumn++)
                {
                    bool columnMatched = false;
                    for (int dataColumn = 0; dataColumn < columnCount; dataColumn++)
                    {
                        if (string.Equals(schemaDefinition[schemaColumn].Item1, data[0, dataColumn].ToString(), StringComparison.OrdinalIgnoreCase))
                        {
                            mapping[schemaColumn] = dataColumn;
                            columnMatched = true;
                            break;
                        }
                    }

                    if (!columnMatched)
                        return Helper.CreateArray(new List<string> { $"Required column '{schemaDefinition[schemaColumn].Item1}' not found in the header" });
                }

                for (int row = 1; row < rowCount; row++)
                {

                    bool checkForNullValues = false;
                    for (int column = 0; column < columnCount; column++)
                    {
                        if (data[row, column] == null)
                            checkForNullValues = true;
                    }

                    if (checkForNullValues) continue;

                    var record = new object[schemaDefinition.Count];

                    for (int schemaColumn = 0; schemaColumn < schemaDefinition.Count; schemaColumn++)
                    {
                        record[schemaColumn] = data[row, mapping[schemaColumn]];
                        
                        //we have to know the earliest business date supplied, which is required for patching dimensions
                        if (string.Equals(schemaDefinition[schemaColumn].Item1,"BusDate",StringComparison.OrdinalIgnoreCase))
                        {
                            DateTime date;
                            if (DateTime.TryParse(data[row, mapping[schemaColumn]].ToString(), out date))
                            {
                                if (date < minBusDate)
                                    minBusDate = date;
                            
                                if (date > maxBusDate)
                                    maxBusDate = date;
                            }
                        }
                    }

                    if (minBusDate == DateTime.MaxValue) minBusDate = DateTime.UtcNow;
                    if (maxBusDate == DateTime.MinValue) maxBusDate = DateTime.UtcNow;

                    flexData.Add(record);
                }

                if (flexData.Count == 0)
                    return Helper.CreateArray(new List<string> { "There is no data to upload (Each row has at least one missing value) " });

                return FlexFactStorage.PopulateStorage(schemaDefinition, flexData, schema, env, minBusDate, maxBusDate, patchingEnabled);
            }
            catch (Exception ex)
            {
                return Helper.CreateArray(new List<string> {ex.Message});
            }

        }


        internal static void ParseFilterColumnNames(ref string fields, ref string filter)
        {

            string[] values = fields.Split(',');

            int iCount = 1;
            foreach(string field in values)
            {
               filter = filter.Replace("Col" + iCount.ToString(), field.Trim());
                iCount++;
            }

        }

        internal static string HandleRecycledDimensionFields(string fields,string type, string dataset)
        {
            
            string sql = String.Concat("exec [target].[p_Get_VirtualDimensionFields] '", type, "','",fields.Replace("'","''"), "','", dataset,"'");
                        
            object[,] result = null;

            if (!Runtime.Ensure())
            {
                result = new object[0, 0];
            }
            else
            {
                result = MarsRepository.GetDataWithTimeout(sql, 360);
            }

            //return the denormalised SQL            
            if (result.GetUpperBound(0) == 1)
            {
                return result[1, 0].ToString();
            }
            else
            {
                //error
                return result[0, 0].ToString();
            }           
                         
        }

        internal static void ParseCalendarOffsetFunction(ref string query, ref string dates)
        {
            //log.Info($"Executing CalendarOffsets for offsets {sOffset} relative to busdate {sBusDate}");

            int functionStart = query.IndexOf("CalendarValues");
            string function = query.Substring(functionStart, query.IndexOf(")", functionStart) - functionStart+1);
            string offsets = string.Empty;
            string busdate = string.Empty;

            if (function.IndexOf(",")>0)
            {
                offsets = function.Substring(15, function.IndexOf(",")-15);
                busdate = function.Substring(function.IndexOf(",") + 1, function.Length - function.IndexOf(",")-2);
            }
            else
            {
                offsets = function.Substring(15, function.IndexOf(")")-15);
                busdate = Context.GetBusDateTimeAsString();
            }


            string sql = String.Concat("select target.f_CalendarValues('", offsets.Replace(";",","), "','", busdate, "')");

            //sql.ValidateSyntaxt(parser);
            object[,] result = null;

            if (!Runtime.Ensure())
            {
                result = new object[0, 0];
            }
            else
            {
                result = MarsRepository.GetDataWithTimeout(sql, 360);
            }

            //Remove quotes
            dates = result[1, 0].ToString();
            dates = dates.Replace("'",string.Empty);

            query = query.Replace(function, dates.Replace(",",";"));

        }

        internal static string GetDenormalisedSQLForDateOffsetting(string dataset, string dates)
        {
            //log.Info($"Executing CalendarOffsets for offsets {sOffset} relative to busdate {sBusDate}");
            string sql = String.Concat("exec [target].[p_Get_DenormalisedSQLForDateOffsetting] 'v", dataset, "','", dates,"'");

            object[,] result = null;

            if (!Runtime.Ensure())
            {
                result = new object[0, 0];
            }
            else
            {
                result = MarsRepository.GetDataWithTimeout(sql, 360);
            }

            //return the denormalised SQL
            return result[1, 0].ToString();                                  
        }

        internal static string GetDenormalisedSQLForFlexFacts(string dataset, string dates, string query)
        {
            string qry = query.Replace("'", "''");

            string sql = String.Concat("exec [target].[p_Get_DenormalisedSQLForFlexFacts] '", dataset, "','", dates, "','", qry, "'");

            object[,] result = null;

            if (!Runtime.Ensure())
            {
                result = new object[0, 0];
            }
            else
            {
                result = MarsRepository.GetDataWithTimeout(sql, 360);
            }

            if (result.GetUpperBound(0) == 1)
            {
                return result[1, 0].ToString();
            }
            else
            {
                //error
                return result[0, 0].ToString();
            }



        }


        /*

        [ExcelFunction(Description = "Get limit data")]
        public static object Limit([ExcelArgument(Description = "Hierarchy Risk Node Id")]int hierarchyNodeId)
        {
            var limits = new LimitRepository().Get(hierarchyNodeId).Where(x => x.Type == LimitModel.ModelType.Limit.ToString()).OrderBy(x => x.Path).ThenBy(x => x.Priority).ToList();
            object[,] rows = new object[limits.Count + 1, 9];

            rows[0, 0] = "HierarchyNode";
            rows[0, 1] = "RiskMeasure";
            rows[0, 2] = "LimitName";
            rows[0, 3] = "CategoryName";
            rows[0, 4] = "Value";
            rows[0, 5] = "LimitID";
            rows[0, 6] = "Priority";
            rows[0, 7] = "Override";
            rows[0, 8] = "Path";

            int index = 1;
            foreach (var row in limits)
            {
                if (row.Priority == 0)
                    continue;

                rows[index, 0] = row.HierarchyNodeName;
                rows[index, 1] = row.RiskMeasureName;
                rows[index, 2] = row.LimitName;
                rows[index, 3] = row.Name;
                rows[index, 4] = row.Value;
                rows[index, 5] = row.LimitId;
                rows[index, 6] = row.Priority;
                rows[index, 7] = row.IsOverride;
                rows[index, 8] = row.Path;
                index++;
            }

            return ArrayResizer.Resize(ArrayResizer.EnsureNonEmpty(rows));
        }

        [ExcelFunction(Description = "Get single limit data")]
        public static object SingleLimit([ExcelArgument(Description = "Hierarchy Risk Node Name")]string riskNodeName, [ExcelArgument(Description = "Risk Measure Name")] string riskMeasureName, [ExcelArgument(Description = "Limit Name")] string limitName, [ExcelArgument(Description = "Limit Category")] string limitCategory)
        {

            var path = String.Concat(LimitRepository.NormalizePathSeperator(riskNodeName), LimitRepository.NormalizePathSeperator(riskMeasureName), LimitRepository.NormalizePathSeperator(limitName), LimitRepository.NormalizePathSeperator(limitCategory));

            var limits = Context.GetLimitCache() as List<LimitViewModel>;
            if (limits == null)
            {
                limits = new LimitRepository().Get();
                Context.SetLimitCache(limits);
            }

            try
            {
                var limit = limits.SingleOrDefault(x => String.Compare(x.FullPath, path, StringComparison.OrdinalIgnoreCase) == 0);

                if (limit == null)
                    return "No limit found";
                else
                    return limit?.Value;
            }
            catch (Exception)
            {
                return "Found more than one record matching the query";
            }
        }
        */
        [ExcelFunction(Description = "Get the data from query catalogue")]
        public static object[,] GetDataWithTimeout(string queryAlias, string queryVersion, int commandTimeout)
        {
            try
            {
                log.Info($"Preparing query {queryAlias}");

                if (!Runtime.Ensure())
                {
                    return new object[0, 0];
                }

                var connection = WorkbookContext.GetContextValue(Context.Db);

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = conn;
                        command.CommandTimeout = commandTimeout;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[target].[p_Run_QueryFromCatalogue]";

                        var param = new SqlParameter("@TrackerCRC", String.Empty)
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };

                        command.Parameters.Add(param);
                        param = new SqlParameter("@FilePath", WorkbookContext.GetContextValue(Context.WorkbookFilePath))
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };
                        command.Parameters.Add(param);
                        param = new SqlParameter("@FileName", WorkbookContext.GetContextValue(Context.WorkbookFileName))
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };
                        command.Parameters.Add(param);

                        param = new SqlParameter("@UserName", WorkbookContext.GetContextValue(Context.UserName))
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };
                        command.Parameters.Add(param);


                        param = new SqlParameter("@QueryAlias", queryAlias)
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };
                        command.Parameters.Add(param);


                        param = new SqlParameter("@QueryVersion", queryVersion)
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };
                        command.Parameters.Add(param);

                        param = new SqlParameter("@Query", "")
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.String
                        };
                        command.Parameters.Add(param);

                        log.Info($"Executing {command.CommandText} FilePath:{command.Parameters["@FilePath"].Value}  FileName:{command.Parameters["@FileName"].Value} FilePath:{command.Parameters["@FilePath"].Value} QueryAlias:{command.Parameters["@QueryAlias"].Value}");

                        List<Object[]> rows = new List<Object[]>(1000);
                        Object[] headers = null;
                        int columns = 0;

                        conn.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Object[] row = new Object[reader.FieldCount];

                                if (headers == null)
                                {
                                    headers = new Object[reader.FieldCount];
                                    for (int index = 0; index < headers.Length; index++)
                                    {
                                        headers[index] = reader.GetName(index);
                                    }

                                    rows.Add(headers);
                                }

                                columns = reader.FieldCount;

                                // Get the Row with all its column values..
                                reader.GetValues(row);

                                // Add this Row to ArrayList.
                                rows.Add(row);
                            }

                        }

                        return rows.To2DArray();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }
        

        [ExcelFunction(Description = "Analyse aggregated RRR results", Name = "RRRAggregatedDrillDown", IsVolatile = true)]
        public static object RRRAggregatedDrillDown([ExcelArgument(Description = "AggregationKey")]string sAggKey)
        {
            object[,] result = null;

            log.Info($"Executing RRRAggregatedDrillDown()");
            var sql = new SqlParser();

            //Build Query
            string query = string.Concat("select * from target.f_RRRAggregatedDrillDown('" + sAggKey + "')");


            result = MarsRepository.GetDataWithTimeout(query, 360);


            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result;
            }
        }

        [ExcelFunction(Description = "Follow path of trade within RRR Aggregation rule engine", Name = "RRRTradeDrillUp", IsVolatile = true)]
        public static object RRRTradeDrillUp([ExcelArgument(Description = "TradeReference")]string sTradeRef)
        {
            object[,] result = null;

            log.Info($"Executing RRRTradeDrillUp()");
            var sql = new SqlParser();

            //Build Query
            string query = string.Concat("select * from target.f_RRRTradeDrillUp('" + sTradeRef + "')");


            result = MarsRepository.GetDataWithTimeout(query, 360);


            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result;
            }
        }

        [ExcelFunction(Description = "Get the business date", Name = "BusDate", IsVolatile =true)]
        public static object BusDate()
        {
            object[,] result = null;
            string query = null;

            log.Info($"Executing busdate()");
            var sql = new SqlParser();

            //Handle brackets, functions, cell references
            query = "select * from target.f_BusDate()";


            result = MarsRepository.GetDataWithTimeout(query, 360);


            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result[1, 0];
            }
        }

        [ExcelFunction(Description = "Get the limit date", Name = "LimitDate", IsVolatile = true)]
        public static object LimitDate()
        {
            object[,] result = null;

            log.Info($"Executing limitdate()");
            var sql = new SqlParser();

            //Handle brackets, functions, cell references
            string query = "select * from target.f_limitDate()";


            result = MarsRepository.GetDataWithTimeout(query, 360);


            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result[1, 0];
            }
        }

        [ExcelFunction(Description = "Get the limit date", Name = "CalendarValues", IsVolatile = true)]
        public static object CalendarValues([ExcelArgument(Description = "Offset Mnemonics")]string sOffset, [ExcelArgument(Description = "Business date to offset from")]string sBusDate)
        {
            object[,] result = null;

            log.Info($"Executing CalendarValues()");
            var sql = new SqlParser();

            //Build Query
            string query = string.Concat("select target.f_CalendarValues('" + sOffset + "','" + sBusDate + "')");


            result = MarsRepository.GetDataWithTimeout(query, 360);

            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result[1, 0];
            }
        }

        [ExcelFunction(Description = "Get the limit date", Name = "CalendarOffset", IsVolatile = true)]
        public static object CalendarOffset([ExcelArgument(Description = "Offset Mnemonics")]string sOffset, [ExcelArgument(Description = "Business date to offset from")]string sBusDate)
        {
            object[,] result = null;

            log.Info($"Executing CalendarOffset()");
            var sql = new SqlParser();

            //Build Query
            string query = string.Concat("select target.f_CalendarOffset('" + sOffset + "','" + sBusDate + "')");


            result = MarsRepository.GetDataWithTimeout(query, 360);


            if (result == null || result.Length == 0)
            {
                return new string[] { "No Data Returned" };
            }
            else
            {
                return result[1, 0];
            }
        }

        static bool RefreshRunning = false;

        [ExcelFunction(Description = "Refresh the sheet", Name = "MARS.REFRESHWORKBOOK", IsVolatile = false)]
        public static void RefreshWorkbook()
        {
            if (RefreshRunning == false)
            {
                RefreshRunning = true;
                ExcelAsyncUtil.QueueMacro("SetRefreshBooleanTrue");
                ExcelAsyncUtil.QueueMacro("RefreshWorkbook");
            }else
            {
                RefreshRunning = false;
                ExcelAsyncUtil.QueueMacro("SetRefreshBooleanFalse");
            }
        }


        [ExcelFunction(Description = "Get Simra snapshotID version", Name = "MARS.GETDATEVERSION", IsVolatile = false)]
        public static object GetDataVersion([ExcelArgument(Description = "SIMRA snapshot ID")]string sSnapshotID)
        {
            object[,] result = null;


            if (!Runtime.Ensure())
            {
                result = new object[0,0];
            }
            else
            {
                result = MarsRepository.GetSnapshotId(sSnapshotID,360);
            }

            if (result == null || result.Length == 0)
            {
                //   return new object[,] { "No Version Returned",""};
                return "";
            }
            else
            {
                return result[1, 0];
            }
        }

        [ExcelFunction(Description = "Set the business date and version", Name = "MARS.SETBUSDATE", IsVolatile = false)]
        public static void SetBusDate([ExcelArgument(Description = "Business date")]string sBusDate, [ExcelArgument(Description = "Version of data")]string sVersion)
        {
            WorkbookContext.SetContextValue("BusinessDate", sBusDate);
            if (sVersion == string.Empty) sVersion = "1";
            WorkbookContext.SetContextValue("BusinessDateVersion", sVersion);
            object[] result = null;

            var db = new MarsDb();
            MarsRepositoryContext.SetTargetDate(db);

            result = new object[] { "Done" };

            Ribbon.InvalidateRibbon();
        }

        [ExcelFunction(Description = "Set the environment", Name = "MARS.SETENVIRONMENT", IsVolatile = false)]
        public static void SetEnvironment([ExcelArgument(Description = "Environment")]string sEnv)
        {
            if(!String.IsNullOrEmpty(sEnv)) Runtime.SetEnvironment(sEnv);
            Ribbon.InvalidateRibbon();
        }
    }
}
