﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExcelDna.Integration;
using log4net;
using Mrap.Common.Util.Wcf.Invoker;
using Mrap.Mars.Common;


namespace Mrap.Mars.XLL.Ribbon
{
    public class Runtime : IExcelAddIn
    {
        private static readonly ILog Logger = LogManager.GetLogger("Mrap.Mars.XLL.Ribbon.Runtime");

        static Runtime()
        {

            var dest = Environment.ExpandEnvironmentVariables(@"%APPDATA%\Microsoft\AddIns");
            string logFilePath = Path.Combine(dest,"Mrap.Mars.XLL.Ribbon-AddIn.xll.config");
            if (File.Exists(logFilePath))
            {
                var finfo = new FileInfo(logFilePath);
                log4net.Config.XmlConfigurator.Configure(finfo);
            }
            else
            {
                log4net.Config.XmlConfigurator.Configure();
            }

            Logger.Info("Initilizing environments...");
            // register env
            WorkbookContext.CreateContextItem(Context.Environment,  String.Empty);
            WorkbookContext.CreateContextItem(Context.UserName,     Environment.UserName);
            WorkbookContext.CreateContextItem(Context.Local,        "net.tcp://localhost:10701/");
            WorkbookContext.CreateContextItem(Context.Dev,          "net.tcp://FMD-A8-2700:10701/");
            WorkbookContext.CreateContextItem(Context.Uat,          "net.tcp://FMU-A8-3077:10701/");
            WorkbookContext.CreateContextItem(Context.Rrr,          "net.tcp://FMU-A8-3077:10711/");
            WorkbookContext.CreateContextItem(Context.Par,          "net.tcp://FMD-A8-2701:10701/");
            WorkbookContext.CreateContextItem(Context.Prod,         "net.tcp://FMP-A8-3077:10701/");
            WorkbookContext.CreateContextItem(Context.Dr,           "net.tcp://FMC-A8-3077:10701/");
            WorkbookContext.CreateContextItem(Context.Schema,       "dbo");
        }

        public static bool Ensure()
        {
            var connection = WorkbookContext.GetContextValue(Context.Db);

            if (String.IsNullOrEmpty(WorkbookContext.GetContextValue(Context.Environment)))
            {
                MessageBox.Show("Please select environment first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (String.IsNullOrEmpty(connection))
            {
                Logger.Warn("Db Connection is not set up");
                return false;
            }

            return true;
        }

        public static void SetEnvironment(string env)
        {
            try
            {
                Logger.Info($"Creating client proxy for environment {env}");

                var clientApp = new ClientApp(new Uri(WorkbookContext.GetContextValue(env)));

                Logger.Info($"Retriving db connectionString");

                var dbConnection = clientApp.GetClientDbProxy().GetConnection(Context.Db);                              

                WorkbookContext.ReplaceContextItem(Context.Environment, env);

                Logger.Info($"Db connection established as {dbConnection}");

                WorkbookContext.ReplaceContextItem(Context.Db, dbConnection);

                WorkbookContext.ReplaceContextItem(Context.Flex, dbConnection);

                //****************** Limits *************************

                //Logger.Info($"Retriving limit db connectionString");

                //var dbConnectionLimits = clientApp.GetClientDbProxy().GetConnection(Context.DbLimits);

                //Logger.Info($"Limit Db connection established as {dbConnectionLimits}");

                //WorkbookContext.ReplaceContextItem(Context.DbLimits, dbConnectionLimits);

                // save to settings file
                Logger.Info($"Saving env: {env} in user settings file");
                Settings.Default.Env = env;
                Settings.Default.Save();

                // set up default context
                var timeTravelContext = ServerFunc.GetDates();
                if (timeTravelContext != null)
                {
                    Logger.Info($"TimeTravel Context BussDate:{timeTravelContext.BusinessDate} LimitDate:{timeTravelContext.LimitEffectiveDate} Version:{timeTravelContext.Version}");
                    WorkbookContext.SetContextValue(Context.BusinessDate, timeTravelContext.BusinessDate.ToShortDateString());
                    WorkbookContext.SetContextValue(Context.LimitEffectiveDate, timeTravelContext.LimitEffectiveDate.ToShortDateString());
                    WorkbookContext.SetContextValue(Context.BusinessDateVersion, timeTravelContext.Version);
                    WorkbookContext.SetContextValue(Context.Hierarchy, timeTravelContext.Hierarchy.ToString());
                }

            }
            catch (Exception ex)
            {
                Logger.Error("Unable to establish database connection", ex);
                MessageBox.Show("Unable to establish database connection, please contact your local support.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public static void SetHierarchy(string hierarchy)
        {
            try
            {
                Logger.Info($"Creating client proxy for hierarchy {hierarchy}");

                var clientApp = new ClientApp(new Uri(WorkbookContext.GetContextValue(WorkbookContext.GetContextValue("ENVIRONMENT"))));

                Logger.Info($"Retriving db connectionString");

                var dbConnection = clientApp.GetClientDbProxy().GetConnection(Context.Db);

                WorkbookContext.ReplaceContextItem(Context.Hierarchy, hierarchy);

                Logger.Info($"Db connection established as {dbConnection}");

        //        WorkbookContext.ReplaceContextItem(Context.Db, dbConnection);
                
                // save to settings file
                Logger.Info($"Saving hierarchy: {hierarchy} in user settings file");
   //             Settings.Default.Hierarchy = hierarchy;
    //            Settings.Default.Save();

                // set up default context
                ServerFunc.SetHierarchyContext(hierarchy);
                
            }
            catch (Exception ex)
            {
                Logger.Error("Unable to establish database connection", ex);
                MessageBox.Show("Unable to establish database connection, please contact your local support.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void AutoOpen()
        {
            try
            {
                var com_addin = new AddInComRoot();
                com_addin.GetType().InvokeMember("DnaLibrary", BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.SetProperty, null, com_addin, new object[] { DnaLibrary.CurrentLibrary });
            
                ExcelComAddInHelper.LoadComAddIn(com_addin);
            }
            catch (Exception e)
            {
                MessageBox.Show("Error loading COM AddIn: " + e.ToString());
            }
        }

        public void AutoClose()
        {
           
        }
    }
}
