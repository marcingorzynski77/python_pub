using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace Mrap.Mars.XLL.Ribbon
{
    [ComVisible(true)]
    public class VbaProxy
    { // This becaomes the VBA addin.Object
        public string Hello()
        {
            return "Hello from Vba Proxy!";
        }

        public string[] DecodeMarsDataSet(string dataSet, string query)
        {
            var res = UserFunc.DecodeMarsDataSetHelper(dataSet, query);
            return MultiToSingle(res);
        }

        public string[] GetListOfColumns(string dataSet, string query)
        {
            return UserFunc.FormulaBreakDown(dataSet, query).MarsFunctionParser.Fields.ToArray();
        }

        public string[] GetListOfFilters(string dataSet, string query)
        {
            return UserFunc.FormulaBreakDown(dataSet, query).MarsFunctionParser.WhereFields.ToArray();
        }

        private string[] MultiToSingle(object[,] array)
        {
            int index = 0;
            int width = array.GetLength(0);
            int height = array.GetLength(1);
            string[] single = new string[width * height];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    single[index] = array[x, y].ToString();
                    index++;
                }
            }
            return single;
        }
        
        //args contains data with header
        public object[,] SaveFlexData(string[,] arg, string schema, bool patchingEnabled)
        {
            return UserFunc.SaveFlexData(arg, schema, patchingEnabled);
        }

    }
}