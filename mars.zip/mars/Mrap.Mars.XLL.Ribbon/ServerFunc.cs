﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Windows.Forms;

using log4net;
using Mrap.Mars.Common;
//using Mrap.Limits.DataAccess;
//using Mrap.Limits.Domain;
//using Mrap.Limits.Domain.DTO;
//using Mrap.Mars.XLL.Limit.ViewModels;
//using LimitRepository = Mrap.Mars.XLL.Limit.LimitRepository;


namespace Mrap.Mars.XLL.Ribbon
{
    public class TimeTravelContext
    {
        public DateTime BusinessDate { get; set; }
        public DateTime LimitEffectiveDate { get; set; }
        public string Version { get; set; }
        public DateTime VersionDateTime { get; set; }
        public Int32 Hierarchy { get; set; }
    }

    public class ServerFunc
    {
        private static ILog log =
            LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Name);

        public static TimeTravelContext GetDates()
        {
            log.Info($"Querying time travel dates");

            if (!Runtime.Ensure())
            {
                return new TimeTravelContext();
            }

            try
            {
                var connection = WorkbookContext.GetContextValue(Context.Db);

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = conn;
                        command.CommandTimeout = 60;
                        command.CommandType = CommandType.Text;
                        //command.CommandText = "select BusDate, Version, VersionDateTime, LimitDate, Hierarchy from target.vTimeTravel";
                        command.CommandText = "select BusDate, Version, VersionDateTime, LimitDate from target.vTimeTravel";

                        log.Info($"Executing {command.CommandText}");

                        conn.Open();

                        var timeTravel = new TimeTravelContext();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                timeTravel.BusinessDate = (DateTime) reader["BusDate"];
                                timeTravel.LimitEffectiveDate = (DateTime) reader["LimitDate"];
                                timeTravel.Version = reader["Version"].ToString();
                                timeTravel.VersionDateTime = (DateTime) reader["VersionDateTime"];
                //                timeTravel.Hierarchy = (Int32)reader["Hierarchy"];
                            }
                        }

                        return timeTravel;
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }

        public static string GetHierarchyEnum(string hierarchy)
        {
            log.Info($"Set the hierarchy context");

            if (!Runtime.Ensure())
            {
                return string.Empty;
            }

            try
            {
                var connection = WorkbookContext.GetContextValue(Context.Db);

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = conn;
                        command.CommandTimeout = 60;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "select Value from "
                                              + "target.FlexFactInstance I "
                                              + "join target.FlexFact F "
                                              +  "on F.FlexFactKey = I.FlexFactKey "
                                              +  "join target.FlexFactHierarchy H "
                                              +  "on H.FlexFactHierarchyKey = F.FlexFactHierarchyKey "
                                              +  "where H.[Description] = 'RingFencing.Hierarchy.Data' "
                                              +  "AND [Key] = '" + hierarchy + "'" ;

                        log.Info($"Executing {command.CommandText}");

                        conn.Open();

                        var i = command.ExecuteScalar();
                        return i.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }

        public static void SetHierarchyContext(string hierarchy)
        {
            log.Info($"Set the hierarchy context");

            if (!Runtime.Ensure())
            {
                return;
            }

            try
            {
                var connection = WorkbookContext.GetContextValue(Context.Db);

                using (SqlConnection conn = new SqlConnection(connection))
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = conn;
                        command.CommandTimeout = 60;
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "[target].[p_Set_HierarchyMode]";

                        var param = new SqlParameter("@Hierarchy", Convert.ToInt16(GetHierarchyEnum(hierarchy)))
                        {
                            Direction = ParameterDirection.Input,
                            DbType = DbType.Int16
                        };
                        command.Parameters.Add(param);                                     

                        log.Info($"Executing {command.CommandText}");

                        conn.Open();

                        var i = command.ExecuteNonQuery();

                        //Checks to confirm context set correctly 
                        command.CommandType = CommandType.Text;
                        command.CommandText = "select BusDate, Version, VersionDateTime, LimitDate, Hierarchy from target.vTimeTravel";
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Debug.WriteLine(reader["BusDate"]);
                                Debug.WriteLine(reader["LimitDate"]);
                                Debug.WriteLine(reader["Version"].ToString());
                                Debug.WriteLine(reader["VersionDateTime"]);
                                Debug.WriteLine(reader["Hierarchy"]);
                                Debug.WriteLine("test");
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }
    }
}
