﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using ExcelDna.Integration.Extensibility;

namespace Mrap.Mars.XLL.Ribbon
{
    [ComVisible(true)]
    public class AddInComRoot : ExcelDna.Integration.ExcelComAddIn
    {
        // : IDTExtensibility2, ie COM "AddIn".ExcelDNA finds this by magic.
        VbaProxy _helper;
        public AddInComRoot()
        {
        }
        public override void OnConnection(object Application,
            ext_ConnectMode ConnectMode, object AddInInst, ref Array custom)
        {
            _helper = new VbaProxy();

            AddInInst.GetType().InvokeMember("Object",
                BindingFlags.Public | BindingFlags.Instance | BindingFlags.SetProperty,
                null,
                AddInInst,
                new object[] { _helper });
        }
        public override void OnDisconnection(ext_DisconnectMode RemoveMode,
            ref Array custom)
        {
        }
        public override void OnAddInsUpdate(ref Array custom)
        {
        }
        public override void OnStartupComplete(ref Array custom)
        {
        }
        public override void OnBeginShutdown(ref Array custom)
        {
        }
    }
}
