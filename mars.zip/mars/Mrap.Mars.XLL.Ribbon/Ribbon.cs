﻿
 using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
﻿using System.Runtime.Remoting.Contexts;
﻿using System.Text;
﻿using System.Threading.Tasks;
﻿using System.Windows.Forms;
﻿using ExcelDna.Integration;
﻿using ExcelDna.Integration.CustomUI;
using log4net;
﻿using Mrap.Common.Util.Task.SubTask;
﻿using Mrap.Common.Util.Wcf.Invoker;
//using Mrap.Limits.DataAccess;
//﻿using Mrap.Limits.Domain;
﻿using Mrap.Mars.Common;
﻿using Context = Mrap.Mars.Common.Context;


namespace Mrap.Mars.XLL.Ribbon
{
    /// <summary>
    /// Ribbon documentation https://msdn.microsoft.com/en-us/library/aa722523(v=office.12).aspx
    /// </summary>
    [ComVisible(true)]
    public class Ribbon : ExcelRibbon
    {
        private static readonly ILog Logger = LogManager.GetLogger("Mrap.Mars.XLL.Ribbon");

        private static IRibbonUI RibbonUi { get; set; }
    
        //private ClientApp ClientApp { get; set; }
        public void Environment_OnAction(IRibbonControl control, string env, int index)
        {
            //Set environment
            Runtime.SetEnvironment(env);            
            ExcelAsyncUtil.QueueMacro("SetXLAMEnvironment");
            RibbonUi.InvalidateControl("ddHierarchy");
        }

        public void Hierarchy_OnAction(IRibbonControl control, string hierarchy, int index)
        {
            //string hierarchyEnum;
            //if (hierarchy == "NORMAL") hierarchyEnum = "0";
            //else if (hierarchy == "RELEASECANDIDATE") hierarchyEnum = "1";
            //else if (hierarchy == "RINGFENCING") hierarchyEnum = "2";
            //else hierarchyEnum = "0";

            Runtime.SetHierarchy(hierarchy);
            //ExcelAsyncUtil.QueueMacro("SetXLAMHierarchy");
        }

        public void OnLoad(IRibbonUI ribbon)
        {
            RibbonUi = ribbon;

            //Settings.Default.Initialize();
            // check if env is saved
            var env = Settings.Default.Env;
            if (!String.IsNullOrEmpty(env))
            {
                Runtime.SetEnvironment(env);
            }
            else
            {
                Runtime.SetEnvironment("PROD");
            }
            
            //Display any alerts
            ExcelAsyncUtil.QueueMacro("CheckForAlerts");
        }

        /*
        private static void PopulateLimits()
        {
            var task = Task.Factory.StartNew(
                 () =>
                 {
                     try
                     {
                         if (WorkbookContext.GetContextValue(Context.DbLimits) != String.Empty)
                         {
                             var limits = new Limit.LimitRepository().Get();
                             Context.SetLimitCache(limits);
                             //WorkbookContext.SetObject(Context.LimitCache, limits);
                         }
                         else
                         {
                             Logger.Info("Unable to populate limits because Db connection is not yet set");
                         }
                     }
                     catch (Exception ex)
                     {
                         Logger.Error("Unable to populate limit cache", ex);
                     }
                 });
        }
        */

        [ExcelFunction(Description = "Retrieve value from the workbook context for the given key")]
        public static void InvalidateRibbon()
        {
            RibbonUi.Invalidate();
        }

        public static void ResizeArrayVBA(string blah)
        {
            ExcelAsyncUtil.QueueMacro("ResizeArrayVBA");
        }

        public void OnQueryCatalogueClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowQueryCatalogue");
        }

        public void ShowDatasetQueryClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowDatasetQuery");
        }

        public void ShowSummaryQueryClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowSummaryQuery");
        }
        
        public void ShowSpecificQueryClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowSpecificQuery");
        }

        public void ShowFlexDataLoaderClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowFlexDataLoader");
        }
        
        public void LoadFlexDataClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("LoadFlexData");
        }               

        public void ShowPredefinedQueryClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowPredefinedQuery");
        }

        public void ShowReportClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowReportGenerator");
        }

        public void OnLimitCatalogueClick(IRibbonControl control)
        {
            MessageBox.Show("Limits button temporarily disabled.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //Logger.Info("Opening Limit Browser");
            //if (Runtime.Ensure())
            //{
            //    try
            //    {
            //        Application.UseWaitCursor = true;
            //        var window = new Limit.Limits();
            //        window.Show();
            //        Application.UseWaitCursor = false;
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("There was an error detected:" + ex.Message, "Info", MessageBoxButtons.OK,
            //            MessageBoxIcon.Error);
            //    }
            //}
        }

        public string GetSelectedItemID(IRibbonControl control)
        {
            var env = WorkbookContext.GetContextValue(Context.Environment);
            if (!String.IsNullOrEmpty(env))
            {
                return env;
            }

            return String.Empty;
        }



        public string GetSelectedHierarchyID(IRibbonControl control)
        {
            var hierarchy = WorkbookContext.GetContextValue(Context.Hierarchy);
            if (!String.IsNullOrEmpty(hierarchy))
            {
                return hierarchy;
            }

            return String.Empty;
        }



        public void OnCommentsClick(IRibbonControl control)
        {
            //do something
        }

        public void OnShowMonitorClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("DisplayMonitorWorksheets");
        }

        public void OnRefreshWorkbookClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("RefreshWorkbook");
        }

        public void OnRefreshWorkSheetClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("RefreshWorksheet");
        }

        public void OpenBusDateSelectionForm(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowBusDateSelector");
        }

        public void OpenLimitDateSelectionForm(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("ShowLimitDateSelector");
        }

        public string BusDate_GetText(IRibbonControl control)
        {
            return String.Concat("Business Date: ", WorkbookContext.GetContextValue(Context.BusinessDate));
        }

        public string LimitDate_GetText(IRibbonControl control)
        {
            return String.Concat("Limit Date: ", WorkbookContext.GetContextValue(Context.LimitEffectiveDate));
        }

        public string BusDateVersion_GetText(IRibbonControl control)
        {
            string sContext;
            sContext = WorkbookContext.GetContextValue(Context.BusinessDateVersion);
            if (sContext == "1")
            {
                return string.Concat(@"        (", WorkbookContext.GetContextValue(Context.BusinessDate), " (Latest))");
            }
            else
            {
                return string.Concat(@"        (",sContext,")");
            }
            
           // return WorkbookContext.GetContextValue(Context.BusinessDateVersion);
        }

        public string BusDate_Changed(IRibbonControl control)
        {
            return WorkbookContext.GetContextValue(Context.BusinessDate);
        }

        public string LimitDate_Changed(IRibbonControl control)
        {
            return WorkbookContext.GetContextValue(Context.LimitEffectiveDate);
        }

        public void OnInfoClick(IRibbonControl control)
        {
            HelpWindow window = new HelpWindow();
            window.Show();
        }

        public void OnHiveClick(IRibbonControl control)
        {
            ExcelAsyncUtil.QueueMacro("OpenHive");
        }

        public string GetRibbonVersionDetail(IRibbonControl control)
        {
            var assembly = new AssemblyName(Assembly.GetExecutingAssembly().FullName);
            
            WorkbookContext.SetContextValue("AddinVersion", assembly.Version.ToString());
            
            //Check version is latest            
            ExcelAsyncUtil.QueueMacro("CheckAddinVersion");
            return assembly.Version.ToString();
        }


        // This is internal bookkeeping 
        //bool _btnIsEnabled = true;

        public bool btn_GetEnabled(IRibbonControl control)
        {
            //if (WorkbookContext.GetContextValue(Context.Environment)=="PAR")
                return true;
            //else
            //    return false;
        }

        //internal void SetBtnEnabled(bool isEnabled)
        //{
        //    _btnIsEnabled = isEnabled;
        //    RibbonUi.InvalidateControl("ddHierarchy");
        //}

    }
}


