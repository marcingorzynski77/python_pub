﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;

namespace Mrap.Mars.XLL.Ribbon
{
    public class WorkbookContext
    {
        private static readonly Dictionary<string,string> _context = new Dictionary<string, string>();

        [ExcelFunction(Description = "Retrive value from the workbbok context for the given key")]
        public static string GetContextValue(string key)
        {
            if (!_context.ContainsKey(key))
            {
                return String.Empty;
            }
            else
            {
                return _context[key];
            }
        }

        [ExcelFunction(Description = "set value for the workbbok context for the given key")]
        public static bool SetContextValue(string key, string value)
        {
            if (!_context.ContainsKey(key))
            {
                return false;
            }
            else
            {
                _context[key] = value;
                return true;
            }
        }

        [ExcelFunction(Description = "Create new key value combination")]
        public static bool CreateContextItem(string key, string value)
        {
            if (_context.ContainsKey(key))
            {
                return false;
            }
            else
            {
                _context.Add(key,value);
                return true;
            }
        }

        [ExcelFunction(Description = "Create new key value combination")]
        public static void ReplaceContextItem(string key, string value)
        {
            if (!_context.ContainsKey(key))
            {
                _context.Add(key, value);
            }
            else
            {
                _context[key] = value;
            }
        }
    }
}
