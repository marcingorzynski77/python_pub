﻿using System;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm;

namespace Mrap.Mars.XLL.Ribbon.ViewModels
{
    [POCOViewModel]
    public class LimitViewModel
    {

    }
}