﻿namespace Mrap.Mars.XLL.Ribbon
{
    public class Context
    {
        public const string Environment = "ENVIRONMENT";
        public const string Local = "LOCAL";
        public const string Dev = "DEV";
        public const string Uat = "UAT";
        public const string Prod = "PROD";
        public const string Dr = "DR";
        public const string Db = "DB";
        public const string DbLimits = "Limits";
        public const string WorkbookFilePath = "WorkbookFilePath";
        public const string WorkbookFileName = "WorkbookFileName";
        public const string UserName = "UserName";
    }
}