﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Mrap.Mars.XLL.Ribbon
{
    public partial class HelpWindow : DevExpress.XtraEditors.XtraForm
    {
        public HelpWindow()
        {
            InitializeComponent();
        }
    }
}