
DECLARE @Message VARCHAR(255)
DECLARE @SchemaFlexFactHierarchyKey INT
DECLARE @SchemaName VARCHAR(255)

DECLARE SchemaCursor CURSOR FAST_FORWARD
  FOR SELECT FlexFactHierarchyKey, [Description]
      FROM target.FlexFactHierarchy 
      WHERE Name LIKE '%Schema'
  
OPEN SchemaCursor  

FETCH NEXT FROM SchemaCursor   
INTO @SchemaFlexFactHierarchyKey, @SchemaName  

WHILE @@FETCH_STATUS = 0  
BEGIN  
 
    SET @Message = 'Checking: ''' + @SchemaName + ''''
    PRINT @Message    


    DECLARE @DataKey INT

    SELECT @DataKey = FlexFactHierarchyKey
      FROM target.FlexFactHierarchy 
     WHERE Name = 'Data'
       AND ParentFlexFactHierarchyKey = @SchemaFlexFactHierarchyKey

    -- Check if schema has data key defined
    IF @DataKey IS NULL
    BEGIN
        SET @Message = 'Schema: ''' + @SchemaName + ''' does not have defined data key'
        PRINT @Message 
    END

    DECLARE @MetaDataKey INT
    -- Check if schema has meta data key defined
    SELECT @MetaDataKey = FlexFactHierarchyKey
                     FROM target.FlexFactHierarchy 
                    WHERE Name = 'MetaData'
                      AND ParentFlexFactHierarchyKey = @SchemaFlexFactHierarchyKey

    IF @MetaDataKey IS NULL
    BEGIN
        SET @Message = 'Schema: ''' + @SchemaName + ''' does not have defined meta data key'
        PRINT @Message 
    END

    -- Check if schema has at least one dimension defined
    IF NOT EXISTS (SELECT 1 
                     FROM target.FlexFactHierarchy 
                    WHERE Name = 'Dimension'
                      AND ParentFlexFactHierarchyKey = @MetaDataKey)
    BEGIN
        SET @Message = 'Schema: ''' + @SchemaName + ''' does not have defined dimension'
        PRINT @Message 
    END

    -- Check if schema has at least one dimension defined
    IF NOT EXISTS (SELECT 1 
                     FROM target.FlexFactHierarchy 
                    WHERE Name = 'Fact'
                      AND ParentFlexFactHierarchyKey = @MetaDataKey)
    BEGIN
        SET @Message = 'Schema: ''' + @SchemaName + ''' does not have defined fact'
        PRINT @Message 
    END

    DECLARE @FlexFactKey INT, 
            @Key VARCHAR(255), 
            @KeyCount INT

    DECLARE FlexFactCursor CURSOR FAST_FORWARD
        FOR SELECT FF.FlexFactKey, FFI.[Key], COUNT(FFI.[Value]) AS KeyCount
       FROM target.FlexFact FF
      INNER JOIN target.FlexFactInstance FFI 
         ON FF.FlexFactKey = FFI.FlexFactKey
      WHERE FF.FlexFactHierarchyKey = @DataKey 
      GROUP BY FF.FlexFactKey, FFI.[Key]
    
    OPEN FlexFactCursor  

    FETCH NEXT FROM FlexFactCursor   
    INTO @FlexFactKey, @Key, @KeyCount 

    WHILE @@FETCH_STATUS = 0  
    BEGIN  

        IF @KeyCount > 1 
        BEGIN
            SET @Message = 'Fact (id:' + @FlexFactKey + ') in Schema ''' + @SchemaName + ''' has multiple entries for ''' + @Key + ''''
            PRINT @Message 
        END

        IF NOT EXISTS (SELECT 1 
                         FROM target.FlexFactHierarchy FFH1
                        INNER JOIN target.FlexFactHierarchy FFH2
                           ON FFH1.Description = FFH2.Description + '.Fact.Name'
                        WHERE FFH2.FlexFactHierarchyKey = @MetaDataKey)

    -- Check if all data is stored against the data key
    --IF EXiSTS (SELECT 1 
    --             FROM target.FlexFact 
    --            WHERE FlexFactHierarchyKey NOT IN (SELECT FlexFactHierarchyKey 
    --                                                 FROM target.FlexFactHierarchy 
    --                                                WHERE Name = 'Data'
    --                                                  AND ParentFlexFactHierarchyKey = @SchemaFlexFactHierarchyKey))
    --BEGIN
    --    SET @Message = 'Schema: ''' + @SchemaName + ''' has data storted against wrong key'
    --    PRINT @Message 
    --END
        FETCH NEXT FROM FlexFactCursor   
        INTO @FlexFactKey, @Key, @KeyCount 
    END

    CLOSE FlexFactCursor;  
    DEALLOCATE FlexFactCursor; 

    FETCH NEXT FROM SchemaCursor   
    INTO @SchemaFlexFactHierarchyKey, @SchemaName  

END
   
CLOSE SchemaCursor;  
DEALLOCATE SchemaCursor; 


DECLARE @Count INT


SELECT @Count = COUNT(*)
  FROM target.FlexFact 
 WHERE FlexFactHierarchyKey NOT IN (SELECT FlexFactHierarchyKey 
                                      FROM target.FlexFactHierarchy 
                                      WHERE Name = 'Data')
IF @Count > 0
BEGIN
    SET @Message = 'Key Facts storted against wrong key'
    PRINT @Message 
END