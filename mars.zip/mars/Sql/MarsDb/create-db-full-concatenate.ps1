Param (
    [Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbName = "MaRS_MainStack",
    [Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbInstance = "FMU-D8-3076\BRIDGEU01"
)

Write-Output "Attempting to create database "
Write-Output $DbInstance $DbName 
Write-Output "------------------------------"

$DatabaseServer = $DbInstance.replace($DbInstance.Substring(0, $DbInstance.IndexOf('\') + 1), '')

Write-Output "Creating database. Params: '$DbInstance' '$DbName'"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.ConnectionInfo.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Management.Sdk.Sfc.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Smo.dll"

function Invoke-Sqlcmd-Smo
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$false)] [string]$Connection, 
    [Parameter(Position=1, Mandatory=$false)] [string]$ServerInstance, 
    [Parameter(Position=2, Mandatory=$false)] [string]$Database, 
    [Parameter(Position=3, Mandatory=$false)] [string]$Query, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$QueryTimeout=600, 
    [Parameter(Position=7, Mandatory=$false)] [Int32]$ConnectionTimeout=60, 
    [Parameter(Position=8, Mandatory=$false)] [ValidateScript({test-path $_})] [string]$InputFile
    ) 

    if ($InputFile) { 
        $filePath = $(resolve-path $InputFile).path 
        $Query =  [System.IO.File]::ReadAllText("$filePath") 
    }

    $conn = new-object System.Data.SqlClient.SQLConnection 

    if ($Connection) {
        $ConnectionString = $Connection
    } else {
        if ($Username) {
            $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance, $Database, $Username, $Password, $ConnectionTimeout
        } else {
            $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance, $Database, $ConnectionTimeout
        } 
    }
    #Write-Output "ConnectionString: '$ConnectionString'"

    $conn.ConnectionString = $ConnectionString 
     
    $serverConnection= new-object Microsoft.SqlServer.Management.Common.ServerConnection($conn)
    $server = new-object Microsoft.SqlServer.Management.Smo.Server($serverConnection)
    
	$server.ConnectionContext.ExecuteNonQuery($Query)
    $conn.Close()
	
} 

#Add script locations in order of dependence
$Folders = New-Object string[] 9
$Folders[0] = $PSScriptRoot + "\Schemas"
$Folders[1] = $PSScriptRoot + "\Types"
$Folders[2] = $PSScriptRoot + "\Tables"
$Folders[3] = $PSScriptRoot + "\Functions"
$Folders[4] = $PSScriptRoot + "\Views"
$Folders[5] = $PSScriptRoot + "\Synonyms"
$Folders[6] = $PSScriptRoot + "\Procedures"
$Folders[7] = $PSScriptRoot + "\Data"
$Folders[8] = $PSScriptRoot + "\UsersAndRoles"


$CreateDbScript =  $PSScriptRoot + "\CreateDatabase.sql"

#Run the scripts

try
{

    # first update create-database script

    get-content $CreateDbScript | % { $_.replace("XXX_DBNAME_XXX",$DbName) } | % { $_.replace("XXX_DBSERVERNAME_XXX",$DatabaseServer) } -outvariable sqlarray | Out-Null
    $sql = $sqlarray -join "`n"

    Invoke-Sqlcmd-Smo -ServerInstance $DbInstance -Database 'master' -Query $sql 

    #Insert groups of scripts in specific order
    Foreach ($path in $Folders)
    {
        Write-Output "Folder -- $path"
        
        $Scripts = Get-ChildItem $path | Sort-Object  #-Include *.sql
        
        
        Foreach ($script in $Scripts)
        {
            if ($script -match "[0-9][0-9][0-9][0-9][0-9].*.sql")
            {
                Write-Output "$path\$script"
                Invoke-Sqlcmd-Smo -ServerInstance $DbInstance -Database $DbName -InputFile "$path\$script" 
            }
            else
            {
                #write "Ignoring file: $path\$script"
            }
        }
        
    }
    
}
catch 
{
    $ex = $_.Exception
    Write-Error "$ex.Message" 
	exit 1
}
finally
{
    
}