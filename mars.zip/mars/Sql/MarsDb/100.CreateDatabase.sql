
USE [master]


IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'MaRS_RC_1_6_test')
BEGIN
	RAISERROR('Database MaRS_RC_1_6_test already exists.  Drop database first.', 1, 1) WITH NOWAIT
	
	SELECT '!! ERROR !!', 'Database MaRS_RC_1_6_test already exists.  Drop database first.'
	RETURN
END
ELSE
BEGIN
	IF 'BRIDGEU01' = 'TRIDENTD01'
	BEGIN
		CREATE DATABASE [MaRS_RC_1_6_test] ON  PRIMARY 
		( NAME = N'MaRS_RC_1_6_test', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test.mdf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1048576KB )
		 LOG ON 
		( NAME = N'MaRS_RC_1_6_test_log', FILENAME = N'G:\Log\MSSQL10_50.BRIDGEU01\MSSQL\Log\MaRS_RC_1_6_test_log.ldf' , SIZE = 1000000KB , MAXSIZE = 2048GB , FILEGROWTH = 1048576KB )
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_RiskMeasurePnlFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_RiskMeasurePnlFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_RiskMeasurePnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_RiskMeasurePnlFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated]

		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated]

		
	END
	ELSE IF 'BRIDGEU01' = 'BRIDGED01' OR 'BRIDGEU01' = 'BRIDGEU01'
	BEGIN
		CREATE DATABASE [MaRS_RC_1_6_test] ON  PRIMARY 
		( NAME = N'MaRS_RC_1_6_test', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test.mdf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1048576KB )
		 LOG ON 
		( NAME = N'MaRS_RC_1_6_test_log', FILENAME = N'H:\Log\MSSQL10_50.BRIDGEU01\MSSQL\Log\MaRS_RC_1_6_test_log.ldf' , SIZE = 1000000KB , MAXSIZE = 2048GB , FILEGROWTH = 1048576KB )

		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_RiskMeasureFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_RiskMeasureFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_RiskMeasurePnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_RiskMeasureFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_MarketDataFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_VarFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_RiskMeasureTradeFact_Part_Unallocated]

		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_TradeLevelFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_AggregatedFact_Part_Unallocated]

		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILEGROUP [MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated]
		ALTER DATABASE [MaRS_RC_1_6_test] ADD FILE ( NAME = N'MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGEU01\MSSQL\DATA\MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_RC_1_6_test_FG_TradeRuleFact_Part_Unallocated]

		--Create Partition Function PnlFact_RangePartFunction (datetime2) as Range LEFT For Values ()
		

		--Create Partition Scheme PnlFact_RangePartScheme as Partition PnlFact_RangePartFunction To ([MaRS_RC_1_6_test_FG_PnlFact_Part_Unallocated])
		--use [master]
		--go
	END
	
	
END




ALTER DATABASE [MaRS_RC_1_6_test] SET COMPATIBILITY_LEVEL = 100


IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
	EXEC [MaRS_RC_1_6_test].[dbo].[sp_fulltext_database] @action = 'enable'
end


ALTER DATABASE [MaRS_RC_1_6_test] SET ANSI_NULL_DEFAULT OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET ANSI_NULLS OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET ANSI_PADDING OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET ANSI_WARNINGS OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET ARITHABORT OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET AUTO_CLOSE OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET AUTO_CREATE_STATISTICS ON 

ALTER DATABASE [MaRS_RC_1_6_test] SET AUTO_SHRINK OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET AUTO_UPDATE_STATISTICS ON 

ALTER DATABASE [MaRS_RC_1_6_test] SET CURSOR_CLOSE_ON_COMMIT OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET CURSOR_DEFAULT  GLOBAL 

ALTER DATABASE [MaRS_RC_1_6_test] SET CONCAT_NULL_YIELDS_NULL OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET NUMERIC_ROUNDABORT OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET QUOTED_IDENTIFIER OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET RECURSIVE_TRIGGERS OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET  DISABLE_BROKER 

ALTER DATABASE [MaRS_RC_1_6_test] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET DATE_CORRELATION_OPTIMIZATION OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET TRUSTWORTHY ON 

ALTER DATABASE [MaRS_RC_1_6_test] SET ALLOW_SNAPSHOT_ISOLATION OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET PARAMETERIZATION SIMPLE 

ALTER DATABASE [MaRS_RC_1_6_test] SET READ_COMMITTED_SNAPSHOT OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET HONOR_BROKER_PRIORITY OFF 

ALTER DATABASE [MaRS_RC_1_6_test] SET READ_WRITE 

ALTER DATABASE [MaRS_RC_1_6_test] SET RECOVERY SIMPLE 

ALTER DATABASE [MaRS_RC_1_6_test] SET  MULTI_USER 

ALTER DATABASE [MaRS_RC_1_6_test] SET PAGE_VERIFY CHECKSUM  

ALTER DATABASE [MaRS_RC_1_6_test] SET DB_CHAINING OFF 



EXEC sys.sp_db_vardecimal_storage_format N'MaRS_RC_1_6_test', N'ON'


PRINT 'MaRS database created'
