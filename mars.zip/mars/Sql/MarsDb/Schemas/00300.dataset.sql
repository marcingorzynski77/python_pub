IF  EXISTS (SELECT * FROM sys.schemas WHERE name = N'dataset')
	DROP SCHEMA [dataset]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'dataset')
	EXEC sys.sp_executesql N'CREATE SCHEMA [dataset] AUTHORIZATION [dbo]'
GO
