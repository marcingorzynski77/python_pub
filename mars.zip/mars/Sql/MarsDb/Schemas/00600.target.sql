IF  EXISTS (SELECT * FROM sys.schemas WHERE name = N'target')
	DROP SCHEMA [target]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'target')
	EXEC sys.sp_executesql N'CREATE SCHEMA [target] AUTHORIZATION [dbo]'
GO
