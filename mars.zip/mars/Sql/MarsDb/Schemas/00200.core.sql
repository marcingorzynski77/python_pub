IF  EXISTS (SELECT * FROM sys.schemas WHERE name = N'core')
	DROP SCHEMA [core]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'core')
	EXEC sys.sp_executesql N'CREATE SCHEMA [core] AUTHORIZATION [dbo]'
GO
