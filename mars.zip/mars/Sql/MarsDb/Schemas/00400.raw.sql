IF  EXISTS (SELECT * FROM sys.schemas WHERE name = N'raw')
	DROP SCHEMA [raw]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'raw')
	EXEC sys.sp_executesql N'CREATE SCHEMA [raw] AUTHORIZATION [dbo]'
GO
