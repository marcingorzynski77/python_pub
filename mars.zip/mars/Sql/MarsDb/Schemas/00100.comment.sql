IF  EXISTS (SELECT * FROM sys.schemas WHERE name = N'comment')
	DROP SCHEMA [comment]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'comment')
	EXEC sys.sp_executesql N'CREATE SCHEMA [comment] AUTHORIZATION [dbo]'
GO
