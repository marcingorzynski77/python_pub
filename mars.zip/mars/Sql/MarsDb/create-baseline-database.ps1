Param (
    [Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbRebuild = "0",
	[Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbInstance = "FMX-D8-3076\BRIDGEX01",
	[Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbName = "MaRS_XXXX"
    
)

Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.ConnectionInfo.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Management.Sdk.Sfc.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Smo.dll"

Write-Output "Attempting to drop database "
Write-Output "instance : $DbInstance"
Write-Output "database : $DbName"

Write-Output "------------------------------"

if ($DbRebuild -eq "0")
{
	Write-Output "drop releaseCandidate database: will not rebuild database";
	exit ;
}


function Invoke-Sqlcmd-Smo
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$false)] [string]$Connection, 
    [Parameter(Position=1, Mandatory=$false)] [string]$ServerInstance, 
    [Parameter(Position=2, Mandatory=$false)] [string]$Database, 
    [Parameter(Position=3, Mandatory=$false)] [string]$Query, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$QueryTimeout=600, 
    [Parameter(Position=7, Mandatory=$false)] [Int32]$ConnectionTimeout=60, 
    [Parameter(Position=8, Mandatory=$false)] [ValidateScript({test-path $_})] [string]$InputFile
    ) 

    if ($InputFile) { 
        $filePath = $(resolve-path $InputFile).path 
        $Query =  [System.IO.File]::ReadAllText("$filePath") 
    }

    $conn = new-object System.Data.SqlClient.SQLConnection 

    if ($Connection) {
        $ConnectionString = $Connection
    } else {
        if ($Username) {
            $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance, $Database, $Username, $Password, $ConnectionTimeout
        } else {
            $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance, $Database, $ConnectionTimeout
        } 
    }
    #Write-Output "ConnectionString: '$ConnectionString'"

    $conn.ConnectionString = $ConnectionString 
     
    $serverConnection= new-object Microsoft.SqlServer.Management.Common.ServerConnection($conn)
    $server = new-object Microsoft.SqlServer.Management.Smo.Server($serverConnection)
    
	$server.ConnectionContext.ExecuteNonQuery($Query)
    $conn.Close()
	
} 

try
{

	$path = $PSScriptRoot + "\ReleaseScript"
	$schema = $path + "\100.Release.1.0.schema.sql"
	$patch = $path + "\101.Release.1.0.PatchJun2017.sql"
	$rolesAndPermissions = $path + "\102.Release.1.0.RolesAndPermissions.sql"
	
	$patches = {
		"101.Release.1.4.PatchSchema.sql" ,
		"103.Release.1.4.RolesAndPermissions.sql",
		"101.Release.1.5.PatchSchema.sql",
		"101.release.1.5.1.ViewPatch.sql",
		"100.release.1.5.2.ViewPatch.sql",
		"100.release.1.5.3.patch_Conform_TradeRule.sql",
		"105.release.1.5.3.Patch_Run_AggregatedQuery.sql",
		"100.release.1.5.4.patch_Conform_Hierarchy.sql",
		"101.release.1.5.4.patch_CreateStar_Hierarchy.sql",
		"102.release.1.5.4.patch_CreateStar_SimraFORiskMeasures.sql",
		"103.release.1.5.4.patch_Conform_HierarchyBook.sql",
		"104.release.1.5.4.create_CheckGoldenSourceMappings.sql",
		"106.release.1.5.4.patch_Staging2Target.sql",
		"107.release.1.5.4.patch__RRRAggregatedDrillDown.sql",
		"108.release.1.5.4.patch__vRiskMeasure.sql",
		"104.release.1.5.5.Recs.sql"}
	
	Write-Output "schema file : $schema";
	Write-Output "patch file : $patch";
	Write-Output "perms  file : $rolesAndPermissions";

	Write-Output "----------------------------------";

	Invoke-Sqlcmd-Smo -ServerInstance $DbInstance -Database "master" -InputFile $schema
	Invoke-Sqlcmd-Smo -ServerInstance $DbInstance -Database "master" -InputFile $rolesAndPermissions
	Invoke-Sqlcmd-Smo -ServerInstance $DbInstance -Database "master" -InputFile $patch

	foreach($patchIter in $pathes)
	{
		$filePath = $path + "\" + $patchIter
		Invoke-Sqlcmd-Smo -ServerInstance $DbInstance -Database "master" -InputFile $patch
	}

}
catch 
{
    $ex = $_.Exception
    Write-Error "$ex.Message" 
	exit 1
}