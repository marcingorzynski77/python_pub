IF OBJECT_ID ('core.MurexSensitivities_InstrumentType') IS NOT NULL
	DROP TABLE core.MurexSensitivities_InstrumentType
GO

CREATE TABLE core.MurexSensitivities_InstrumentType
(
	 CoreInstrumentTypeKey	BIGINT IDENTITY NOT NULL
	,CoreSourceKey			BIGINT NOT NULL
	,InstrumentType			VARCHAR (50) NOT NULL
	,InstrumentSubType		VARCHAR (50) NOT NULL
)
GO
