IF OBJECT_ID ('staging.HierarchyBook') IS NOT NULL
	DROP TABLE staging.HierarchyBook
GO

CREATE TABLE [staging].[HierarchyBook](
	[CoreHierarchyBookKey] [bigint] NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeId] [bigint]  NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[SourceKey] [bigint] NULL,
	[BookCad2] [bit] NULL,
	[Trading] [bit] NULL,
	[AppliedRules] [varchar](100) NULL,
	[BookSystem] [varchar](50) NULL,
	[HierarchyBookKey] BIGINT NULL
) ON [PRIMARY]
GO
