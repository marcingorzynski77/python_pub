IF OBJECT_ID ('raw.Holiday') IS NOT NULL
	DROP TABLE raw.Holiday
GO

CREATE TABLE raw.Holiday
	(
	  [Date]             DATETIME2 NOT NULL
	, Location           VARCHAR (20) NOT NULL
	, HolidayDescription VARCHAR (30)
	, CONSTRAINT PK_Holiday_1 PRIMARY KEY ([Date], Location)
	)
GO

