IF OBJECT_ID ('core.GDIRiskMeasureTrade_Trade') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_Trade
GO

CREATE TABLE core.GDIRiskMeasureTrade_Trade
	(
	  CoreTradeKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey	BIGINT NOT NULL
	, TradeReference		VARCHAR (255) NOT NULL
	, CONSTRAINT PK_GDIRiskMeasureTrade_Trade PRIMARY KEY (coreTradeKey)
	)
GO