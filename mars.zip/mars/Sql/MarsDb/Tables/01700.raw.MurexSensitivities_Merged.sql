IF OBJECT_ID ('raw.MurexSensitivities_Merged') IS NOT NULL
	DROP TABLE raw.MurexSensitivities_Merged
GO

CREATE TABLE raw.MurexSensitivities_Merged
	(
		  BusDate				DateTime2
		, FINANCIAL_CONTRACT	BIGINT
		, TRADEDATETIME			DATETIME2
		, Product				VARCHAR (50)
		, [Index]				VARCHAR (50)
		, Portfolio				VARCHAR (50)
		, TradeType				VARCHAR (50)
		, [Buy/Sell]			VARCHAR (5)
		, MIRRORED				BIGINT
		, TP_CMIQ0				VARCHAR (50)
		, Nominal_CCY			VARCHAR (50)
		, Nominal				FLOAT
		, Nominal_GBP			FLOAT
		, Maturity_date			DATETIME2
		, Delivery_date			DATETIME2
		, [P&L_CCY]				VARCHAR (50)
		, Closing_MTM			FLOAT
		, Delta					FLOAT
		, Delta_GBP				FLOAT
		, Gamma					FLOAT
		, Gamma_GBP				FLOAT
		, Vega					FLOAT
		, Vega_GBP				FLOAT
		, Theta					FLOAT
		, Theta_GBP				FLOAT
		, Rho					FLOAT
		, Rho_GBP				FLOAT
		, [Rho(f)]				FLOAT
		, Rhof_GBP				FLOAT
		, Swap_points			FLOAT
		, Instrument			VARCHAR (50)
		, Call_Put				VARCHAR (50)
		, Strike				FLOAT
		, Status				VARCHAR (50)
		, [Booking Units]		VARCHAR (50)
		, Units					VARCHAR (20)
	)
GO
