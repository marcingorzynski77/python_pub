﻿IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_TradeRule]') AND type in (N'U'))
DROP TABLE [core].[RRR_TradeRule]
GO

CREATE TABLE [core].[RRR_TradeRule] (
    [CoreTradeRuleKey] BIGINT         IDENTITY (1, 1) NOT NULL,
    [CoreSourceKey]    INT            NOT NULL,
    [BusDate]          DATETIME2 (7)  NULL,
    [TradeReference]   VARCHAR (255)  NOT NULL,
    [RuleName]         VARCHAR (1000) NOT NULL,
    [FiredAt]          DATETIME2 (7)  NOT NULL
    --[RuleType]		   VARCHAR (100)  NOT NULL,
	--[RuleValue]		   VARCHAR (255)  NULL
);


