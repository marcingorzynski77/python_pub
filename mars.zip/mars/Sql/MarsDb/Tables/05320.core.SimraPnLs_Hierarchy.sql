IF OBJECT_ID ('core.SimraPnLs_Hierarchy') IS NOT NULL
	DROP TABLE core.SimraPnLs_Hierarchy
GO

CREATE TABLE core.SimraPnLs_Hierarchy
	(
	  CoreHierarchyKey 	BIGINT NOT NULL
	, CoreSourceKey		BIGINT
	, NodeName			VARCHAR (50) NOT NULL
	, NodeType			CHAR (2) NOT NULL
	, BookLegalEntity	VARCHAR (20)
	, HierarchyString	VARCHAR (900)
	, BookSystem		VARCHAR (50) NOT NULL
	, HierarchyTag		INT NULL
	, CONSTRAINT PK_SimraPnLs_Hierarchy PRIMARY KEY (CoreHierarchyKey)
	)
GO
