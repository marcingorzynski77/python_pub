IF OBJECT_ID ('core.Limit_Hierarchy') IS NOT NULL
	DROP TABLE core.Limit_Hierarchy
GO

CREATE TABLE core.Limit_Hierarchy
	(
		[CoreHierarchyKey] [bigint] IDENTITY(1,1) NOT NULL,
		[CoreSourceKey] [bigint] NOT NULL,
		[HierarchyString] [varchar](1000) NOT NULL,
		[NodeName] [varchar](50) NOT NULL,
		[NodeType] [varchar](2) NOT NULL,
		[BookSystem] [varchar](50) NOT NULL,
		[HierarchyTag] [int] NOT NULL
		, CONSTRAINT PK_CoreHierarchyKey PRIMARY KEY (CoreHierarchyKey)
	)
GO
