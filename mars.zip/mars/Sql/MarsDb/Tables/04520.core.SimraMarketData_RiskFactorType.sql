IF OBJECT_ID ('core.SimraMarketData_RiskFactorType') IS NOT NULL
	DROP TABLE core.SimraMarketData_RiskFactorType
GO

CREATE TABLE core.SimraMarketData_RiskFactorType
	(
	  CoreRiskFactorTypeKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey			BIGINT NOT NULL
	, RiskFactorTypeName	VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraMarketData_RiskFactorType PRIMARY KEY (CoreRiskFactorTypeKey)
	)
GO
