IF OBJECT_ID ('core.GDIRiskMeasureTrade_HierarchyBook') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_HierarchyBook
GO

CREATE TABLE core.GDIRiskMeasureTrade_HierarchyBook
	(
	[CoreHierarchyBookKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookCad2] [bit] NULL,
	[Trading]  [bit] NULL,
	[BookSystem] [varchar](50) NOT NULL
	, CONSTRAINT PK_GDIRiskMeasureTrade_HierarchyBook PRIMARY KEY (CoreHierarchyBookKey)
	)
GO
