/****** Object:  Table [raw].[RRR_FinancialDefinition]    Script Date: 10/13/2017 16:27:00 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_FinancialDefinition]') AND type in (N'U'))
DROP TABLE [raw].[RRR_FinancialDefinition]
GO


CREATE TABLE [raw].[RRR_FinancialDefinition](
	[BusinessDate] [datetime2](7) NULL,
	[LegalEntity] [varchar](50) NULL,
	[Denominator] [varchar](255) NULL,
	[DenominatorType] [varchar](50) NULL,
	[FDValueGBP] [float]  NULL,
	[Notes] [varchar](255) NULL,
) ON [PRIMARY]

GO

