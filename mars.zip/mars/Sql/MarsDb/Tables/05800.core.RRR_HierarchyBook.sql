IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_HierarchyBook]') AND type in (N'U'))
DROP TABLE [core].[RRR_HierarchyBook]
GO

CREATE TABLE [core].[RRR_HierarchyBook](
	[CoreHierarchyBookKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookCAD2] [bit] NULL,
	[Trading] [bit] NULL,
	[BookSystem] [varchar](50) NOT NULL,
 CONSTRAINT [PK_RRR_HierarchyBook] PRIMARY KEY CLUSTERED 
(
	[CoreHierarchyBookKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


