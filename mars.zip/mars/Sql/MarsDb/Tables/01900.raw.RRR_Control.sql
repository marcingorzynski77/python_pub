/****** Object:  Table [raw].[RRR_Control]    Script Date: 08/31/2017 11:49:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_Control]') AND type in (N'U'))
DROP TABLE [raw].[RRR_Control]
GO


CREATE TABLE [raw].[RRR_Control](
	[CounterpartyDate] [datetime2](7) NULL,
	[HierarchyDate] [datetime2](7) NULL,
	[InstrumentTypeDate] [datetime2](7) NULL,
	[RiskFactorDate] [datetime2](7) NULL,
	[RiskFactorTypeDate] [datetime2](7) NULL,
	[RiskMeasureTypeDate] [datetime2](7) NULL,
	[TradeDate] [datetime2](7) NULL,
	[TradeRuleDate] [datetime2](7) NULL,
	[TradeResultsDate] [datetime2](7) NULL,	
	[AggregatedResultsDate] [datetime2](7) NULL
) ON [PRIMARY]

GO


