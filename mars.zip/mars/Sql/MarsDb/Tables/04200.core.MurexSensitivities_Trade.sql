IF OBJECT_ID ('core.MurexSensitivities_Trade') IS NOT NULL
	DROP TABLE core.MurexSensitivities_Trade
GO

CREATE TABLE core.MurexSensitivities_Trade
	(
	  CoreTradeKey		BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, Financial_Contract	BIGINT
	, Portfolio		VARCHAR (50)
	, TradeDateTime		DATETIME2
	, TradeType		VARCHAR (50)
	, Nominal_CCY		VARCHAR (50)
	, Call_Put		VARCHAR (50)
	, Strike		FLOAT
	, Status		VARCHAR (50)
	, [Booking Units]	VARCHAR (50)
	)
GO

