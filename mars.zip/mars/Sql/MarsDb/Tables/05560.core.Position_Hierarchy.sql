/****** Object:  Table [core].[Position_Hierarchy]    Script Date: 03/22/2017 14:42:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_Hierarchy]') AND type in (N'U'))
DROP TABLE [core].[Position_Hierarchy]
GO

CREATE TABLE [core].[Position_Hierarchy](
	[CoreHierarchyKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[HierarchyString] [varchar](900) NULL,
	[BookSystem] [varchar](50) NOT NULL,
	[HierarchyTag]		INT NULL
) 

GO


