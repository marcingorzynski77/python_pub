IF OBJECT_ID ('core.MurexSensitivities_RiskMeasure_Fact') IS NOT NULL
	DROP TABLE core.MurexSensitivities_RiskMeasure_Fact
GO

CREATE TABLE [core].[MurexSensitivities_RiskMeasure_Fact] (
	[CoreRiskMeasureKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[CoreHierarchyKey] [bigint] NOT NULL,
	[CoreRiskMeasureTypeKey] [bigint] NOT NULL,
	[CoreRiskFactorTypeKey] [bigint] NULL,
	[CoreRiskFactorKey] [bigint] NULL,
	[CoreInstrumentTypeKey] [bigint] NULL,
	[CoreInstrumentTenorKey] [bigint] NULL,
	[BusDate] [datetime2](7) NOT NULL,
	[Product] [varchar](50) NOT NULL,
	[ValueCurrency] [varchar](7) NULL,
	[Value] [float] NULL,
	[ValueGBP] [float] NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX [IX_MurexSensitivities_RiskMeasure_Fact_BusinessKeys]
    ON [core].[MurexSensitivities_RiskMeasure_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreRiskMeasureTypeKey] ASC, [CoreRiskFactorTypeKey] ASC, [CoreRiskFactorKey] ASC, [CoreInstrumentTypeKey] ASC, [CoreInstrumentTenorKey] ASC, [Product] ASC, [ValueCurrency] ASC);
GO
