IF OBJECT_ID ('raw.ScenarioHierarchy') IS NOT NULL
	DROP TABLE raw.ScenarioHierarchy
GO

CREATE TABLE raw.ScenarioHierarchy
(
	  BusinessDate		DATETIME2
	, NodeID			INT
	, NodeParentID		INT
	, [Level]			INT
	, NodeName			VARCHAR (255)
	, AggregationType	VARCHAR (255)
	, HierarchyString	VARCHAR (500)
)
GO
