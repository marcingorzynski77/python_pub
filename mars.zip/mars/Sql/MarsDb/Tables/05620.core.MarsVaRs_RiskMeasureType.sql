IF OBJECT_ID ('[core].[MarsVaRs_RiskMeasureType]') IS NOT NULL
    DROP TABLE [core].[MarsVaRs_RiskMeasureType]
GO

CREATE TABLE [core].[MarsVaRs_RiskMeasureType]
( 
    [CoreRiskMeasureTypeKey] BIGINT IDENTITY(1,1) NOT NULL,
    [CoreSourceKey] BIGINT NOT NULL,
    [RiskMeasureTypeName] VARCHAR(255),
    [RiskMeasureFamily] VARCHAR(255),
    CONSTRAINT PK_MarsVaRs_RiskMeasureType PRIMARY KEY (CoreRiskMeasureTypeKey)
) 