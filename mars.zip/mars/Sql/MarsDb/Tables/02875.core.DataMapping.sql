IF OBJECT_ID ('core.DataMapping') IS NOT NULL
	DROP TABLE core.DataMapping
GO

CREATE TABLE core.DataMapping
(
	  [CoreDataMappingKey]	BIGINT IDENTITY NOT NULL
	, [DataFeed]			[VARCHAR](128) NOT NULL
	, [FactOrDimName]		[NVARCHAR] (128) NULL
	, [ColumnName]			[NVARCHAR] (128)
	, [SourceValue]			[VARCHAR] (256) NOT NULL
	, [TargetValue]			[VARCHAR] (256) NOT NULL
	, CONSTRAINT PK_DataMappingKey PRIMARY KEY (CoreDataMappingKey)
)
GO
