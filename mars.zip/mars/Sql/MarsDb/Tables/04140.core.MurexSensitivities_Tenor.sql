IF OBJECT_ID ('core.MurexSensitivities_Tenor') IS NOT NULL
	DROP TABLE core.MurexSensitivities_Tenor
GO

CREATE TABLE core.MurexSensitivities_Tenor
	(
	  CoreTenorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey	BIGINT NOT NULL
	, TenorName		VARCHAR (255) NOT NULL
	, TenorDate		DATETIME2
	, CONSTRAINT PK_MurexSensitivities_Tenor PRIMARY KEY (CoreTenorKey)
	)
GO

