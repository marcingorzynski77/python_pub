/****** Object:  Table [staging].[Counterparty]    Script Date: 08/31/2017 14:20:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[staging].[Counterparty]') AND type in (N'U'))
DROP TABLE [staging].[Counterparty]
GO

CREATE TABLE [staging].[Counterparty](
	[CoreCounterpartyKey]		[bigint] NULL,
	[CoreSourceKey]				[bigint] NULL,
	[CounterpartyCode]			[varchar](255) NOT NULL,
	[CounterpartyCodeType]		[varchar](255) NOT NULL,
	[LegalName]					[varchar](1000) NULL,
	[TradingStatus]				[varchar](255) NULL,
	[TradingName]				[varchar](1000) NULL,
	[BusinessType]				[varchar](255) NULL,
	[InternalClassification]	[varchar](255) NULL,
	[InternalDescription]		[varchar](255) NULL,
	[RfbSegment]				[varchar](255) NULL,
	[DiamondSegment]			[varchar](255) NULL,
	[HocustCode]				[varchar](255) NULL,
	[InternalClient]			[bit] NULL,
	SourceKey					[BIGINT] NULL,
	AppliedRules				[VARCHAR] (100) NULL,
	CounterpartyKey				[BIGINT] NULL
) ON [PRIMARY]

GO

