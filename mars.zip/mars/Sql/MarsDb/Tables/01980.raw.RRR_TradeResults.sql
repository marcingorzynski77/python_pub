/****** Object:  Table [raw].[RRR_TradeResults]    Script Date: 08/31/2017 14:08:20 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_TradeResults]') AND type in (N'U'))
DROP TABLE [raw].[RRR_TradeResults]
GO

CREATE TABLE [raw].[RRR_TradeResults](
	[TradeReference] [varchar](255) NULL,
	[RiskMeasureTypeKey] [bigint] NULL,
	[InstrumentTypeKey] [bigint] NULL,
	[RiskFactorKey] [bigint] NULL,
	[RiskFactorTypeKey] [bigint] NULL,
	[HierarchyId] [int] NULL,
	[CounterpartyKey] [bigint] NULL,	
	[ValueCurrency] [char](3) NULL,
	[Value] [float] NULL,
	[ValueGBP] [float] NULL,
	[MaturityBucket] [varchar](255) NULL,
	[BatchName] [varchar](255) NULL
) ON [PRIMARY]

GO
