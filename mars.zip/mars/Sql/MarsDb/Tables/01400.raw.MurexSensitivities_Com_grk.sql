IF OBJECT_ID ('raw.MurexSensitivities_Com_grk') IS NOT NULL
	DROP TABLE raw.MurexSensitivities_Com_grk
GO

CREATE TABLE raw.MurexSensitivities_Com_grk
	(
	  Trd_num       BIGINT
	, [New trade]   NVARCHAR (255)
	, Amend         NVARCHAR (255)
	, Orig_Trd_num  BIGINT
	, Strategy      NVARCHAR (255)
	, Family        NVARCHAR (255)
	, [Group]       NVARCHAR (255)
	, Type          NVARCHAR (255)
	, Portfolio     NVARCHAR (255)
	, Strike_not    NVARCHAR (255)
	, Nominal_CCY   NVARCHAR (255)
	, Nominal       NVARCHAR (255)
	, Nominal_GBP   NVARCHAR (255)
	, Maturity_date NVARCHAR (255)
	, Delivery_date NVARCHAR (255)
	, [P&L_CCY]     NVARCHAR (255)
	, Closing_MTM   NVARCHAR (255)
	, Delta_CCY     NVARCHAR (255)
	, Delta         NVARCHAR (255)
	, Delta_GBP     NVARCHAR (255)
	, Gamma_CCY     NVARCHAR (255)
	, Gamma         NVARCHAR (255)
	, Gamma_GBP     NVARCHAR (255)
	, Vega_CCY      NVARCHAR (255)
	, Vega          NVARCHAR (255)
	, Vega_GBP      NVARCHAR (255)
	, Theta         NVARCHAR (255)
	, Theta_GBP     NVARCHAR (255)
	, Rho           NVARCHAR (255)
	, Rho_GBP       NVARCHAR (255)
	, [Rho(f)]      NVARCHAR (255)
	, Rhof_GBP      NVARCHAR (255)
	, Swap_points   NVARCHAR (255)
	, Instrument    NVARCHAR (255)
	, Call_Put      NVARCHAR (255)
	, Strike        NVARCHAR (255)
	, [Buy/Sell]    NVARCHAR (255)
	, Status        NVARCHAR (255)
	)
GO

