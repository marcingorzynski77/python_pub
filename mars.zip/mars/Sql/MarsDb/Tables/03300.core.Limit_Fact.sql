IF OBJECT_ID ('core.Limit_Fact') IS NOT NULL
	DROP TABLE core.Limit_Fact
GO

CREATE TABLE core.Limit_Fact
	(
	  CoreLimitKey				BIGINT IDENTITY NOT NULL
	, CoreHierarchyKey			BIGINT NOT NULL
	, CoreRiskMeasureTypeKey	BIGINT NOT NULL
	, CoreSourceKey				BIGINT NOT NULL
	, Name						VARCHAR (255) NOT NULL
	, LimitId					INT NOT NULL
	, CategoryName				VARCHAR (255) NOT NULL
	, CategoryPriority			INT NOT NULL
	, Value						DECIMAL (30, 4) NOT NULL
	, IsOverride				INT NOT NULL
	, LimitStartDate			DATETIME2 NOT NULL
	, LimitEndDate				DATETIME2 NOT NULL
	, LimitOwner				VARCHAR (255) NOT NULL
	, RiskApprover				VARCHAR (255) NOT NULL
	, LimitApprover				VARCHAR (255) NOT NULL
	, ApprovedFlag				INT NOT NULL	
	)
GO

CREATE NONCLUSTERED INDEX [IX_Limit_Fact_BusinessKeys]
    ON [core].[Limit_Fact]([LimitId] ASC, [LimitStartDate] ASC, [LimitEndDate] ASC, [IsOverride] ASC);
GO