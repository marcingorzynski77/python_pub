IF OBJECT_ID ('raw.SummitBondPosition') IS NOT NULL
	DROP TABLE raw.SummitBondPosition
GO

CREATE TABLE raw.SummitBondPosition
	(
	  [OST RT]							INTEGER
	, [COB Date]						VARCHAR (100)		-- convert(DATE, [COB Date], 103)
	, [Summit]							VARCHAR (100)
	, [Issue Date]						VARCHAR (100)
	, [Sec State]						VARCHAR (100)
	, [Security Id]						VARCHAR (100)
	, [Book]							VARCHAR (100)
	, [Ccy]								VARCHAR (100)
	, [Desk]							VARCHAR (100)
	, [Eff Date]						VARCHAR (100)
	, [Mat Date]						VARCHAR (100)
	, [Class]							VARCHAR (100)
	, [Issuer]							VARCHAR (100)
	, [Issuer Full Name]				VARCHAR (100)
	, [Trade Type]						VARCHAR (100)
	, [Security Type]					VARCHAR (100)
	, [Security Sub Type]				VARCHAR (100)
	, [Fix/Float]						VARCHAR (100)
	, [Seniority Level]					VARCHAR (100)
	, [Day Basis]						VARCHAR (100)
	, [Position_TradeDate]				FLOAT
	, [Position_ValueDate]				FLOAT
	, [WABP]							FLOAT
	, [StartAccrual]					FLOAT
	, [EndAccrual]						FLOAT
	, [ValueDateAccrual]				FLOAT
	, [Daily Amort]						FLOAT
	, [Amortised]						FLOAT
	, [Unamortised]						FLOAT
	, [PurchaseIntTVD]					FLOAT
	, [PremiumDiscountTVD]				FLOAT
	, [BookVal]							FLOAT
	, [BookValGBP]						FLOAT
	, [MarkeVal]						FLOAT
	, [MarketValGBP]					FLOAT
	, [MarkeValDP]						FLOAT
	, [MarketValDPGBP]					FLOAT
	, [Last Reset]						VARCHAR (100)
	, [Next Reset]						VARCHAR (100)
	, [Next Int Payment]				VARCHAR (100)
	, [PayFrequency]					VARCHAR (100)
	, [ISIN]							VARCHAR (100)
	, [Settle Ccy]						VARCHAR (100)
	, [CUSIP]							VARCHAR (100)
	, [Issue Price]						FLOAT
	, [dmAssetId]						VARCHAR (100)
	, [Realised PnL]					FLOAT
	, [NPV]								FLOAT
	, [Issue_INSTN ClsVal]				VARCHAR (100)
	, [Issue_SIC ClsVal]				VARCHAR (100)
	, [Issue_DEV_BK ClsVal]				VARCHAR (100)
	, [Issue_INTL_ORG Cls_Val]			VARCHAR (100)
	, [Issue_FIN_INST ClsVal]			VARCHAR (100)
	, [Issue_GROUP_CO ClsVal]			VARCHAR (100)
	, [Issue_LOCAL_BK ClsVal]			VARCHAR (100)
	, [Issue_RSK_WGT Cls_Val]			VARCHAR (100)
	, [IssuerS&P_RISKRATE]				VARCHAR (100)
	, [SecS&P_RISKRATE]					VARCHAR (100)
	, [SECMoodys_RISKRATE]				VARCHAR (100)
	, [INTERNAL_RISKRATE]				VARCHAR (100)
	, [Issuer Physical Country]			VARCHAR (100)
	, [Issue Log Country]				VARCHAR (100)
	, [SecCountry]						VARCHAR (100)
	, [Issuer Book Class]				VARCHAR (100)
	, [Period Start]					VARCHAR (100)
	, [Period End]						VARCHAR (100)
	, [XDivDate]						VARCHAR (100)
	, [XDivPeriodFlag]					VARCHAR (100)
	, [RedemptionPrice]					FLOAT
	, [MarketPrice]						FLOAT
	, [Rate]							FLOAT
	, [Spread]							VARCHAR (100)		-- FLOAT but has empty values which break the loader
	, [AllinRate]						FLOAT
	, [Pool Factor]						FLOAT
	, [LastXNL]							FLOAT
	, [FXRate12]						FLOAT
	, [CleanPrice]						VARCHAR (100)
	, [DirtyPrice]						VARCHAR (100)
	, [Yield]							VARCHAR (100)
	, [AccrualSec]						VARCHAR (100)
	, [SecNotional]						VARCHAR (100)
	, [PosValDateNPV]					FLOAT
	, [Product Name]					VARCHAR (100)
	, [Inst_Style]						VARCHAR (100)
	, [Ref Guarantor]					VARCHAR (100)
	, [SecECAI_RiskRate]				VARCHAR (100)
	, [SecPortClas_IndGrg]				VARCHAR (100)
	, [NextCallDate]					VARCHAR (100)
	, [NextCallStrike]					VARCHAR (100)
	, [NextCallITM]						VARCHAR (100)
	, [Company]							VARCHAR (100)
	, [RefGuarantor_INSTN_ClsVal]		VARCHAR (100)
	, [RefGuarantor_PhysCountry]		VARCHAR (100)
	, [SecHBOS_RiskRate]				VARCHAR (100)
	, [Notional_Quantity]				FLOAT
	, [PorR]							VARCHAR (100)
	, [Interest_Days]					INTEGER
	, [Coupon_Amount]					FLOAT
	, [OUR_Custodian]					VARCHAR (100)
	, [OUR_Nostro]						VARCHAR (100)
	, [Hard_Call_Date]					VARCHAR (100)
	, [Notes_LongName1]					VARCHAR (100)
	, [Notes_Remarks1]					VARCHAR (100)
	, [Notes_Remarks2]					VARCHAR (100)
	, [CaptureSystem]					VARCHAR (100)
	, [SAR_Resp]						VARCHAR (100)
	, [SIC2007]							VARCHAR (100)
	, [LastTradedDate]					VARCHAR (100)
	, [LastTradedNotional]				FLOAT
	, [Fitch_RiskRate]					VARCHAR (100)
	, [Profit Centre]					VARCHAR (100)
	, [PMU Code]						VARCHAR (100)
	, [Branch Sort Code]				VARCHAR (100)
	, [Atlas Trade ID]					VARCHAR (100)
	, [GCT Subtype]						VARCHAR (100)
	, [Index Linked Bond]				VARCHAR (100)
	, [Lag]								VARCHAR (100)
	, [Current Index Ratio]				VARCHAR (100)
	, [Inflation Uplifted Notional TD]	VARCHAR (100)		-- FLOAT but has empty values which break the loader
	, [Inflation Uplifted Notional VD]	VARCHAR (100)		-- FLOAT but has empty values which break the loader
	, [Initial Uplifted Notional TD]	VARCHAR (100)		-- FLOAT but has empty values which break the loader
	, [Initial Uplifted Notional VD]	VARCHAR (100)		-- FLOAT but has empty values which break the loader
	, [Delayed_Coupon_Amount]			VARCHAR (100)		-- FLOAT but has empty values which break the loader
	, [Delayed_Paydown_Notional]		VARCHAR (100)		-- FLOAT but has empty values which break the loader
	)
GO
