IF OBJECT_ID ('core.MurexSensitivities_HierarchyBook') IS NOT NULL
	DROP TABLE core.MurexSensitivities_HierarchyBook
GO

CREATE TABLE core.MurexSensitivities_HierarchyBook
	(
	[CoreHierarchyBookKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookSystem] [varchar](50) NOT NULL,
	 CONSTRAINT PK_MurexSensitivities_HierarchyBook PRIMARY KEY (CoreHierarchyBookKey)
	)
GO
