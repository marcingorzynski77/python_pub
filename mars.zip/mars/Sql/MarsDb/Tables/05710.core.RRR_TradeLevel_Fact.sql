/****** Object:  Table [core].[RRR_TradeLevel_Fact]    Script Date: 08/31/2017 14:11:03 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_TradeLevel_Fact]') AND type in (N'U'))
DROP TABLE [core].[RRR_TradeLevel_Fact]
GO

CREATE TABLE [core].[RRR_TradeLevel_Fact](
	[CoreRRRTradeLevelKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreTradeKey] [bigint] NULL,
	[CoreRiskMeasureTypeKey] [bigint] NULL,
	[CoreInstrumentTypeKey] [bigint] NULL,
	[CoreCounterpartyKey] [bigint] NULL,
	[CoreRiskFactorKey] [bigint] NULL,
	[CoreRiskFactorTypeKey] [bigint] NULL,
	[CoreHierarchyKey] [bigint] NULL,
	[CoreSourceKey] [bigint] NULL,
	[BusDate] [datetime2](7) NULL,
	[ValueCurrency] [char](3) NULL,
	[Value] [float] NULL,
	[ValueGBP] [float] NULL,
	[MaturityBucket] [varchar](255) NULL,
) ON [PRIMARY]

GO


CREATE NONCLUSTERED INDEX [IX_RRR_TradeLevel_Fact_BusinessKeys] ON [core].[RRR_TradeLevel_Fact] ([BusDate], [CoreHierarchyKey], [CoreInstrumentTypeKey], [CoreRiskFactorKey], [CoreRiskFactorTypeKey], [CoreRiskMeasureTypeKey], [CoreCounterpartyKey], [CoreTradeKey])
GO
