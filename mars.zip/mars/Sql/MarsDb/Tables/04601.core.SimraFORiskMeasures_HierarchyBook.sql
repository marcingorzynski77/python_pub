IF OBJECT_ID ('core.SimraFORiskMeasures_HierarchyBook') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_HierarchyBook
GO

CREATE TABLE core.SimraFORiskMeasures_HierarchyBook
	(
	[CoreHierarchyBookKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookCad2] [bit] NULL,
	[BookSystem] [varchar](50) NOT NULL
	, CONSTRAINT PK_SimraFORiskMeasures_HierarchyBook PRIMARY KEY (CoreHierarchyBookKey)
	)
GO
