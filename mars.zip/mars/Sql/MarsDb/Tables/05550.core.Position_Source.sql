/****** Object:  Table [core].[Position_Source]    Script Date: 03/22/2017 14:45:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_Source]') AND type in (N'U'))
DROP TABLE [core].[Position_Source]
GO


CREATE TABLE [core].[Position_Source](
	[CoreSourceKey] [bigint] IDENTITY(1,1) NOT NULL,
	[InterfaceName] [varchar](64) NOT NULL,
	[Environment] [varchar](50) NOT NULL,
	[Origin] [varchar](50) NOT NULL,
	[Source] [varchar](50) NOT NULL
)

GO
