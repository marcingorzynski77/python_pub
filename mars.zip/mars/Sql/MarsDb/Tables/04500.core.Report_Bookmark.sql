IF OBJECT_ID ('core.Report_Bookmark') IS NOT NULL
	DROP TABLE core.Report_Bookmark
GO

CREATE TABLE [core].[Report_Bookmark](
	[BookmarkKey] [bigint] IDENTITY(1,1) NOT NULL,
	[Start] [datetime2](7) NOT NULL,
	[Finish] [datetime2](7) NOT NULL,
	[Bookmark] [varchar](50) NULL,
	[Formula] [varchar](1000) NULL,
	[ReportConfigKey] [bigint] NULL,
	[CreatedBy] [nvarchar](256) NOT NULL
)
GO