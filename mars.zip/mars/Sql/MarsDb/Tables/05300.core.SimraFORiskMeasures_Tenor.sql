IF OBJECT_ID ('core.SimraFORiskMeasures_Tenor') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_Tenor
GO

CREATE TABLE core.SimraFORiskMeasures_Tenor
	(
	  CoreTenorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey	BIGINT NOT NULL
	, TenorName		VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraFORiskMeasures_Tenor PRIMARY KEY (CoreTenorKey)
	)
GO