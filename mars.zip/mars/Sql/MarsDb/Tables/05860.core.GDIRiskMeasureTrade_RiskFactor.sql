IF OBJECT_ID ('core.GDIRiskMeasureTrade_RiskFactor') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_RiskFactor
GO

CREATE TABLE core.GDIRiskMeasureTrade_RiskFactor
	(
	  CoreRiskFactorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorName	VARCHAR (255) NOT NULL
	, CONSTRAINT PK_GDIRiskMeasureTrade_RiskFactor PRIMARY KEY (CoreRiskFactorKey)
	)
GO
