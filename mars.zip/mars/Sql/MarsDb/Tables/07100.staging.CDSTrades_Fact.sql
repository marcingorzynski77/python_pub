IF OBJECT_ID ('staging.CDSTrades_Fact') IS NOT NULL
	DROP TABLE staging.CDSTrades_Fact
GO

CREATE TABLE staging.CDSTrades_Fact
	(
	  coreCDSTradesKey	BIGINT NOT NULL
	, CoreSourceKey		BIGINT
	, CoreHierarchyKey	BIGINT
	, CoreInstrumentKey	BIGINT
	, FactKey		BIGINT NOT NULL
	, SourceKey		BIGINT
	, HierarchyKey		BIGINT
	, InstrumentKey		BIGINT
	, BusDate		DATETIME2 NOT NULL
	, TradeRef		VARCHAR (50) NOT NULL
	, BuySell		VARCHAR (1) NOT NULL
	, Maturity		DATETIME2
	, Currency		NVARCHAR (3)
	, Nominal		FLOAT
	, NominalGBP		FLOAT
	, MarketValue		FLOAT
	, MarketValueGBP	FLOAT
	, CS01			FLOAT NOT NULL
	, AppliedRules		VARCHAR (100)
	)
GO
