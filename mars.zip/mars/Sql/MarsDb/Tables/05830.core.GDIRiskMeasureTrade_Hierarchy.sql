IF OBJECT_ID ('core.GDIRiskMeasureTrade_Hierarchy') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_Hierarchy
GO

CREATE TABLE core.GDIRiskMeasureTrade_Hierarchy
	(
	  CoreHierarchyKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT
	, NodeName			VARCHAR (50) NOT NULL
	, NodeType			CHAR (2) NOT NULL
	, BookLegalEntity	VARCHAR (20)
	, HierarchyString	VARCHAR (900)
	, BookSystem		VARCHAR (50) NOT NULL
	, HierarchyTag		INT NULL
	, CONSTRAINT PK_GDIRiskMeasureTrade_Hierarchy PRIMARY KEY (CoreHierarchyKey)
	)
GO
