IF OBJECT_ID ('core.ScenarioHierarchy_Source') IS NOT NULL
	DROP TABLE core.ScenarioHierarchy_Source
GO

CREATE TABLE core.ScenarioHierarchy_Source
	(
	  CoreSourceKey	BIGINT IDENTITY NOT NULL
	, InterfaceName	VARCHAR (64) NOT NULL
	, Environment	VARCHAR (50) NOT NULL
	, Origin		VARCHAR (20) NOT NULL
	, Source		VARCHAR (20) NOT NULL
	, CONSTRAINT PK_ScenarioHierarchy_Source_1 PRIMARY KEY (CoreSourceKey)
	)
GO