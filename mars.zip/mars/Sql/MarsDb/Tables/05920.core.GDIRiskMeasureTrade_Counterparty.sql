IF OBJECT_ID ('core.GDIRiskMeasureTrade_Counterparty') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_Counterparty
GO

CREATE TABLE [core].[GDIRiskMeasureTrade_Counterparty]
	(
	  CoreCounterpartyKey	[bigint] IDENTITY NOT NULL
	, CoreSourceKey			[bigint] NULL
	, CounterpartyCode		[varchar](255) NOT NULL
	, CounterpartyCodeType  [varchar](255) NOT NULL
	CONSTRAINT PK_GDIRiskMeasureTrade_Counterparty PRIMARY KEY (CoreCounterpartyKey)
	)

GO


