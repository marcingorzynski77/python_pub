IF OBJECT_ID ('staging.InstrumentType') IS NOT NULL
	DROP TABLE staging.InstrumentType
GO

CREATE TABLE staging.InstrumentType
	(
		[CoreInstrumentTypeKey] [bigint] NULL,
		[CoreSourceKey] [bigint] NULL,
		[InstrumentType] [varchar](255) NOT NULL,
		[InstrumentSubType] [varchar](255) NOT NULL,
		[AssetClass] [varchar](50) NULL,
		[DerivativeFlag] [bit] NULL,
		[OptionFlag] [bit] NULL,
		[Permitted] [varchar](20) NULL,
		[LegsExpected] [int] NULL,
		[SourceKey] [bigint] NULL,
		[InstrumentTypeKey] [bigint] NULL
	)
GO

