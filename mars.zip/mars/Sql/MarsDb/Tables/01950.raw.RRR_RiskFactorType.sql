/****** Object:  Table [raw].[RRR_RiskFactorType]    Script Date: 08/31/2017 11:52:54 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_RiskFactorType]') AND type in (N'U'))
DROP TABLE [raw].[RRR_RiskFactorType]
GO

CREATE TABLE [raw].[RRR_RiskFactorType](
	[RiskFactorTypeKey] [bigint] IDENTITY(1,1) NOT NULL,
	[RiskFactorType] [varchar](100) NOT NULL
) ON [PRIMARY]

GO


