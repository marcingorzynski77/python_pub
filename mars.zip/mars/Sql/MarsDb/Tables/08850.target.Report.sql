IF OBJECT_ID ('target.Report') IS NOT NULL
	DROP TABLE target.Report
GO

CREATE TABLE target.Report
	(
	  ReportKey   BIGINT IDENTITY NOT NULL
	, Start       DATETIME2 NOT NULL
	, Finish      DATETIME2 NOT NULL
	, TemplateKey BIGINT
	, ReportID    BIGINT NOT NULL
	, ReportPath  VARCHAR (max) NOT NULL
	, ReportName  VARCHAR (100) NOT NULL
	, AppliedRules		VARCHAR (100)
	, CONSTRAINT PK_Report PRIMARY KEY (ReportKey)
	)
GO
