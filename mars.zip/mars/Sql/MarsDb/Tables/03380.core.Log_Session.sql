IF OBJECT_ID ('core.Log_Session') IS NOT NULL
	DROP TABLE core.Log_Session
GO

CREATE TABLE core.Log_Session
	(
	  ID             BIGINT IDENTITY NOT NULL
	, DataFeedKey    INT
	, Start          DATETIME CONSTRAINT DF_t_LogSession_ChangeDate DEFAULT (getdate()) NOT NULL
	, Finish         DATETIME
	, SPID           SMALLINT CONSTRAINT DF_t_LogSession_SPID DEFAULT (@@spid)
	, HostName       NVARCHAR (128) CONSTRAINT DF_t_LogSession_HostName DEFAULT (host_name())
	, NestLevel      INT
	, Procedure_ID   BIGINT
	, ProcedureName  NVARCHAR (128)
	, UserName       NVARCHAR (256) CONSTRAINT DF_t_LogSession_UserName DEFAULT (user_name()) NOT NULL
	, SystemUserName NVARCHAR (256) CONSTRAINT DF_t_LogSession_SystemUserName DEFAULT ((original_login()+' as ')+suser_sname()) NOT NULL
	, Additonal_Info NVARCHAR (256)
	, CONSTRAINT PK_t_LogSession PRIMARY KEY NONCLUSTERED (ID)
	WITH (FILLFACTOR = 80)
	)
GO
