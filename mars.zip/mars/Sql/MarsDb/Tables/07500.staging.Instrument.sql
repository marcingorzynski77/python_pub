IF OBJECT_ID ('staging.Instrument') IS NOT NULL
	DROP TABLE staging.Instrument
GO

CREATE TABLE [staging].[Instrument] (
	[CoreInstrumentKey]		[bigint],
	[CoreSourceKey]			[bigint],
	[Product]				[varchar](255) NOT NULL,
	[InstrumentIdType]		[varchar](30) NOT NULL,
	[InstrumentID]			[varchar](30) NOT NULL,
	[ISIN]					[varchar](30),
	[CUSIP]					[varchar](255),
	[ProductName]			[varchar](30),
	[IssueCountry]			[varchar](30),
	[Ticker]				[varchar](20),
	[Maturity]				[varchar](20),
	[FixedFRN]				[varchar](3),
	[Sector]				[varchar](40),
	[Currency]				[varchar](3),
	[IssueRating]			[varchar](10),
	[Seniority]				[varchar](20),
	[SeniorityLevel]		[varchar](20),
	[IssuerName]			[varchar](40),
	[Issue Date]			[datetime2](7),
	[Eff Date]				[datetime2](7),
	[Issuer]				[varchar](255),	
	[Day Basis]				[varchar](255),
	[PayFrequency]			[varchar](255),
	[Settle Ccy]			[varchar](255),
	[Issue Price]			[float],
	[RedemptionPrice]		[float],
	[Ref Guarantor]			[varchar](255),
	[Notes_LongName1]		[varchar](255),
	[SIC2007]				[varchar](255),
	[Index Linked Bond]		[varchar](255),
	[SourceKey]				[bigint],
	[InstrumentKey]			[bigint],
	[AppliedRules]			[varchar](100)
) ON [PRIMARY]

GO
