IF OBJECT_ID ('core.GoldenSource') IS NOT NULL
	DROP TABLE core.GoldenSource
GO

CREATE TABLE core.GoldenSource
(
	  [CoreGoldenSourceKey]	BIGINT IDENTITY NOT NULL
	, [Dimension]			[NVARCHAR] (128) NOT NULL
	, [Origin]				[NVARCHAR] (128) NOT NULL
	, [InterfaceName]		[NVARCHAR] (128) NOT NULL
	, [Precedence]			[INT] NOT NULL
	, CONSTRAINT PK_GoldenSourceKey PRIMARY KEY (CoreGoldenSourceKey)
)
GO
