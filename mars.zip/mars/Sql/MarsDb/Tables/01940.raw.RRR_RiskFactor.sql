/****** Object:  Table [raw].[RRR_RiskFactor]    Script Date: 08/31/2017 11:52:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_RiskFactor]') AND type in (N'U'))
DROP TABLE [raw].[RRR_RiskFactor]
GO


CREATE TABLE [raw].[RRR_RiskFactor](
	[RiskFactorKey] [bigint] IDENTITY(1,1) NOT NULL,
	[RiskFactor] [varchar](100) NOT NULL
) ON [PRIMARY]

GO



