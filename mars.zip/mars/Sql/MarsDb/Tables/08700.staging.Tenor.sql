IF OBJECT_ID ('staging.Tenor') IS NOT NULL
	DROP TABLE staging.Tenor
GO

CREATE TABLE staging.Tenor
	(
	  CoreTenorKey	BIGINT
	, CoreSourceKey	BIGINT
	, TenorName		VARCHAR (255) NOT NULL
	, TenorDate		DATETIME2
	, SourceKey		BIGINT
	, AppliedRules	VARCHAR (100)
	, TenorKey		BIGINT
	)
GO