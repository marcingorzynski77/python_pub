/****** Object:  Table [raw].[Position_Control]    Script Date: 03/22/2017 14:47:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[Position_Control]') AND type in (N'U'))
DROP TABLE [raw].[Position_Control]
GO

CREATE TABLE [raw].[Position_Control](
	[TriDate] [date] NULL,
	[SumDate] [date] NULL
) 

GO


