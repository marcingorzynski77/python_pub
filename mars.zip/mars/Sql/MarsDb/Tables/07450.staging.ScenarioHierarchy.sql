IF OBJECT_ID ('staging.ScenarioHierarchy') IS NOT NULL
	DROP TABLE staging.ScenarioHierarchy
GO

CREATE TABLE staging.ScenarioHierarchy
(
	  CoreScenarioHierarchyKey	BIGINT
	, CoreSourceKey				BIGINT
	, NodeId					BIGINT NOT NULL
	, NodeParentID				BIGINT
	, [Level]					BIGINT NOT NULL
	, ScenarioNodeName			VARCHAR (255) NOT NULL
	, AggregationType			VARCHAR (255) NOT NULL
	, NameLevel1				VARCHAR (50)
	, NameLevel2				VARCHAR (50)
	, NameLevel3				VARCHAR (50)
	, NameLevel4				VARCHAR (50)
	, NameLevel5				VARCHAR (50)
	, NameLevel6				VARCHAR (50)
	, NameLevel7				VARCHAR (50)
	, NameLevel8				VARCHAR (50)
	, NameLevel9				VARCHAR (50)
	, ScenarioHierarchyString	VARCHAR (500)
	, AppliedRules				VARCHAR (100)
	, ScenarioHierarchyKey		BIGINT
	, SourceKey					BIGINT
)
GO
