IF OBJECT_ID ('core.SimraFORiskMeasures_Source') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_Source
GO

CREATE TABLE core.SimraFORiskMeasures_Source
	(
	  CoreSourceKey BIGINT NOT NULL
	, InterfaceName VARCHAR (64) NOT NULL
	, Environment   VARCHAR (50) NOT NULL
	, Origin        VARCHAR (50) NOT NULL
	, Source        VARCHAR (50) NOT NULL
	, CONSTRAINT PK_SimraFORiskMeasures_Source PRIMARY KEY (CoreSourceKey)
	)
GO