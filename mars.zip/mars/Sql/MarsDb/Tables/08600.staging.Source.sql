IF OBJECT_ID ('staging.Source') IS NOT NULL
	DROP TABLE staging.Source
GO

CREATE TABLE staging.Source
	(
	  CoreSourceKey  BIGINT NULL
	, InterfaceName  VARCHAR (64) NOT NULL
	, Environment    VARCHAR (50) NOT NULL
	, Source         VARCHAR (50) NOT NULL
	, Origin         VARCHAR (50) NOT NULL
	, AppliedRules   VARCHAR (100)
	, SourceKey      BIGINT NULL
	, CONSTRAINT PK_Staging_Source_1 PRIMARY KEY (InterfaceName, Source, Environment, Origin)
	)
GO
