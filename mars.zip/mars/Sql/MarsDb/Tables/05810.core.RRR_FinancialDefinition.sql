/****** Object:  Table [core].[RRR_FinancialDefinition]    Script Date: 10/13/2017 16:11:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_FinancialDefinition]') AND type in (N'U'))
DROP TABLE [core].[RRR_FinancialDefinition]
GO


CREATE TABLE [core].[RRR_FinancialDefinition](
	[CoreFinancialDefinitionKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[EffectiveDate] [datetime2](7) NULL,
	[FDLegalEntity] [varchar](50) NULL,
	[Denominator] [varchar](255) NULL,
	[DenominatorType] [varchar](50) NULL,
	[FDValueGBP] [float] NULL,
	[Notes] [varchar](255) NULL
) ON [PRIMARY]

GO

