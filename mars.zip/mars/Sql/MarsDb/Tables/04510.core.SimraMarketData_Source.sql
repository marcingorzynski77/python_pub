IF OBJECT_ID ('core.SimraMarketData_Source') IS NOT NULL
	DROP TABLE core.SimraMarketData_Source
GO

CREATE TABLE core.SimraMarketData_Source
	(
	  CoreSourceKey	BIGINT IDENTITY NOT NULL
	, InterfaceName	VARCHAR (64) NOT NULL
	, Environment	VARCHAR (50) NOT NULL
	, Origin		VARCHAR (50) NOT NULL
	, Source		VARCHAR (50) NOT NULL
	, CONSTRAINT PK_SimraMarketData_Source PRIMARY KEY (CoreSourceKey)
	)
GO