IF OBJECT_ID ('raw.SimraPnLs') IS NOT NULL
	DROP TABLE raw.SimraPnLs
GO

CREATE TABLE raw.SimraPnLs
	(
	 [BusinessDate]						DATE
	,[DataSnapshot]						VARCHAR(255)
	,[AnalysisTypeName]					VARCHAR(255)
	,[AnalysisName]						VARCHAR(255)
	,[ScenarioName]						VARCHAR(255)
	,[SourceSystemName]					VARCHAR(255)
	,[BusinessHierarchyPath]			VARCHAR(900)
	,[Cad2]								VARCHAR(50)
	,[LegalEntity]						VARCHAR(255)
	,[RiskMeasureTypeName]				VARCHAR(255)
	,[StandardisedRiskMeasureTypeName]	VARCHAR(255)
	,[RiskFactorFamily]					VARCHAR(255)
	,[RiskFactorType]					VARCHAR(255)
	,[RiskfactorName]					VARCHAR(255)
	,[InstrumentType]					VARCHAR(255)
	,[FO_DataStatusId]					INT
	,[PNLStrip_DataStatusId]			INT
	,[InstrumentTypeBlipSize]			FLOAT
	,[PnlFunctionId]					INT
	,[ValueCurrency]					VARCHAR(255)
	,[Scenario Date]					DATE
	,[FXRate]							FLOAT
	,[sum Value]						FLOAT
	,[sum Value GBP]					FLOAT
	)
GO

