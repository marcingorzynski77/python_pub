IF OBJECT_ID ('core.MurexSensitivities_Source') IS NOT NULL
      DROP TABLE core.MurexSensitivities_Source
GO

CREATE TABLE core.MurexSensitivities_Source
      (
              CoreSourceKey	BIGINT IDENTITY NOT NULL
            , InterfaceName	VARCHAR (64) NOT NULL
            , Environment	VARCHAR (50) NOT NULL
            , Source		VARCHAR (50) NOT NULL
            , Origin		VARCHAR (50) NOT NULL
            , CONSTRAINT PK_MurexSensitivities_Source PRIMARY KEY (CoreSourceKey)
      )
GO