IF OBJECT_ID ('core.MurexSensitivities_Hierarchy') IS NOT NULL
	DROP TABLE core.MurexSensitivities_Hierarchy
GO

CREATE TABLE core.MurexSensitivities_Hierarchy
	(
	  CoreHierarchyKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT
	, NodeName			VARCHAR (50) NOT NULL
	, NodeType			CHAR (2) NOT NULL
	, HierarchyString	VARCHAR (900)
	, BookSystem		VARCHAR (50) NOT NULL
	, HierarchyTag		INT NULL
	, CONSTRAINT PK_MurexSensitivities_Hierarchy PRIMARY KEY (CoreHierarchyKey)
	)
GO
