IF OBJECT_ID ('core.MurexOption_Source') IS NOT NULL
      DROP TABLE core.MurexOption_Source
GO

CREATE TABLE core.MurexOption_Source
      (
              CoreSourceKey	BIGINT IDENTITY NOT NULL
            , InterfaceName	VARCHAR (64) NOT NULL
            , Environment	VARCHAR (50) NOT NULL
            , Source		VARCHAR (50) NOT NULL
            , Origin		VARCHAR (50) NOT NULL
            , CONSTRAINT PK_MurexOption_Source PRIMARY KEY (CoreSourceKey)
      )
GO