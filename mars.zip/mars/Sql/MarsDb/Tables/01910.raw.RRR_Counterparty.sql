/****** Object:  Table [raw].[RRR_Counterparty]    Script Date: 08/31/2017 11:50:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_Counterparty]') AND type in (N'U'))
DROP TABLE [raw].[RRR_Counterparty]
GO


CREATE TABLE [raw].[RRR_Counterparty](	
		[CounterpartyId]			[bigint] NOT NULL,
		[CounterpartyCode]			[varchar](255) NOT NULL,
		[CounterpartyCodeType]		[varchar](255) NOT NULL,
		[LegalName]					[varchar](1000) NULL,
		[TradingStatus]				[varchar](255) NULL,
		[TradingName]				[varchar](1000) NULL,
		[BusinessType]				[varchar](255) NULL,
		[InternalClassification]	[varchar](255) NULL,
		[InternalDescription]		[varchar](255) NULL,
		[RfbSegment]				[varchar](255) NULL,
		[DiamondSegment]			[varchar](255) NULL,
		[HocustCode]				[varchar](255) NULL,
		[InternalClient]			[bit] NULL
) ON [PRIMARY]

GO

