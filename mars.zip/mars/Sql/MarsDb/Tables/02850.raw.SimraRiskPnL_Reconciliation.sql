IF OBJECT_ID ('raw.SimraRiskPnL_Reconciliation') IS NOT NULL
	DROP TABLE raw.SimraRiskPnL_Reconciliation
GO

CREATE TABLE raw.SimraRiskPnL_Reconciliation
	(
	[ReportDate] [varchar](50) NULL,
	[FeedSource] [varchar](50) NULL,
	[ModelRunDate] [varchar](50) NULL,
	[BackwardsDate] [varchar](50) NULL,
	[BackwardsItem] [varchar](50) NULL,
	[Calendar] [varchar](50) NULL,
	[BusinessEntity] [varchar](50) NULL,
	[BusinessEntitySource] [varchar](50) NULL,
	[TableName] [varchar](50) NULL,
	[BusinessEntityType] [varchar](50) NULL,
	[Currency] [varchar](50) NULL,
	[RateBasis] [varchar](50) NULL,
	[Industry] [varchar](50) NULL,
	[Rating] [varchar](50) NULL,
	[Obligor] [varchar](50) NULL,
	[DataType] [varchar](50) NULL,
	[RiskType] [varchar](50) NULL,
	[Analysis] [varchar](50) NULL,
	[Scenario] [varchar](50) NULL,
	[Trade] [varchar](50) NULL,
	[NotionalValue] [varchar](50) NULL,
	[RiskValue] [varchar](50) NULL
	)
GO

