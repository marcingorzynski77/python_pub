IF OBJECT_ID ('core.Log_Type') IS NOT NULL
	DROP TABLE core.Log_Type
GO

CREATE TABLE core.Log_Type
	(
	  MessageType_ID BIGINT IDENTITY NOT NULL
	, Name           VARCHAR (50) NOT NULL
	, Description    VARCHAR (100)
	, ChangeDate     DATETIME CONSTRAINT DF_t_MessageType_ChangeDate1 DEFAULT (getdate()) NOT NULL
	, CONSTRAINT PK_t_MessageType PRIMARY KEY NONCLUSTERED (MessageType_ID)
	WITH (FILLFACTOR = 80)
	)
GO


