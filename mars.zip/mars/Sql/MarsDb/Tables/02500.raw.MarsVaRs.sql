IF OBJECT_ID ('[raw].[MarsVaRs]') IS NOT NULL
	DROP TABLE [raw].MarsVaRs
GO

CREATE TABLE [raw].[MarsVaRs]
( 
    [ScenarioNodeName] VARCHAR(255) NOT NULL,
    [AnalysisTypeName] VARCHAR(255) NOT NULL,
    [Group] VARCHAR(255) NOT NULL,
    [SubGroup] VARCHAR(255) NULL,
    [Business] VARCHAR(255) NULL,
    [BusinessArea] VARCHAR(255) NULL,
    [Division] VARCHAR(255) NULL,
    [Desk] VARCHAR(255) NULL,
    [SubDesk] VARCHAR(255) NULL,
    [Cad2] BIT NULL,
    [LegalEntity] VARCHAR(255) NULL,
    [RiskMeasureTypeName] VARCHAR(255) NULL,
    [RiskMeasureFamily] VARCHAR(255) NULL,
    [CalculationType] VARCHAR(255) NOT NULL,
    [ConfidenceLevel] FLOAT NOT NULL,
    [ValueGBP] FLOAT NOT NULL
    
) 