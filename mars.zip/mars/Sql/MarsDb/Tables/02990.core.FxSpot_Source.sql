IF OBJECT_ID ('core.FxSpot_Source') IS NOT NULL
      DROP TABLE core.FxSpot_Source
GO

CREATE TABLE core.FxSpot_Source
      (
              CoreSourceKey	BIGINT NOT NULL
            , InterfaceName	VARCHAR (64) NOT NULL
            , Environment	VARCHAR (50) NOT NULL
            , Source		VARCHAR (50) NOT NULL
            , Origin		VARCHAR (50) NOT NULL
            , CONSTRAINT PK_FxSpot_Source PRIMARY KEY (CoreSourceKey)
      )
GO

