/****** Object:  Table [core].[RRR_InstrumentType]    Script Date: 08/31/2017 14:13:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_InstrumentType]') AND type in (N'U'))
DROP TABLE [core].[RRR_InstrumentType]
GO


CREATE TABLE [core].[RRR_InstrumentType](
	[CoreInstrumentTypeKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[InstrumentSubType] [varchar](50) NULL,
	[InstrumentType] [varchar](50) NULL,
	[AssetClass] [varchar](50) NULL,
	[DerivativeFlag] [bit] NULL,
	[OptionFlag] [bit] NULL,
	[Permitted] [varchar](20) NULL,
	[LegsExpected][int] NULL,
 CONSTRAINT [PK_RRR_InstrumentType] PRIMARY KEY CLUSTERED 
(
	[CoreInstrumentTypeKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

