IF OBJECT_ID ('staging.RiskFactorType') IS NOT NULL
	DROP TABLE staging.RiskFactorType
GO

CREATE TABLE staging.RiskFactorType
	(
	  CoreRiskFactorTypeKey BIGINT NULL
	, CoreSourceKey		BIGINT
	, RiskFactorTypeName    VARCHAR (255) NOT NULL
	, SourceKey             BIGINT
	, AppliedRules          VARCHAR (100)
	, RiskFactorTypeKey     BIGINT NULL
	)
GO
