IF OBJECT_ID ('raw.Hierarchy') IS NOT NULL
	DROP TABLE raw.Hierarchy
GO

CREATE TABLE raw.Hierarchy
	(
	  Start                 DATETIME2 NOT NULL
	, Finish                DATETIME2 NOT NULL
	, RiskNodeId            BIGINT NOT NULL
	, RiskNodeParentId      BIGINT
	, RiskNodeName          VARCHAR (50) NOT NULL
	, RiskNodeType          CHAR (2) NOT NULL
	, Reporting             BIT
	, Source                VARCHAR (20)
	, SourceOrigin          VARCHAR (20) NOT NULL
	, Ordinality            INT
	, Cad                   BIT
	, Trading               BIT
	, LegalEntity           VARCHAR (20)
	, ActiveTrade           BIT NOT NULL
	, ActiveTradeHistorical BIT NOT NULL
	, HierarchyString       VARCHAR (900)
	, RingFenced            BIT NULL
	)
GO

