/****** Object:  Table [core].[RRR_Aggregated_Fact]    Script Date: 09/08/2017 16:43:43 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_Aggregated_Fact]') AND type in (N'U'))
DROP TABLE [core].[RRR_Aggregated_Fact]
GO

CREATE TABLE [core].[RRR_Aggregated_Fact](
	[CoreRRRAggregatedKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreHierarchyKey] [bigint] NULL,
	[CoreRiskMeasureTypeKey] [bigint] NULL,	
	[CoreFinancialDefinitionKey] [bigint] NULL,
	--[CoreInstrumentTypeKey] [bigint] NULL,
	[CoreSourceKey] [bigint] NULL,
	[BusDate] [datetime2](7) NOT NULL,
	[AggregationID] [varchar](2000) NOT NULL,
	[AggregationType] [varchar](255) NOT NULL,
	[AggregationRule] [varchar](1000) NOT NULL,
	[ValueGBP] [float] NOT NULL,	
	[ValueCurrency] [varchar](6) NULL,
	[LegalEntity] [varchar](255) NULL,
	[InstrumentType] [varchar](255) NULL,
	[CounterpartyLegalName] [varchar](255) NULL,
	[MaturityBucket] [varchar](255) NULL,
	[AssetClass] [varchar](255) NULL,
	--[Internal] [varchar](4) NULL,
	--[DerivativeFlag] [varchar](4) NULL,
	--[OptionFlag] [varchar](4) NULL,
	[Internal] bit NULL,
	[DerivativeFlag] bit NULL,
	[OptionFlag] bit NULL,
	[GrandFatheredFlag]		varchar(255) NULL,
	[HedgeTradeFlag]		varchar(255) NULL,
	[ProxyTradeFlag]		varchar(255) NULL,
	[InternalTradeFlag]		varchar(255) NULL,	
	[TradePurpose]			varchar(255) NULL,
	[IncludedTrades] [int] NULL,	
	[ExcludedTrades] [int] NULL	
) ON [PRIMARY]

GO


CREATE NONCLUSTERED INDEX [IX_RRR_Aggregated_Fact_BusinessKeys]
    ON [core].[RRR_Aggregated_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreRiskMeasureTypeKey] ASC, [CoreFinancialDefinitionKey] ASC);
GO