IF OBJECT_ID ('core.GDIRiskMeasureTrade_Source') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_Source
GO

CREATE TABLE core.GDIRiskMeasureTrade_Source
	(
	  CoreSourceKey BIGINT NOT NULL
	, InterfaceName VARCHAR (64) NOT NULL
	, Environment   VARCHAR (50) NOT NULL
	, Origin        VARCHAR (50) NOT NULL
	, Source        VARCHAR (50) NOT NULL
	, CONSTRAINT PK_GDIRiskMeasureTrade_Source PRIMARY KEY (CoreSourceKey)
	)
GO