IF OBJECT_ID ('core.SimraPnLs_Fact') IS NOT NULL
	DROP TABLE core.SimraPnLs_Fact
GO

CREATE TABLE core.SimraPnLs_Fact (
	  CorePnLKey				BIGINT IDENTITY NOT NULL
	, CoreSourceKey				BIGINT NOT NULL
	, CoreHierarchyKey			BIGINT NOT NULL
	, CoreScenarioHierarchyKey	BIGINT NOT NULL
	, CoreRiskMeasureTypeKey	BIGINT NOT NULL
	, CoreRiskFactorTypeKey		BIGINT -- NOT NULL
	, CoreRiskFactorKey			BIGINT -- NOT NULL
	, CoreInstrumentTypeKey		BIGINT NOT NULL
	, BusDate					DATETIME2 NOT NULL
	, AnalysisTypeName			VARCHAR (255)
	, InstrumentTypeBlipSize	FLOAT
	, PnLFunctionID				BIGINT
	, LegalEntity				VARCHAR (50)
	, Cad2						BIT
	, ScenarioDate				DATE
	, ValueCurrency				VARCHAR (7)
	, Value						FLOAT
	, ValueGBP					FLOAT
)
GO

CREATE NONCLUSTERED INDEX [IX_SIMRAPnls_Fact_BusinessKeys]
    ON [core].[SimraPnLs_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreScenarioHierarchyKey] ASC, [CoreRiskMeasureTypeKey] ASC, [CoreInstrumentTypeKey] ASC, [CoreRiskFactorKey] ASC, [CoreRiskFactorTypeKey] ASC, [AnalysisTypeName] ASC, [LegalEntity] ASC, [Cad2] ASC, [ValueCurrency] ASC, [ScenarioDate] ASC);
GO
