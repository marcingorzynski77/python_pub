IF OBJECT_ID ('core.QueryCatalogue_Hierarchy') IS NOT NULL
	DROP TABLE core.QueryCatalogue_Hierarchy
GO

CREATE TABLE core.QueryCatalogue_Hierarchy
	(
	  NodeID       BIGINT IDENTITY NOT NULL
	, NodeName     VARCHAR (50)
	, ParentNodeID BIGINT
	, Owner        VARCHAR (100)
	)
GO
