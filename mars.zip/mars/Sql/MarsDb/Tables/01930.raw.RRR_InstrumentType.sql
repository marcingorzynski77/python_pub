/****** Object:  Table [raw].[RRR_InstrumentType]    Script Date: 08/31/2017 11:51:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_InstrumentType]') AND type in (N'U'))
DROP TABLE [raw].[RRR_InstrumentType]
GO


CREATE TABLE [raw].[RRR_InstrumentType](
	[InstrumentTypeKey] [bigint] IDENTITY(1,1) NOT NULL,
	[InstrumentSubType] [varchar](50) NULL,
	[InstrumentType] [varchar](50) NULL,
	[AssetClass] [varchar](50) NULL,
	[DerivativeFlag] [bit] NULL,
	[OptionFlag] [bit] NULL,
	[Permitted] [varchar](20) NULL,
	[LegsExpected] [int] NULL,
) ON [PRIMARY]

GO

