IF OBJECT_ID ('core.SimraPnLs_RiskFactorType') IS NOT NULL
	DROP TABLE core.SimraPnLs_RiskFactorType
GO

CREATE TABLE core.SimraPnLs_RiskFactorType
	(
	  CoreRiskFactorTypeKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey			BIGINT NOT NULL
	, RiskFactorTypeName    VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraPnLs_RiskFactorType PRIMARY KEY (CoreRiskFactorTypeKey)
	)
GO
