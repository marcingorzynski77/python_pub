IF OBJECT_ID ('core.SimraFORiskMeasures_RiskFactorType') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_RiskFactorType
GO

CREATE TABLE core.SimraFORiskMeasures_RiskFactorType
	(
	  CoreRiskFactorTypeKey BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorTypeName    VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraFORiskMeasures_RiskFactorType PRIMARY KEY (CoreRiskFactorTypeKey)
	)
GO
