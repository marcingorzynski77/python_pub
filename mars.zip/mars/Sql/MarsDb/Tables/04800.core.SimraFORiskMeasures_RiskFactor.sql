IF OBJECT_ID ('core.SimraFORiskMeasures_RiskFactor') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_RiskFactor
GO

CREATE TABLE core.SimraFORiskMeasures_RiskFactor
	(
	  CoreRiskFactorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorName	VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraFORiskMeasures_RiskFactor PRIMARY KEY (CoreRiskFactorKey)
	)
GO
