IF OBJECT_ID ('core.ScenarioHierarchy_ScenarioHierarchy') IS NOT NULL
	DROP TABLE core.ScenarioHierarchy_ScenarioHierarchy
GO

CREATE TABLE core.ScenarioHierarchy_ScenarioHierarchy
	(
	  CoreScenarioHierarchyKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey				BIGINT NOT NULL
	, NodeId					BIGINT NOT NULL
	, NodeParentID				BIGINT
	, [Level]					BIGINT NOT NULL
	, ScenarioNodeName			VARCHAR (255) NOT NULL
	, AggregationType			VARCHAR (255) NOT NULL
	, ScenarioHierarchyString	VARCHAR (500)
	)
GO
