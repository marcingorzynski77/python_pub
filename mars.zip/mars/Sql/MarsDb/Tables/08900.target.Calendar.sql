IF OBJECT_ID ('target.Calendar') IS NOT NULL
	DROP TABLE target.Calendar
GO

CREATE TABLE target.Calendar
	(
	  [Date]              DATETIME2 NOT NULL
	, DateString          VARCHAR (10) NOT NULL
	, Year                VARCHAR (4) NOT NULL
	, Quarter             VARCHAR (1) NOT NULL
	, Month               VARCHAR (2) NOT NULL
	, Day                 VARCHAR (2) NOT NULL
	, WeekDay             VARCHAR (2) NOT NULL
	, WeekNo              VARCHAR (2) NOT NULL
	, WeekEnd             VARCHAR (1) NOT NULL
	, PeriodEnd           VARCHAR (1)
	, Archived            VARCHAR (1)
	, WorkingDay          VARCHAR (1)
	, NextWorkingDate     DATETIME2
	, PreviousWorkingDate DATETIME2
	, AppliedRules		  VARCHAR (100)
	, CONSTRAINT PK_Calendar_Date PRIMARY KEY ([Date])
	)
GO

CREATE INDEX IX_PreviosuWorkingDate
	ON target.Calendar (PreviousWorkingDate)
GO

CREATE INDEX [IX_Calendar_Target_WorkingDay_Date] ON [target].[Calendar] ([WorkingDay],[Date]) INCLUDE ([NextWorkingDate], [PreviousWorkingDate])
GO

CREATE INDEX [IX_Calendar_WeekDay_WorkingDay_Date] ON [target].[Calendar] ([WeekDay], [WorkingDay],[Date]) INCLUDE ([NextWorkingDate], [PreviousWorkingDate])

GO

CREATE INDEX [IX_Calendar_WorkingDay_Date] ON [target].[Calendar] ([WorkingDay],[Date]) INCLUDE ([WeekDay], [NextWorkingDate], [PreviousWorkingDate])

GO
