IF OBJECT_ID ('core.MurexSensitivities_CommodityGreeks') IS NOT NULL
	DROP TABLE core.MurexSensitivities_CommodityGreeks
GO

CREATE TABLE core.MurexSensitivities_CommodityGreeks
	(
	  CoreCommodityGreeksKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey			BIGINT NOT NULL
	, BusDate			DATETIME2 NOT NULL
	, coreMuexTradeKey		BIGINT NOT NULL
	, coreInstrumentKey		BIGINT NOT NULL
	, coreIndexKey			BIGINT NOT NULL
	, [Buy/Sell]			VARCHAR (5) NOT NULL
	, Mirrored			BIGINT NOT NULL
	, TP_CMIQ0			VARCHAR (50) NOT NULL
	, Nominal			FLOAT NOT NULL
	, Nominal_GBP			FLOAT NOT NULL
	, MaturityDate			DATETIME2 NOT NULL
	, DeliveryDate			DATETIME2 NOT NULL
	, [P&L_CCY]			VARCHAR (50) NOT NULL
	, ClosingMTM			FLOAT NOT NULL
	, Delta				FLOAT NOT NULL
	, Gamma_GBP			FLOAT NOT NULL
	, Vega				FLOAT NOT NULL
	, Theta				FLOAT NOT NULL
	, Theta_GBP			FLOAT NOT NULL
	, Rho_GBP			FLOAT NOT NULL
	, Rhof_GBP			FLOAT NOT NULL
	, Swap_Points			FLOAT NOT NULL
	)
GO

