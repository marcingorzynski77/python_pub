IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[MurexOption_Trade]') AND type in (N'U'))
DROP TABLE [core].[MurexOption_Trade]
GO

CREATE TABLE [core].[MurexOption_Trade](	
	[CoreTradeKey]			BIGINT IDENTITY NOT NULL,
	[CoreSourceKey]			BIGINT NULL,
	/* business Key */
	[TradeReference]		VARCHAR(50) NOT NULL, 
	/* reference data */
	[TradeVersion]			INT NOT NULL, 
	[TradeState]			VARCHAR(50) NOT NULL,
	[TradeDateTime]			DATETIME2 NULL,
	[CaptureDateTime]		DATETIME2 NULL,
	[AmendDateTime]			DATETIME2 NULL,
	[AmendArea]				VARCHAR(50) NULL,
	[AmendReason]			VARCHAR(50) NULL,
	/* trade details */
	[BorS]					VARCHAR(1) NULL,
	[ExpiryDate]			DATETIME2 NULL,
	[Exercisetype]			varchar(1) NULL,
	[PutOrCall]				VARCHAR(1) NULL,
	[MaturityDate]			DATETIME2 NULL,
	[ExerciseDate]			DATETIME2 NULL,
	[Strike]				DECIMAL(18,8) NULL,
	[ValueDate]				DATETIME2 NULL,
	[Price]					DECIMAL(18,8) NULL,
	[ReceiveCurrency]		VARCHAR(3) NULL, 
	[ReceiveAmount]			DECIMAL(18,2) NULL,
	[PayCurrency]			VARCHAR(3) NULL,
	[PayAmount]				DECIMAL(18,2) NULL,
	[MainCurrency]			VARCHAR(3) NULL,
	[ForwardRate]			DECIMAL(18,8) NULL,
	[PremiumCurrency]		VARCHAR(3) NULL,
	[PremiumAmount]			DECIMAL(18,2) NULL,
	[TradeTypeSubType]		VARCHAR(100) NULL
) ON [PRIMARY]

GO