IF OBJECT_ID ('core.MarsVaRs_Source') IS NOT NULL
	DROP TABLE core.MarsVaRs_Source
GO

CREATE TABLE core.MarsVaRs_Source
	(
	  CoreSourceKey BIGINT IDENTITY NOT NULL
	, InterfaceName VARCHAR (64) NOT NULL
	, Environment   VARCHAR (50) NOT NULL
	, Origin        VARCHAR (50) NOT NULL
	, Source        VARCHAR (50) NOT NULL
	, CONSTRAINT PK_MarsVaRs_Source PRIMARY KEY (CoreSourceKey)
	)
GO