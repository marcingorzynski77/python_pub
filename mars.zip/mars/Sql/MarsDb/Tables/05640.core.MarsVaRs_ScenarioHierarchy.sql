IF OBJECT_ID ('core.MarsVaRs_ScenarioHierarchy') IS NOT NULL
	DROP TABLE core.MarsVaRs_ScenarioHierarchy
GO

CREATE TABLE core.MarsVaRs_ScenarioHierarchy
	(
	  [CoreScenarioHierarchyKey] BIGINT IDENTITY NOT NULL,
      [CoreSourceKey] BIGINT NOT NULL,
      [NodeID] BIGINT NOT NULL,
	  [ScenarioNodeName] VARCHAR (255) NOT NULL,
      [Level] INT NOT NULL,
      [AggregationType]	VARCHAR (255),
	  [ScenarioHierarchyString]	VARCHAR (1000) NOT NULL,
	  CONSTRAINT PK_MarsVaRs_ScenarioHierarchy PRIMARY KEY (CoreScenarioHierarchyKey)
	)
GO
