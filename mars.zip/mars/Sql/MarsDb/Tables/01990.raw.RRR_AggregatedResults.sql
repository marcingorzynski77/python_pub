/****** Object:  Table [raw].[RRR_AggregatedResults]    Script Date: 09/08/2017 16:40:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_AggregatedResults]') AND type in (N'U'))
DROP TABLE [raw].[RRR_AggregatedResults]
GO

CREATE TABLE [raw].[RRR_AggregatedResults](
	[RiskMeasureTypeKey] [bigint] NULL,	
	[InstrumentType] [varchar](255) NULL,
	[InstrumentSubType] [varchar](255) NULL,
	[CounterpartyCode] [varchar](15) NULL,	
	[AggregationID] [varchar](2000) NULL,
	[AggregationType] [varchar](255) NULL,
	[AggregationRule] [varchar](1000) NULL,
	[ValueGBP] [float] NOT NULL,
	[ValueCurrency] [varchar](6) NULL,
	[LegalEntity] [varchar](255) NULL,
	[CounterpartyLegalName] [varchar](255) NULL,
	[CounterpartySegment] [varchar](255) NULL,
	[MaturityBucket] [varchar](255) NULL,
	[AssetClass] [varchar](255) NULL,
	[Internal] [bit] NULL,
	[DerivativeFlag] [bit] NULL,
	[OptionFlag] [bit] NULL,
	[Book] [varchar](50) NULL,
	[SubDesk] [varchar](50) NULL,
	[Desk][varchar](50) NULL,
	[Division][varchar](50) NULL,
	[BusinesArea][varchar](50) NULL,
	[Business][varchar](50) NULL,
	[SubGroup] [varchar](50) NULL,
	[IncludedTrades][int],
	[ExcludedTrades][int],
	[Attributes]		varchar(max) NULL
) ON [PRIMARY]

GO
