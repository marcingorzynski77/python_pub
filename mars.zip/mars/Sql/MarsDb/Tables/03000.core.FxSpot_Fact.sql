IF OBJECT_ID ('core.FxSpot_Fact') IS NOT NULL
	DROP TABLE core.FxSpot_Fact
GO

CREATE TABLE [core].[FxSpot_Fact]
(
	[CoreFxSpotKey]		[BIGINT] IDENTITY NOT NULL,
	[BusDate] 			[datetime2](7) NOT NULL,
	[CoreSourceKey]		[BIGINT],
	[BaseCurrency] 		[char](3) NOT NULL,
	[VariableCurrency]	[char](3) NOT NULL,
	[Rate]				[float] NOT NULL
)
GO

CREATE NONCLUSTERED INDEX [IX_FXSpot_Fact_BusinessKeys]
    ON [core].[FxSpot_Fact]([BusDate] ASC, [BaseCurrency] ASC, [VariableCurrency] ASC);
GO