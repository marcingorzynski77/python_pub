/****** Object:  Table [core].[RRR_RiskFactorType]    Script Date: 08/31/2017 14:15:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_RiskFactorType]') AND type in (N'U'))
DROP TABLE [core].[RRR_RiskFactorType]
GO

CREATE TABLE [core].[RRR_RiskFactorType](
	[CoreRiskFactorTypeKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[RiskFactorTypeName] [varchar](100) NOT NULL
) ON [PRIMARY]

GO