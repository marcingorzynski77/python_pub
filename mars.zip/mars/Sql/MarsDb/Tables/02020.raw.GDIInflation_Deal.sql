IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[GDIInflation_Deal]') AND type in (N'U'))
	DROP TABLE [raw].[GDIInflation_Deal]
GO

CREATE TABLE [raw].[GDIInflation_Deal](
	[Record Identifier]			[VARCHAR](100) NULL,
	[Trade Identifier]			[VARCHAR](100) NULL,
	[Counterparty Identifier]	[VARCHAR](100) NULL,
	[Currency 1]				[VARCHAR](100) NULL,
	[Book Identifier]			[VARCHAR](100) NULL,
	[Instrument Type]			[VARCHAR](100) NULL,
	[Instrument Family]			[VARCHAR](100) NULL,
	[Original Data Source]		[VARCHAR](100) NULL,
	[Max Notional Received]		[VARCHAR](100) NULL,
	[Notional Currency]			[VARCHAR](100) NULL,
	[Maturity Date]				[VARCHAR](100) NULL,
	[Trader]					[VARCHAR](100) NULL,
	[InstrumentCode]			[VARCHAR](100) NULL,
	[NominalValue]				[VARCHAR](100) NULL,
	[IssuerName]				[VARCHAR](100) NULL,
	[IssuerTicker]				[VARCHAR](100) NULL,
	[BB_IndustrySubgroup]		[VARCHAR](100) NULL,
	[Seniority]					[VARCHAR](100) NULL,
	[ReferenceEntityCountry]	[VARCHAR](100) NULL,
	[Ratings]					[VARCHAR](100) NULL,
	[DocClause]					[VARCHAR](100) NULL,
	[MarkITTicker]				[VARCHAR](100) NULL,
	[MaturityTerm]				[VARCHAR](100) NULL,
	[IndexName]					[VARCHAR](100) NULL,
	[IndexSeries]				[VARCHAR](100) NULL
) ON [PRIMARY]

GO

