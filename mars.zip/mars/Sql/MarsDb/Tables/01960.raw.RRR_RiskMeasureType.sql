/****** Object:  Table [raw].[RRR_RiskMeasureType]    Script Date: 08/31/2017 13:38:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_RiskMeasureType]') AND type in (N'U'))
DROP TABLE [raw].[RRR_RiskMeasureType]
GO

CREATE TABLE [raw].[RRR_RiskMeasureType](
	[RiskMeasureTypeKey] [bigint] IDENTITY(1,1) NOT NULL,
	[RiskMeasureType] [varchar](50) NOT NULL,
	[RiskMeasureFamily] [varchar](50) NOT NULL
) ON [PRIMARY]

GO


