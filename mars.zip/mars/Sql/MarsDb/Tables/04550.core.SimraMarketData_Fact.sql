IF OBJECT_ID ('core.SimraMarketData_Fact') IS NOT NULL
	DROP TABLE core.SimraMarketData_Fact
GO

CREATE TABLE [core].[SimraMarketData_Fact] (
	[CoreMarketDataKey]			[bigint] IDENTITY NOT NULL,
	[CoreSourceKey]				[bigint] NOT NULL,
	[CoreRiskFactorTypeKey]		[bigint] NOT NULL,
	[CoreRiskFactorKey]			[bigint] NOT NULL,
	[CoreInstrumentTenorKey]	[bigint] NOT NULL,
	[CoreUnderlyingTenorKey]	[bigint] NOT NULL,
	[CoreFixingTenorKey]		[bigint] NOT NULL,
	[BusDate]					[datetime2](7) NOT NULL,
	[Index]						[varchar](128) NULL,
	[Curve]						[varchar](128) NULL,
	[Currency1]					[varchar](7) NULL,
	[Currency2]					[varchar](7) NULL,
	[Value]						[float] NULL,
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX [IX_MarketData_Fact_BusinessKeys]
    ON [core].[SimraMarketData_Fact]([BusDate] ASC, [CoreRiskFactorTypeKey] ASC, [CoreRiskFactorKey] ASC);
GO