IF OBJECT_ID ('raw.MurexSensitivities_Control') IS NOT NULL
	DROP TABLE raw.MurexSensitivities_Control
GO

CREATE TABLE raw.MurexSensitivities_Control
	(
	  OmiCommodDate		DATE
	, GrkDate		DATE
	, PvbpDate		DATE
	, ComDataDate		DATE
	)
GO

INSERT INTO raw.MurexSensitivities_Control (
	  OmiCommodDate
	, GrkDate
	, PvbpDate
	, ComDataDate
)
VALUES (
	  '19000101'
	, '19000101'
	, '19000101'
	, '19000101'
)
GO
