IF OBJECT_ID ('raw.Limit') IS NOT NULL
	DROP TABLE raw.Limit
GO

CREATE TABLE [raw].[Limit]
(
	[LimitId] [bigint] NOT NULL,
	[LimitStartDate] [datetime2](7) NOT NULL,
	[LimitEndDate] [datetime2](7) NOT NULL,
	[RiskNodeName] [varchar](255) NOT NULL,
	[RiskNodeType] [varchar](2) NOT NULL,
	[HierarchyPath] [varchar](1000) NOT NULL,
	[BookSystem] [varchar](50) NOT NULL,
	[SourceOrigin] [varchar](50) NOT NULL,
	[RiskMeasureTypeGroup] [varchar](255) NOT NULL,
	[RiskMeasureTypeName] [varchar](255) NOT NULL,
	[LimitName] [varchar](255) NOT NULL,
	[LimitCategory] [varchar](255) NOT NULL,
	[LimitCategoryPriority] [int] NOT NULL,
	[LimitValue] [decimal](30, 4) NOT NULL,
	[IsOverride] [int] NOT NULL,
	[LimitOwner] [varchar](255) NOT NULL,
	[RiskApprover] [varchar](255) NOT NULL,
	[LimitApprover] [varchar](255) NOT NULL,
	[ApprovedFlag] [int] NOT NULL
)
GO
