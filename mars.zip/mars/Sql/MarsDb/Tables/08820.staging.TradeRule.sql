/****** Object:  Table [staging].[TradeRule]    Script Date: 10/24/2017 11:26:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[staging].[TradeRule]') AND type in (N'U'))
DROP TABLE [staging].[TradeRule]
GO


CREATE TABLE [staging].[TradeRule](
	[CoreTradeRuleKey] [bigint] NULL,
	[CoreSourceKey] [bigint] NULL,
	[BusDate] [datetime2](7) NULL,
	[TradeReference] [varchar](255) NULL,
	[RuleName] [varchar](1000) NULL,
	[FiredAt] [datetime2](7) NULL,
	[AppliedRules] [varchar](100) NULL,
	[SourceKey][bigint] NULL,
	[TradeRuleKey] [bigint] NULL
) ON [PRIMARY]

GO

