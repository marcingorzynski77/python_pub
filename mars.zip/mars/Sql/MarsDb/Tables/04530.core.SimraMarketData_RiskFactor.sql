IF OBJECT_ID ('core.SimraMarketData_RiskFactor') IS NOT NULL
	DROP TABLE core.SimraMarketData_RiskFactor
GO

CREATE TABLE core.SimraMarketData_RiskFactor
	(
	  CoreRiskFactorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorName	VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraMarketData_RiskFactor PRIMARY KEY (CoreRiskFactorKey)
	)
GO
