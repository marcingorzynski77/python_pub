IF OBJECT_ID ('core.SimraPnLs_ScenarioHierarchy') IS NOT NULL
	DROP TABLE core.SimraPnLs_ScenarioHierarchy
GO

CREATE TABLE core.SimraPnLs_ScenarioHierarchy
	(
	  [CoreScenarioHierarchyKey]	BIGINT IDENTITY NOT NULL
	, [CoreSourceKey]				BIGINT
	, [NodeID]						BIGINT
	, [ScenarioNodeName]			VARCHAR (50) NOT NULL
	, [Level]						INT
	, [AggregationType]				VARCHAR (255)
	, [ScenarioHierarchyString]		VARCHAR (500)
	, CONSTRAINT PK_SimraPnLs_ScenarioHierarchy PRIMARY KEY (CoreScenarioHierarchyKey)
	)
GO
