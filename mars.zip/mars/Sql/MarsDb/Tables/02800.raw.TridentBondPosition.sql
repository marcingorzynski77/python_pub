IF OBJECT_ID ('raw.TridentBondPosition') IS NOT NULL
	DROP TABLE raw.TridentBondPosition
GO

CREATE TABLE raw.TridentBondPosition
	(
	  ReportDate        DATETIME NOT NULL
	, TradeDate         DATETIME2
	, TradeID           VARCHAR (200)
	, Obligor_ID_Bond   BIGINT
	, Obligor_ID_CDS    BIGINT
	, Ticker_For_CDS    VARCHAR (50)
	, Ticker_For_Bond   VARCHAR (50)
	, BuySell           VARCHAR (100)
	, Product           VARCHAR (100) NOT NULL
	, SingleNameIndex   VARCHAR (100)
	, SummitBondType    VARCHAR (100)
	, SummitBondSubType VARCHAR (100)
	, POD               VARCHAR (100)
	, Strategy          VARCHAR (100)
	, Book              VARCHAR (100) NOT NULL
	, BookDescription   VARCHAR (100)
	, Trader            VARCHAR (100)
	, ISIN              VARCHAR (15)
	, InstrumentName    VARCHAR (100)
	, IssuerName        VARCHAR (200)
	, Currency          VARCHAR (3)
	, Maturity          DATETIME
	, IsGoverment       CHAR (1)
	, Seniority         VARCHAR (50)
	, Sector            VARCHAR (50)
	, SNPRating         VARCHAR (10)
	, MoodyRating       VARCHAR (10)
	, FitchRating       VARCHAR (10)
	, CompositeRating   VARCHAR (10)
	, CountryOfRisk     VARCHAR (50)
	, BondMaturity      DATETIME
	, DocClause         VARCHAR (50)
	, FixFloat          VARCHAR (50)
	, [Index]           VARCHAR (50)
	, IndexName         VARCHAR (50)
	, IndexFamily       VARCHAR (50)
	, IndexSeries       INT
	, IndexVersion      INT
	, REDCode           VARCHAR (50)
	, BondPrice         FLOAT
	, Spread            FLOAT
	, StandardisedCS01  FLOAT
	, CS01              FLOAT
	, CS01GBP           FLOAT
	, CS01_BBG          FLOAT
	, CS01GBP_BBG       FLOAT
	, IR01              FLOAT
	, [IR-1GBP]         FLOAT
	, Notional          FLOAT
	, NotionalGBP       FLOAT
	, MarketValue       FLOAT
	, MarketValueGBP    FLOAT
	, JTD               FLOAT
	, Book_Filter       INT
	, Bond_ID           BIGINT
	, RecoveryRate      FLOAT
	, ChangeDate        DATETIME
	, ID                INT
	, Source            VARCHAR (100)
	, Origin            VARCHAR (100)
	)
GO

