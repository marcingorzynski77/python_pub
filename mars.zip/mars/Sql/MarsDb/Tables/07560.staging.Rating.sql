IF OBJECT_ID ('staging.Rating') IS NOT NULL
	DROP TABLE staging.Rating
GO

CREATE TABLE staging.Rating
(
	  CoreRatingKey			BIGINT NULL
	, CoreSourceKey			BIGINT
	, [SecSandP_RISKRATE]		VARCHAR (30)
	, [SECMoodys_RISKRATE]	VARCHAR (30)
	, [INTERNAL_RISKRATE]	VARCHAR (30)
	, [SecECAI_RiskRate]	VARCHAR (30)
	, [SecHBOS_RiskRate]	VARCHAR (30)
	, [Fitch_RiskRate]		VARCHAR (30)
	, SourceKey				BIGINT
	, AppliedRules			VARCHAR (100)
	, RatingKey				BIGINT
)
GO
