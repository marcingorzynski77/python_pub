IF OBJECT_ID ('core.GDIRiskMeasureTrade_Tenor') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_Tenor
GO

CREATE TABLE core.GDIRiskMeasureTrade_Tenor
	(
	  CoreTenorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey	BIGINT NOT NULL
	, TenorName		VARCHAR (255) NOT NULL
	, CONSTRAINT PK_GDIRiskMeasureTrade_Tenor PRIMARY KEY (CoreTenorKey)
	)
GO