/****** Object:  Table [core].[Position_Country]    Script Date: 03/22/2017 14:38:19 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_Country]') AND type in (N'U'))
DROP TABLE [core].[Position_Country]
GO

CREATE TABLE [core].[Position_Country](
	[CoreCountryKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[IssuerPhysicalCountry] [varchar](30) NULL,
	[IssuerLogCountry] [varchar](30) NULL,
	[SecCountry] [varchar](30) NULL
)

GO


