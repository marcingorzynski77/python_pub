IF OBJECT_ID ('raw.DataLoad_Config') IS NOT NULL
	DROP TABLE raw.DataLoad_Config
GO

CREATE TABLE raw.DataLoad_Config
	(
	  ID                 BIGINT IDENTITY NOT NULL
	, DataFeed           VARCHAR (64) NOT NULL
	, Environment        VARCHAR (6)
	, SourceType         VARCHAR (20) NOT NULL
	, Connection         VARCHAR (200)
	, [Database]         VARCHAR (50)
	, Query              VARCHAR (max)
	, FilePath           VARCHAR (1000)
	, FileName           VARCHAR (100)
	, WorkSheet          VARCHAR (30)
	, [Range]            VARCHAR (10)
	, StagingTable       VARCHAR (50)
	, PostLoadProcessing VARCHAR (50)
	, TriggerDay         VARCHAR (30)
	, TriggerTime        TIME
	, Active             INT NOT NULL
	, DateUpdated        DATETIME2 NOT NULL
	, UpdatedBY          VARCHAR (50) NOT NULL
	, DateCreated        DATETIME2 NOT NULL
	, CreatedBy          VARCHAR (50) NOT NULL
	, CONSTRAINT PK_DataLoad_Config PRIMARY KEY (ID)
	)
GO
