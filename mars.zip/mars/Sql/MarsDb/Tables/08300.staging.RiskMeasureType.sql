IF OBJECT_ID ('staging.RiskMeasureType') IS NOT NULL
	DROP TABLE staging.RiskMeasureType
GO

CREATE TABLE staging.RiskMeasureType
	(
	  CoreRiskMeasureTypeKey	BIGINT NULL
	, CoreSourceKey				BIGINT
	, RiskMeasureTypeName		VARCHAR (255) NOT NULL
	, RiskMeasureFamily			VARCHAR (255) NOT NULL
	, SourceKey					BIGINT
	, AppliedRules				VARCHAR (100)
	, RiskMeasureTypeKey		BIGINT NULL
	)
GO
