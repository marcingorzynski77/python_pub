/****** Object:  Table [core].[Position_Rating]    Script Date: 03/22/2017 14:44:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_Rating]') AND type in (N'U'))
DROP TABLE [core].[Position_Rating]
GO


CREATE TABLE [core].[Position_Rating](
	[CoreRatingKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[SecSandP_RISKRATE] [varchar](30) NULL,
	[SECMoodys_RISKRATE] [varchar](30) NULL,
	[INTERNAL_RISKRATE] [varchar](30) NULL,
	[SecECAI_RiskRate] [varchar](30) NULL,
	[SecHBOS_RiskRate] [varchar](30) NULL,
	[Fitch_RiskRate] [varchar](30) NULL
)

GO
