IF OBJECT_ID ('core.Limit_HierarchyBook') IS NOT NULL
	DROP TABLE core.Limit_HierarchyBook
GO

CREATE TABLE [core].[Limit_HierarchyBook](
	[CoreHierarchyBookKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookSystem] [varchar](50) NOT NULL
) ON [PRIMARY]
GO
