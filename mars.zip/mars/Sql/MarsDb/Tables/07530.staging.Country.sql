IF OBJECT_ID ('staging.Country') IS NOT NULL
	DROP TABLE staging.Country
GO

CREATE TABLE staging.Country
(
	  CoreCountryKey			BIGINT NULL
	, CoreSourceKey				BIGINT
	, [IssuerPhysicalCountry]	VARCHAR (30)
	, [IssuerLogCountry]		VARCHAR (30)
	, [SecCountry]				VARCHAR (30)
	, SourceKey					BIGINT
	, AppliedRules				VARCHAR (100)
	, CountryKey				BIGINT
)
GO
