IF OBJECT_ID ('coreGDIRiskMeasureTrade_InstrumentType') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_InstrumentType
GO

CREATE TABLE core.GDIRiskMeasureTrade_InstrumentType
	(
	 CoreInstrumentTypeKey	BIGINT IDENTITY NOT NULL
	,CoreSourceKey			BIGINT NOT NULL
	,InstrumentType			VARCHAR (255) NOT NULL
	,InstrumentSubType		VARCHAR (255) NOT NULL
	,CONSTRAINT PK_GDIRiskMeasureTrade_CoreInstrumentTypeKey PRIMARY KEY (CoreInstrumentTypeKey)
	)
GO
