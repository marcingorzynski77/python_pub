IF OBJECT_ID ('raw.MurexSensitivities_Com_pvbp') IS NOT NULL
	DROP TABLE raw.MurexSensitivities_Com_pvbp
GO

CREATE TABLE raw.MurexSensitivities_Com_pvbp
	(
	  [Family Group Type]		VARCHAR (255)
	, Curve				VARCHAR (255)
	, Portfolio			VARCHAR (255)
	, Tenor				VARCHAR (255)
	, Instrument			VARCHAR (255)
	, [Total IR Sensistivity]	VARCHAR (255)
	, [Extra]			VARCHAR (255)
	)
GO

