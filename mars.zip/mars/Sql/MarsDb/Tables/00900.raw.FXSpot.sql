IF OBJECT_ID ('raw.FXSpot') IS NOT NULL
	DROP TABLE raw.FXSpot
GO

CREATE TABLE raw.FXSpot
	(
	  COBDate          DATE NOT NULL
	, BaseCurrency     CHAR (3) NOT NULL
	, VariableCurrency CHAR (3) NOT NULL
	, Rate             FLOAT NOT NULL
	, Domain           VARCHAR (100) NOT NULL
	)
GO
