IF OBJECT_ID ('raw.FinancePnL') IS NOT NULL
	DROP TABLE raw.FinancePnL
GO

CREATE TABLE raw.FinancePnL
	(
	  Id                        BIGINT IDENTITY NOT NULL
	, ReportingDate             DATETIME
	, TradingDesk               VARCHAR (max)
	, ConsDailyRepNumber        BIGINT
	, PortfolioLevel            VARCHAR (max)
	, Entity                    VARCHAR (max)
	, SalesAddedValue           FLOAT
	, Day1TradedIncome          FLOAT
	, Yield_Delta               FLOAT
	, BondSwapSpread            FLOAT
	, Time_Theta                FLOAT
	, Rho                       FLOAT
	, Vega                      FLOAT
	, Gamma                     FLOAT
	, Reset_PnL                 FLOAT
	, FX_Revaluation            FLOAT
	, Pricing_Adjustmants       FLOAT
	, Brokerage                 FLOAT
	, Other_Fees                FLOAT
	, Bid_Offer                 FLOAT
	, Smile_Skew                FLOAT
	, FX_Delta                  FLOAT
	, FX_Vega                   FLOAT
	, FX_Smile_Skew             FLOAT
	, Inflation_Delta           FLOAT
	, Inflation_Vega            FLOAT
	, Inflation_Vega_Smile_Skew FLOAT
	, Inflation_Seasonality     FLOAT
	, Inflation_Lambda_Rho      FLOAT
	, Management_Reserve        FLOAT
	, Capitalised_Funding       FLOAT
	, Residual                  FLOAT
	, Total_Income              FLOAT
	, ConsDailyRepAdjustmant    FLOAT
	, SAP_Node                  VARCHAR (max)
	, CAD2TradingBook           VARCHAR (max)
	, Book                      VARCHAR (max)
	, EndDate                   DATETIME
	, CONSTRAINT PK_RawPnL PRIMARY KEY (Id)
	)
GO

