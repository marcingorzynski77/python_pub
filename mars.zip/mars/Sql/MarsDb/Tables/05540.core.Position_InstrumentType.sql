IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_InstrumentType]') AND type in (N'U'))
	DROP TABLE [core].[Position_InstrumentType]
GO

CREATE TABLE [core].[Position_InstrumentType] (
	 CoreInstrumentTypeKey	[bigint] IDENTITY(1,1) NOT NULL
	,CoreSourceKey			[bigint] NOT NULL
	,InstrumentType			[varchar](255) NULL
	,InstrumentSubType		[varchar](255) NULL
) 

GO

