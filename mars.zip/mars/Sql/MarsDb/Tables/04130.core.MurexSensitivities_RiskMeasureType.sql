IF OBJECT_ID ('core.MurexSensitivities_RiskMeasureType') IS NOT NULL
	DROP TABLE core.MurexSensitivities_RiskMeasureType
GO

CREATE TABLE core.MurexSensitivities_RiskMeasureType
	(
	 CoreRiskMeasureTypeKey	BIGINT IDENTITY NOT NULL
	,CoreSourceKey			BIGINT NOT NULL
	,RiskMeasureTypeName	VARCHAR (255) NOT NULL
	,RiskMeasureFamily		VARCHAR (255) NOT NULL
	,CONSTRAINT PK_MurexSensitivities_RiskMeasureType PRIMARY KEY (CoreRiskMeasureTypeKey)
	)
GO
