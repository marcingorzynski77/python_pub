IF OBJECT_ID ('core.Report_Config') IS NOT NULL
	DROP TABLE core.Report_Config
GO

CREATE TABLE core.[Report_Config]
(
	[ReportConfigKey] [bigint] IDENTITY(1,1) NOT NULL,
	[Start] [datetime2](7) NOT NULL,
	[Finish] [datetime2](7) NOT NULL,
	[Name] [varchar](50) NULL,
	[Description] [varchar](1000) NULL,
	[TemplateFilepath] [varchar](1000) NULL,
	[CreatedBy] [nvarchar](256) NOT NULL
)
GO