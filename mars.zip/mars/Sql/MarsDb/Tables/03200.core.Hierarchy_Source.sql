IF OBJECT_ID ('core.Hierarchy_Source') IS NOT NULL
	DROP TABLE core.Hierarchy_Source
GO

CREATE TABLE core.Hierarchy_Source
	(
	  CoreSourceKey	BIGINT NOT NULL
	, InterfaceName	VARCHAR (64) NOT NULL
	, Environment	VARCHAR (50) NOT NULL
	, Origin	VARCHAR (20) NOT NULL
	, Source	VARCHAR (20) NOT NULL
	, CONSTRAINT PK_Hierarchy_Source_1 PRIMARY KEY (CoreSourceKey)
	)
GO