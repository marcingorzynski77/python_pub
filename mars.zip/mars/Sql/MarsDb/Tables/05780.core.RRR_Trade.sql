IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_Trade]') AND type in (N'U'))
DROP TABLE [core].[RRR_Trade]
GO

CREATE TABLE [core].[RRR_Trade](
	[CoreTradeKey]			BIGINT IDENTITY NOT NULL,
	[CoreSourceKey]			BIGINT NULL,
	/* business key */
	[TradeReference]		VARCHAR(255) NULL,
	/* rrr data */
	[InScopeForRRR]			BIT NULL,
	[Notional]				DECIMAL(24,4) NULL,
	[NotionalCurrency]		CHAR(3) NULL,
	[Maturity]				DATETIME2(7) NULL,
	[StructureId]			VARCHAR(100) NULL,
	[PackageMemberType]		VARCHAR(10) NULL,
	[GrandFatheredFlag]		VARCHAR(255) NULL,
	[ProxyTradeFlag]		VARCHAR(255) NULL,
	[InternalTradeFlag]		VARCHAR(255) NULL,
	[HedgeTradeFlag]		VARCHAR(255) NULL,
	[TradePurpose]		VARCHAR(255) NULL,
	[AppliedRules]			VARCHAR(100) NULL
) ON [PRIMARY]

GO

