IF OBJECT_ID ('core.SimraMarketData_Tenor') IS NOT NULL
	DROP TABLE core.SimraMarketData_Tenor
GO

CREATE TABLE core.SimraMarketData_Tenor
	(
	  CoreTenorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey	BIGINT NOT NULL
	, TenorName		VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraMarketData_Tenor PRIMARY KEY (CoreTenorKey)
	)
GO
