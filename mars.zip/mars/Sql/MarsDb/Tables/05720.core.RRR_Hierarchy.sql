/****** Object:  Table [core].[RRR_Hierarchy]    Script Date: 08/31/2017 14:12:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_Hierarchy]') AND type in (N'U'))
DROP TABLE [core].[RRR_Hierarchy]
GO

CREATE TABLE [core].[RRR_Hierarchy](
	[CoreHierarchyKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[NodeId] [bigint] NULL,
	[NodeParentID] [bigint] NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookLegalEntity] [varchar](20) NULL,	
	[BookSystem] [varchar](50) NOT NULL,
	[Book] [varchar](50) NULL,
	[SubDesk] [varchar](200) NULL,
	[Desk] [varchar](50) NULL,
	[Division] [varchar](50) NULL,
	[BusinessArea] [varchar](50) NULL,
	[Business] [varchar](50) NULL,
	[SubGroup] [varchar](50) NULL,
	[HierarchyTag][int] NULL
) ON [PRIMARY]

GO


