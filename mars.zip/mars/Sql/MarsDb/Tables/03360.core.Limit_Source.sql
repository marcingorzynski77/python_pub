IF OBJECT_ID ('core.Limit_Source') IS NOT NULL
      DROP TABLE core.Limit_Source
GO

CREATE TABLE core.Limit_Source
      (
              CoreSourceKey	BIGINT NOT NULL
            , InterfaceName	VARCHAR (64) NOT NULL
            , Environment	VARCHAR (50) NOT NULL
            , Source		VARCHAR (50) NOT NULL
            , Origin		VARCHAR (50) NOT NULL
            , CONSTRAINT PK_Limit_Source PRIMARY KEY (CoreSourceKey)
      )
GO
