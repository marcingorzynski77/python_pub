IF OBJECT_ID ('core.GDIRiskMeasureTrade_Fact') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_Fact
GO

CREATE TABLE [core].[GDIRiskMeasureTrade_Fact] (
	[CoreRiskMeasureTradeKey]	[bigint] IDENTITY NOT NULL,
	[BusDate]					[datetime2](7) NOT NULL,
	[CoreSourceKey]				[bigint] NOT NULL,
	[CoreHierarchyKey]			[bigint] NOT NULL,
	[CoreCounterpartyKey]		[bigint] NOT NULL,
	[CoreRiskFactorKey]			[bigint] NULL,
	[CoreInstrumentTenorKey]	[bigint] NULL,
	[CoreUnderlyingTenorKey]	[bigint] NULL,
	[CoreRiskMeasureTypeKey]	[bigint] NOT NULL,
	[CoreInstrumentTypeKey]		[bigint] NULL,
	[CoreTradeKey]				[bigint] NOT NULL,
	[ValueCurrency]				[varchar](7) NULL,
	[Value]						[decimal](20,8) NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX [IX_GDIRiskMeasureTrade_Fact_BusinessKeys]
    ON [core].[GDIRiskMeasureTrade_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreCounterpartyKey] ASC, [CoreRiskFactorKey] ASC, [CoreInstrumentTenorKey] ASC, [CoreUnderlyingTenorKey] ASC, [CoreRiskMeasureTypeKey] ASC, [CoreInstrumentTypeKey] ASC, [ValueCurrency] ASC);
GO