IF OBJECT_ID ('raw.MurexSensitivities_C_omi_commod') IS NOT NULL
	DROP TABLE raw.MurexSensitivities_C_omi_commod
GO

CREATE TABLE raw.MurexSensitivities_C_omi_commod
	(
	  FINANCIAL_CONTRACT          BIGINT
	, TRADEID                     BIGINT
	, PACKAGEID                   FLOAT
	, INITIATOR_YN                NVARCHAR (255)
	, INTERNAL_YN                 NVARCHAR (255)
	, TRADE_TYPE                  NVARCHAR (255)
	, TRADESUBTYPE                NVARCHAR (255)
	, CUSTOMERID                  NVARCHAR (255)
	, BROKER                      NVARCHAR (255)
	, TRADERID                    NVARCHAR (255)
	, EXTERNALTRADEID             NVARCHAR (255)
	, TRADEDATETIME               DATETIME2 (0)
	, VALUEDATE                   DATETIME2 (0)
	, PRICE                       FLOAT
	, MATURITYDATE                DATETIME2 (0)
	, BOUGHTCCY                   VARCHAR (255)
	, BOUGHTAMT                   FLOAT
	, SOLDCCY                     VARCHAR (255)
	, SOLDAMT                     FLOAT
	, TRADERATE                   FLOAT
	, FORWARDRATE                 FLOAT
	, CAPTUREOPERATORID           VARCHAR (255)
	, CAPTUREDATE_TIME            DATETIME2 (0)
	, AMENDOPERATORID             NVARCHAR (255)
	, AMENDDATE                   NVARCHAR (255)
	, AMENDTIME                   NVARCHAR (255)
	, AMENDMENTAREA               NVARCHAR (255)
	, AMENDMENTREASON             NVARCHAR (255)
	, VERIFYOPERATORID            NVARCHAR (255)
	, VERIFYDATE_TIME             NVARCHAR (255)
	, CANCELOPERATORID            NVARCHAR (255)
	, CANCELDATE_TIME             NVARCHAR (255)
	, CANCELDATE                  NVARCHAR (255)
	, CANCELTIME                  NVARCHAR (255)
	, BOOK                        NVARCHAR (255)
	, DESK                        NVARCHAR (255)
	, SETTLEMENTMETHOD            NVARCHAR (255)
	, SETTLEMENTMEDIUM            NVARCHAR (255)
	, PORS                        NVARCHAR (255)
	, TRADEVERSION                BIGINT
	, TRADESTATE                  NVARCHAR (255)
	, COMPANY                     NVARCHAR (255)
	, HPCCODE                     NVARCHAR (255)
	, COMMENTS                    NVARCHAR (255)
	, STRUCTUREID                 FLOAT
	, PARENTTRADEID               BIGINT
	, MIRRORED                    NVARCHAR (255)
	, NAVOPSCODE                  NVARCHAR (255)
	, CPTYINWARDCONFRMSTATUS      NVARCHAR (255)
	, CPTYINWARDCONFRMDATETIME    NVARCHAR (255)
	, BROKERINWARDCONFRMSTATUS    NVARCHAR (255)
	, BROKERINWARDCONFRMDATE_TIME NVARCHAR (255)
	, CLSFLAG                     NVARCHAR (255)
	, MARKETSLINKTRADEID          NVARCHAR (255)
	, MKTSLINKTRADETYPE           NVARCHAR (255)
	, MKTLINKTRADERID             NVARCHAR (255)
	, MKTLINKCAPTUREDATE_TIME     NVARCHAR (255)
	, MIGRATEDTRADEID             NVARCHAR (255)
	, EXTERNALSYSTEM              NVARCHAR (255)
	, NETTINGMODE                 NVARCHAR (255)
	, COMLTBS                     NVARCHAR (255)
	, COMHB                       NVARCHAR (255)
	, LEGALLLOYDS                 NVARCHAR (255)
	, LEGALHBOS                   NVARCHAR (255)
	, CLSLTSB                     NVARCHAR (255)
	, CLSHBOS                     NVARCHAR (255)
	)
GO

