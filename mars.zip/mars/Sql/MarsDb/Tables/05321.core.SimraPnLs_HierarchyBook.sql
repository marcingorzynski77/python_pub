IF OBJECT_ID ('core.SimraPnLs_HierarchyBook') IS NOT NULL
	DROP TABLE core.SimraPnLs_HierarchyBook
GO

CREATE TABLE core.SimraPnLs_HierarchyBook
	(
	  CoreHierarchyBookKey 	BIGINT NOT NULL
	, CoreSourceKey		BIGINT
	, NodeName			VARCHAR (50) NOT NULL
	, NodeType			CHAR (2) NOT NULL
	--, BookLegalEntity	VARCHAR (20)
	, BookCad2			BIT
	, BookSystem		VARCHAR (50) NOT NULL
	, CONSTRAINT PK_SimraPnLs_HierarchyBook PRIMARY KEY (CoreHierarchyBookKey)
	)
GO
