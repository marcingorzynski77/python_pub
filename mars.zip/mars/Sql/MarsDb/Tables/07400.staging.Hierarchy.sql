IF OBJECT_ID ('staging.Hierarchy') IS NOT NULL
	DROP TABLE staging.Hierarchy
GO

CREATE TABLE staging.Hierarchy
	(
	  CoreHierarchyKey	BIGINT
	, CoreSourceKey		BIGINT
	, NodeId		BIGINT
	, NodeParentID		BIGINT
	, NodeName		VARCHAR (50) NOT NULL
	, NodeType			CHAR (2) NOT NULL
	, SourceKey			BIGINT
	, BookLegalEntity	VARCHAR (20)
	, Ordinality		INT
	, Reporting			BIT
	, RingFenced		BIT
	, [Group]			VARCHAR (50)
	, SubGroup			VARCHAR (50)
	, Business			VARCHAR (50)
	, BusinessArea		VARCHAR (50)
	, Division			VARCHAR (50)
	, Desk				VARCHAR (50)
	, SubDesk			VARCHAR (200)
	, Book				VARCHAR (50)
	, BookSystem		VARCHAR (50) NOT NULL
	, HierarchyString	VARCHAR (900)
	, AppliedRules		VARCHAR (100)
	, HierarchyKey		BIGINT NULL
	, HierarchyTag 		INT NULL
	, HierarchyBookKey      BIGINT NULL
	)
GO
CREATE NONCLUSTERED INDEX IX_SourceKey ON [staging].[Hierarchy] ([SourceKey])INCLUDE ([CoreSourceKey])
GO