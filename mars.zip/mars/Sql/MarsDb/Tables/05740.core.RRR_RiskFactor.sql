/****** Object:  Table [core].[RRR_RiskFactor]    Script Date: 08/31/2017 14:14:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_RiskFactor]') AND type in (N'U'))
DROP TABLE [core].[RRR_RiskFactor]
GO

CREATE TABLE [core].[RRR_RiskFactor](
	[CoreRiskFactorKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[RiskFactorName] [varchar](100) NOT NULL
) ON [PRIMARY]

GO


