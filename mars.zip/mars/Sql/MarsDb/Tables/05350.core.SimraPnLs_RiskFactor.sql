IF OBJECT_ID ('core.SimraPnLs_RiskFactor') IS NOT NULL
	DROP TABLE core.SimraPnLs_RiskFactor
GO

CREATE TABLE core.SimraPnLs_RiskFactor
	(
	  CoreRiskFactorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorName	VARCHAR (255) NOT NULL
	, CONSTRAINT PK_SimraPnLs_RiskFactor PRIMARY KEY (CoreRiskFactorKey)
	)
GO
