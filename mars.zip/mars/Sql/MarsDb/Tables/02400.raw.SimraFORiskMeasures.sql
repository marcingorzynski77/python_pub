IF OBJECT_ID ('raw.SimraFORiskMeasures') IS NOT NULL
	DROP TABLE raw.SimraFORiskMeasures
GO

CREATE TABLE raw.SimraFORiskMeasures
	(
	  [BusinessDate]					DATE
	, [DataSnapshot]					VARCHAR (255)
	, [AnalysisTypeName]				VARCHAR (255)
	, [AnalysisName]					VARCHAR (255)
	, [ScenarioName]					VARCHAR (255)
	, [ProformaShiftValue]				FLOAT
	, [SourceSystemName]				VARCHAR (255)
	, [BusinessHierarchyPath]			VARCHAR (900)
	, [Cad2]							VARCHAR (50)
	, [LegalEntity]						VARCHAR (255)
	, [RiskMeasureTypeName]				VARCHAR (255)
	, [StandardisedRiskMeasureTypeName]	VARCHAR (255)
	, [RiskFactorFamily]				VARCHAR (255)
	, [RiskFactorType]					VARCHAR (255)
	, [RiskfactorName]					VARCHAR (255)
	, [InstrumentType]					VARCHAR (255)
	, [InstrumentSubType]				VARCHAR (255)
	, [Instrument Tenor]				VARCHAR (255)
	, [IT Residual Maturity]			INT
	, [Underlying Tenor]				VARCHAR (255)
	, [UT Residual Maturity]			INT
	, [Fixing Tenor]					VARCHAR (255)
	, [FT Residual Maturity]			INT
	, [FO_DataStatusId]					VARCHAR (255)
	, [ValueCurrency]					VARCHAR (255)
	, [FXRate]							VARCHAR (255)
	, [sum Value]						FLOAT
	, [sum Value GBP]					FLOAT
	)
GO
