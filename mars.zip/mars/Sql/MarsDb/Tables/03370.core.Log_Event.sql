IF OBJECT_ID ('core.Log_Event') IS NOT NULL
	DROP TABLE core.Log_Event
GO

CREATE TABLE core.Log_Event
	(
	  ID             BIGINT IDENTITY NOT NULL
	, SessionID      BIGINT
	, Start          DATETIME CONSTRAINT DF_t_LogEvent_ChangeTime DEFAULT (getutcdate()) NOT NULL
	, MessageTypeID  BIGINT NOT NULL
	, ProcedureName  VARCHAR (125)
	, NestLevel      INT
	, Comment        VARCHAR (1000)
	, ErrorNumber    INT
	, ErrorSeverity  INT
	, ErrorState     INT
	, ErrorLine      INT
	, ErrorMessage   VARCHAR (max)
	, ErrorProcedure NVARCHAR (126)
	, CONSTRAINT FK_t_LogEvent_t_MessageType FOREIGN KEY (MessageTypeID) REFERENCES core.Log_Type (MessageType_ID)
	)
GO
