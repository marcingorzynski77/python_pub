IF OBJECT_ID ('[core].[MarsVaRs_Fact]') IS NOT NULL
	DROP TABLE [core].[MarsVaRs_Fact]
GO

CREATE TABLE [core].[MarsVaRs_Fact]
( 
    [CoreVarKey] BIGINT IDENTITY(1,1) NOT NULL
    ,[BusDate] DATETIME2 NOT NULL
	,[CoreSourceKey] BIGINT NOT NULL
	,[CoreHierarchyKey]	BIGINT NOT NULL
	,[CoreScenarioHierarchyKey] BIGINT NOT NULL
	,[CoreRiskMeasureTypeKey] BIGINT NOT NULL
	,[AnalysisTypeName] VARCHAR (255) NOT NULL
    ,[VarMeasureType] VARCHAR (255) NOT NULL
    ,[LegalEntity] VARCHAR(255) NULL
    ,[Cad2] BIT NULL
    ,[ConfidenceLevel] FLOAT NOT NULL
    ,[Label] VARCHAR(255) NOT NULL
    ,[ValueGBP] FLOAT NOT NULL
    ,CONSTRAINT [PK_CalculatedVaRs_Fact] PRIMARY KEY ([CoreVarKey])
);
GO

CREATE NONCLUSTERED INDEX [IX_MarsVaRs_Fact_BusinessKeys]
    ON [core].[MarsVaRs_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreScenarioHierarchyKey] ASC, [CoreRiskMeasureTypeKey] ASC, [AnalysisTypeName] ASC, [LegalEntity] ASC, [Cad2] ASC, [ConfidenceLevel] ASC, [VarMeasureType] ASC);
GO
