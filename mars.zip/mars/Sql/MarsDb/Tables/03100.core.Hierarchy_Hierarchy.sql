IF OBJECT_ID ('core.Hierarchy_Hierarchy') IS NOT NULL
	DROP TABLE core.Hierarchy_Hierarchy
GO

CREATE TABLE core.Hierarchy_Hierarchy
	(
	  CoreHierarchyKey	BIGINT NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, NodeId			BIGINT NOT NULL
	, NodeParentID		BIGINT NOT NULL
	, NodeName			VARCHAR (50) NOT NULL
	, NodeType			CHAR (2) NOT NULL
	, BookLegalEntity	VARCHAR (20)
	, Ordinality		BIT
	, Reporting			BIT
	, RingFenced		BIT
	, [Group]			VARCHAR (50)
	, SubGroup			VARCHAR (50)
	, Business 			VARCHAR (50)
	, BusinessArea		VARCHAR (50)
	, Division			VARCHAR (50)
	, Desk				VARCHAR (50)
	, SubDesk			VARCHAR (200)
	, Book				VARCHAR (50)
	, BookSystem		VARCHAR (50) NOT NULL
	, HierarchyString	VARCHAR (900)
	, HierarchyTag [int] NULL
	)
GO
