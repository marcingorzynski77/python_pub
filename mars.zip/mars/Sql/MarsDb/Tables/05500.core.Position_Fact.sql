/****** Object:  Table [core].[Position_Fact]    Script Date: 03/22/2017 14:40:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_Fact]') AND type in (N'U'))
DROP TABLE [core].[Position_Fact]
GO


CREATE TABLE [core].[Position_Fact](
	[CorePositionKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[CoreHierarchyKey] [bigint] NOT NULL,
	[CoreInstrumentKey] [bigint] NOT NULL,
	[CoreInstrumentTypeKey] [bigint] NOT NULL,
	[CoreCountryKey] [bigint] NOT NULL,
	[CoreRatingKey] [bigint] NOT NULL,
	[BusDate] [datetime2](7) NULL,
	[PositionTradeDate] [float] NULL,
	[PositionValueDate] [float] NULL,
	[WABP] [float] NULL,
	[StartAccrual] [float] NULL,
	[EndAccrual] [float] NULL,
	[ValueDateAccrual] [float] NULL,
	[Unamortised] [float] NULL,
	[MarketValue] [float] NULL,
	[MarketValueGBP] [float] NULL,
	[MarketValueDP] [float] NULL,
	[MarketValueDPGBP] [float] NULL,
	[RealisedPnL] [float] NULL,
	[NPV] [float] NULL,
	[PosValDateNPV] [float] NULL,
	[InterestDays] [int] NULL,
	[CouponAmount] [float] NULL,
	[CS01] [float] NULL,
	[StandardisedCS01] [float] NULL,
	[ZSpread] [float] NULL,
	[HardCallDate] [datetime2](7) NULL
)

GO


CREATE NONCLUSTERED INDEX [IX_Position_Fact_BusinessKeys]
    ON [core].[Position_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreInstrumentKey] ASC, [CoreInstrumentTypeKey] ASC, [CoreCountryKey] ASC, [CoreRatingKey] ASC);
GO