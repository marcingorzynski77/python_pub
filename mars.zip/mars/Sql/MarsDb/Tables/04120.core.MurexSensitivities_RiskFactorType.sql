IF OBJECT_ID ('core.MurexSensitivities_RiskFactorType') IS NOT NULL
	DROP TABLE core.MurexSensitivities_RiskFactorType
GO

CREATE TABLE core.MurexSensitivities_RiskFactorType
	(
	  CoreRiskFactorTypeKey BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorTypeName    VARCHAR (255) NOT NULL
	, CONSTRAINT PK_MurexSensitivities_RiskFactorType PRIMARY KEY (CoreRiskFactorTypeKey)
	)
GO
