IF OBJECT_ID ('core.Hierarchy_HierarchyBook') IS NOT NULL
	DROP TABLE core.Hierarchy_HierarchyBook
GO

CREATE TABLE [core].[Hierarchy_HierarchyBook](
	[CoreHierarchyBookKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[NodeId] [bigint] NOT NULL,
	[NodeName] [varchar](50) NOT NULL,
	[NodeType] [char](2) NOT NULL,
	[BookCad2] [bit] NULL,
	[Trading] [bit] NULL,
	[BookSystem] [varchar](50) NOT NULL
) ON [PRIMARY]

GO
