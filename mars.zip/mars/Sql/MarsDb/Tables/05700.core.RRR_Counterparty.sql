/****** Object:  Table [core].[RRR_Counterparty]    Script Date: 08/31/2017 14:09:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_Counterparty]') AND type in (N'U'))
DROP TABLE [core].[RRR_Counterparty]
GO

CREATE TABLE [core].[RRR_Counterparty](
	[CoreCounterpartyKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[CounterpartyCode]			[varchar](255) NOT NULL,
	[CounterpartyCodeType]		[varchar](255) NOT NULL,
	[LegalName]					[varchar](1000) NULL,
	[TradingStatus]				[varchar](255) NULL,
	[TradingName]				[varchar](1000) NULL,
	[BusinessType]				[varchar](255) NULL,
	[InternalClassification]	[varchar](255) NULL,
	[InternalDescription]		[varchar](255) NULL,
	[RfbSegment]				[varchar](255) NULL,
	[DiamondSegment]			[varchar](255) NULL,
	[HocustCode]				[varchar](255) NULL,
	[InternalClient]			[bit] NULL
) ON [PRIMARY]

GO


