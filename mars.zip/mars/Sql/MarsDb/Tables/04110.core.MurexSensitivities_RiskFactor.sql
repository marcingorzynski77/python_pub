IF OBJECT_ID ('core.MurexSensitivities_RiskFactor') IS NOT NULL
	DROP TABLE core.MurexSensitivities_RiskFactor
GO

CREATE TABLE core.MurexSensitivities_RiskFactor
	(
	  CoreRiskFactorKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey		BIGINT NOT NULL
	, RiskFactorName	VARCHAR (255) NOT NULL
	, CONSTRAINT PK_MurexSensitivities_RiskFactor PRIMARY KEY (CoreRiskFactorKey)
	)
GO
