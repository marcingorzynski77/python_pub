IF OBJECT_ID ('core.SimraPnLs_InstrumentType') IS NOT NULL
	DROP TABLE core.SimraPnLs_InstrumentType
GO

CREATE TABLE core.SimraPnLs_InstrumentType
	(
	 CoreInstrumentTypeKey	BIGINT IDENTITY NOT NULL
	,CoreSourceKey			BIGINT NOT NULL
	,InstrumentType			VARCHAR (255) NOT NULL
	,InstrumentSubType		VARCHAR (255) NOT NULL
	,CONSTRAINT PK_SimraPnLs_InstrumentType PRIMARY KEY (InstrumentType, CoreSourceKey)
	)
GO

CREATE UNIQUE INDEX IX_SimraPnLs_InstrumentType
	ON core.SimraPnLs_InstrumentType (CoreInstrumentTypeKey)
GO

