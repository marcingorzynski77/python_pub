IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[staging].[FinancialDefinition]') AND type in (N'U'))
DROP TABLE [staging].[FinancialDefinition]
GO

CREATE TABLE [staging].[FinancialDefinition](
	[CoreFinancialDefinitionKey][bigint] NULL,
	[CoreSourceKey][bigint] NULL,
	[EffectiveDate] [datetime2](7) NULL,
	[FDLegalEntity] [varchar](50) NULL,
	[Denominator] [varchar](255) NULL,
	[DenominatorType] [varchar](50) NULL,
	[FDValueGBP] [float] NULL,
	[Notes] [varchar](255) NULL,
	[SourceKey][bigint]NULL,
	[AppliedRules] [varchar](100) NULL,
	[FinancialDefinitionKey][bigint]NULL
) ON [PRIMARY]

GO



