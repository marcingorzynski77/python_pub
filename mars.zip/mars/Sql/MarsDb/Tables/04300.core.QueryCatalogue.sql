IF OBJECT_ID ('core.QueryCatalogue') IS NOT NULL
	DROP TABLE core.QueryCatalogue
GO

CREATE TABLE core.QueryCatalogue
	(
	  ID             BIGINT IDENTITY NOT NULL
	, Start          DATETIME2 NOT NULL
	, Finish         DATETIME2
	, HierarchyNode  BIGINT
	, Name           VARCHAR (50)
	, Alias          VARCHAR (50)
	, VersionID      INT
	, Query          VARCHAR (max)
	, Comment        VARCHAR (1000)
	, DesignedBy     VARCHAR (20)
	, QuestionAsked  VARCHAR (max)
	, LegoXML        VARCHAR (max)
	, UserName       NVARCHAR (256) NOT NULL
	, Active         BIT
	, SystemUserName NVARCHAR (256) CONSTRAINT DF_t_Query_Catalogue_SystemUserName DEFAULT ((original_login()+' as ')+suser_sname()) NOT NULL
	, VersionPath    VARCHAR (max)
	, CONSTRAINT PK_t_Query_Catalogue PRIMARY KEY NONCLUSTERED (ID)
	WITH (FILLFACTOR = 80)
	)
GO
