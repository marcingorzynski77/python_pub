/****** Object:  Table [core].[RRR_RiskMeasureType]    Script Date: 08/31/2017 14:16:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_RiskMeasureType]') AND type in (N'U'))
DROP TABLE [core].[RRR_RiskMeasureType]
GO


CREATE TABLE [core].[RRR_RiskMeasureType](
	[CoreRiskMeasureTypeKey] [bigint] NOT NULL,
	[CoreSourceKey] [bigint] NULL,
	[RiskMeasureTypeName] [varchar](50) NOT NULL,
	[RiskMeasureFamily] [varchar](50) NOT NULL
) ON [PRIMARY]

GO



