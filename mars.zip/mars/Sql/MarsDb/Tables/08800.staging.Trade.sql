/****** Object:  Table [staging].[Trade]    Script Date: 08/31/2017 14:25:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[staging].[Trade]') AND type in (N'U'))
DROP TABLE [staging].[Trade]
GO

CREATE TABLE [staging].[Trade](
	[CoreTradeKey]			bigint NULL,
	[CoreSourceKey]			bigint NULL,
	[TradeKey]				bigint NULL,
	[SourceKey]				bigint NULL,	
	/* common data */
	[TradeReference]		varchar(255) NULL,
	/* RRR data */	
	[InScopeForRRR]			bit NULL,
	[Maturity]				DATETIME2(7) NULL,
	[Notional]				decimal(24,4) NULL,
	[NotionalCurrency]		char(3) NULL,
	[StructureId]			VARCHAR(100) NULL,
	[PackageMemberType]		VARCHAR(10) NULL,
	[ProxyTradeFlag]		varchar(255) NULL,
	[InternalTradeFlag]		varchar(255) NULL,
	[HedgeTradeFlag]		varchar(255) NULL,
	[GrandFatheredFlag]		varchar(255) NULL,
	[TradePurpose]			varchar(255) NULL,
	[AppliedRules]			VARCHAR(100) NULL,
	/* Murex Option data */ 
	[TradeVersion]			INT NULL, 
	[TradeState]			VARCHAR(50) NULL,
	[TradeDateTime]			DATETIME2 NULL,
	[CaptureDateTime]		DATETIME2 NULL,
	[AmendDateTime]			DATETIME2 NULL,
	[AmendArea]				VARCHAR(50) NULL,
	[AmendReason]			VARCHAR(50) NULL,
	/* trade details */
	[BorS]					VARCHAR(1) NULL,
	[ExpiryDate]			DATETIME2 NULL,
	[Exercisetype]			varchar(1) NULL,
	[PutOrCall]				VARCHAR(1) NULL,
	[MaturityDate]			DATETIME2 NULL,
	[ExerciseDate]			DATETIME2 NULL,
	[Strike]				DECIMAL(18,8) NULL,
	[ValueDate]				DATETIME2 NULL,
	[Price]					DECIMAL(18,8) NULL,
	[ReceiveCurrency]		VARCHAR(3) NULL, 
	[ReceiveAmount]			DECIMAL(18,2) NULL,
	[PayCurrency]			VARCHAR(3) NULL,
	[PayAmount]				DECIMAL(18,2) NULL,
	[MainCurrency]			VARCHAR(3) NULL,
	[ForwardRate]			DECIMAL(18,8) NULL,
	[PremiumCurrency]		VARCHAR(3) NULL,
	[PremiumAmount]			DECIMAL(18,2) NULL,
	[TradeTypeSubType]		VARCHAR(100) NULL
) ON [PRIMARY]

GO

CREATE UNIQUE CLUSTERED INDEX [PK_StagingTrade_BusinessKey] ON [staging].[Trade] 
(	
	[TradeReference]
) 