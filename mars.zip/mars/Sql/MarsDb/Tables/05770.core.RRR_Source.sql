/****** Object:  Table [core].[RRR_Source]    Script Date: 08/31/2017 14:16:39 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[RRR_Source]') AND type in (N'U'))
DROP TABLE [core].[RRR_Source]
GO

CREATE TABLE [core].[RRR_Source](
	[CoreSourceKey] [bigint] IDENTITY(1,1) NOT NULL,
	[InterfaceName] [varchar](64) NOT NULL,
	[Environment] [varchar](50) NOT NULL,
	[Source] [varchar](50) NOT NULL,
	[Origin] [varchar](50) NOT NULL,
 CONSTRAINT [PK_RRR_Source] PRIMARY KEY CLUSTERED 
(
	[CoreSourceKey] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO



