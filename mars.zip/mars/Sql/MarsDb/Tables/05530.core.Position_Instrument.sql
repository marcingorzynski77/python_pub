/****** Object:  Table [core].[Position_Instrument]    Script Date: 03/22/2017 14:43:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[Position_Instrument]') AND type in (N'U'))
DROP TABLE [core].[Position_Instrument]
GO

CREATE TABLE [core].[Position_Instrument](
	[CoreInstrumentKey] [bigint] IDENTITY(1,1) NOT NULL,
	[CoreSourceKey] [bigint] NOT NULL,
	[Issue Date] [datetime2](7) NULL,
	[InstrumentID] [varchar](30) NULL,
	[InstrumentIDType] [varchar](30) NULL,
	[Product] [varchar](255) NULL,
	[Currency] [varchar](255) NULL,
	[Eff Date] [datetime2](7) NULL,
	[Maturity] [datetime2](7) NULL,
	[Issuer] [varchar](255) NULL,
	[IssuerName] [varchar](255) NULL,
	[FixedFRN] [char](3) NULL,
	[SeniorityLevel] [varchar](255) NULL,
	[Day Basis] [varchar](255) NULL,
	[PayFrequency] [varchar](255) NULL,
	[ISIN] [varchar](255) NULL,
	[CUSIP] [varchar](255) NULL,
	[Settle Ccy] [varchar](255) NULL,
	[Issue Price] [float] NULL,
	[RedemptionPrice] [float] NULL,
	[Ref Guarantor] [varchar](255) NULL,
	[Notes_LongName1] [varchar](255) NULL,
	[SIC2007] [varchar](255) NULL,
	[Index Linked Bond] [varchar](255) NULL
)

GO
