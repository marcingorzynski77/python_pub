IF OBJECT_ID ('core.GDIRiskMeasureTrade_RiskMeasureType') IS NOT NULL
	DROP TABLE core.GDIRiskMeasureTrade_RiskMeasureType
GO

CREATE TABLE core.GDIRiskMeasureTrade_RiskMeasureType
	(
	  CoreRiskMeasureTypeKey	BIGINT IDENTITY NOT NULL
	, CoreSourceKey				BIGINT NOT NULL
	, RiskMeasureTypeName		VARCHAR (255) NOT NULL
	, RiskMeasureFamily			VARCHAR (255) NOT NULL
	, CONSTRAINT PK_GDIRiskMeasuresTrade_RiskMeasureType PRIMARY KEY (CoreRiskMeasureTypeKey)
	)
GO
