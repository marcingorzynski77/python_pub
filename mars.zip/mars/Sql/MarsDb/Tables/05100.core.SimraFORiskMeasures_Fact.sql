IF OBJECT_ID ('core.SimraFORiskMeasures_Fact') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_Fact
GO

CREATE TABLE [core].[SimraFORiskMeasures_Fact] (
	[CoreRiskMeasureKey]		[bigint] IDENTITY NOT NULL,
	[CoreSourceKey]				[bigint] NOT NULL,
	[CoreHierarchyKey]			[bigint] NOT NULL,
	[CoreRiskMeasureTypeKey]	[bigint] NOT NULL,
	[CoreRiskFactorTypeKey]		[bigint] NOT NULL,
	[CoreRiskFactorKey]			[bigint] NOT NULL,
	[CoreInstrumentTypeKey]		[bigint] NOT NULL,
	[CoreInstrumentTenorKey]	[bigint] NOT NULL,
	[CoreUnderlyingTenorKey]	[bigint] NOT NULL,
	[CoreFixingTenorKey]		[bigint] NOT NULL,
	[BusDate]					[datetime2](7) NOT NULL,
	[ProformaShift]				[varchar](255) NULL,
	[ProformaShiftValue]		[float] NULL,
	[LegalEntity]				[varchar](50) NULL,
	[Cad2]						[bit] NULL,
	[InstrumentMatDays]			[int] NULL,
	[UnderlyingMatDays]			[int] NULL,
	[FixingMatDays]				[int] NULL,
	[ValueCurrency]				[varchar](7) NULL,
	[Value]						[float] NULL,
	[ValueGBP]					[float] NULL
) ON [PRIMARY]

GO

CREATE NONCLUSTERED INDEX [IX_SimraFORiskMeasures_Fact_BusinessKeys]
    ON [core].[SimraFORiskMeasures_Fact]([BusDate] ASC, [CoreHierarchyKey] ASC, [CoreRiskMeasureTypeKey] ASC, [CoreRiskFactorTypeKey] ASC, [CoreRiskFactorKey] ASC, [CoreInstrumentTypeKey] ASC, [CoreInstrumentTenorKey] ASC, [CoreUnderlyingTenorKey] ASC, [CoreFixingTenorKey] ASC, [ProformaShift] ASC, [LegalEntity] ASC, [Cad2] ASC, [ValueCurrency] ASC);
GO