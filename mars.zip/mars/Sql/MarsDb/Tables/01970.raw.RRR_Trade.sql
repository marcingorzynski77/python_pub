IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[RRR_Trade]') AND type in (N'U'))
	DROP TABLE [raw].[RRR_Trade]	
GO


CREATE TABLE [raw].[RRR_Trade](	
	/* Business Key */
	[TradeReference] [varchar](255) NULL,
	/* RRR Data */	
	[Maturity]				datetime2(7) NULL,
	[InScopeForRRR]			bit NULL,
	[Notional]				decimal(24,4) NULL,
	[NotionalCurrency]		char(3) NULL,
	[Origin]				varchar(25) NULL,
	[StructureId]			VARCHAR(100) NULL,
	[PackageMemberType]		VARCHAR(10) NULL,
	/* Attributes */
	[GrandFatheredFlag]		varchar(255) NULL,
	[HedgeTradeFlag]		varchar(255) NULL,
	[ProxyTradeFlag]		varchar(255) NULL,
	[InternalTradeFlag]		varchar(255) NULL,	
	[TradePurpose]			varchar(255) NULL,
	[AppliedRules]			varchar(100) NULL
) ON [PRIMARY]

GO

