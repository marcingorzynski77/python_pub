IF OBJECT_ID ('staging.RiskFactor') IS NOT NULL
	DROP TABLE staging.RiskFactor
GO

CREATE TABLE staging.RiskFactor
	(
	  CoreRiskFactorKey	BIGINT NULL
	, CoreSourceKey		BIGINT
	, RiskFactorName	VARCHAR (255) NOT NULL
	, SourceKey			BIGINT
	, AppliedRules		VARCHAR (100)
	, RiskFactorKey		BIGINT NULL
	)
GO
