IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[raw].[GDIInflation_Result]') AND type in (N'U'))
	DROP TABLE [raw].[GDIInflation_Result]
GO

CREATE TABLE [raw].[GDIInflation_Result](
	[Record Identifier]	   [VARCHAR](100) NULL,
	[Trade Identifier]	   [VARCHAR](100) NULL,
	[Instrument Type]	   [VARCHAR](100) NULL,
	[Risk Factor Name]	   [VARCHAR](100) NULL,
	[GridCell]			   [VARCHAR](100) NULL,
	[Risk Currency]		   [VARCHAR](100) NULL,
	[Index]				   [VARCHAR](100) NULL,
	[Underlying]		   [VARCHAR](100) NULL,
	[Scenario Underlying]  [VARCHAR](100) NULL,
	[Sensitivity Value]	   [VARCHAR](100) NULL,
	[ExceptionCode]		   [VARCHAR](100) NULL,
	[ExceptionDescription] [VARCHAR](100) NULL
) ON [PRIMARY]

GO

