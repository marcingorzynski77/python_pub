IF OBJECT_ID ('core.SimraFORiskMeasures_InstrumentType') IS NOT NULL
	DROP TABLE core.SimraFORiskMeasures_InstrumentType
GO

CREATE TABLE core.SimraFORiskMeasures_InstrumentType
	(
	 CoreInstrumentTypeKey	BIGINT IDENTITY NOT NULL
	,CoreSourceKey			BIGINT NOT NULL
	,InstrumentType			VARCHAR (255) NOT NULL
	,InstrumentSubType		VARCHAR (255) NOT NULL
	,CONSTRAINT PK_SimraFORiskMeasures_CoreInstrumentTypeKey PRIMARY KEY (CoreInstrumentTypeKey)
	)
GO
