IF OBJECT_ID ('[core].[MarsVaRs_Hierarchy]') IS NOT NULL
	DROP TABLE [core].[MarsVaRs_Hierarchy]
GO

CREATE TABLE [core].[MarsVaRs_Hierarchy]
( 
    [CoreHierarchyKey] BIGINT IDENTITY(1,1) NOT NULL,
    [CoreSourceKey] BIGINT NOT NULL,
    [NodeName] VARCHAR (50) NOT NULL,
	[NodeType] CHAR (2) NOT NULL,
	[BookSystem] VARCHAR (50) NOT NULL,
	[HierarchyTag] INT NULL,
    [HierarchyString] VARCHAR(900) NULL,
    [Group] VARCHAR(255) NOT NULL,
    [SubGroup] VARCHAR(255) NULL,
    [Business] VARCHAR(255) NULL,
    [BusinessArea] VARCHAR(255) NULL,
    [Division] VARCHAR(255) NULL,
    [Desk] VARCHAR(255) NULL,
    [SubDesk] VARCHAR(255) NULL,
    CONSTRAINT PK_MarsVaRs_Hierarchy PRIMARY KEY (CoreHierarchyKey)
) 