Param (
    [Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbName = "MaRS_XXXX",
    [Parameter(Mandatory=$False)]
    [ValidateNotNull()]
    $DbInstance = "FMX-D8-3076\BRIDGEX01"
)

Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.ConnectionInfo.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Management.Sdk.Sfc.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Smo.dll"

Write-Output "Attempting to drop database "
Write-Output "instance : $DbInstance"
Write-Output "database : $DbName"

Write-Output "------------------------------"

$Query = "

select * from sys.databases where name = '$DbName'

if (@@rowcount > 0)
begin
	ALTER DATABASE $DbName SET RESTRICTED_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE $DbName;
END
"

$ConnectionTimeout=60
$conn = new-object System.Data.SqlClient.SQLConnection 
$ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $DbInstance, 'master', $ConnectionTimeout
$conn.ConnectionString = $ConnectionString

$serverConnection= new-object Microsoft.SqlServer.Management.Common.ServerConnection($conn)
$server = new-object Microsoft.SqlServer.Management.Smo.Server($serverConnection)
Write-Output $ConnectionString
Write-Output $Query
$server.ConnectionContext.ExecuteNonQuery($Query)
$conn.Close()


