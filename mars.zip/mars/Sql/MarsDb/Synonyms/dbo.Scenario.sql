IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Scenario')
	DROP SYNONYM [dbo].[Scenario]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Scenario')
	CREATE SYNONYM [dbo].[Scenario] FOR [target].[vScenario]
GO
