IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Instrument')
	DROP SYNONYM [dbo].[Instrument]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Instrument')
	CREATE SYNONYM [dbo].[Instrument] FOR [target].[vInstrument]
GO
