IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskNode_Fact')
	DROP SYNONYM [dbo].[RiskNode_Fact]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskNode_Fact')
	CREATE SYNONYM [dbo].[RiskNode_Fact] FOR [target].[vRiskNode_Fact]
GO
