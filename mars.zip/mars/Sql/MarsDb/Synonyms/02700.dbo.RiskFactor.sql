IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskFactor')
	DROP SYNONYM [dbo].[RiskFactor]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskFactor')
	CREATE SYNONYM [dbo].[RiskFactor] FOR [target].[vRiskFactor]
GO
