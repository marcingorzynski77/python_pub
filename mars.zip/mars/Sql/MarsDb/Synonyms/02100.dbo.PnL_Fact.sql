IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Pnl_Fact')
	DROP SYNONYM [dbo].[Pnl_Fact]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Pnl_Fact')
	CREATE SYNONYM [dbo].[Pnl_Fact] FOR [target].[vPnl_Fact]
GO
