IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Rating')
DROP SYNONYM [dbo].[Rating]
GO

/****** Object:  Synonym [dbo].[Country]    Script Date: 03/30/2017 17:38:31 ******/
CREATE SYNONYM [dbo].[Rating] FOR [target].[vRating]
GO


