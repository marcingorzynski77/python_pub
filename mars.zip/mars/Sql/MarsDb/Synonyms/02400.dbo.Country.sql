IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Country')
DROP SYNONYM [dbo].[Country]
GO

/****** Object:  Synonym [dbo].[Country]    Script Date: 03/30/2017 17:38:31 ******/
CREATE SYNONYM [dbo].[Country] FOR [target].[vCountry]
GO


