IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasureType')
	DROP SYNONYM [dbo].[RiskMeasureType]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasureType')
	CREATE SYNONYM [dbo].[RiskMeasureType] FOR [target].[vRiskMeasureType]
GO
