IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasure')
	DROP SYNONYM [dbo].[RiskMeasure] 
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasure')
	CREATE SYNONYM [dbo].[RiskMeasure] FOR [dataset].[vRiskMeasure]
GO
