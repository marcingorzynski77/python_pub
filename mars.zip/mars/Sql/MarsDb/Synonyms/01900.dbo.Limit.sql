IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Limit')
	DROP SYNONYM [dbo].[Limit]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Limit')
	CREATE SYNONYM [dbo].[Limit] FOR [dataset].[vLimit]
GO


