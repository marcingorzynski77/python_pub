IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Trident_t_CR01')
	DROP SYNONYM [dbo].[Trident_t_CR01]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Trident_t_CR01')
	CREATE SYNONYM [dbo].[Trident_t_CR01] FOR [FMU-D8-3076\TRIDENTU01].[Trident].[report].[t_CR01]
GO
