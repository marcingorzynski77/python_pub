/****** Object:  Synonym [dbo].[RRRAggregated]    Script Date: 09/01/2017 16:08:49 ******/
IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RRRAggregated')
DROP SYNONYM [dbo].[RRRAggregated]
GO

/****** Object:  Synonym [dbo].[RRRAggregated]    Script Date: 09/01/2017 16:08:49 ******/
CREATE SYNONYM [dbo].[RRRAggregated] FOR [dataset].[vRRRAggregated]
GO


