IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'MarketData')
	DROP SYNONYM [dbo].[MarketData] 
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'MarketData')
	CREATE SYNONYM [dbo].[MarketData] FOR [dataset].[vMarketData]
GO
