IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FinancialDefinition')
	DROP SYNONYM [dbo].[FinancialDefinition]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FinancialDefinition')
	CREATE SYNONYM [dbo].[FinancialDefinition] FOR [target].[vFinancialDefinition]
GO
