IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FXSpot')
	DROP SYNONYM [dbo].[FXSpot]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FXSpot')
	CREATE SYNONYM [dbo].[FXSpot] FOR [dataset].[vFXSpot]
GO


