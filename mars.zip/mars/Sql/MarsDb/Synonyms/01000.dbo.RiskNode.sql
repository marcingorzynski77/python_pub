IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskNode')
	DROP SYNONYM [dbo].[RiskNode]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskNode')
	CREATE SYNONYM [dbo].[RiskNode] FOR [dataset].[vRiskNode]
GO
