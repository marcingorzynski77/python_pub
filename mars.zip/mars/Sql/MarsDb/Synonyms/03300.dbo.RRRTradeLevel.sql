/****** Object:  Synonym [dbo].[RRRTradeLevel]    Script Date: 09/01/2017 16:08:49 ******/
IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RRRTradeLevel')
DROP SYNONYM [dbo].[RRRTradeLevel]
GO

/****** Object:  Synonym [dbo].[RRRTradeLevel]    Script Date: 09/01/2017 16:08:49 ******/
CREATE SYNONYM [dbo].[RRRTradeLevel] FOR [dataset].[vRRRTradeLevel]
GO


