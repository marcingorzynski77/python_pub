/****** Object:  Synonym [dbo].[Counterparty]    Script Date: 08/30/2017 14:49:31 ******/
IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Counterparty')
DROP SYNONYM [dbo].[Counterparty]
GO

/****** Object:  Synonym [dbo].[Counterparty]    Script Date: 08/30/2017 14:49:31 ******/
CREATE SYNONYM [dbo].[Counterparty] FOR [target].[Counterparty]
GO


