IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'TimeTravel')
	DROP SYNONYM [dbo].[TimeTravel]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'TimeTravel')
	CREATE SYNONYM [dbo].[TimeTravel] FOR [target].[vTimeTravel]
GO
