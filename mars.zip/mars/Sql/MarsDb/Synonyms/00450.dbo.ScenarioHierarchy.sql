IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'ScenarioHierarchy')
	DROP SYNONYM [dbo].[ScenarioHierarchy]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'ScenarioHierarchy')
	CREATE SYNONYM [dbo].[ScenarioHierarchy] FOR [dataset].[vScenarioHierarchy]
GO
