IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'VAR')
	DROP SYNONYM [dbo].[VAR]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'VAR')
	CREATE SYNONYM [dbo].[VAR] FOR [dataset].[vVAR]
GO


