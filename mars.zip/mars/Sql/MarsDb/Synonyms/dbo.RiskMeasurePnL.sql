IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasurePnL')
	DROP SYNONYM [dbo].[RiskMeasurePnL] 
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasurePnL')
	CREATE SYNONYM [dbo].[RiskMeasurePnL] FOR [dataset].[vRiskMeasurePnL]
GO
