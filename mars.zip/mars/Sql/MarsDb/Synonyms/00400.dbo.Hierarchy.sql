IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Hierarchy')
	DROP SYNONYM [dbo].[Hierarchy]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Hierarchy')
	CREATE SYNONYM [dbo].[Hierarchy] FOR [dataset].[vHierarchy]
GO
