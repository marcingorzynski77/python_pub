IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'PnL')
	DROP SYNONYM [dbo].[PnL]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'PnL')
	CREATE SYNONYM [dbo].[PnL] FOR [dataset].[vPnL]
GO


