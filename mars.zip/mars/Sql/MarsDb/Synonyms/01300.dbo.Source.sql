IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Source')
	DROP SYNONYM [dbo].[Source]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Source')
	CREATE SYNONYM [dbo].[Source] FOR [target].[vSource]
GO
