IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'InstrumentType')
	DROP SYNONYM [dbo].[InstrumentType]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'InstrumentType')
	CREATE SYNONYM [dbo].[InstrumentType] FOR [target].[InstrumentType]
GO
