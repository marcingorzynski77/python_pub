IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasureTrade')
	DROP SYNONYM [dbo].[RiskMeasureTrade] 
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskMeasureTrade')
	CREATE SYNONYM [dbo].[RiskMeasureTrade] FOR [dataset].[vRiskMeasureTrade]
GO
