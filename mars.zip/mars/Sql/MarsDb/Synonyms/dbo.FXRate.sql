IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FXRate')
	DROP SYNONYM [dbo].[FXRate]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FXRate')
	CREATE SYNONYM [dbo].[FXRate] FOR [dataset].[vFXRate]
GO
