IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Position_Fact')
	DROP SYNONYM [dbo].[Position_Fact]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Position_Fact')
	CREATE SYNONYM [dbo].[Position_Fact] FOR [target].[vPosition_Fact]
GO
