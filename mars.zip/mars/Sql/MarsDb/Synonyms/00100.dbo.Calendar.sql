IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Calendar')
	DROP SYNONYM [dbo].[Calendar]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Calendar')
	CREATE SYNONYM [dbo].[Calendar] FOR [dataset].[vCalendar]
GO
