IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FXRate_Fact')
	DROP SYNONYM [dbo].[FXRate_Fact]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'FXRate_Fact')
	CREATE SYNONYM [dbo].[FXRate_Fact] FOR [target].[vFXRate_Fact]
GO
