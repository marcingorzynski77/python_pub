IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskFactorType')
	DROP SYNONYM [dbo].[RiskFactorType]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'RiskFactorType')
	CREATE SYNONYM [dbo].[RiskFactorType] FOR [target].[vRiskFactorType]
GO
