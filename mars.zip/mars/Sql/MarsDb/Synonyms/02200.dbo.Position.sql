IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Position')
	DROP SYNONYM [dbo].[Position]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Position')
	CREATE SYNONYM [dbo].[Position] FOR [dataset].[vPosition]
GO

