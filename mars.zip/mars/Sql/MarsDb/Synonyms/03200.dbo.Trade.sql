/****** Object:  Synonym [dbo].[RRRTradeLevel]    Script Date: 09/01/2017 10:07:09 ******/
IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Trade')
DROP SYNONYM [dbo].[Trade]
GO


/****** Object:  Synonym [dbo].[RRRTradeLevel]    Script Date: 09/01/2017 10:07:09 ******/
CREATE SYNONYM [dbo].[Trade] FOR [target].[vTrade]
GO


