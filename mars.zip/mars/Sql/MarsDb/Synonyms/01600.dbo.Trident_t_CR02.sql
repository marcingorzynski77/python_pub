IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Trident_t_CR02')
	DROP SYNONYM [dbo].[Trident_t_CR02]
GO

IF NOT EXISTS (SELECT * FROM sys.synonyms WHERE name = N'Trident_t_CR02')
	CREATE SYNONYM [dbo].[Trident_t_CR02] FOR [FMU-D8-3076\TRIDENTU01].[Trident].[report].[t_CR01]
GO
