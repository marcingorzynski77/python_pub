#Location of the script to create
$destination = "$PSScriptRoot\200.BootStrap.sql"

# Database Server and Database to be built
#
#$DBServer = "FMD-D8-3076\TRIDENTD01"
$DBServer = "FMD-D8-3076\BRIDGED01"
#$DBServer = "FMU-D8-3076\BRIDGEU01"
#$DBServer = "FMP-D8-3076\BRIDGEP01"

$DBDatabase = "MaRS_RC14"
#$DBDatabase = "MaRS_AS"
#$DBDatabase = "MaRS_SIT"

$DatabaseServer = $DBServer.replace($DBServer.Substring(0, $DBServer.IndexOf('\') + 1), '')

Function QueryInfoMessage($sender, $e) {
    foreach ($err in $e.Errors)
    {
        Write-Host $err.Message;
    }
}

Function ExecuteSql ($Connection, $SQLQuery) {
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $SQLQuery

    try
    {
        $reader = [System.Data.SqlClient.SqlDataReader]$command.ExecuteReader()

        while (!$reader.IsClosed)
        {
            while ($reader.Read())
            {
                if ($reader[0] -eq '!! ERROR !!')
                {
                    throw $reader[0] + ": " + $reader[1]
                }
            }

            if (!$reader.NextResult())
            {
                $reader.Close()
            }
        }
    }
    Catch [System.Data.SqlClient.SqlException]
    {
        $Err = $_
        Write-Host "SQL Error: $Err"
        Throw $Err
    }
}

#$ConnectionString = "Provider=SQLNCLI10.1;Data Source=$DBSERVER;Initial Catalog=master;Trusted_Connection=Yes"

#Remove previously concatenated file
If (Test-Path $destination){
	Remove-Item $destination
}


#Add script locations in order of dependence
$Folders = New-Object string[] 9
$Folders[0] = $PSScriptRoot + "\Schemas"
$Folders[1] = $PSScriptRoot + "\Types"
$Folders[2] = $PSScriptRoot + "\Tables"
$Folders[3] = $PSScriptRoot + "\Functions"
$Folders[4] = $PSScriptRoot + "\Views"
$Folders[5] = $PSScriptRoot + "\Synonyms"
$Folders[6] = $PSScriptRoot + "\Procedures"
$Folders[7] = $PSScriptRoot + "\Data"
$Folders[8] = $PSScriptRoot + "\UsersAndRoles"


$CreateScript =  $PSScriptRoot + "\CreateDatabase.sql"

#Run the scripts

try
{
    #$Connection = New-Object System.Data.SQLClient.SQLConnection
    #$Connection.ConnectionString = "server='$DBServer';database='master';trusted_connection=true;"
    #$Connection.Open()

    # first get and edit the Create-database script
#    get-content $CreateScript | % { $_.replace("XXX_DBNAME_XXX",$DBDatabase) } | % { $_.replace("XXX_DBSERVERNAME_XXX",$DatabaseServer) } | Out-File $destination -Append -encoding ascii
    get-content $CreateScript | % { $_.replace("XXX_DBNAME_XXX",$DBDatabase) } | % { $_.replace("XXX_DBSERVERNAME_XXX",$DatabaseServer) } | % { $_ -replace "(^|\s+)GO(\s+|$)", "" } -outvariable sqlarray | Out-Null
    $sql = $sqlarray -join "`n" 
#    ExecuteSql -Connection $Connection -SQLQuery $sql

    write $sql | Out-File "$PSScriptRoot\100.CreateDatabase.sql" -encoding ascii

    write "USE [$DBDatabase]" | Out-File $destination -Append -encoding ascii
    write "GO" | Out-File $destination -Append -encoding ascii

#    $Connection.Close()
#    $Connection.ConnectionString = "server='$DBServer';database='$DBDatabase';trusted_connection=true;"
#    $Connection.Open()

    #Insert groups of scripts in specific order
    Foreach ($path in $Folders)
    {
        write "Folder -- $path"

        write "PRINT '----$path----'`n" | Out-File $destination -Append -encoding ascii

        $Scripts = Get-ChildItem $path | Sort-Object  #-Include *.sql

        Foreach ($script in $Scripts)
        {
            
            if ($script -match "[0-9][0-9][0-9][0-9][0-9].*.sql")
            {
                write "$path\$script"
                write "`n`n--`n-- $path\$script`n--`n" | Out-File $destination -Append -encoding ascii
                ##write "PRINT '$path\$script'`n" | Out-File $destination -Append -encoding ascii
                get-content $path\$script | Out-File $destination -Append -encoding ascii
                write "GO" | Out-File $destination -Append -encoding ascii            # To be sure, to be sure

                get-content $path\$script | % { $_ -replace "(^|\s+)GO(\s+|$)", "" } -outvariable sqlarray | Out-Null
                $sql = $sqlarray -join "`n"
#                ExecuteSql -Connection $Connection -SQLQuery $sql
            }
            else
            {
                write "Ignoring file: $path\$script"
            }
        }
    }

     write "PRINT 'MaRS DB Objects created'`n" | Out-File $destination -Append -encoding ascii

    #
    # Now connect to the server and load the file
    #
##    Invoke-Sqlcmd2 -ServerInstance $DBServer -InputFile $destination
#    $Connection.Close()
}
catch 
{
    $ex = $_.Exception
    Write-Error "$ex.Message" 
}
finally
{
    #$Connection.Close()
}
