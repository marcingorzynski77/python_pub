IF OBJECT_ID ('target.p_Run_QueryFromCatalogue2') IS NOT NULL
	DROP PROCEDURE target.p_Run_QueryFromCatalogue2
GO

CREATE PROC [target].[p_Run_QueryFromCatalogue2] 
(
	@TrackerCRC VARCHAR(6),
	@FilePath VARCHAR(300),
	@FileName VARCHAR(100),	
	@UserName varchar(50),
	@ID INT = 0,
	@QueryAlias VARCHAR(100) = '',
	@QueryVersion VARCHAR(3) = 0,
	@Query AS VARCHAR(MAX) = ''
)
AS
BEGIN
	SET NOCOUNT ON

    DECLARE
    	@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@Public			VARCHAR(50);

BEGIN TRY

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--


	--SQL provided or just the ID?
	IF @Query = '' 	
	BEGIN		
		SET @Query = (SELECT Query FROM core.QueryCatalogue WHERE VersionID = cast(@QueryVersion as int) and Alias = @QueryAlias)
	END
	
	
	--Get owner because we only want to track public queries
	set @Public = (select [owner] 
					from core.QueryCatalogue_Hierarchy  H
					join core.QueryCatalogue C
					on C.HierarchyNode = h.NodeID
					where C.ID = @ID)
	

	--If a public query, update the tracker to log activity
	IF @Public = 'Public'
		EXEC [target].[p_IU_QueryTracker] @FilePath, @FileName, @UserName, @ID, 'INSERT'


	--Do IT!
	EXECUTE(@Query)
	
	
	--If a public query, finalise the tracker
	IF @Public = 'Public'
		EXEC [target].[p_IU_QueryTracker] @FilePath, @FileName, @UserName, @ID, 'FINISH'
	

END TRY

BEGIN CATCH

    SELECT 
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,        
		@ErrorProcedure = isnull(ERROR_PROCEDURE(),'err') ,        
        @ErrorLine		= ERROR_LINE();
		        
        --LOG        
        EXEC [core].p_LogError @SessionID = 0
					  ,@ErrorNumber = @ErrorNumber
					  ,@ProcedureName=@ProcedureName
					  ,@ProcID = @@ProcID
					  ,@ErrorProcedure = @ErrorProcedure
					  ,@ErrorSeverity = @ErrorSeverity
					  ,@ErrorState = @ErrorState
					  ,@ErrorMessage = @ErrorMessage
					  ,@NESTLEVEL = @@NESTLEVEL
					  ,@ErrorLine = @ErrorLine;
			               
		select 'There has been an error: ' + @ErrorMessage 

END CATCH

END

GO
