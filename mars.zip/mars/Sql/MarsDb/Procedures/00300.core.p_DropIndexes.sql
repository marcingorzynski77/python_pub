IF OBJECT_ID ('core.p_DropIndexes') IS NOT NULL
	DROP PROCEDURE core.p_DropIndexes
GO

CREATE PROC core.p_DropIndexes (
      @IndexSchemaName	varchar(250),
      @IndexTableName	varchar(250)
)
AS
BEGIN
	declare @IndexName	varchar(250)
	declare @SQL		NVARCHAR(MAX)

	-- create a temporary table only available for this connection
	IF (OBJECT_ID('tempdb..#IndexTab') is not null)
		truncate table #IndexTab
	ELSE
		create table #IndexTab (row_n int, IndexName varchar(max));

	INSERT INTO #IndexTab
	SELECT DISTINCT
		ROW_NUMBER() over (order by ind.name) as row_n, ind.name AS IndexName
	FROM
	 	sys.indexes ind
		INNER JOIN 
		sys.tables t
	    	ON
	    		ind.object_id = t.object_id
	WHERE
		t.is_ms_shipped = 0
		AND
		OBJECT_SCHEMA_NAME(ind.object_id) = @IndexSchemaName
		AND
		OBJECT_NAME(ind.object_id) = @IndexTableName
		AND
		ind.type <> 0			-- not a heap
		AND
		ind.is_primary_key <> 1		-- not a primary key column
	ORDER BY
		ind.name

	declare @IdxTotalRows	int
	declare @idxCurrentrow	int = 1

	set @IdxTotalRows = (select COUNT(*) from #IndexTab)

	IF @IdxTotalRows > 0
	BEGIN
		WHILE @IdxCurrentrow <= @IdxTotalRows
		BEGIN
			SET @IndexName = (select IndexName from #IndexTab where row_n = @IdxCurrentrow)

			IF isnull(@IndexName,'blank') = 'blank' or LEN(@IndexName) = 0
				Print '@IndexName is zero length varchar'
			ELSE
			BEGIN
				SET @SQL = ''
				SET @SQL = @SQL + ' drop index ' + @IndexName
				SET @SQL = @SQL + ' on ' + @IndexSchemaName + '.' + @IndexTableName

--				PRINT @SQL
				EXEC sp_executesql @SQL
			END

			set @IdxCurrentrow = @IdxCurrentrow + 1
		END
	END
	ELSE
	BEGIN
		PRINT 'No Index(s) found for table ' + @IndexSchemaName + '.' + @IndexTableName
	END

	--    drop the temporary table - only available for this connection
	IF (OBJECT_ID('tempdb..#DimTab') is not null) drop table #DimTab;
END
GO
