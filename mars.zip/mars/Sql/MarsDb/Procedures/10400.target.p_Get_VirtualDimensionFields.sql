/****** Object:  StoredProcedure [target].[p_Get_VirtualDimensionFields]    Script Date: 07/10/2017 11:53:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_VirtualDimensionFields]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Get_VirtualDimensionFields]
GO

CREATE PROC [target].[p_Get_VirtualDimensionFields] (
	@Event as varchar(10),
	@Fields as varchar(max),
	@Fact as varchar(50) = null
)
AS 

BEGIN

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--

	SET NOCOUNT ON
	
	--hack to temporatily allow cross compatibility across adin versions
	if @Fact is null set @Fact = 'MarketData'	
	

	if charindex('D_InstrumentTenor',@Fields,1) = 0
		AND charindex('D_UnderlyingTenor',@Fields,1) = 0
		AND charindex('D_FixingTenor',@Fields,1) = 0
	begin
		if @Event = 'SELECT'
		begin
			--Determine the @Fields to be returned and handle columns from recycled dimensions 
			set @Fields = Replace(@Fields,'[InstrumentTenorName]', 'D_InstrumentTenor.[tenorName] as [InstrumentTenorName]');
			set @Fields = Replace(@Fields,'[UnderlyingTenorName]', 'D_UnderlyingTenor.[tenorName] as [UnderlyingTenorName]');
			set @Fields = Replace(@Fields,'[FixingTenorName]', 'D_FixingTenor.[tenorName] as [FixingTenorName]');
			set @Fields = Replace(@Fields,'[InstrumentTenorDays]', ' ISNULL(CASE WHEN D_InstrumentTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_InstrumentTenor.TenorName, target.' + @Fact + '_Fact.BusDate) ' +
										  'ELSE DATEDIFF(day, target.' + @Fact + '_Fact.BusDate, D_InstrumentTenor.TenorDate) END, '' '') AS InstrumentTenorDays');
			set @Fields = Replace(@Fields,'[UnderlyingTenorDays]', ' ISNULL(CASE WHEN D_UnderlyingTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_UnderlyingTenor.TenorName, target.' + @Fact + '_Fact.BusDate) ' +
										  'ELSE DATEDIFF(day, target.' + @Fact + '_Fact.BusDate, D_UnderlyingTenor.TenorDate) END, '' '') as [UnderlyingTenorDays]');
			set @Fields = Replace(@Fields,'[FixingTenorDays]', ' ISNULL(CASE WHEN D_FixingTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_FixingTenor.TenorName, target.' + @Fact + '_Fact.BusDate) ' +
										  'ELSE DATEDIFF(day, target.' + @Fact + '_Fact.BusDate, D_FixingTenor.TenorDate) END, '' '') as [FixingTenorDays]');
		end
		else if @Event = 'WHERE'
		begin
			--Determine the @Fields to be returned and handle columns from recycled dimensions 
			set @Fields = Replace(@Fields,'[InstrumentTenorName]', 'D_InstrumentTenor.[tenorName]');
			set @Fields = Replace(@Fields,'[UnderlyingTenorName]', 'D_UnderlyingTenor.[tenorName]');
			set @Fields = Replace(@Fields,'[FixingTenorName]', 'D_FixingTenor.[tenorName]');
			set @Fields = Replace(@Fields,'[InstrumentTenorDays]', 'D_InstrumentTenor.[tenorDays]');
			set @Fields = Replace(@Fields,'[UnderlyingTenorDays]', 'D_UnderlyingTenor.[tenorDays]');
			set @Fields = Replace(@Fields,'[FixingTenorDays]', 'D_FixingTenor.[tenorDays]');                
		end
	end            

    select @Fields;   
			 			 
	RETURN

--#-------------------------------------------------- END OF HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

END

GO


