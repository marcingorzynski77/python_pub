/****** Object:  StoredProcedure [target].[p_Get_ExistingAlias]    Script Date: 02/22/2017 16:14:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_ExistingAlias]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Get_ExistingAlias]
GO


CREATE PROC [target].[p_Get_ExistingAlias] 
(
	@Owner NVARCHAR(30),
	@Alias NVARCHAR(30),	
	@Name NVARCHAR(50)
)
AS 

BEGIN

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--

	SET NOCOUNT ON;

	DECLARE @ProcedureName AS NVARCHAR(128)
	SET	@ProcedureName = OBJECT_NAME(@@PROCID)
	
	DECLARE @SQL NVARCHAR(300)

	CREATE TABLE #Alias
	(
		Alias VARCHAR(50)
	)

	--Build query to get all Aliases similar to proposed Alias name
	SET @sql = 'SELECT DISTINCT Alias FROM core.QueryCatalogue Q'
				+ ' INNER JOIN core.QueryCatalogue_Hierarchy H on Q.HierarchyNode = H.NodeID'
				+ ' WHERE H.[Owner] = ''' + @Owner + ''''
				+ ' AND Q.Alias like ''' + @Alias + '%'''
				+ ' AND Q.Name <> ''' + @Name + ''''
	
	EXEC [core].[p_LogDebug] @ProcedureName, @SQL
	
	--Run query into temp table
	INSERT INTO #Alias EXECUTE (@SQL)
	
	--If proposed alias doesn't feature in list then wipe the table
	IF (SELECT COUNT(1) FROM #Alias WHERE Alias = @Alias) = 0
		TRUNCATE TABLE #Alias
	
	 
	SELECT Alias FROM #Alias
	
	DROP TABLE #Alias
	 
	RETURN

--#-------------------------------------------------- END OF HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

END
GO


