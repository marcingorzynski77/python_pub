/****** Object:  StoredProcedure [target].[p_Flex_GetReportData]    Script Date: 06/23/2017 10:05:02 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Flex_GetReportData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [target].[p_Flex_GetReportData]
GO

--exec [target].[p_Flex_GetReportData] 'LimitValueExpansion','PV01 (�k) IR Delta', 'Select * from target.Limit_fact'
--exec [target].[p_Flex_GetReportData] 'LimitValueExpansion','Limit/Trigger','SELECT * from target.limit_fact'

CREATE PROC [target].[p_Flex_GetReportData] 
(
	@Report as varchar(50),
	@ReportTable as varchar(50),
	@DataSetQuery as varchar(MAX)
)
AS

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE
		@return_status		int,
        @ProcedureName      NVARCHAR(128),
        @Message 	        NVARCHAR(MAX),
        @BusinessLogicSev	INT,
        @SessionID  		BIGINT ,
        @VersionPath		varchar(100);
		
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
        @Message            = 'Invoking ' + @ProcedureName;

	exec [core].p_LogInfo @ProcedureName, @Message
	set @SessionID = @@IDENTITY	
  
--#---------------------------------------- END OF STANDARD TRANSACTION HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY	

set nocount on
	DECLARE @colsUnpivot AS NVARCHAR(MAX),
			@query  AS NVARCHAR(MAX),
			@colsPivot as  NVARCHAR(MAX),
			@colsHeader as  NVARCHAR(MAX)
    
	SELECT @query = N'IF EXISTS (SELECT 1 FROM tempdb.dbo.sysobjects WHERE name = ''@table'' AND xtype = ''U'') DROP TABLE @table'
	SELECT @query = REPLACE(@query, N'@table', N'##Values')
	EXEC sp_executesql @query
    
   --Get headers
    SELECT I.FlexFactKey,I.[key],I.Value into #Headers
	FROM   target.flexfactinstance I 
		   INNER JOIN target.flexfact F 
				   ON I.flexfactkey = F.flexfactkey 
		   INNER JOIN target.flexfacthierarchy H 
				   ON F.flexfacthierarchykey = H.flexfacthierarchykey      
	WHERE  H.description = 'Report.Headers.Data'  
		AND I.[Key] like 'ColumnDisplayName%'
		
	--Only take the headers we're interested in	
	delete from #Headers where FlexFactKey <> (select flexfactkey from #Headers where [KEY] = 'ColumnDisplayName0' and  Value = @ReportTable)
	

	--Identify headers
	select @colsHeader = STUFF((SELECT  ',' 
                      + quotename(Value)
						from #Headers t
						FOR XML PATH(''), TYPE
						).value('.', 'NVARCHAR(MAX)') 
					,1,1,'')

	print 'headers: ' + @colsHeader


	--Get values
    SELECT   I.flexfactkey,I.[key],I.Value  into #Values
	FROM   target.flexfactinstance I 
		   INNER JOIN target.flexfact F 
				   ON I.flexfactkey = F.flexfactkey 
		   INNER JOIN target.flexfacthierarchy H 
				   ON F.flexfacthierarchykey = H.flexfacthierarchykey      
	WHERE  H.description = 'Report.Values.Data'  		
	--	AND (I.[Key] like 'ColumnValue%' OR I.[Key] like 'DataValue')
		AND F.finish = '99991231'
	
	print 'delete'
	
	--Only take the rows we're interested in	
	delete from #Values where FlexFactKey not in (select flexfactkey from #Values where [key] = 'Dataset' and Value = 'Limit')
	
	print 'try'
	if (select COUNT(1) from #Values) > 0
	begin
		Print 'Start'
		--build strings for pivot
		set @colsPivot = ''
		select @colsPivot = @colsPivot + ',' + [key] from (select distinct [key] from #Values)a
		select @colspivot = right(@colspivot,len(@colspivot)-1)
		
		print 'cols: ' + @colspivot


		--Pivot query around values
		set @query 
		  = 'select *, columnvalue0 as ''' + @ReportTable + ''' into ##Values
			 from
			 (	select   flexfactkey, '+@colsPivot+' 
				  from
				  (
					select  flexfactkey,value,[key]
					from #Values        
				  ) src	
				  pivot
				  (
					max([value])
					for [key] in ('+@colsPivot+')
				  ) piv
			  )V
			  left join (' + @DataSetQuery + ') L on L.name = V.Datavalue'

		exec(@query)
		
		
		--Pivot query around identified headers
		set @query 
		  = 'select * 
			 from
			 (	select '+@colsHeader+' 
				  from
				  (
					select  value,[columnvalue2]
					from ##Values
				  ) src	
				  pivot
				  (
					sum([value])
					for [columnvalue2] in ('+@colsHeader+')
				  ) piv
			  )tab'

		print @query

		exec(@query)
		
		drop table #Values	
		drop table #Headers

		SELECT @query = N'IF EXISTS (SELECT 1 FROM tempdb.dbo.sysobjects WHERE name = ''@table'' AND xtype = ''U'') DROP TABLE @table'
		SELECT @query = REPLACE(@query, N'@table', N'##Values')
		EXEC sp_executesql @query
		
	end
	
	--exec [target].[p_Flex_GetReportData] 'LimitValueExpansion','PV01 �k IR Delta', 'Select * from target.Limit_fact'
	
	return

set nocount off

END TRY

--#---------------------------------------------------- END OF IUSP ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END






GO


