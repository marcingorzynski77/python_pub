/****** Object:  StoredProcedure [core].[p_Purge_TradeRule]    Script Date: 04/05/2018 13:52:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Purge_TradeRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_Purge_TradeRule]
GO


create proc [core].[p_Purge_TradeRule]
AS
begin

	--Delete previous data older than 1 week 
	declare @7daysAgo as datetime2(7) = DATEADD(DAY,-7,GETUTCDATE())
	
	delete from target.TradeRule
	where BusDate < @7daysAgo

end
GO


