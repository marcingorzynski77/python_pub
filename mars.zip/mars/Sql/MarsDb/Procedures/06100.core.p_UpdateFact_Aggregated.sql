/****** Object:  StoredProcedure [core].[p_UpdateFact_RRRAggregated]    Script Date: 09/08/2017 10:55:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_UpdateFact_RRRAggregated]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_UpdateFact_RRRAggregated]
GO

CREATE PROC [core].[p_UpdateFact_RRRAggregated]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT		= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName  			NVARCHAR(128),
		@Message 	 		   		NVARCHAR(MAX),
		@return_value				BIGINT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT			= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
    DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter
	
	print 'Clear out any temp tables'

	-------------------------------------------------------------------------------------------------
	-- Clear out any temp tables
	IF OBJECT_ID ('tempdb..#C2T_Source') IS NOT NULL DROP TABLE #C2T_Source;
	IF OBJECT_ID ('tempdb..#C2T_Hierarchy') IS NOT NULL DROP TABLE #C2T_Hierarchy;	
	IF OBJECT_ID ('tempdb..#C2T_FinancialDefinition') IS NOT NULL DROP TABLE #C2T_FinancialDefinition;
	IF OBJECT_ID ('tempdb..#C2T_RiskMeasureType') IS NOT NULL DROP TABLE #C2T_RiskMeasureType;
	--IF OBJECT_ID ('tempdb..#C2T_Counterparty') IS NOT NULL DROP TABLE #C2T_Counterparty;
	IF OBJECT_ID ('tempdb..#C2T_RRRAggregated') IS NOT NULL DROP TABLE #C2T_Fact_RRRAggregated;
	
	IF OBJECT_ID ('tempdb..#C2T_Fact_Updates') IS NOT NULL DROP TABLE #C2T_Fact_Updates;

	--Create the temp tables
	CREATE TABLE #C2T_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	CREATE TABLE #C2T_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);	
	CREATE TABLE #C2T_FinancialDefinition (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	CREATE TABLE #C2T_RiskMeasureType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
--	CREATE TABLE #C2T_Counterparty (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
				
	CREATE TABLE #C2T_Fact_Updates (CoreRRRAggregatedKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);	
		
	print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'	
	-------------------------------------------------------------------------------------------------
		
	
	PRINT 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
	
	INSERT INTO @CoreIndexColumns VALUES ('BusDate'),('CoreHierarchyKey'),('CoreRiskMeasureTypeKey'),('CoreFinancialDefinitionKey')
	EXEC core.p_CreateIndex
		@IndexName = 'IX_RRR_Aggregated_Fact_BusinessKeys',
		@SchemaName = 'core',
		@TableName = 'RRR_Aggregated_Fact',
		@TableOfColumns = @CoreIndexColumns


	SELECT DISTINCT
		@LoadInterface =S.InterfaceName
	FROM
		[core].[RRR_Aggregated_Fact] F
		join
		[core].RRR_Source S
		on
			F.CoreSourceKey = S.CoreSourceKey
			
	
	INSERT #C2T_Source (CoreDimKey, TargetDimKey)
		SELECT DISTINCT C.CoreSourceKey, T.SourceKey
		FROM [CORE].[RRR_Source] C JOIN [TARGET].[Source] T ON
			C.InterfaceName = T.InterfaceName AND C.Environment = T.Environment AND C.Source = T.Source AND C.Origin = T.Origin
			AND T.Start <= @Nowdate AND T.Finish > @Nowdate
			

	INSERT #C2T_Hierarchy (CoreDimKey, TargetDimKey)
		SELECT [C].CoreHierarchyKey, MAX([T].HierarchyKey)									-- Be defensive on possible Corruption
		FROM [CORE].[RRR_Hierarchy] [C] JOIN [TARGET].vHierarchyConsolidated [T]
			ON 	COALESCE([C].[NodeName],'') = COALESCE([T].[NodeName],'')
				AND COALESCE([C].[NodeType],'') = COALESCE([T].[NodeType],'')
				AND COALESCE([C].[BookSystem],'') = COALESCE([T].[BookSystem],'')
				AND T.Start <= @Nowdate AND T.Finish > @Nowdate
		GROUP BY [C].CoreHierarchyKey
	
		
	INSERT #C2T_FinancialDefinition (CoreDimKey, TargetDimKey)
		SELECT [C].CoreFinancialDefinitionKey, MAX([T].FinancialDefinitionKey)						-- Be defensive on possible Corruption
		FROM [CORE].[RRR_FinancialDefinition] [C] JOIN [TARGET].FinancialDefinition [T]
			ON C.EffectiveDate = T.EffectiveDate
				AND C.FDLegalEntity = T.FDLegalEntity
				and C.Denominator = T.Denominator
				and c.DenominatorType = t.DenominatorType
				AND T.Start <= @Nowdate AND T.Finish > @Nowdate
		GROUP BY [C].CoreFinancialDefinitionKey
				
		
	INSERT #C2T_RiskMeasureType (CoreDimKey, TargetDimKey)
		SELECT [C].CoreRiskMeasureTypeKey, MAX([T].RiskMeasureTypeKey)						-- Be defensive on possible Corruption
		FROM [CORE].[RRR_RiskMeasureType] [C] JOIN [TARGET].RiskMeasureType [T]
			ON C.RiskMeasureFamily = T.RiskMeasureFamily
				AND C.RiskMeasureTypeName = T.RiskMeasureTypeName
				AND T.Start <= @Nowdate AND T.Finish > @Nowdate
		GROUP BY [C].CoreRiskMeasureTypeKey


	--INSERT #C2T_Counterparty (CoreDimKey, TargetDimKey)
	--	SELECT [C].CoreCounterpartyKey, MAX([T].CounterpartyKey)							-- Be defensive on possible Corruption
	--	FROM [CORE].[RRR_Counterparty] [C] JOIN [TARGET].Counterparty [T]
	--		ON C.CounterpartyCode = T.CounterpartyCode
	--			AND C.CounterpartyCodeType = T.CounterpartyCodeType
	--			AND T.Start <= @Nowdate AND T.Finish > @Nowdate
	--	GROUP BY [C].CoreCounterpartyKey


	-- Perform the actual merge
	INSERT #C2T_Fact_Updates ( CoreRRRAggregatedKey ,  FactKey, IsAttributeMatch )		
	SELECT [C].CoreRRRAggregatedKey,
		   [TARGET].FactKey,
		  CASE WHEN COALESCE([C].[ValueGBP],0)=COALESCE([TARGET].[ValueGBP],0) 
				 AND COALESCE([C].[Internal],'')=COALESCE([TARGET].[Internal],'') 				
				 AND COALESCE([C].[DerivativeFlag],'')=COALESCE([TARGET].[DerivativeFlag],'') 				
				 AND COALESCE([C].[OptionFlag],'')=COALESCE([TARGET].[OptionFlag],'')
				 AND COALESCE([C].[GrandFatheredFlag],'') =COALESCE([TARGET].[GrandFatheredFlag],'')
				 AND COALESCE([C].[ProxyTradeFlag],'') =COALESCE([TARGET].[ProxyTradeFlag],'')	
				 AND COALESCE([C].[InternalTradeFlag],'') =COALESCE([TARGET].[InternalTradeFlag],'')
				 AND COALESCE([C].[HedgeTradeFlag],'') =COALESCE([TARGET].[HedgeTradeFlag],'')
				 AND COALESCE([C].[TradePurpose],'') =COALESCE([TARGET].[TradePurpose],'')
				 AND COALESCE([C].[IncludedTrades],0)=COALESCE([TARGET].[IncludedTrades],0) 
				 AND COALESCE([C].[ExcludedTrades],0)=COALESCE([TARGET].[ExcludedTrades],0) 					
		   THEN 1 ELSE 0 END AS IsAttributeMatch	
	FROM [CORE].[RRR_Aggregated_Fact] [C]
	JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [C].[CoreSourceKey]
	LEFT JOIN #C2T_Hierarchy ON #C2T_Hierarchy.[CoreDimKey] = [C].[CoreHierarchyKey]	
	LEFT JOIN #C2T_FinancialDefinition ON #C2T_FinancialDefinition.[CoreDimKey] = [C].[CoreFinancialDefinitionKey]
	LEFT JOIN #C2T_RiskMeasureType ON #C2T_RiskMeasureType.[CoreDimKey] = [C].[CoreRiskMeasureTypeKey]
--	LEFT JOIN #C2T_Counterparty ON #C2T_Counterparty.[CoreDimKey] = [C].[CoreCounterpartyKey]
	FULL OUTER JOIN (SELECT * FROM [TARGET].[RRRAggregated_Fact] where BusDate = @BusDate AND Finish > @Nowdate) [TARGET] ON
		[C].[BusDate] = [TARGET].[BusDate]
		--AND isnull([TARGET].[ValueGBP],0) = isnull(c.ValueGBP,0)
		AND isnull([TARGET].[ValueCurrency],0) = isnull(c.ValueCurrency,0)
		AND isnull([TARGET].AggregationID,'') = isnull(c.AggregationID,'')
		AND isnull([TARGET].AggregationRule,'') = isnull(c.AggregationRule,'')
		AND isnull([TARGET].AggregationType,'') = isnull(c.AggregationType,'')
		AND isnull([TARGET].LegalEntity,'') = isnull(c.LegalEntity,'')
		AND isnull([TARGET].MaturityBucket,'') = isnull(c.MaturityBucket,'')
		AND isnull([TARGET].AssetClass,'') = isnull(c.AssetClass,'')
	--	AND isnull([TARGET].Internal,'') = isnull(c.Internal,'')
--		AND isnull([TARGET].DerivativeFlag,'') = isnull(c.DerivativeFlag,'')
--		AND isnull([TARGET].OptionFlag,'') = isnull(c.OptionFlag,'')
		--AND isnull([TARGET].IncludedTrades,0) = isnull(c.IncludedTrades,0)
		AND isnull([TARGET].[HierarchyKey],0) = isnull(#C2T_Hierarchy.[TargetDimKey],0)
		AND isnull([TARGET].[FinancialDefinitionKey],0) = isnull(#C2T_FinancialDefinition.[TargetDimKey],0)
		AND isnull([TARGET].[RiskMeasureTypeKey],0) = isnull(#C2T_RiskMeasureType.[TargetDimKey],0)
	--	AND isnull([TARGET].[CounterpartyKey],0) = isnull(#C2T_Counterparty.[TargetDimKey],0)


	----Print 'Adding the index'
	CREATE CLUSTERED INDEX IX_C2T_Fact_Updates_FactKey ON #C2T_Fact_Updates(FactKey,CoreRRRAggregatedKey)

	BEGIN TRANSACTION

	--Print 'Expire previous and replaced records'
	UPDATE [TARGET].[RRRAggregated_Fact] SET
		[Finish] = @NowDate
	FROM
		[TARGET].[RRRAggregated_Fact] AS FACT
		INNER JOIN
		#C2T_Fact_Updates C2T
		on
			FACT.FactKey = C2T.FactKey
		INNER JOIN
		[TARGET].[Source] S
		on
			S.SourceKey = FACT.SourceKey
	WHERE
		(
				(C2T.CoreRRRAggregatedKey IS NULL AND C2T.FactKey IS NOT NULL)
				OR
				(C2T.CoreRRRAggregatedKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
		)
		AND
		S.InterfaceName = @LoadInterface
		AND
		FACT.BusDate = @BusDate

	SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--PRINT 'Adding new and updated records'
	INSERT [TARGET].[RRRAggregated_Fact]( /*[FactKey], */ --[AppliedRules] -- CoreFactKey & TargetFactKey
		[Start]
		,[Finish]
		,[BusDate]
		,[HierarchyKey]
		,[FinancialDefinitionKey]
		,[RiskMeasureTypeKey]
	--	,[CounterpartyKey]		
		,[SourceKey]		
		,[AggregationID]
		,[AggregationType]
		,[AggregationRule]
		,[ValueGBP]
		,[ValueCurrency]
		,[LegalEntity]
		,[InstrumentType]
		,[CounterpartyLegalName]
		,[MaturityBucket]
		,[AssetClass]
		,[Internal]
		,[DerivativeFlag]
		,[OptionFlag]
		,[GrandFatheredFlag]
		,[ProxyTradeFlag]
		,[InternalTradeFlag]
		,[HedgeTradeFlag]
		,[TradePurpose]	
		,[IncludedTrades]
		,[ExcludedTrades])
	SELECT
		 @NowDate, @Finish
		,[CORE].[BUSDATE]
		, isnull(#C2T_Hierarchy.[TargetDimKey],0) as 'HierarchyKey'
		, isnull(#C2T_FinancialDefinition.[TargetDimKey],0) as 'FinancialDefinitionKey'
		, isnull(#C2T_RiskMeasureType.[TargetDimKey],0) as 'RiskMeasureTypeKey'
		--, isnull(#C2T_Counterparty.[TargetDimKey] ,0) as 'CounterpartyKey'
		, isnull(#C2T_Source.[TargetDimKey] ,0) as 'SourceKey'
		,[core].[AggregationID]
		,[core].[AggregationType]
		,[core].[AggregationRule]
		,[core].[ValueGBP]
		,[core].[ValueCurrency]
		,[core].[LegalEntity]	
		,[core].[InstrumentType]
		,[core].[CounterpartyLegalName]	
		,[core].[MaturityBucket]
		,[core].[AssetClass]
		,[core].[Internal]
		,[core].[DerivativeFlag]
		,[core].[OptionFlag]
		,[core].[GrandFatheredFlag]
		,[core].[ProxyTradeFlag]
		,[core].[InternalTradeFlag]
		,[core].[HedgeTradeFlag]
		,[core].[TradePurpose]		
		,[core].[IncludedTrades]	
		,[core].[ExcludedTrades]	
	FROM [CORE].[RRR_Aggregated_Fact] [Core]
	JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [Core].[CoreSourceKey]
	LEFT JOIN #C2T_Hierarchy ON #C2T_Hierarchy.[CoreDimKey] = [Core].[CoreHierarchyKey]	
	LEFT JOIN #C2T_FinancialDefinition ON #C2T_FinancialDefinition.[CoreDimKey] = [Core].[CoreFinancialDefinitionKey]
	LEFT JOIN #C2T_RiskMeasureType ON #C2T_RiskMeasureType.[CoreDimKey] = [Core].[CoreRiskMeasureTypeKey]
	--LEFT JOIN #C2T_Counterparty ON #C2T_Counterparty.[CoreDimKey] = [Core].[CoreCounterpartyKey]
	JOIN #C2T_Fact_Updates C2T ON [Core].CoreRRRAggregatedKey = C2T.[CoreRRRAggregatedKey]
	WHERE (C2T.CoreRRRAggregatedKey IS NOT NULL AND C2T.FactKey IS NULL)
	OR
	(C2T.CoreRRRAggregatedKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
	
	
	SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	COMMIT

	print 'Done'
	
END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	 DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END

GO


