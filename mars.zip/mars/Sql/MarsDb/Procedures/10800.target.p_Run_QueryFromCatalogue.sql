/****** Object:  StoredProcedure [target].[p_Run_QueryFromCatalogue]    Script Date: 03/23/2017 14:34:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Run_QueryFromCatalogue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Run_QueryFromCatalogue]
GO


CREATE PROC [target].[p_Run_QueryFromCatalogue] 
(
	@TrackerCRC VARCHAR(6),
	@FilePath VARCHAR(300),
	@FileName VARCHAR(100),	
	@UserName varchar(50),
	@ID INT = 0,
	@QueryAlias VARCHAR(100) = '',
	@QueryVersion VARCHAR(3) = 0,
	@Query AS VARCHAR(MAX) = ''
)
AS
BEGIN
	SET NOCOUNT ON

    DECLARE
    	@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@Public				varchar(50);

BEGIN TRY

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--


	--SQL provided or just the ID?
	IF @Query = '' 	
	BEGIN		
		SET @Query = (SELECT Query FROM core.QueryCatalogue WHERE VersionID = cast(@QueryVersion as int) and Alias = @QueryAlias)
	END
	
	IF @Query <> ''
	begin
		--Get owner because we only want to track public queries
		set @Public = (select [owner] 
					from core.QueryCatalogue_Hierarchy  H
					join core.QueryCatalogue C
					on C.HierarchyNode = h.NodeID
					where C.ID = @ID)
	

		--If a public query, update the tracker to log activity
		--IF @Public = 'Public'
		--	EXEC [target].[p_IU_QueryTracker] @FilePath, @FileName, @UserName, @ID, 'INSERT'


		--Do IT!
		EXECUTE(@Query)
	
	
		--If a public query, finalise the tracker
		--IF @Public = 'Public'
		--	EXEC [target].[p_IU_QueryTracker] @FilePath, @FileName, @UserName, @ID, 'FINISH'
	end
	else
	begin
		select '' as 'Query not found'
	end
	

END TRY

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
