IF OBJECT_ID ('core.p_DataMapping') IS NOT NULL
	DROP PROCEDURE core.p_DataMapping
GO

CREATE PROCEDURE [core].[p_DataMapping]
(
	@DataFeed		nVARCHAR(100),
	@UpdateTable	nVARCHAR(128),
	@FactOrDimTable	nVARCHAR(128),
	@SessionID		INT	= 0
)
AS

BEGIN
	SET NOCOUNT ON

	DECLARE
		@return_status      INT,
		@ProcedureName      nvarchar(128),
		@Message			NVARCHAR(MAX),
		@SQL				NVARCHAR(2048),
		@Count				INTEGER	= 0
		

	SELECT
		@ProcedureName  = OBJECT_NAME(@@PROCID),
		@SessionID		= @@IDENTITY,
		@Message		= 'Invoking ' + @ProcedureName
		
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

	SET @Message = 'DataFeed = ' + @Datafeed + ', UpdateTable = ' + @UpdateTable + ', FactOrDimTable = ' + @FactOrDimTable
    EXEC [core].p_LogDebug  @ProcedureName, @Message

	DECLARE C CURSOR FOR
		SELECT
			'UPDATE ' + @UpdateTable + ' SET ' + M.ColumnName + ' = ''' + M.TargetValue + ''' WHERE ' + M.ColumnName + ' = ''' + M.SourceValue + ''''
		FROM
			core.DataMapping M
		WHERE
			DataFeed = @DataFeed
			AND
			FactOrDimName = @FactOrDimTable

	OPEN C
	FETCH NEXT FROM C INTO @SQL

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		-- SELECT @SQL
		EXEC sp_executeSQL @SQL
		set @Count = @count + @@ROWCOUNT

		FETCH NEXT FROM C INTO @SQL
	END

	CLOSE C
	DEALLOCATE C

	--Log affected rows
	SET @Message = 'Mapped  ' + CAST(@Count AS VARCHAR(30)) + ' fields to target values in ' + @UpdateTable
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'
	
END

GO
