IF OBJECT_ID ('core.p_UpdateFact_RiskMeasureTrade') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_RiskMeasureTrade
GO

CREATE PROC [core].[p_UpdateFact_RiskMeasureTrade]
(
 	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT = 0
)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName  		NVARCHAR(128),
		@Message 	    		NVARCHAR(MAX),
		@return_value			BIGINT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50),
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
	DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

    --Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter

	set @Message = 'Clear out any temp tables'
	EXEC [core].p_LogInfo @ProcedureName, @Message
		-- Clear out any temp tables
		-------------------------------------------------------------------------------------------------
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_Source')				IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_Source;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_Hierarchy')				IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_Hierarchy;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_Counterparty')			IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_Counterparty;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_RiskFactor')			IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_RiskFactor;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_TenorUT')				IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_TenorUT;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_TenorIT')				IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_TenorIT;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_RiskMeasureType')		IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_RiskMeasureType;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_InstrumentType')		IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_InstrumentType;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_Trade')					IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_Trade;
	IF OBJECT_ID ('tempdb..#C2T_GDIRiskMeasureTrade_RiskMeasureTradeFact')	IS NOT NULL DROP TABLE #C2T_GDIRiskMeasureTrade_RiskMeasureTradeFact;
	IF OBJECT_ID ('tempdb..#C2T_RiskMeasureTradeFact_Updates')				IS NOT NULL DROP TABLE #C2T_RiskMeasureTradeFact_Updates;

	-- Keep a tempory record of our deliberations

	CREATE TABLE #C2T_RiskMeasureTradeFact_Updates (CoreKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);

	begin

		-- Do the Data Mapping in the core table
		exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = '[core].[GDIRiskMeasureTrade_Fact]', @FactOrDimTable = 'RiskMeasureTrade', @SessionID = @SessionID

		SET @Message = 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
		EXEC [core].p_LogInfo @ProcedureName, @Message
	
		
		-- Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision
		-------------------------------------------------------------------------------------------------

		CREATE TABLE #C2T_GDIRiskMeasureTrade_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_Source (CoreDimKey, TargetDimKey)
			SELECT DISTINCT C.CoreSourceKey, T.SourceKey
			FROM [CORE].[GDIRiskMeasureTrade_Source] C JOIN [TARGET].[Source] T ON
				C.InterfaceName = T.InterfaceName AND C.Environment = T.Environment AND C.Source = T.Source AND C.Origin = T.Origin
				AND T.Start <= @NowDate AND T.Finish > @NowDate

		CREATE TABLE #C2T_GDIRiskMeasureTrade_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_Hierarchy (CoreDimKey, TargetDimKey)
			SELECT [C].CoreHierarchyKey, MAX([T].HierarchyKey)											-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_Hierarchy] [C] JOIN [TARGET].vHierarchyConsolidated [T]
				ON 	COALESCE([C].[NodeName],'') = COALESCE([T].[NodeName],'')
					AND COALESCE([C].[NodeType],'') = COALESCE([T].[NodeType],'')
					AND [C].[BookSystem] = [T].[BookSystem]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreHierarchyKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_Counterparty (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_Counterparty (CoreDimKey, TargetDimKey)
			SELECT [C].CoreCounterpartyKey, MAX([T].CounterpartyKey)							-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_Counterparty] [C] JOIN [TARGET].Counterparty [T]
				ON C.CounterpartyCode = T.CounterpartyCode
					AND C.CounterpartyCodeType = T.CounterpartyCodeType
					AND T.Start <= @Nowdate AND T.Finish > @Nowdate
			GROUP BY [C].CoreCounterpartyKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_RiskFactor (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_RiskFactor (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskFactorKey, MAX([T].RiskFactorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_RiskFactor] [C] JOIN [TARGET].RiskFactor [T]
				ON [C].[RiskFactorName] = [T].[RiskFactorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskFactorKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_TenorIT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_TenorIT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_TenorUT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_TenorUT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_RiskMeasureType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_RiskMeasureType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskMeasureTypeKey, MAX([T].RiskMeasureTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_RiskMeasureType] [C] JOIN [TARGET].RiskMeasureType [T]
				ON [C].[RiskMeasureTypeName] = [T].[RiskMeasureTypeName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskMeasureTypeKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_InstrumentType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_InstrumentType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreInstrumentTypeKey, MAX([T].InstrumentTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_InstrumentType] [C] JOIN [TARGET].InstrumentType [T]
				ON [C].[InstrumentType] = [T].[InstrumentType]
					AND [C].[InstrumentSubType] = [T].[InstrumentSubType]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreInstrumentTypeKey

		CREATE TABLE #C2T_GDIRiskMeasureTrade_Trade(CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_GDIRiskMeasureTrade_Trade(CoreDimKey, TargetDimKey)
			SELECT [C].CoreTradeKey, MAX([T].TradeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[GDIRiskMeasureTrade_Trade] [C] JOIN [TARGET].Trade [T]
				ON [C].[TradeReference] = [T].[TradeReference]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTradeKey
			
		SET @Message = 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
		EXEC [core].p_LogInfo @ProcedureName, @Message
	
		INSERT INTO @CoreIndexColumns VALUES ('BusDate'),('CoreHierarchyKey'),('CoreCounterpartyKey'),('CoreRiskFactorKey'),('CoreInstrumentTenorKey'),('CoreUnderlyingTenorKey'),('CoreRiskMeasureTypeKey'),('CoreInstrumentTypeKey'),('CoreTradeKey'),('ValueCurrency')
		EXEC core.p_CreateIndex
				@IndexName		= 'IX_GDIRiskMeasureTrade_Fact_BusinessKeys',
				@SchemaName		= 'core',
				@TableName		= 'GDIRiskMeasureTrade_Fact',
				@TableOfColumns	= @CoreIndexColumns

		SELECT DISTINCT
			@LoadInterface = S.InterfaceName
		FROM [core].[SimraFORiskMeasures_Fact] F
		JOIN [core].[SimraFORiskMeasures_Source] S ON 1 = 1
			AND F.CoreSourceKey = S.CoreSourceKey

		-- Perform the actual merge
		-------------------------------------------------------------------------------------------------
		
		SET @Message = 'Perform the actual merge'
		EXEC [core].p_LogInfo @ProcedureName, @Message
		INSERT #C2T_RiskMeasureTradeFact_Updates ( CoreKey ,  FactKey, IsAttributeMatch )
	    SELECT [C].CoreRiskMeasureTradeKey, [TARGET].FactKey,
            CASE WHEN COALESCE([C].[Value],0)=COALESCE([TARGET].[Value],0)
            THEN 1 ELSE 0 END AS IsAttributeMatch
			
                  FROM [CORE].[GDIRiskMeasureTrade_Fact] [C]
					JOIN #C2T_GDIRiskMeasureTrade_Source S				ON S.[CoreDimKey]   = [C].[CoreSourceKey]
					JOIN #C2T_GDIRiskMeasureTrade_Hierarchy H			ON H.[CoreDimKey]   = [C].[CoreHierarchyKey]
					JOIN #C2T_GDIRiskMeasureTrade_Counterparty CP		ON CP.[CoreDimKey]  = [C].[CoreCounterpartyKey]
					JOIN #C2T_GDIRiskMeasureTrade_RiskFactor RF			ON RF.[CoreDimKey]  = [C].[CoreRiskFactorKey]
					JOIN #C2T_GDIRiskMeasureTrade_TenorIT IT			ON IT.[CoreDimKey]  = [C].[CoreInstrumentTenorKey]
					JOIN #C2T_GDIRiskMeasureTrade_TenorUT UT			ON UT.[CoreDimKey]  = [C].[CoreUnderlyingTenorKey]
					JOIN #C2T_GDIRiskMeasureTrade_RiskMeasureType RM	ON RM.[CoreDimKey]  = [C].[CoreRiskMeasureTypeKey]
					JOIN #C2T_GDIRiskMeasureTrade_InstrumentType I		ON I.[CoreDimKey]   = [C].[CoreInstrumentTypeKey]
					JOIN #C2T_GDIRiskMeasureTrade_Trade T				ON T.[CoreDimKey]   = [C].[CoreTradeKey]
                  FULL OUTER JOIN (	SELECT * 
									FROM [TARGET].[RiskMeasureTrade_Fact] F 
									INNER JOIN #C2T_GDIRiskMeasureTrade_Source S ON 1 = 1
										AND F.SourceKey = S.TargetDimKey 
									WHERE 1 = 1 
										AND BusDate = @BusDate
										AND Finish > @NowDate) [TARGET] ON 1 = 1
                        AND [C].[ValueCurrency] = [TARGET].[ValueCurrency]
						AND [C].[BusDate]		= [TARGET].[BusDate]											-- Will not be empty
						AND H.[TargetDimKey]	= [TARGET].[HierarchyKey]					-- And Dimension Keys - Should not be null, but just in case
						AND CP.[TargetDimKey]	= [TARGET].[CounterpartyKey]
						AND RF.[TargetDimKey]	= [TARGET].[RiskFactorKey]
						AND IT.[TargetDimKey]	= [TARGET].[InstrumentTenorKey]
						AND UT.[TargetDimKey]	= [TARGET].[UnderlyingTenorKey]
						AND RM.[TargetDimKey]	= [TARGET].[RiskMeasureTypeKey]
						AND I.[TargetDimKey]	= [TARGET].[InstrumentTypeKey]
						AND T.[TargetDimKey]	= [TARGET].[TradeKey]

		CREATE CLUSTERED INDEX IX_C2T_RiskMeasureTradeFact_Updates_FactKey ON #C2T_RiskMeasureTradeFact_Updates(FactKey,CoreKey)

        BEGIN TRANSACTION
	    -- 'Expire previous and replaced records'
		UPDATE
			[TARGET].[RiskMeasureTrade_Fact]
		SET
			[Finish] = @NowDate
		FROM [TARGET].[RiskMeasureTrade_Fact] FACT
		JOIN #C2T_RiskMeasureTradeFact_Updates C2T ON 1 = 1 
			AND FACT.FactKey = C2T.FactKey
		JOIN [TARGET].[Source] S ON 1 = 1
			AND S.SourceKey = FACT.SourceKey
		WHERE 1 = 1 
			AND ((C2T.CoreKey IS NULL AND C2T.FactKey IS NOT NULL)
				OR (C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0))
			AND S.InterfaceName = @LoadInterface
			AND FACT.BusDate = @BusDate

		SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
		EXEC [core].p_LogInfo @ProcedureName, @Message

		INSERT [TARGET].[RiskMeasureTrade_Fact] ( 
						Busdate, Start, Finish, AppliedRules
						, SourceKey
						, HierarchyKey
						, CounterpartyKey
						, RiskFactorKey
						, InstrumentTenorKey
						, UnderlyingTenorKey
						, RiskMeasureTypeKey
						, InstrumentTypeKey
						, TradeKey
						, ValueCurrency
						, [Value])
		SELECT
			[CORE].[BUSDATE], @NowDate, @finish, NULL 
				,S.[TargetDimKey]	[SourceKey]
				,H.[TargetDimKey]	[HierarchyKey]
				,CP.[TargetDimKey]	[CounterpartyKey]
				,RF.[TargetDimKey]	[RiskFactorKey]
				,IT.[TargetDimKey]	[InstrumentTenorKey]
				,UT.[TargetDimKey]	[UnderlyingTenorKey]
				,RM.[TargetDimKey]	[RiskMeasureTypeKey]
				,I.[TargetDimKey]	[InstrumentTypeKey]
				,T.[TargetDimKey]	[TradeKey]
				,[Core].ValueCurrency
				,[Core].Value
		FROM [CORE].[GDIRiskMeasureTrade_Fact] [Core]
		JOIN #C2T_GDIRiskMeasureTrade_Source S				ON S.[CoreDimKey]  = [Core].[CoreSourceKey]
		JOIN #C2T_GDIRiskMeasureTrade_Hierarchy H			ON H.[CoreDimKey]  = [Core].[CoreHierarchyKey]
		JOIN #C2T_GDIRiskMeasureTrade_Counterparty CP		ON CP.[CoreDimKey] = [Core].[CoreCounterpartyKey]
		JOIN #C2T_GDIRiskMeasureTrade_RiskFactor RF			ON RF.[CoreDimKey] = [Core].[CoreRiskFactorKey]
		JOIN #C2T_GDIRiskMeasureTrade_TenorIT IT			ON IT.[CoreDimKey] = [Core].[CoreInstrumentTenorKey]
		JOIN #C2T_GDIRiskMeasureTrade_TenorUT UT			ON UT.[CoreDimKey] = [Core].[CoreUnderlyingTenorKey]
		JOIN #C2T_GDIRiskMeasureTrade_RiskMeasureType RM	ON RM.[CoreDimKey] = [Core].[CoreRiskMeasureTypeKey]
		JOIN #C2T_GDIRiskMeasureTrade_InstrumentType I		ON I.[CoreDimKey]  = [Core].[CoreInstrumentTypeKey]
		JOIN #C2T_GDIRiskMeasureTrade_Trade	T				ON T.[CoreDimKey]  = [Core].[CoreTradeKey]
		JOIN #C2T_RiskMeasureTradeFact_Updates C2T			ON [Core].CoreRiskMeasureTradeKey = C2T.CoreKey
		WHERE 1 = 1
		AND ((C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NULL)
			OR (C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0))

		SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
		EXEC [core].p_LogInfo @ProcedureName, @Message

		COMMIT

	end

	-- Change the Superceeded data to mark it as just expired in this run
	-------------------------------------------------------------------------------------------------

END TRY


--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO