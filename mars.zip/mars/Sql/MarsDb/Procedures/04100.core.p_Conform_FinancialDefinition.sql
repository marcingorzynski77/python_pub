IF OBJECT_ID ('core.p_Conform_FinancialDefinition') IS NOT NULL
	DROP PROCEDURE core.p_Conform_FinancialDefinition
GO

CREATE PROC [core].[p_Conform_FinancialDefinition]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT	= 0
)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName				NVARCHAR(128),
        @Message					NVARCHAR(1000),
		@InitialTranCount			BIGINT,
		@Origin						VARCHAR(30),
		@EndDate					DATETIME2,
		@InsertedCount				BIGINT,
		@return_value				BIGINT,
		@ReStatement				BINARY		= 0,
		@RowCount					BIGINT,
		@SQL						nvarchar(MAX);

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7),
		@ExpireDimensionData		BINARY,
		@MaxRow						BIGINT

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@FactTableSync				INT		= 0,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName,
		@EndDate			= CAST('9999-12-31' AS DATETIME2);

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	-- Core Synchronisation Parameters
	SELECT @CoreStarPrefix = target.f_CoreStarPrefix (@DataFeed)

	-- Common Staging & Target Syncronisation Parameters
	SET @TableToSync			= 'FinancialDefinition'					-- Ommit schemas, brackets and _FACT if a fact table.
	SET @CoreSourceKeyColumn	= 'CoreSourceKey'
	
	INSERT INTO @TargetBusinessKeyColumns VALUES					-- Must be logically Unique from a business perspective
				('EffectiveDate')
				,('FDLegalEntity')
				,('Denominator')
				,('DenominatorType')

	INSERT INTO @TargetDimensionKeyColumns VALUES ('SourceKey') 	-- How This table references other Dimensions

	-- Remainder are computed
	SET @StagingTable	 = @TableToSync
	SET @TargetTable	 = @StagingTable
	SET @TargetKeyColumn = @TableToSync + 'Key'
	SET @CoreTable		 = @CoreStarPrefix + @TableToSync
	SET @CoreSourceTable = @CoreStarPrefix + 'Source'
	SET @CoreKeyColumn	 = 'Core' + @TableToSync + 'Key'


	INSERT INTO @CoreBusinessKeyColumns SELECT id from @TargetBusinessKeyColumns
	INSERT INTO @TargetIgnoreColumns VALUES ('Core'+ @TableToSync +'Key')
	-- End of Staging & Target Syncronisation Parameters

	-- CORE TO STAGING - Merge new data with existing in TARGET from other sources
	EXEC	@return_value				= [core].[p_Core2Staging]
			@Datafeed					= @Datafeed,
			@Environment				= @Env,
			@CoreTable					= @CoreTable,
			@CoreSourceTable			= @CoreSourceTable,
			@CoreKeyColumn				= @CoreKeyColumn,
			@CoreSourceKeyColumn		= @CoreSourceKeyColumn,
			@CoreBusinessKeyColumns		= @CoreBusinessKeyColumns,
			@CoreIgnoreColumns			= @CoreIgnoreColumns,
			@StagingTable				= @StagingTable,
			@TargetTable				= @TargetTable,
			@TargetKeyColumn			= @TargetKeyColumn,
			@TargetBusinessKeyColumns	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumns		= @TargetIgnoreColumns,
			@TargetRefDateTime			= @NowDate,
			@ExcludeDeprecatedFlag		= @ExcludeDeprecatedFlag,
			@SessionID					= @SessionID	

	SET @Message = CAST(@@ROWCOUNT AS VARCHAR(30)) + ' rows came from ' + @StagingTable + ' from ' + @CoreTable
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	INSERT INTO @TargetIgnoreColumns VALUES (@CoreSourceKeyColumn)

	-- STAGING TO TARGET - Update the bitemporal TARGET with the new consolidated view provided in STAGING
	EXEC	@return_value					= [core].[p_Staging2Target]
			@StagingTable					= @StagingTable,
			@StagingKeyColumn				= @CoreKeyColumn,
			@StagingBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@StagingIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@StagingRefDateTime				= @NowDate,
			@TargetTable					= @TargetTable,
			@TargetKeyColumn				= @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@TargetRefDateTime				= @NowDate,
			@ExpireDimensionData			= @ExcludeDeprecatedFlag,
			@ReStatement					= 0,
			@SessionID						= @SessionID

	SET @Message = CAST(@return_value AS VARCHAR(30)) + ' rows inserted into ' + @TargetTable + ' from Staging'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#--------------------------------------------------------------------------------------------------------------------#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END
GO