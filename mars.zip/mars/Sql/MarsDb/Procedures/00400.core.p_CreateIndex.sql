IF OBJECT_ID ('core.p_CreateIndex') IS NOT NULL
	DROP PROCEDURE core.p_CreateIndex
GO

CREATE PROC [core].[p_CreateIndex] 
(
	@IndexName	VARCHAR(250),
	@SchemaName	VARCHAR(250),
	@TableName	VARCHAR(250),
	@TableOfColumns	core.Core2TargetParameter readonly
)
As
begin
	declare @SQL NVARCHAR(MAX)
	declare @ColumnsCsv nvarchar(max)

	-- convert columns to csv
	set @ColumnsCsv = core.f_TableToCsv(@TableOfColumns,'',1)

	SET @SQL = 'CREATE INDEX ' + @IndexName 
	SET @SQL = @SQL + ' on ' + @SchemaName + '.' + @TableName + '(' + @ColumnsCsv + ')' 

--	PRINT @SQL
	EXEC sp_executesql @SQL
end

GO
