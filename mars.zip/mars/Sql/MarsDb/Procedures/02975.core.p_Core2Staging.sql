IF OBJECT_ID ('core.p_Core2Staging') IS NOT NULL
	DROP PROCEDURE core.p_Core2Staging
GO

CREATE PROC [core].[p_Core2Staging]
(
	@Datafeed					nVARCHAR(64),
	@Environment				nvarchar(30),
	@CoreTable					nVARCHAR(50),
	@CoreSourceTable			nVARCHAR(50), -- NEW
	@CoreKeyColumn				nVARCHAR(50),
	@CoreSourceKeyColumn		nVARCHAR(50),
	@CoreBusinessKeyColumns	    Core2TargetParameter READONLY,
	@CoreIgnoreColumns			Core2TargetParameter READONLY,
	@StagingTable				nVARCHAR(50),
	@TargetTable				nVARCHAR(50),
	@TargetKeyColumn			nVARCHAR(50),
	@TargetBusinessKeyColumns	Core2TargetParameter READONLY,
	@TargetIgnoreColumns		Core2TargetParameter READONLY,
	@TargetRefDateTime			DATETIME2(7),
	@ExcludeDeprecatedFlag		INT = 0,
	@SessionID					INT = 0
)

AS

BEGIN
	SET NOCOUNT ON

	DECLARE
		@return_status      INT,
		@ProcedureName      nvarchar(128),
		@Message		    NVARCHAR(MAX),
		@BusinessLogicSev   INT,
		--@SQL                varchar(1000),
		@ID					int;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName,
		@SessionID	= @@IDENTITY
		
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @DEBUG BINARY=1 -- default debug is off

	DECLARE @nSQL nvarchar(MAX)=''
	DECLARE @nAnalysisSQL nvarchar(MAX)=''
	DECLARE @nSQLCandidate nvarchar(MAX)=''

	DECLARE @AnalysisBusinessKeys VARCHAR(MAX)
	DECLARE @BusinessKeyCompare VARCHAR(MAX)
	DECLARE @CoreBusinessKeyAlias VARCHAR(MAX)
	DECLARE @CorePayloadColumns VARCHAR(MAX)
	DECLARE @CoreImportJoinCols VARCHAR(MAX)
	DECLARE @CoreBusinessKeyColumnList as varchar(MAX)
	DECLARE @StagingTableParameter nVARCHAR(50)
	DECLARE @StagingBusinessKeyColumnList as VARCHAR(MAX)
	DECLARE @StagingColumnList VARCHAR(MAX)
	DECLARE @TargetBusinessKeyColumnList as varchar(MAX)
	DECLARE @TargetImportJoinCols VARCHAR(MAX)
	DECLARE @TargetPayloadColumns VARCHAR(MAX)
	DECLARE @TargetColumnList VARCHAR(MAX)
	DECLARE @TargetRefDateStr nvarchar(30)
	DECLARE @TargetSourceTable nVARCHAR(50)
	DECLARE @TargetSourceKeyColumn nvarchar(50)
	DECLARE @COUNTER int
	DECLARE @CoreStarPrefix nVARCHAR(50)

	-- Add system suffixs to table names
	SET @StagingTableParameter	= @StagingTable
	SET @CoreTable				= '[Core].[' + @CoreTable + ']'
	SET @CoreSourceTable		= '[Core].[' + @CoreSourceTable + ']'
	SET @StagingTable			= '[Staging].[' + @StagingTable + ']'
	SET @TargetTable			= '[Target].[' + @TargetTable + ']'
	SET @TargetSourceTable		= '[Target].[SOURCE]'
	SET @TargetSourceKeyColumn	= '[SourceKey]'

	SET @Message = 'Tables names are : @CoreTable = ' + isnull(@CoreTable,' Null or no value ') + ',  @StagingTable = ' + isnull(@StagingTable,' Null or no value ') + ', @TargetTable = ' + isnull(@TargetTable, ' Null or no value ')
    IF @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	-- Do the Data Mapping in the core table or the comparison Core-to-Target won't work and staging will be wrong.
	exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = @CoreTable, @FactOrDimTable = @StagingTableParameter, @SessionID = @SessionID

	-- Transfer Parameters into working variables
	SET @TargetRefDateTime = ISNULL(@TargetRefDateTime,GETUTCDATE())
	SET @TargetRefDateStr = CONVERT(nvarchar(19),@TargetRefDateTime,121)

	-- Prepare Staging to receive new data
	SET @nSQLCandidate = 'truncate table ' + @StagingTable +';'
	EXEC sp_executesql @nSQLCandidate

	-- Business Key Columns with appropriate prefixes
	SET @CoreBusinessKeyColumnList = Null
	SELECT @CoreBusinessKeyColumnList = COALESCE( @CoreBusinessKeyColumnList + ', ', '') + '[C].[' + ID + ']'
		FROM @CoreBusinessKeyColumns;
    
    SET @Message = '@CoreBusinessKeyColumnList = ' + isnull(@CoreBusinessKeyColumnList, 'WARNING - @CoreBusinessKeyColumnList Has no Columns')
	EXEC [core].p_LogDebug @ProcedureName, @Message 

	SET @CoreBusinessKeyColumnList = isnull(@CoreBusinessKeyColumnList, '')
	SET @StagingBusinessKeyColumnList = REPLACE (@CoreBusinessKeyColumnList,'[C].','[S].')
	SET @TargetBusinessKeyColumnList = REPLACE (@CoreBusinessKeyColumnList,'[C].','[T].')
	SET @AnalysisBusinessKeys = replace (@CoreBusinessKeyColumnList,'[C].[','[A].[CORE_')

    -- Business key Alias
	SET @CoreBusinessKeyAlias = Null
	SELECT @CoreBusinessKeyAlias = COALESCE(@CoreBusinessKeyAlias + ', ', '') + '[CORE].[' + Id + '] [CORE_' + Id + ']'
		FROM @CoreBusinessKeyColumns ORDER BY id;

    SET @Message = '@CoreBusinessKeyAlias = ' + isnull(@CoreBusinessKeyAlias, 'WARNING - @CoreBusinessKeyAlias Has no Columns')
	EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @CoreBusinessKeyAlias = isnull(@CoreBusinessKeyAlias, '')
	SET @AnalysisBusinessKeys = replace (@CoreBusinessKeyAlias,'[CORE','[TARGET')

	-- CORE Payload columns with [C.] Prefix
	SET @CorePayloadColumns = Null
	SELECT @CorePayloadColumns = COALESCE(@CorePayloadColumns + ', ', '')  + '[C].[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@CoreTable)
			  and name not in (select ID name from @CoreIgnoreColumns)
			 order by name

	SET @Message = '@CorePayloadColumns = ' + isnull(@CorePayloadColumns, 'WARNING - @CorePayloadColumns Has no Columns')
	IF @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message
	
    SET @CorePayloadColumns = ISNULL(@CorePayloadColumns,'') -- avoid null + varchar giving null later
	SET @StagingColumnList = REPLACE (@CorePayloadColumns,'[C].','[S].')

	-- CORE to TARGET Business Key Compare
	SET @BusinessKeyCompare = Null
	SELECT @BusinessKeyCompare = COALESCE(@BusinessKeyCompare + ' AND ', '') + 'COALESCE([CORE].[' + Id + '],"") = COALESCE([TARGET].[' + Id + '],"")'
		FROM @CoreBusinessKeyColumns ORDER BY id;

    SET @Message = '@BusinessKeyCompare = ' + isnull(@BusinessKeyCompare, 'WARNING - @BusinessKeyCompare Has no Columns')
	EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @BusinessKeyCompare = isnull(@BusinessKeyCompare, '')

	SET @TargetImportJoinCols  = REPLACE (@BusinessKeyCompare,'[CORE].[','[T].[')
	SET @TargetImportJoinCols  = REPLACE (@TargetImportJoinCols,'[TARGET].[','[A].[TARGET_')

	SET @CoreImportJoinCols  = REPLACE (@BusinessKeyCompare,'[CORE].[','[C].[')
	SET @CoreImportJoinCols  = REPLACE (@CoreImportJoinCols,'[TARGET].[','[A].[CORE_')
	DECLARE @CoreToTargetJoinCols VARCHAR(MAX)
	SET @CoreToTargetJoinCols  = REPLACE (@BusinessKeyCompare,'[CORE].[','[C].[')
	SET @CoreToTargetJoinCols  = REPLACE (@CoreToTargetJoinCols,'[TARGET].[','[T].[')

	-- Target PayLoad Columns
	SET @TargetPayloadColumns = Null
	SELECT @TargetPayloadColumns = COALESCE(@TargetPayloadColumns + ', ', '')  + '[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable)
			  and name not in (select * from @TargetIgnoreColumns)
			  and name not in ('Start','Finish')
			 order by name
    
    SET @Message = '@TargetPayloadColumns = ' + isnull(@TargetPayloadColumns, 'WARNING - @TargetPayloadColumns Has no Columns')
	EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @TargetPayloadColumns = ISNULL(@TargetPayloadColumns,'') -- avoid null + varchar giving null later
	SET @TargetColumnList  = REPLACE (@TargetPayloadColumns,'[','[T].[')

	DECLARE @TargetAttributes varchar(MAX)
	DECLARE @CoreAttributes varchar(MAX)
	SET @TargetAttributes = Null

	SELECT @TargetAttributes = COALESCE(@TargetAttributes + ', ', '') + NullAlias
	FROM
		(SELECT COL.name name, 'COALESCE([T].['+ COL.name +'],"")' NullAlias
		FROM sys.columns as COL
		JOIN sys.types AS TYPES ON COL.system_type_id = TYPES.system_type_id
		WHERE COL.object_id = OBJECT_ID(@CoreTable)) TT
			WHERE not name = @TargetKeyColumn
			and not name in (select * from @TargetBusinessKeyColumns)
			and not name in (select * from @TargetIgnoreColumns)
			and not name in ('Start','Finish' ) --,'AppliedRules')
			and name <> @CoreKeyColumn
			and name <> 'CoreSourceKey'
			order by name
	
	IF @TargetAttributes is null SET @TargetAttributes = ' "ANY_ATTRIBUTE" '
	SET @CoreAttributes  = REPLACE (@TargetAttributes,'[T]','[C]')

	SET @Message = '@CoreAttributes = ''' + CONVERT(VARCHAR(8000), @CoreAttributes) + '@TargetAttributes=''' + CONVERT(VARCHAR(8000), @TargetAttributes) + '''' 
	EXEC [core].p_LogDebug @ProcedureName, @Message
	
	-- Contstruct the Analysis Clause
	SET @nSQL = ''
	SET @nSQL = @nSQL + 'WITH ANALYSIS AS ('
	SET @nSQL = @nSQL + '	SELECT'
	SET @nSQL = @nSQL + '		CASE'
	SET @nSQL = @nSQL + '			WHEN ('
	SET @nSQL = @nSQL + '					(CORE_PRECEDENCE IS NOT NULL)'
	SET @nSQL = @nSQL + '					AND'
	SET @nSQL = @nSQL + '					('
	SET @nSQL = @nSQL + '						TARGET_PRECEDENCE IS NULL'
	SET @nSQL = @nSQL + '						OR'
	SET @nSQL = @nSQL + '						('
	SET @nSQL = @nSQL + '							TARGET_PRECEDENCE IS NOT NULL'
	SET @nSQL = @nSQL + '							AND'
	SET @nSQL = @nSQL + '							CORE_PRECEDENCE <= TARGET_PRECEDENCE'
	SET @nSQL = @nSQL + '						)'
	SET @nSQL = @nSQL + '					)'
	SET @nSQL = @nSQL + '				)'
	SET @nSQL = @nSQL + '				THEN "CORE"'
	SET @nSQL = @nSQL + '			ELSE'
	SET @nSQL = @nSQL + '				('
	SET @nSQL = @nSQL + '					CASE'
	SET @nSQL = @nSQL + '						WHEN'
	SET @nSQL = @nSQL + '								(CORE_PRECEDENCE IS NULL) '
	SET @nSQL = @nSQL + '								AND'
	SET @nSQL = @nSQL + '								' + CONVERT(nVARCHAR(1),@ExcludeDeprecatedFlag) + ' = 1 '
	SET @nSQL = @nSQL + '								AND'
	SET @nSQL = @nSQL + '								TARGET.[TARGET_Interface] = "' + @Datafeed + '"'
	SET @nSQL = @nSQL + '								AND'
	SET @nSQL = @nSQL + '								TARGET.[TARGET_Env] = "' + @Environment + '"'
	SET @nSQL = @nSQL + '							THEN "DEPRECATE"'
	SET @nSQL = @nSQL + '						ELSE "TARGET"'
	SET @nSQL = @nSQL + '					END'
	SET @nSQL = @nSQL + '				)'
	SET @nSQL = @nSQL + '			END [USE],'
	IF RIGHT(@CoreTable,8) <> '_SOURCE]'
	BEGIN
		SET @nSQL = @nSQL + '		[Core].[CoreSourceKey],'
	END
	SET @nSQL = @nSQL + '			 ' + @CoreBusinessKeyAlias + ','
	SET @nSQL = @nSQL + '			 ' + @AnalysisBusinessKeys
	SET @nSQL = @nSQL + '	FROM'
	SET @nSQL = @nSQL + '		('
	SET @nSQL = @nSQL + '			SELECT'
	SET @nSQL = @nSQL + '				CC.*'
	SET @nSQL = @nSQL + '			from'
	SET @nSQL = @nSQL + '				('
	SET @nSQL = @nSQL + '					SELECT'
	SET @nSQL = @nSQL + '						ROW_NUMBER() OVER (PARTITION BY ' + @CoreBusinessKeyColumnList + ' ORDER BY ISNULL(G.Precedence, 999999)) AS CORE_RANK,'
	SET @nSQL = @nSQL + '						' + @CoreBusinessKeyColumnList + ', '
	IF RIGHT(@CoreTable,8) <> '_SOURCE]'
	BEGIN
		SET @nSQL = @nSQL + '					[C].[CoreSourceKey],'
		SET @nSQL = @nSQL + '					[CS].[Source],'
	END
	SET @nSQL = @nSQL + '						[CS].Origin as CORE_Origin,'
	SET @nSQL = @nSQL + '						[CS].InterfaceName as CORE_Interface,'
	SET @nSQL = @nSQL + '						[CS].Environment as CORE_Env,'
	SET @nSQL = @nSQL + '						ISNULL(G.Precedence, 999999) as CORE_PRECEDENCE'
	SET @nSQL = @nSQL + '					FROM'
	SET @nSQL = @nSQL + '						' + @CoreTable + ' C '
	SET @nSQL = @nSQL + '						JOIN'
	SET @nSQL = @nSQL + '						' + @CoreSourceTable + ' CS'
	SET @nSQL = @nSQL + '						ON'
	SET @nSQL = @nSQL + '							C.' + @CoreSourceKeyColumn + ' = CS.' + @CoreSourceKeyColumn
	SET @nSQL = @nSQL + '						left join'
	SET @nSQL = @nSQL + '						core.GoldenSource G'
	SET @nSQL = @nSQL + '						on'
	SET @nSQL = @nSQL + '							G.Dimension = "' + @StagingTableParameter + '"'
	SET @nSQL = @nSQL + '							and'
	SET @nSQL = @nSQL + '							G.Origin = CS.Origin'
	SET @nSQL = @nSQL + '							and'
	SET @nSQL = @nSQL + '							G.InterfaceName = CS.InterfaceName'
	SET @nSQL = @nSQL + ''
	SET @nSQL = @nSQL + '				) CC'
	SET @nSQL = @nSQL + '			WHERE'
	SET @nSQL = @nSQL + '				CC.CORE_RANK = 1'
	SET @nSQL = @nSQL + '		) CORE'
	SET @nSQL = @nSQL + '		FULL OUTER JOIN'
	SET @nSQL = @nSQL + '		('
	SET @nSQL = @nSQL + '			SELECT'
	SET @nSQL = @nSQL + '				TT.*'
	SET @nSQL = @nSQL + '			from'
	SET @nSQL = @nSQL + '				('
	SET @nSQL = @nSQL + '					SELECT'
	SET @nSQL = @nSQL + '						ROW_NUMBER() OVER (PARTITION BY ' + @TargetBusinessKeyColumnList + ' ORDER BY ISNULL(G.Precedence, 999999)) AS TARGET_RANK,'
	SET @nSQL = @nSQL + '						' + @TargetBusinessKeyColumnList + ', '
	IF RIGHT(@CoreTable,8) <> '_SOURCE]'
	BEGIN
		SET @nSQL = @nSQL + '					[TS].[Source] , '
		SET @nSQL = @nSQL + '					[TS].[SourceKey], '
	END
	SET @nSQL = @nSQL + '						[TS].Origin as TARGET_Origin,'
	SET @nSQL = @nSQL + '						[TS].InterfaceName as TARGET_Interface,'
	SET @nSQL = @nSQL + '						[TS].Environment as TARGET_Env,'
	SET @nSQL = @nSQL + '						ISNULL(G.Precedence, 999999) as TARGET_PRECEDENCE'
	SET @nSQL = @nSQL + '					FROM '
	SET @nSQL = @nSQL + '						' + @TargetTable + ' [T] '
	SET @nSQL = @nSQL + '						JOIN '
	SET @nSQL = @nSQL + '						' + @TargetSourceTable + ' TS '
	SET @nSQL = @nSQL + '						ON '
	SET @nSQL = @nSQL + '							T.' + @TargetSourceKeyColumn + ' = TS.' + @TargetSourceKeyColumn
	SET @nSQL = @nSQL + '						left join'
	SET @nSQL = @nSQL + '						core.GoldenSource G'
	SET @nSQL = @nSQL + '						on'
	SET @nSQL = @nSQL + '							G.Dimension = "' + @StagingTableParameter + '"'
	SET @nSQL = @nSQL + '							and'
	SET @nSQL = @nSQL + '							G.Origin = TS.Origin'
	SET @nSQL = @nSQL + '							and'
	SET @nSQL = @nSQL + '							G.InterfaceName = TS.InterfaceName'
	SET @nSQL = @nSQL + '						WHERE '
	SET @nSQL = @nSQL + '							T.Start <= "' + @TargetRefDateStr + '" '
	SET @nSQL = @nSQL + '							AND '
	SET @nSQL = @nSQL + '							T.Finish > "' + @TargetRefDateStr + '" '
	SET @nSQL = @nSQL + '				) TT'
	SET @nSQL = @nSQL + '			WHERE'
	SET @nSQL = @nSQL + '				TT.TARGET_RANK = 1'
	SET @nSQL = @nSQL + '		) TARGET '
	SET @nSQL = @nSQL + '		ON'
	SET @nSQL = @nSQL + '			' + @BusinessKeyCompare + ''
	SET @nSQL = @nSQL + ')'
	SET @nAnalysisSQL = @nSQL

	-- Insert data to staging from Target
	SET @nSQL = ''
	SET @nSQL = @nSQL + @nAnalysisSQL
	SET @nSQL = @nSQL +  ' INSERT INTO ' + @StagingTable + ' ( ' + @TargetPayloadColumns + ' ) '
	SET @nSQL = @nSQL +  ' SELECT ' + @TargetColumnList + ' '
	SET @nSQL = @nSQL +  ' FROM ' + @TargetTable + ' T '
	SET @nSQL = @nSQL +  ' INNER JOIN ANALYSIS A on ' + @TargetImportJoinCols
	SET @nSQL = @nSQL +  ' WHERE A.[USE] = "TARGET" '
	SET @nSQL = @nSQL +  '   AND T.Start <= "'+ @TargetRefDateStr + '"'
	SET @nSQL = @nSQL +  '   AND T.Finish > "'+ @TargetRefDateStr + '";'
	SET @nSQL = @nSQL +  ' SELECT @COUNTER = @@ROWCOUNT;'

	set @nSQLCandidate = ''
	SET @nSQLCandidate = @nSQLCandidate + replace (@nSQL,'"',char(39))
	SET @Message = 'From Target to Staging' + @nSQLCandidate
	EXEC [core].p_LogDebug @ProcedureName, @Message 
	EXEC sp_executesql @nSQLCandidate, N'@COUNTER INT OUTPUT', @COUNTER OUTPUT

	SET @Message = 'From Target to Staging inserted : ' + CONVERT(VARCHAR,@COUNTER);
	EXEC [core].p_LogDebug @ProcedureName, @Message;
	

	-- CORE data

	SET @nSQL = ''
	SET @nSQL = @nSQL + @nAnalysisSQL
	SET @nSQL = @nSQL + ' INSERT INTO ' + @StagingTable + ' ( ' + @CorePayloadColumns + ' , '
	SET @nSQL = @nSQL + @TargetKeyColumn +  ') '
	SET @nSQL = @nSQL + ' SELECT ' + @CorePayloadColumns + ',  '
	SET @nSQL = @nSQL + ' NULL'
	SET @nSQL = @nSQL + ' FROM ' + @CoreTable + ' C '
	SET @nSQL = @nSQL + ' INNER JOIN ANALYSIS A ON ' + @CoreImportJoinCols
	IF RIGHT(@CoreTable,8) <> '_SOURCE]'
	BEGIN
		SET @nSQL = @nSQL +  '		AND'
		--SET @nSQL = @nSQL +  '		A.[CoreSourceKey] = C.[CoreSourceKey]'
		SET @nSQL = @nSQL +  '		 COALESCE([A].[CoreSourceKey], '''') = COALESCE([C].[CoreSourceKey], '''')' 
	END
	SET @nSQL = @nSQL + ' WHERE A.[USE] = "CORE" ;'
	SET @nSQL = @nSQL + ' SELECT @COUNTER = @@ROWCOUNT;'

	set @nSQLCandidate = ''
	SET @nSQLCandidate = @nSQLCandidate + replace (@nSQL,'"',char(39))
	SET @Message = 'Core Data : ' + @nSQLCandidate
	EXEC [core].p_LogDebug @ProcedureName, @Message

	EXEC sp_executesql @nSQLCandidate, N'@COUNTER INT OUTPUT', @COUNTER OUTPUT;
	SET @Message = 'Core Data Inserted : ' + CONVERT(VARCHAR,@COUNTER)
	EXEC [core].p_LogDebug @ProcedureName, @Message

	-- Insert the Target (From Staging, assuming Source is first) Source References into Staging (for the data that just came from Core),
	-- ready to be merged into Target

	IF CHARINDEX('_',@Coretable,1) > 1 AND SUBSTRING(@Coretable,CHARINDEX('_',@Coretable,1)+1,6) <> 'SOURCE'
	BEGIN

		DECLARE @UpdateCounter INT;

		SET @CoreStarPrefix = SUBSTRING(@CoreTable,1,CHARINDEX('_',@Coretable,1)-1)
		SET @nSQL = ''
		SET @nSQL = @nSQL + 'UPDATE ' + @StagingTable
		SET @nSQL = @nSQL + '	SET SourceKey = StagingSourceKeys.SourceKey '
		SET @nSQL = @nSQL + 'FROM '
		SET @nSQL = @nSQL + '	( '
		SET @nSQL = @nSQL + '		SELECT DISTINCT '
		SET @nSQL = @nSQL + '			CS.CoreSourceKey, '
		SET @nSQL = @nSQL + '			TS.SourceKey '
		SET @nSQL = @nSQL + '		FROM ' + @CoreSourceTable + ' CS '
		SET @nSQL = @nSQL + '			JOIN TARGET.Source TS '
		SET @nSQL = @nSQL + '			ON '
		SET @nSQL = @nSQL + '				CS.InterfaceName = TS.InterfaceName '
		SET @nSQL = @nSQL + '				AND '
		SET @nSQL = @nSQL + '				CS.Environment = TS. Environment '
		SET @nSQL = @nSQL + '				AND '
		SET @nSQL = @nSQL + '				CS.Source = TS.Source '
		SET @nSQL = @nSQL + '				AND '
		SET @nSQL = @nSQL + '				CS.Origin = TS.Origin '
		SET @nSQL = @nSQL + '       AND TS.Start <= "' + @TargetRefDateStr + '" AND TS.Finish > "' + @TargetRefDateStr + '" '
		SET @nSQL = @nSQL + '	) StagingSourceKeys '
		SET @nSQL = @nSQL + 'WHERE ' + @StagingTable + '.CoreSourceKey = StagingSourceKeys.CoreSourceKey'
		SET @nSQL = @nSQL + '	AND ' + @StagingTable + '.SourceKey IS NULL; ' -- Not null if SOURCEs & payloads are the same, then use target Interface.
		SET @nSQL = @nSQL + 'SELECT @UpdateCounter = @@ROWCOUNT;'

		SET @nSQLCandidate = replace (@nSQL,'"',char(39))

		SET @Message = 'Update Staging:' + @nSQLCandidate
		EXEC [core].p_LogDebug @ProcedureName, @Message
		EXEC sp_executesql @nSQLCandidate, N'@UpdateCounter INT OUTPUT', @UpdateCounter OUTPUT

		SET @Message = 'Update Staging source Key Counter :' + CONVERT(VARCHAR,@UpdateCounter)
		EXEC [core].p_LogDebug @ProcedureName, @Message
		
	END

	RETURN isnull(@COUNTER,0)

END TRY

--#------------------------------------------------- END OF PROCEDURE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		nvarchar(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
