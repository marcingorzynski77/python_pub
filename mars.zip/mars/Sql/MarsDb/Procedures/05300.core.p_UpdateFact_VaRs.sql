IF OBJECT_ID ('core.p_UpdateFact_VaRs') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_VaRs
GO

/*
  DECLARE @TargetDate AS DATETIME2; 
  SET @TargetDate = GETUTCDATE()
  EXEC [core].[p_UpdateFact_VaRs] '2017-07-07', @TargetDate, 'MarsVaRs', 'PROD' 
*/


CREATE PROC [core].[p_UpdateFact_VaRs]
(
	@BusDate	  DATETIME2,
	@NowDate	  DATETIME2,
	@DataFeed	  VARCHAR(64),
	@Env	 	  VARCHAR(6),
    @HierarchyTag INT = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName  			NVARCHAR(128),
		@Message 	    			NVARCHAR(MAX),
		@return_value				BIGINT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT			= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
    DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	
	DECLARE @Finish DATETIME2(7) = '9999-12-31'
    EXEC [target].p_Set_HierarchyMode @HierarchyTag

	EXEC [core].p_LogDebug @ProcedureName, 'Create Index on BusinessKey. [NOTE: the CreateStar routines, take off prior to loading with values]'
	
    DECLARE	@CoreIndexColumns core.Core2TargetParameter
	INSERT INTO @CoreIndexColumns VALUES ('BusDate'),('CoreHierarchyKey'),('CoreScenarioHierarchyKey'),('CoreRiskMeasureTypeKey'),('AnalysisTypeName'),('LegalEntity'),('Cad2'),('ConfidenceLevel'),('VarMeasureType')


    IF NOT EXISTS (SELECT 1 FROM sys.indexes  WHERE name='IX_MarsVaRs_Fact_BusinessKeys' AND object_id = OBJECT_ID('[core].[MarsVaRs_Fact]'))
    EXEC core.p_CreateIndex
		@IndexName = 'IX_MarsVaRs_Fact_BusinessKeys',
		@SchemaName = 'core',
		@TableName = 'MarsVaRs_Fact',
		@TableOfColumns = @CoreIndexColumns

	SELECT DISTINCT @LoadInterface = S.InterfaceName
	 FROM [core].[MarsVaRs_Fact] F
	INNER JOIN [core].[MarsVaRs_Source] S
	   ON F.CoreSourceKey = S.CoreSourceKey

	EXEC [core].p_LogDebug @ProcedureName, 'Clear out any temp tables'
	-------------------------------------------------------------------------------------------------
	IF OBJECT_ID ('tempdb..#C2T_Delta') IS NOT NULL DROP TABLE #C2T_Delta;
	IF OBJECT_ID ('tempdb..#C2T_Source') IS NOT NULL DROP TABLE #C2T_Source;
	IF OBJECT_ID ('tempdb..#C2T_Hierarchy') IS NOT NULL DROP TABLE #C2T_Hierarchy;
	IF OBJECT_ID ('tempdb..#C2T_ScenarioHierarchy') IS NOT NULL DROP TABLE #C2T_ScenarioHierarchy;
	IF OBJECT_ID ('tempdb..#C2T_RiskMeasureType') IS NOT NULL DROP TABLE #C2T_RiskMeasureType;
	IF OBJECT_ID ('tempdb..#C2T_Fact_Updates') IS NOT NULL DROP TABLE #C2T_Fact_Updates;

	-- Do the Data Mapping in the core table
	EXEC [core].[p_DataMapping] @DataFeed, '[core].[MarsVaRs_Fact]', 'VaR'

	EXEC [core].p_LogDebug @ProcedureName, 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_Source (CoreDimKey, TargetDimKey)
		SELECT DISTINCT C.CoreSourceKey, T.SourceKey
		FROM [core].[MarsVaRs_Source] C 
       INNER JOIN [target].[Source] T 
          ON C.[InterfaceName] = T.[InterfaceName] 
         AND C.[Environment] = T.[Environment] 
         AND C.[Source] = T.[Source] 
         AND C.[Origin] = T.[Origin]
		 AND T.[Start] <= @NowDate 
         AND T.[Finish] > @NowDate

    SET @Message = '#C2T_Source Count = ' + CONVERT(VARCHAR(20), @@ROWCOUNT)
    EXEC [core].p_LogDebug @ProcedureName, @Message

	CREATE TABLE #C2T_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_Hierarchy (CoreDimKey, TargetDimKey)
		SELECT C.CoreHierarchyKey, MAX(T.HierarchyKey)											
		FROM [core].[MarsVaRs_Hierarchy] C 
       INNER JOIN [target].vHierarchyConsolidated T
		  ON ISNULL(C.[Group],'') = ISNULL(T.[Group],'')
         AND ISNULL(C.[SubGroup],'') = ISNULL(T.[SubGroup],'')
	     AND ISNULL(C.[Business],'') = ISNULL(T.[Business],'')
		 AND ISNULL(C.[BusinessArea],'') = ISNULL(T.[BusinessArea],'')
         AND ISNULL(C.[Division],'') = ISNULL(T.[Division],'')
         AND ISNULL(C.[Desk],'') = ISNULL(T.[Desk],'')
         AND ISNULL(C.[SubDesk],'') = ISNULL(T.[SubDesk],'')
		 AND ISNULL(C.[NodeType],'') = ISNULL(T.[NodeType],'')
		 AND T.[Start] <= @NowDate 
         AND T.[Finish] > @NowDate
         AND C.NodeType <> 'BO'
		GROUP BY C.CoreHierarchyKey
    
    SET @Message = '#C2T_Hierarchy Count = ' + CONVERT(VARCHAR(20), @@ROWCOUNT)
    EXEC [core].p_LogDebug @ProcedureName, @Message

	CREATE TABLE #C2T_ScenarioHierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_ScenarioHierarchy (CoreDimKey, TargetDimKey)
		SELECT C.CoreScenarioHierarchyKey, MAX(T.ScenarioHierarchyKey)							
		  FROM [core].[MarsVaRs_ScenarioHierarchy] C 
         INNER JOIN [target].ScenarioHierarchy T
			ON C.[ScenarioHierarchyString] = T.[ScenarioHierarchyString]
           AND C.[ScenarioNodeName] = T.[ScenarioNodeName]
           AND C.[Level] = T.[Level]
		   AND T.[Start] <= @NowDate 
           AND T.[Finish] > @NowDate
		GROUP BY [C].CoreScenarioHierarchyKey

    SET @Message = '#C2T_ScenarioHierarchy Count = ' + CONVERT(VARCHAR(20), @@ROWCOUNT)
    EXEC [core].p_LogDebug @ProcedureName, @Message

	CREATE TABLE #C2T_RiskMeasureType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_RiskMeasureType (CoreDimKey, TargetDimKey)
		SELECT C.CoreRiskMeasureTypeKey, MAX(T.RiskMeasureTypeKey)								
		FROM [core].[MarsVaRs_RiskMeasureType] C
       INNER JOIN [target].RiskMeasureType [T]
	   	  ON ISNULL(C.[RiskMeasureTypeName], '') = ISNULL(T.[RiskMeasureTypeName], '')
         AND ISNULL(C.[RiskMeasureFamily], '') = ISNULL(T.[RiskMeasureFamily], '')
         AND T.Start <= @NowDate 
         AND T.Finish > @NowDate
		GROUP BY [C].CoreRiskMeasureTypeKey

    SET @Message = '#C2T_RiskMeasureType Count = ' + CONVERT(VARCHAR(20), @@ROWCOUNT)
    EXEC [core].p_LogDebug @ProcedureName, @Message

	CREATE TABLE #C2T_Fact_Updates (CoreVaRKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);

	EXEC [core].p_LogInfo @ProcedureName, 'Perform the actual Merge.'

	INSERT #C2T_Fact_Updates( 
           CoreVaRKey,  
           FactKey, 
           IsAttributeMatch)
	SELECT C.CoreVaRKey, 
           F.FactKey,
           CASE WHEN ISNULL(C.[ValueGBP],0)=ISNULL(F.[ValueGBP],0) THEN 1 ELSE 0 END AS IsAttributeMatch
     FROM [core].[MarsVaRs_Fact] C
    INNER JOIN #C2T_Source
       ON #C2T_Source.[CoreDimKey] = [C].[CoreSourceKey]
    INNER JOIN #C2T_Hierarchy 
       ON #C2T_Hierarchy.[CoreDimKey] = [C].[CoreHierarchyKey]
    INNER JOIN #C2T_ScenarioHierarchy 
       ON #C2T_ScenarioHierarchy.[CoreDimKey] = [C].[CoreScenarioHierarchyKey]
    INNER JOIN #C2T_RiskMeasureType 
       ON #C2T_RiskMeasureType.[CoreDimKey] = [C].[CoreRiskMeasureTypeKey]
     FULL OUTER JOIN (SELECT [FactKey],
                             [AnalysisTypeName], 
                             [Cad2],
                             [LegalEntity], 
                             [ConfidenceLevel], 
                             [VarMeasureType],
                             [HierarchyKey], 
                             [ScenarioHierarchyKey], 
                             [RiskMeasureTypeKey], 
                             [SourceKey], 
                             [ValueGBP] 
                        FROM [target].[VaR_Fact]
                       INNER JOIN #C2T_ScenarioHierarchy SH -- ONLY Update/Expire entries for affected Scenario Hierarchy
                          ON SH.TargetDimKey = [target].[VaR_Fact].ScenarioHierarchyKey
                       WHERE BusDate = @BusDate 
                         AND Start <= @NowDate
                         AND Finish > @NowDate) F 
       ON C.[AnalysisTypeName] = F.[AnalysisTypeName]
      AND ISNULL(CAST(C.[Cad2] AS INT),-1) = ISNULL(CAST(F.[Cad2] AS INT), -1)
      AND ISNULL(C.[LegalEntity],'') = ISNULL(F.[LegalEntity],'')
      AND C.[ConfidenceLevel] = F.[ConfidenceLevel]
      AND C.[VarMeasureType] = F.[VarMeasureType]
      AND F.[HierarchyKey] = #C2T_Hierarchy.[TargetDimKey]
      AND F.[ScenarioHierarchyKey] = #C2T_ScenarioHierarchy.[TargetDimKey]
      AND F.[RiskMeasureTypeKey] = #C2T_RiskMeasureType.[TargetDimKey]
      AND F.[SourceKey] = #C2T_Source.[TargetDimKey]

    SET @Message = '#C2T_Fact_Updates Count = ' + CONVERT(VARCHAR(20), @@ROWCOUNT)
    EXEC [core].p_LogDebug @ProcedureName, @Message

    EXEC [core].p_LogInfo @ProcedureName, 'Adding the index'
    CREATE CLUSTERED INDEX IX_C2T_Fact_Updates_FactKey ON #C2T_Fact_Updates(FactKey,CoreVaRKey)

    BEGIN TRANSACTION
    
    EXEC [core].p_LogDebug @ProcedureName, 'Expire previous and replaced records'

    UPDATE [target].[VaR_Fact]
       SET [Finish] = @NowDate
      FROM [target].[VaR_Fact] AS F
     INNER JOIN	#C2T_Fact_Updates C2T
		ON F.FactKey = C2T.FactKey
     INNER JOIN [target].[Source] S
		ON S.SourceKey = F.SourceKey
     INNER JOIN [target].[ScenarioHierarchy] SH
		ON SH.ScenarioHierarchyKey = F.ScenarioHierarchyKey
	WHERE (
            (C2T.CoreVaRKey IS NULL AND C2T.FactKey IS NOT NULL)
			OR
            (C2T.CoreVaRKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
		)
      AND S.InterfaceName = @LoadInterface
      AND F.BusDate = @BusDate

	SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
    EXEC [core].p_LogDebug @ProcedureName,  'Adding new and updated records'

    INSERT [target].[VaR_Fact]
         ( [BusDate] 
          ,[Start]
          ,[Finish]
          ,[SourceKey]
		  ,[HierarchyKey]
		  ,[ScenarioHierarchyKey]
		  ,[RiskMeasureTypeKey]
		  ,[AnalysisTypeName]
          ,[Cad2]
          ,[LegalEntity]
          ,[ConfidenceLevel]
          ,[VarMeasureType]
          ,[Label]
          ,[ValueGBP])
    SELECT @BusDate
		  ,@NowDate
          ,@Finish
		  ,#C2T_Source.[TargetDimKey] [SourceKey]
		  ,#C2T_Hierarchy.[TargetDimKey] [HierarchyKey]
		  ,#C2T_ScenarioHierarchy.[TargetDimKey] [ScenarioHierarchyKey]
	      ,#C2T_RiskMeasureType.[TargetDimKey] [RiskMeasureTypeKey]
		  ,C.[AnalysisTypeName]
          ,C.[Cad2]
          ,C.[LegalEntity]
          ,C.[ConfidenceLevel]
          ,[VarMeasureType]
          ,C.[Label]
          ,C.[ValueGBP]
      FROM [core].[MarsVaRs_Fact] C
     INNER JOIN #C2T_Source 
        ON #C2T_Source.[CoreDimKey] = C.[CoreSourceKey]
     INNER JOIN #C2T_Hierarchy 
        ON #C2T_Hierarchy.[CoreDimKey] = C.[CoreHierarchyKey]
	 INNER JOIN #C2T_ScenarioHierarchy 
        ON #C2T_ScenarioHierarchy.[CoreDimKey] = C.[CoreScenarioHierarchyKey]
	 INNER JOIN #C2T_RiskMeasureType 
        ON #C2T_RiskMeasureType.[CoreDimKey] = C.[CoreRiskMeasureTypeKey]
	 INNER JOIN #C2T_Fact_Updates C2T
        ON C2T.CoreVaRKey = C.CoreVarKey 
	 WHERE (C2T.CoreVaRKey IS NOT NULL AND C2T.FactKey IS NULL)
		OR (C2T.CoreVaRKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)

	SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	COMMIT TRAN

	EXEC [core].p_LogInfo @ProcedureName, 'End of processing. Success'
	
END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();
		
		
	IF @@TRANCOUNT > 0
	BEGIN
		-- The transaction uncommittable transaction.
		ROLLBACK TRANSACTION -- @MyTranID;

		SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName
		EXEC [core].p_LogInfo @ProcedureName, @Message
		
	END		

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END
GO
