IF OBJECT_ID ('core.p_UpdateFact_Position') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_Position
GO

CREATE PROC [core].[p_UpdateFact_Position]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT		= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName  			NVARCHAR(128),
		@Message 	 		   		NVARCHAR(MAX),
		@return_value				BIGINT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT			= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
    DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter
	
	print 'Clear out any temp tables'

	-------------------------------------------------------------------------------------------------
	-- Clear out any temp tables
	IF OBJECT_ID ('tempdb..#C2T_Source') IS NOT NULL DROP TABLE #C2T_Source;
	IF OBJECT_ID ('tempdb..#C2T_Hierarchy') IS NOT NULL DROP TABLE #C2T_Hierarchy;
	IF OBJECT_ID ('tempdb..#C2T_Instrument') IS NOT NULL DROP TABLE #C2T_Instrument;
	IF OBJECT_ID ('tempdb..#C2T_InstrumentType') IS NOT NULL DROP TABLE #C2T_InstrumentType;
	IF OBJECT_ID ('tempdb..#C2T_Country') IS NOT NULL DROP TABLE #C2T_Country;
	IF OBJECT_ID ('tempdb..#C2T_Rating') IS NOT NULL DROP TABLE #C2T_Rating;
	IF OBJECT_ID ('tempdb..#C2T_Fact_Updates') IS NOT NULL DROP TABLE #C2T_Fact_Updates;

	--Create the temp tables
	CREATE TABLE #C2T_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	CREATE TABLE #C2T_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	CREATE TABLE #C2T_Instrument (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);		
	CREATE TABLE #C2T_InstrumentType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	CREATE TABLE #C2T_Country (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);		
	CREATE TABLE #C2T_Rating (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
			
	CREATE TABLE #C2T_Fact_Updates (CorePositionKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);	
		
	print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'	
	-------------------------------------------------------------------------------------------------
		
	
	PRINT 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
	
	INSERT INTO @CoreIndexColumns VALUES ('BusDate'),('CoreHierarchyKey'),('CoreInstrumentKey'),('CoreInstrumentTypeKey'),('CoreCountryKey'),('CoreRatingKey')
	EXEC core.p_CreateIndex
		@IndexName = 'IX_Position_Fact_BusinessKeys',
		@SchemaName = 'core',
		@TableName = 'Position_Fact',
		@TableOfColumns = @CoreIndexColumns


	SELECT DISTINCT
		@LoadInterface =S.InterfaceName
	FROM
		[core].[Position_Fact] F
		join
		[core].Position_Source S
		on
			F.CoreSourceKey = S.CoreSourceKey
			
	
	INSERT #C2T_Source (CoreDimKey, TargetDimKey)
		SELECT DISTINCT C.CoreSourceKey, T.SourceKey
		FROM [CORE].[Position_Source] C JOIN [TARGET].[Source] T ON
			C.InterfaceName = T.InterfaceName AND C.Environment = T.Environment AND C.Source = T.Source AND C.Origin = T.Origin
			AND T.Start <= @Nowdate AND T.Finish > @Nowdate
			

	INSERT #C2T_Hierarchy (CoreDimKey, TargetDimKey)
		SELECT [C].CoreHierarchyKey, MAX([T].HierarchyKey)									-- Be defensive on possible Corruption
		FROM [CORE].[Position_Hierarchy] [C] JOIN [TARGET].vHierarchyConsolidated [T]
			ON 	COALESCE([C].[NodeName],'') = COALESCE([T].[NodeName],'')
				AND COALESCE([C].[NodeType],'') = COALESCE([T].[NodeType],'')
				AND COALESCE([C].[BookSystem],'') = COALESCE([T].[BookSystem],'')
				AND T.Start <= @Nowdate AND T.Finish > @Nowdate
		GROUP BY [C].CoreHierarchyKey


	INSERT #C2T_Instrument (CoreDimKey, TargetDimKey)
		SELECT [C].CoreInstrumentKey, MAX([T].InstrumentKey)								-- Be defensive on possible Corruption
		FROM [CORE].[Position_Instrument] [C] JOIN [TARGET].Instrument [T]
			ON [C].[Product] = [T].[Product]
				AND [C].[InstrumentIdType] = [T].[InstrumentIdType]
				AND [C].[InstrumentId] = [T].[InstrumentId]
				AND T.Start <=  @Nowdate AND T.Finish >  @Nowdate
		GROUP BY [C].CoreInstrumentKey
		
		
	INSERT #C2T_InstrumentType (CoreDimKey, TargetDimKey)
		SELECT [C].CoreInstrumentTypeKey, MAX([T].InstrumentTypeKey)						-- Be defensive on possible Corruption
		FROM [CORE].[Position_InstrumentType] [C] JOIN [TARGET].InstrumentType [T]
			ON C.InstrumentType = T.InstrumentType
				AND C.InstrumentSubType = T.InstrumentSubType
				AND T.Start <= @Nowdate AND T.Finish > @Nowdate
		GROUP BY [C].CoreInstrumentTypeKey
				
		
	INSERT #C2T_Country (CoreDimKey, TargetDimKey)
		SELECT [C].CoreCountryKey, MAX([T].CountryKey)										-- Be defensive on possible Corruption
		FROM [CORE].[Position_Country] [C] JOIN [TARGET].Country [T]
			ON [C].[IssuerPhysicalCountry] = [T].[IssuerPhysicalCountry]
				AND [C].[IssuerLogCountry] = [T].[IssuerLogCountry]					
				AND [C].[SecCountry] = [T].[SecCountry]
				AND T.Start <= @Nowdate AND T.Finish > @Nowdate
		GROUP BY [C].CoreCountryKey

	
	INSERT #C2T_Rating (CoreDimKey, TargetDimKey)
		SELECT [C].CoreRatingKey, MAX([T].RatingKey)										-- Be defensive on possible Corruption
		FROM [CORE].[Position_Rating] [C] JOIN [TARGET].Rating [T]
			ON T.Start <= @Nowdate AND T.Finish > @Nowdate
				and C.[SecSandP_RISKRATE] = T.[SecSandP_RISKRATE]
				and C.[SECMoodys_RISKRATE] = T.[SECMoodys_RISKRATE]
				and C.[INTERNAL_RISKRATE] = T.[INTERNAL_RISKRATE]
				and C.[SecECAI_RiskRate] = T.[SecECAI_RiskRate]
				and C.[SecHBOS_RiskRate] = T.[SecHBOS_RiskRate]
				and C.[Fitch_RiskRate] = T.[Fitch_RiskRate]
		GROUP BY [C].CoreRatingKey


	-- Perform the actual merge
	INSERT #C2T_Fact_Updates ( CorePositionKey ,  FactKey, IsAttributeMatch )		
	SELECT [C].CorePositionKey,
		   [TARGET].FactKey,
		   CASE WHEN COALESCE([C].[PositionTradeDate],0)=COALESCE([TARGET].[PositionTradeDate],0) 
				AND COALESCE([C].[PositionValueDate],0)=COALESCE([TARGET].[PositionValueDate],0) 
				AND COALESCE([C].[WABP],0)=COALESCE([TARGET].[WABP],0) 
				AND COALESCE([C].[StartAccrual],0)=COALESCE([TARGET].[StartAccrual],0) 
				AND COALESCE([C].[EndAccrual],0)=COALESCE([TARGET].[EndAccrual],0) 
				AND COALESCE([C].[ValueDateAccrual],0)=COALESCE([TARGET].[ValueDateAccrual],0) 				
				AND COALESCE([C].[Unamortised],0)=COALESCE([TARGET].[Unamortised],0) 					 					
				AND COALESCE([C].[MarketValue],0)=COALESCE([TARGET].[MarketValue],0) 
				AND COALESCE([C].[MarketValueGBP],0)=COALESCE([TARGET].[MarketValueGBP],0) 
				AND COALESCE([C].[MarketValueDP],0)=COALESCE([TARGET].[MarketValueDP],0) 
				AND COALESCE([C].[MarketValueDPGBP],0)=COALESCE([TARGET].[MarketValueDPGBP],0) 
				AND COALESCE([C].[RealisedPnL],0)=COALESCE([TARGET].[RealisedPnL],0) 
				AND COALESCE([C].[NPV],0)=COALESCE([TARGET].[NPV],0) 				
				AND COALESCE([C].[PosValDateNPV],0)=COALESCE([TARGET].[PosValDateNPV],0) 
				AND COALESCE([C].[InterestDays],0)=COALESCE([TARGET].[InterestDays],0)
				AND COALESCE([C].[CouponAmount],0)=COALESCE([TARGET].[CouponAmount],0)
				AND COALESCE([C].[CS01],0)=COALESCE([TARGET].[CS01],0) 
				AND COALESCE([C].[StandardisedCS01],0)=COALESCE([TARGET].[StandardisedCS01],0)
				AND COALESCE([C].[ZSpread],0)=COALESCE([TARGET].[ZSpread],0) 
		   THEN 1 ELSE 0 END AS IsAttributeMatch
	FROM [CORE].[Position_Fact] [C]
	JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [C].[CoreSourceKey]
	JOIN #C2T_Hierarchy ON #C2T_Hierarchy.[CoreDimKey] = [C].[CoreHierarchyKey]
	JOIN #C2T_Instrument ON #C2T_Instrument.[CoreDimKey] = [C].[CoreInstrumentKey]
	JOIN #C2T_InstrumentType ON #C2T_InstrumentType.[CoreDimKey] = [C].[CoreInstrumentTypeKey]
	JOIN #C2T_Rating ON #C2T_Rating.[CoreDimKey] = [C].[CoreRatingKey]
	JOIN #C2T_Country ON #C2T_Country.[CoreDimKey] = [C].[CoreCountryKey]
	FULL OUTER JOIN (SELECT * FROM [TARGET].[Position_Fact] where BusDate = @BusDate AND Finish > @Nowdate) [TARGET] ON
		[C].[BusDate] = [TARGET].[BusDate]
		AND [TARGET].[HierarchyKey] = #C2T_Hierarchy.[TargetDimKey]
		AND [TARGET].[InstrumentKey] = #C2T_Instrument.[TargetDimKey]
		AND [TARGET].[InstrumentTypeKey] = #C2T_InstrumentType.[TargetDimKey]
		AND [TARGET].[RatingKey] = #C2T_Rating.[TargetDimKey]
		AND [TARGET].[CountryKey] = #C2T_Country.[TargetDimKey]

	--Print 'Adding the index'
	CREATE CLUSTERED INDEX IX_C2T_Fact_Updates_FactKey ON #C2T_Fact_Updates(FactKey,CorePositionKey)

	BEGIN TRANSACTION

	--Print 'Expire previous and replaced records'
	UPDATE [TARGET].[Position_Fact] SET
		[Finish] = @NowDate
	FROM
		[TARGET].[Position_Fact] AS FACT
		INNER JOIN
		#C2T_Fact_Updates C2T
		on
			FACT.FactKey = C2T.FactKey
		INNER JOIN
		[TARGET].[Source] S
		on
			S.SourceKey = FACT.SourceKey
	WHERE
		(
				(C2T.CorePositionKey IS NULL AND C2T.FactKey IS NOT NULL)
				OR
				(C2T.CorePositionKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
		)
		AND
		S.InterfaceName = @LoadInterface
		AND
		FACT.BusDate = @BusDate

	SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--PRINT 'Adding new and updated records'
	INSERT [TARGET].[Position_Fact]( /*[FactKey], */ --[AppliedRules] -- CoreFactKey & TargetFactKey
				 Start, Finish
				,Busdate
				,HierarchyKey
				,InstrumentKey
				,InstrumentTypeKey
				,SourceKey
				,RatingKey
				,CountryKey
				,PositionTradeDate 
				,PositionValueDate 
				,WABP 
				,StartAccrual 
				,EndAccrual 
				,ValueDateAccrual 
				,Unamortised				
				,MarketValue 
				,MarketValueGBP 
				,MarketValueDP 
				,MarketValueDPGBP 					
				,RealisedPnL
				,NPV 					
				,PosValDateNPV 					
				,InterestDays 
				,CouponAmount 		
				,CS01
				,StandardisedCS01
				,ZSpread			
				,HardCallDate)
	SELECT
		 @NowDate, @Finish
		,[CORE].[BUSDATE]
		, #C2T_Hierarchy.[TargetDimKey] [HierarchyKey]
		, #C2T_Instrument.[TargetDimKey] [InstrumentKey]
		, #C2T_InstrumentType.[TargetDimKey] [InstrumentTypeKey]
		, #C2T_Source.[TargetDimKey] [SourceKey]
		, #C2T_Rating.[TargetDimKey] [RatingKey]
		, #C2T_Country.[TargetDimKey] [CountryKey]
		, [core].[PositionTradeDate] 
		, [core].[PositionValueDate] 
		, [core].[WABP] 
		, [core].[StartAccrual] 
		, [core].[EndAccrual]  
		, [core].[ValueDateAccrual] 
		, [core].[Unamortised] 
		, [core].[MarketValue] 
		, [core].[MarketValueGBP] 
		, [core].[MarketValueDP] 
		, [core].[MarketValueDPGBP] 
		, [core].[RealisedPnL] 
		, [core].[NPV] 
		, [core].[PosValDateNPV] 
		, [core].[InterestDays] 
		, [core].[CouponAmount] 
		, [core].[CS01] 
		, [core].[StandardisedCS01] 
		, [core].[ZSpread] 
		, [core].[HardCallDate] 			
	FROM [CORE].[Position_Fact] [Core]
	JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [Core].[CoreSourceKey]
	JOIN #C2T_Hierarchy ON #C2T_Hierarchy.[CoreDimKey] = [Core].[CoreHierarchyKey]
	JOIN #C2T_Instrument ON #C2T_Instrument.[CoreDimKey] = [Core].[CoreInstrumentKey]
	JOIN #C2T_InstrumentType ON #C2T_InstrumentType.[CoreDimKey] = [Core].[CoreInstrumentTypeKey]
	JOIN #C2T_Country ON #C2T_Country.[CoreDimKey] = [Core].[CoreCountryKey]
	JOIN #C2T_Rating ON #C2T_Rating.[CoreDimKey] = [Core].[CoreRatingKey]
	JOIN #C2T_Fact_Updates C2T ON [Core].CoreSourceKey = C2T.CorePositionKey
	WHERE (C2T.CorePositionKey IS NOT NULL AND C2T.FactKey IS NULL)
	OR
	(C2T.CorePositionKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
	
	
	SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	COMMIT


	print 'Done'
	
END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	 DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END
GO
