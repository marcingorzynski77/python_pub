
/****** Object:  StoredProcedure [target].[p_CheckGoldenSourceMappings]    Script Date: 03/15/2018 16:38:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_CheckGoldenSourceMappings]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_CheckGoldenSourceMappings]
GO

/****** Object:  StoredProcedure [target].[p_CheckGoldenSourceMappings]    Script Date: 03/15/2018 16:38:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE procedure [target].[p_CheckGoldenSourceMappings]
(
	@Datafeed Varchar(64),	
	@Dimension varchar(64)		
)
AS 
BEGIN
SET NOCOUNT ON;

	DECLARE
		@ProcedureName  			NVARCHAR(128),
		@Message 	    			NVARCHAR(MAX),
		@Booksystems				NVARCHAR(128),
		@SQL						VARCHAR(1000);

	-- Relevant column parameters
    DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	create table #Missing
	(
		BookSystem varchar(255)
	)
	
	--clean the table name
	set @Datafeed = REPLACE(@Datafeed,'_','')
	
	
	set @SQL = 'SELECT DISTINCT BookSystem 
				FROM core.' + @Datafeed + '_' + @Dimension + ' H
				LEFT JOIN CORE.GOLDENSOURCE G
				ON H.BookSystem = G.Origin
					AND G.InterfaceName = ''' + @Datafeed + '''
					AND G.Dimension = ''' + @Dimension + '''
				WHERE CoreGoldenSourceKey IS NULL'
	
	insert into #Missing
	execute (@SQL)

	if (select COUNT(1) from #Missing) > 0
	begin
		select @Booksystems = COALESCE(@Booksystems + ', ', '') + cast(BookSystem as varchar) FROM #Missing
		SET @Message = 'The core.GoldenSource prioritisation table is incomplete.'
					 + 'The following Booksystems are missing for the ' + @Datafeed 
					 + ' datafeed, when entering into the ' + @Dimension + ' dimension. ' + @Booksystems + '.'
					 
		
		EXEC [core].p_LogWarning @ProcedureName, @Message
		print @message
	end
	
	drop table #Missing

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();
		
		
	IF @@TRANCOUNT > 0
	BEGIN
		-- The transaction uncommittable transaction.
		ROLLBACK TRANSACTION -- @MyTranID;

		SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName
		EXEC [core].p_LogInfo @ProcedureName, @Message
		
	END		

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END


GO


