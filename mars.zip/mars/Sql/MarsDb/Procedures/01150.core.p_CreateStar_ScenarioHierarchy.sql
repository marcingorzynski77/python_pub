IF OBJECT_ID ('core.p_CreateStar_ScenarioHierarchy') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_ScenarioHierarchy
GO

CREATE PROC [core].[p_CreateStar_ScenarioHierarchy]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT	 = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@return_status		INT,
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@BusinessLogicSev	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--First empty the snowflake ready for new data
	TRUNCATE TABLE [core].ScenarioHierarchy_Source
	TRUNCATE TABLE [core].ScenarioHierarchy_ScenarioHierarchy

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'ScenarioHierarchy_ScenarioHierarchy'

	--#--------------------------------------------- Populate the Source Dimension -----------------------------------------#--

	--Source Dimension
	INSERT INTO [core].ScenarioHierarchy_Source (
		 [InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	)
	SELECT
		 @DataFeed
		,@Env
		,@DataFeed
		,'ScenarioVault'

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].ScenarioHierarchy_Source dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	--#------------------------------------------ Populate the ScenarioHierarchy Dimension ----------------------------------------#--

	--Hierarchy Dimension
	--
	INSERT INTO [core].ScenarioHierarchy_ScenarioHierarchy (
		 [CoreSourceKey]
		,[NodeId]
		,[NodeParentID]
		,[Level]
		,[ScenarioNodeName]
		,[AggregationType]
		,[ScenarioHierarchyString]
	)
	SELECT S.[CoreSourceKey]
		  ,V.[NodeId]
		  ,V.[NodeParentID]
		  ,V.[Level]
		  ,REPLACE(REPLACE(V.[NodeName], '(', '*'), ')', '*')				-- teporary hack to work around VBA/SQL problems
		  ,V.[AggregationType]
		  ,REPLACE(REPLACE(V.[HierarchyString], '(', '*'), ')', '*')		-- teporary hack to work around VBA/SQL problems
	 FROM [raw].ScenarioHierarchy V
	INNER JOIN [core].[ScenarioHierarchy_Source] S
	   ON S.Source = @DataFeed
      AND S.Origin = 'ScenarioVault'

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].ScenarioHierarchy_ScenarioHierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

END TRY

--#---------------------------------------------- END OF SNOWFLAKE CODE -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

RETURN 0;

END

GO