IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Merge_Positions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [core].[p_Merge_Positions]
GO


CREATE PROC [core].[p_Merge_Positions]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT		= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--First empty the star ready for new data
	TRUNCATE TABLE [raw].Position_Merged

--#--------------------------------------------- Merge  ------------------------------------------#--

	Insert into [raw].Position_Merged
	(
		[OST RT]
		,[COB Date]
		,Summit
		,[Issue Date]
		,[Sec State]
		,[Security Id]
		,Book
		,Ccy
		,Desk
		,[Eff Date]
		,[Mat Date]
		,Class
		,Issuer
		,[Issuer Full Name]
		,[Trade Type]
		,[Security Type]
		,[Security Sub Type]
		,[Fix/Float]
		,[Seniority Level]
		,[Day Basis]
		,Position_TradeDate
		,Position_ValueDate
		,WABP
		,StartAccrual
		,EndAccrual
		,ValueDateAccrual
		,[Daily Amort]
		,Amortised
		,Unamortised
		,PurchaseIntTVD
		,PremiumDiscountTVD
		,BookVal
		,BookValGBP
		,MarkeVal
		,MarketValGBP
		,MarkeValDP
		,MarketValDPGBP
		,[Last Reset]
		,[Next Reset]
		,[Next Int Payment]
		,PayFrequency
		,ISIN
		,[Settle Ccy]
		,CUSIP
		,[Issue Price]
		,dmAssetId
		,[Realised PnL]
		,NPV
		,[Issue_INSTN ClsVal]
		,[Issue_SIC ClsVal]
		,[Issue_DEV_BK ClsVal]
		,[Issue_INTL_ORG Cls_Val]
		,[Issue_FIN_INST ClsVal]
		,[Issue_GROUP_CO ClsVal]
		,[Issue_LOCAL_BK ClsVal]
		,[Issue_RSK_WGT Cls_Val]
		,[IssuerS&P_RISKRATE]
		,[SecS&P_RISKRATE]
		,SECMoodys_RISKRATE
		,INTERNAL_RISKRATE
		,[Issuer Physical Country]
		,[Issue Log Country]
		,SecCountry
		,[Issuer Book Class]
		,[Period Start]
		,[Period End]
		,XDivDate
		,XDivPeriodFlag
		,RedemptionPrice
		,MarketPrice
		,Rate
		,Spread
		,AllinRate
		,[Pool Factor]
		,LastXNL
		,FXRate12
		,CleanPrice
		,DirtyPrice
		,Yield
		,AccrualSec
		,SecNotional
		,PosValDateNPV
		,[Product Name]
		,Inst_Style
		,[Ref Guarantor]
		,SecECAI_RiskRate
		,SecPortClas_IndGrg
		,NextCallDate
		,NextCallStrike
		,NextCallITM
		,Company
		,RefGuarantor_INSTN_ClsVal
		,RefGuarantor_PhysCountry
		,SecHBOS_RiskRate
		,Notional_Quantity
		,PorR
		,Interest_Days
		,Coupon_Amount
		,OUR_Custodian
		,OUR_Nostro
		,Hard_Call_Date
		,Notes_LongName1
		,Notes_Remarks1
		,Notes_Remarks2
		,CaptureSystem
		,SAR_Resp
		,SIC2007
		,LastTradedDate
		,LastTradedNotional
		,Fitch_RiskRate
		,[Profit Centre]
		,[PMU Code]
		,[Branch Sort Code]
		,[Atlas Trade ID]
		,[GCT Subtype]
		,[Index Linked Bond]
		,Lag
		,[Current Index Ratio]
		,[Inflation Uplifted Notional TD]
		,[Inflation Uplifted Notional VD]
		,[Initial Uplifted Notional TD]
		,[Initial Uplifted Notional VD]
		,Delayed_Coupon_Amount
		,Delayed_Paydown_Notional
		,CS01
		,StandardisedCS01
		,ZSpread
	)
	Select
		S.[OST RT]
		,S.[COB Date]
		,S.Summit
		,S.[Issue Date]
		,S.[Sec State]
		,S.[Security Id]
		,S.Book
		,S.Ccy
		,S.Desk
		,S.[Eff Date]
		,S.[Mat Date]
		,S.Class
		,S.Issuer
		,S.[Issuer Full Name]
		,S.[Trade Type]
		,S.[Security Type]
		,S.[Security Sub Type]
		,S.[Fix/Float]
		,S.[Seniority Level]
		,S.[Day Basis]
		,S.Position_TradeDate
		,S.Position_ValueDate
		,S.WABP
		,S.StartAccrual
		,S.EndAccrual
		,S.ValueDateAccrual
		,S.[Daily Amort]
		,S.Amortised
		,S.Unamortised
		,S.PurchaseIntTVD
		,S.PremiumDiscountTVD
		,S.BookVal
		,S.BookValGBP
		,S.MarkeVal
		,S.MarketValGBP
		,S.MarkeValDP
		,S.MarketValDPGBP
		,S.[Last Reset]
		,S.[Next Reset]
		,S.[Next Int Payment]
		,S.PayFrequency
		,S.ISIN
		,S.[Settle Ccy]
		,S.CUSIP
		,S.[Issue Price]
		,S.dmAssetId
		,S.[Realised PnL]
		,S.NPV
		,S.[Issue_INSTN ClsVal]
		,S.[Issue_SIC ClsVal]
		,S.[Issue_DEV_BK ClsVal]
		,S.[Issue_INTL_ORG Cls_Val]
		,S.[Issue_FIN_INST ClsVal]
		,S.[Issue_GROUP_CO ClsVal]
		,S.[Issue_LOCAL_BK ClsVal]
		,S.[Issue_RSK_WGT Cls_Val]
		,S.[IssuerS&P_RISKRATE]
		,S.[SecS&P_RISKRATE]
		,S.SECMoodys_RISKRATE
		,S.INTERNAL_RISKRATE
		,S.[Issuer Physical Country]
		,S.[Issue Log Country]
		,S.SecCountry
		,S.[Issuer Book Class]
		,S.[Period Start]
		,S.[Period End]
		,S.XDivDate
		,S.XDivPeriodFlag
		,S.RedemptionPrice
		,S.MarketPrice
		,S.Rate
		,S.Spread
		,S.AllinRate
		,S.[Pool Factor]
		,S.LastXNL
		,S.FXRate12
		,S.CleanPrice
		,S.DirtyPrice
		,S.Yield
		,S.AccrualSec
		,S.SecNotional
		,S.PosValDateNPV
		,S.[Product Name]
		,S.Inst_Style
		,S.[Ref Guarantor]
		,S.SecECAI_RiskRate
		,S.SecPortClas_IndGrg
		,S.NextCallDate
		,S.NextCallStrike
		,S.NextCallITM
		,S.Company
		,S.RefGuarantor_INSTN_ClsVal
		,S.RefGuarantor_PhysCountry
		,S.SecHBOS_RiskRate
		,S.Notional_Quantity
		,S.PorR
		,S.Interest_Days
		,S.Coupon_Amount
		,S.OUR_Custodian
		,S.OUR_Nostro
		,S.Hard_Call_Date
		,S.Notes_LongName1
		,S.Notes_Remarks1
		,S.Notes_Remarks2
		,S.CaptureSystem
		,S.SAR_Resp
		,S.SIC2007
		,S.LastTradedDate
		,S.LastTradedNotional
		,S.Fitch_RiskRate
		,S.[Profit Centre]
		,S.[PMU Code]
		,S.[Branch Sort Code]
		,S.[Atlas Trade ID]
		,S.[GCT Subtype]
		,S.[Index Linked Bond]
		,S.Lag
		,S.[Current Index Ratio]
		,S.[Inflation Uplifted Notional TD]
		,S.[Inflation Uplifted Notional VD]
		,S.[Initial Uplifted Notional TD]
		,S.[Initial Uplifted Notional VD]
		,S.Delayed_Coupon_Amount
		,S.Delayed_Paydown_Notional		
		,T.CS01
		,T.StandardisedCS01
		,T.Spread		
	from raw.SummitBondPosition S
	left join 
	(	
		select 
			isin
			,book
			,sum(CS01) as CS01
			,StandardisedCS01
			,Spread
		from
		raw.TridentBondPosition 
		group by isin, book, standardisedcs01,spread
	)T
	on S.ISIN = T.ISIN
	and S.Book	= T.Book
--where (S.ISIN is not null or S.CUSIP is not null)
	

	set @insertedCount = @@ROWCOUNT
	
	--Log affected rows
	SET @Message = 'Inserted '+ CAST((@insertedCount)AS VARCHAR(30)) + ' rows into [raw].[Positions_Merged] table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#------------------------------------------------ END OF MERGE CODE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN 0;

END

GO


