IF OBJECTPROPERTY(OBJECT_ID('core.p_LogError'), N'IsProcedure') = 1
	DROP PROCEDURE [core].[p_LogError]
GO

CREATE PROCEDURE [core].[p_LogError]
(	
	@ProcedureName 	NVARCHAR(128),	
	@Message 		NVARCHAR(MAX),
	@ErrorNumber 	INT,
	@ErrorProcedure NVARCHAR(128),
	@ErrorSeverity 	INT,
	@ErrorState 	INT,
	@NESTLEVEL 		INT,
	@ErrorLine 		INT
)
AS
BEGIN

	DECLARE @FullMessage AS NVARCHAR(MAX)
	
	SET @FullMessage = @Message + ' (Error Number = ''' + CONVERT(VARCHAR(255), @ErrorNumber) + '''' 
                                + ' Error Severity  = ''' + CONVERT(VARCHAR(255), @ErrorSeverity) + '''' 
								+ ' Error State  = ''' + CONVERT(VARCHAR(255), @ErrorState) + '''' 
								+ ' Error Procedure  = ''' + @ErrorProcedure + '''' 
								+ ' Error Line  = ''' + CONVERT(VARCHAR(255), @ErrorLine) + '''' 
								+ ' NESTLEVEL  = ''' + CONVERT(VARCHAR(255), @NESTLEVEL) + '''' 
								+ ')';
								
	EXEC [core].[p_LogEvent] @ProcedureName, @FullMessage, 'ERROR'
	
END
GO 
