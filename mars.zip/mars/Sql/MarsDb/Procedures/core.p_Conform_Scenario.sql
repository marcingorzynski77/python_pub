IF OBJECT_ID ('core.p_Conform_Scenario') IS NOT NULL
	DROP PROCEDURE core.p_Conform_Scenario
GO

CREATE PROC [core].[p_Conform_Scenario] 
(	
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(30),
	@Env		VARCHAR(6),
	@SessionID	INT		= 0	
)
AS 

BEGIN
    SET NOCOUNT ON;

	DECLARE
		@return_status				INT,
		@ProcedureName				NVARCHAR(128),
		@Message					NVARCHAR(1000),
		@BusinessLogicSev			INT,
		@MaxRow						BIGINT,
		@EndDate					DATETIME2,
		@AffectedRowsCount			BIGINT,
		@return_value				BIGINT,
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ReStatement				BINARY = 0,
		@ExpireDimensionData		BINARY,
		@RowCount					BIGINT;
		 
	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@ErrorNumber	= 50000,  -- ok we are in an error for transaction purposes (ie post roll back)                
		@EndDate		= CAST('9999-12-31' AS DATETIME2),    
		@Comment		= 'Invoking ' + @ProcedureName

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
  
--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--#------------------------------------------------- 'Update Target Table' ----------------------------------------------#--
		
	--Get Max key for use in offsetting new keys
	SET @MaxRow = (SELECT (ISNULL(Max(ScenarioKey),0)) FROM [target].Scenario)	
	
	delete from staging.scenario
	
	--IF @DataFeed in ('SimraPnL_Stressed', 
	--				 'SimraPnL_VaR1D',
	--				 'SimraPnL_Var10D',
	--				 'SimraPnL_StressedVar1D_LBG',
	--				 'SimraPnL_StressedVaR10D_HBOS',
	--				 'SimraPnL_StressedVaR10D_LBG',
	--				 'SimraPnL_StressedVaR10D_LTSB')
	--BEGIN			
	
	--	insert into [staging].[Scenario](
	--		[coreScenarioKey]	
	--		,[SGroup]
	--		,[Name]
	--		,[RiskType]
	--		,[AppliedRules]
	--		,[Source]
	--		,[Currency]
	--		,ScenarioKey)
	--	select 
	--		[coreScenarioKey]			
	--		,C.[SGroup]
	--		,C.[Name]
	--		,C.[RiskType]
	--		,''
	--		,C.[Source]
	--		,'GBP'
	--		,ISNULL(T.scenariokey, ROW_NUMBER() OVER(ORDER BY C.[name] ASC) + @MaxRow) AS 'ScenarioKey'
	--	from core.SimraRiskPnL_Scenario C
	--	LEFT JOIN [target].Scenario T		
	--	ON C.SGroup = T.SGroup 
	--	AND C.Name = T.Name 
	--	AND C.RiskType = T.RiskType
	--	--AND C.Currency = T.Currency
	--	AND(T.Start <= @NowDate and T.Finish > @NowDate)
		
	--	--Log affected rows
	--	SET @Message = CAST(@@ROWCOUNT AS VARCHAR(10)) + ' rows inserted from core into [staging].[Scenario]'
	--	EXEC [core].p_LogInfo @ProcedureName, @Message
			
	--END
	--ELSE 
	
	IF @DataFeed = 'SimraVaR_Stressed'
	BEGIN
		
		insert into [staging].[Scenario] (
			[coreScenarioKey]	
			,[SGroup]
			,[Name]
			,[RiskType]
			,[AppliedRules]
			,[Source]
			,[Currency]
			,ScenarioKey
		)
		select 
			[coreScenarioKey]			
			,C.[SGroup]
			,C.[Name]
			,C.[RiskType]
			,''
			,C.[Source]
			,C.Currency
			,ISNULL(T.scenariokey, ROW_NUMBER() OVER(ORDER BY C.[name] ASC) + @MaxRow) AS 'ScenarioKey'
		from
			core.SimraRiskVaR_Scenario C
			LEFT JOIN 
			[target].Scenario T		
			ON 
				C.SGroup = T.SGroup 
				AND 
				C.Name = T.Name 
				AND 
				C.RiskType = T.RiskType
				AND 
				C.Currency = T.Currency
				AND
				(T.Start <= @NowDate and T.Finish > @NowDate)
		
		--Log affected rows
		SET @Message = CAST(@@ROWCOUNT AS VARCHAR(30)) + ' rows inserted from core into [staging].[Scenario]'
		EXEC [core].p_LogInfo @ProcedureName, @Message
	END
	ELSE
	BEGIN
		RAISERROR( 'DataFeed Not recognised',11,-1, @ProcedureName)
	END
	
	
----#------------------------------------------------ 'Update Staging Table' ----------------------------------------------#--
	
	set @RowCount = (select COUNT(1) from staging.[Scenario])

	--Create a tempory table to include all the new/revised sceanarios and all the existing (except the scenarios about to be loaded/reloaded).
	insert into [staging].[Scenario] (
		[coreScenarioKey]	
		,[SGroup]
		,[Name]
		,[RiskType]
		,[AppliedRules]
		,[Source]
		,[Currency]
		,ScenarioKey
	)
	SELECT
		CurrentPicture.*
	FROM 
	(		
		SELECT @RowCount + T.ScenarioKey as [coreScenarioKey],
				T.[SGroup],
				T.[Name],
				T.[RiskType],
				T.[Source],
				T.[Currency],
				T.[AppliedRules],
				T.ScenarioKey
		FROM
			target.[Scenario] T
			LEFT JOIN 
			(
				SELECT DISTINCT [SGroup],[Name],[RiskType],[Currency] FROM staging.Scenario
			) OTHER_PAYLOADS
			ON
				T.[SGroup] = OTHER_PAYLOADS.[SGroup] 
				AND 
				T.[Name]= OTHER_PAYLOADS.[Name] 
				AND 
				T.[RiskType]= OTHER_PAYLOADS.[RiskType]
				AND 
				T.[Currency]= OTHER_PAYLOADS.[Currency]
		WHERE
			T.Start <= getutcdate() 
			AND 
			T.Finish > getutcdate() 	
			AND 
			OTHER_PAYLOADS.SGroup is null
			AND 
			OTHER_PAYLOADS.Name is null
			AND 
			OTHER_PAYLOADS.RiskType is null
			AND 
			OTHER_PAYLOADS.Currency is null	
	) CurrentPicture	

	--Log affected rows
	SET @Message = CAST(@@ROWCOUNT AS VARCHAR(30)) + ' rows inserted from target into [staging].[Scenario]'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#-------------------------------------------------- 'Apply Updates' -----------------------------------------------#--	
	
	-- Source Parameters
	SET @SourceTable = 'Scenario'  
	SET @SourceKeyColumn = 'CoreScenarioKey'
	INSERT INTO @SourceBusinessKeyColumns VALUES ('SGroup'),('Name'),('RiskType') --<< Currency too?
	INSERT INTO @SourceIgnoreColumns VALUES (@SourceKeyColumn),('ScenarioKey')
	SET @SourceRefDateTime = GETUTCDATE() 

	
	-- Target Parameters
	SET @TargetTable = 'Scenario'
	SET @TargetKeyColumn = 'ScenarioKey'  
	INSERT INTO @TargetBusinessKeyColumns VALUES ('SGroup'),('Name'),('RiskType') --<< Currency too?
	INSERT INTO @TargetIgnoreColumns VALUES (@TargetKeyColumn),('ScenarioKey')
	SET @TargetRefDateTime = GETUTCDATE()
	SET @ExpireDimensionData = 0
	
	
	-- Run the script
	EXEC	@return_value = [core].[p_Core2Target]
			@SourceTable = @SourceTable,
			@SourceKeyColumn = @SourceKeyColumn,
			@SourceBusinessKeyColumnsPARAM = @SourceBusinessKeyColumns,
			@SourceIgnoreColumnsPARAM = @SourceIgnoreColumns,
			@SourceRefDateTime = @SourceRefDateTime,
			@TargetTable = @TargetTable,
			@TargetKeyColumn = @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM = @TargetBusinessKeyColumns,
			@TargetIgnoreColumnsPARAM = @TargetIgnoreColumns,
			@TargetRefDateTime = @TargetRefDateTime,
			@ExpireDimensionData = @ExpireDimensionData,
			@ReStatement = 0,
			@SessionID = @SessionID;
		

	--Log Conformed count
	SET @Message = CAST(@return_value AS VARCHAR(30)) + ' scenario dimension rows were inserted.'
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
END TRY


--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH  

    SELECT 
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),        
		@ErrorProcedure = ERROR_PROCEDURE(),        
        @ErrorLine		= ERROR_LINE();
        
        --LOG        
	EXEC [core].p_LogError @SessionID = @SessionID
				  ,@ErrorNumber = @ErrorNumber
				  ,@ProcedureName=@ProcedureName
				  ,@ProcID = @@ProcID
				  ,@ErrorProcedure = @ProcedureName
				  ,@ErrorSeverity = @ErrorSeverity
				  ,@ErrorState = @ErrorState
				  ,@ErrorMessage = @ErrorMessage
				  ,@NESTLEVEL = @@NESTLEVEL
				  ,@ErrorLine = @ErrorLine;

	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN @ErrorNumber
END
GO
