/****** Object:  StoredProcedure [core].[p_Conform_Hierarchy]    Script Date: 11/17/2017 15:28:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Conform_Hierarchy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_Conform_Hierarchy]
GO

CREATE PROC [core].[p_Conform_Hierarchy]
(
	@BusDate			DATETIME2,
	@NowDate			DATETIME2,
	@DataFeed			VARCHAR(64),
	@Env				VARCHAR(6),
	@SessionID			INT	= 0 ,
	@hierarchyMode		INT	= -1	
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName				NVARCHAR(128),
		@InitialTranCount			BIGINT,
		@Message					NVARCHAR(MAX),
		@Origin						VARCHAR(30),
		@EndDate					DATETIME2,
		@InsertedCount				BIGINT,
		@return_value				BIGINT,
		@ReStatement				BINARY		= 0,
		@RowCount					BIGINT,
		@SQL						nvarchar(MAX);

	-- Legacy Core2Target
	DECLARE
		@TargetMaxRow				BIGINT,
		@AffectedRowsCount			BIGINT

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
--		@FactTableSync				INT		= 0,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= CASE WHEN @DataFeed = 'Hierarchy' OR @DataFeed = 'HierarchyT' THEN 1 ELSE 0 END,		--  Hierarchy feed is master,
		@MinNodeID as integer

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@EndDate			= CAST('9999-12-31' AS DATETIME2),
		@Message			= 'Invoking ' + @ProcedureName

	--Start logging
	EXEC [core].[p_LogInfo] @ProcedureName, @Message	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	-- 
	

	DECLARE @hierarchyTag INT
	SELECT @hierarchyTag = hierarchy FROM target.f_Hierarchy() 
	EXEC target.p_Set_HierarchyMode @hierarchyMode
	
	SET @Message = 'hierarchymode set to ' + cast(@hierarchyMode as varchar)
	EXEC [core].[p_LogDebug] @ProcedureName, @Message


	-- Core Synchronisation Parameters
	SELECT @CoreStarPrefix = target.f_CoreStarPrefix (@DataFeed)
	

	-- Check Golden Source Mappings
	exec [target].[p_CheckGoldenSourceMappings] @CoreStarPrefix,'Hierarchy'


	-- Common Staging & Target Syncronisation Parameters
	SET @TableToSync = 'Hierarchy'															-- Ommit schemas
	INSERT INTO @TargetBusinessKeyColumns VALUES ('NodeName'),('NodeType'),('BookSystem'),('HierarchyTag')	-- Must be logically Unique from a business perspective
	INSERT INTO @TargetDimensionKeyColumns VALUES ('NOTHING_FOR DIMENSIONS')				-- How This table references other Dimensions. NULL for Dimensions
	SET @CoreSourceKeyColumn	= 'CoreSourceKey'
	
	-- Remainder are computed
	SET @StagingTable		= @TableToSync
	SET @TargetTable		= 'vHierarchyAttribution'--@StagingTable
	SET @TargetKeyColumn	= @TableToSync + 'Key'
	SET @CoreTable			= @CoreStarPrefix + @TableToSync
	SET @CoreSourceTable	= @CoreStarPrefix + 'Source'
	SET @CoreKeyColumn		= 'Core' + @TableToSync + 'Key'
--	breaks CORE2STAGING INSERT INTO @CoreIgnoreColumns VALUES (@CoreSourceKeyColumn)
	INSERT INTO @CoreBusinessKeyColumns SELECT id from @TargetBusinessKeyColumns
	INSERT INTO @TargetIgnoreColumns VALUES (@CoreSourceKeyColumn)

    SET @Message = 'DataFeed = ''' +  @Datafeed  + ''''
	EXEC [core].[p_LogDebug] @ProcedureName, @Message

    SET @Message = 'CoreStarPrefix = ''' +  @CoreStarPrefix  + ''''
	EXEC [core].[p_LogDebug] @ProcedureName, @Message

	-- CORE TO STAGING - Merge new data with existing in TARGET from other sources
	EXEC	@return_value				= [core].[p_Core2Staging]
			@Datafeed					= @Datafeed,
			@Environment				= @Env,
			@CoreTable					= @CoreTable,
			@CoreSourceTable			= @CoreSourceTable,
			@CoreKeyColumn				= @CoreKeyColumn,
			@CoreSourceKeyColumn		= @CoreSourceKeyColumn,
			@CoreBusinessKeyColumns 	= @CoreBusinessKeyColumns,
			@CoreIgnoreColumns			= @CoreIgnoreColumns,
			@StagingTable				= @StagingTable,
			@TargetTable				= @TargetTable,
			@TargetKeyColumn			= @TargetKeyColumn,
			@TargetBusinessKeyColumns	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumns		= @TargetIgnoreColumns,
			@TargetRefDateTime			= @NowDate,
			@ExcludeDeprecatedFlag		= @ExcludeDeprecatedFlag,
			@SessionID					= @SessionID
    
	SET @Message = CAST(@return_value AS VARCHAR) + ' rows inserted into ' + @StagingTable + ' from ' + @TargetTable + ' and ' + @CoreTable
	EXEC [core].[p_LogInfo] @ProcedureName, @Message


	--Try and resolve null nodeids from target
	IF @CoreStarPrefix IN ('Position_', 'SimraPnLs_', 'RRR_', 'SimraFORiskMeasures_','GDIRiskMeasureTrade_')
	BEGIN
		SET @Message = '[Step 1Aa]. Updating staging from target for DataFeed = ''' +  @DataFeed  + ''''
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message
		UPDATE H SET
			 H.NodeId = T.NodeId
			,H.NodeParentID = T.NodeParentID			
		FROM staging.Hierarchy H
		join target.Hierarchy T on 1 = 1 
			and H.NodeName		= T.NodeName
			and	H.NodeType		= T.NodeType
			and	H.BookSystem	= T.BookSystem
			and	H.HierarchyTag	= T.HierarchyTag
			and	T.Start			<= @NowDate
			and T.Finish		> @NowDate
		where H.nodeid IS NULL

		SET @Message = '[Step 1Aa]. Done.' + CAST(@@ROWCOUNT as varchar) + ' nodeids and nodeParentIds updated' 
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message
	END

	--Resolve any remaining null nodeids
	IF @CoreStarPrefix IN ('Position_', 'SimraPnLs_', 'RRR_', 'SimraFORiskMeasures_','GDIRiskMeasureTrade_')
	BEGIN
		SET @Message = '[Step 1Ab]. Updating staging from staging for DataFeed = ''' +  @DataFeed  + ''''
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message

		UPDATE H SET
			 H.NodeId = (SELECT Min(NodeId) FROM STAGING.Hierarchy) +  MinNodeID
			,H.NodeParentID = Parent.NodeID
		FROM
			(SELECT corehierarchykey, 
               coresourcekey, 
               nodeid, 
               nodeparentid, 
               nodetype, 
               hierarchystring, 
               Reverse(Substring(gnirtsyhcrareih, 1, Charindex('/', gnirtsyhcrareih, 2) - 1)) ParentNodeName, 
               Reverse(gnirtsyhcrareih) ParentHierarchyString 
			FROM   (SELECT corehierarchykey, 
						   coresourcekey, 
						   nodeid, 
						   nodeparentid, 
						   nodetype, 
						   hierarchystring, 
						   Substring(Reverse(hierarchystringadj), Charindex('/', Reverse(hierarchystringadj), 2),100 ) gnirtSyhcrareiH 
					FROM   (SELECT corehierarchykey, 
								   coresourcekey, 
								   nodeid, 
								   nodeparentid, 
								   nodetype, 
								   hierarchystring, 
								   CASE WHEN hierarchystring IN ( '/', '/LBG/' ) THEN '///' 
										ELSE hierarchystring 
								   END HierarchyStringAdj 
							FROM   staging.hierarchy
							) H
					) H
			) H 
			JOIN 
			(
				SELECT Row_number() OVER (ORDER BY nodeid) *- 1 AS MinNodeID, * 
				FROM   staging.hierarchy 
				WHERE  nodeid IS NULL
		   ) S
		   ON H.corehierarchykey = S.corehierarchykey 
		   AND H.coresourcekey = S.coresourcekey 
		   CROSS apply (SELECT nodeid 
						FROM   staging.hierarchy 
						WHERE  hierarchystring = H.parenthierarchystring) Parent   
			
		SET @Message = '[Step 1Ab]. Done.' + CAST(@@ROWCOUNT as varchar) + ' nodeids and nodeParentIds updated' 
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message
	END
    ELSE IF @CoreStarPrefix = 'MarsVaRs_'
    BEGIN
        SET @Message = '[Step 1B]. Updating staging for DataFeed = ''' +  @DataFeed  + ''''
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message

        UPDATE H 
           SET NodeId = H1.NodeId
			  ,NodeParentID  = H1.NodeParentId
		  FROM staging.[Hierarchy] H
         INNER JOIN staging.[Hierarchy] H1
            ON H.NodeName = H1.NodeName
           AND H.NodeType = H1.NodeType
           AND H.HierarchyTag = H1.HierarchyTag
         WHERE H.NodeId IS NULL
           AND H.CoreSourceKey IS NOT NULL

        SET @Message = '[Step 1B]. Done'
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    END
    ELSE
    BEGIN
        EXEC [core].[p_LogDebug] @ProcedureName, '[Step 1]. Skipped'
    END


	IF @DataFeed <> 'Hierarchy' and  @DataFeed <> 'HierarchyT' and @DataFeed <> 'LIMIT' and @DataFeed <> 'MarsVaR'
	BEGIN
		
        SET @Message = '[Step 2]. Default the Risk Node Type for DataFeed = ''' +  @DataFeed  + ''''
	    EXEC [core].[p_LogDebug] @ProcedureName, @Message
        
        -- Doesn't matter if this is wrong, the hierarchy feed (golden source) has this info and will sort it out
		UPDATE Staging.Hierarchy
			SET NodeType = SUBSTRING('GRBUBADVDESDBO',((LEN(HierarchyString) - LEN(REPLACE(HierarchyString,'/','')) -2)*2)+1,2)
		WHERE NodeType is null

		SET @Message = 'All' + CAST(@@ROWCOUNT AS VARCHAR) + ' nodetypes deduced from hierarchyString in ' + @StagingTable
		EXEC [core].[p_LogInfo] @ProcedureName, @Message

		-- Use the Last node in the hierarchy string as the name
		UPDATE Staging.Hierarchy
		SET NodeName = (
			SELECT Item
			FROM TARGET.f_Split(HierarchyString, '/')
			WHERE Item NOT IN (
				SELECT TOP (
					(
						SELECT COUNT(*)
						FROM TARGET.f_Split(HierarchyString, '/')
						) - 2
					) Item
				FROM TARGET.f_Split(HierarchyString, '/')
				)
			)
		WHERE NodeName IS NULL

		SET @Message = CAST(@@ROWCOUNT AS VARCHAR) + ' null nodenames updated from hierarchyString in ' + @StagingTable
		EXEC [core].[p_LogInfo] @ProcedureName, @Message
        
	    EXEC [core].[p_LogDebug] @ProcedureName, '[Step 2]. Done'
	END
    ELSE
	BEGIN
        EXEC [core].[p_LogDebug] @ProcedureName, '[Step 2]. Skipped'
	END
	
	
	SET @Message = '[Step 3A]. Split Hierarchy for DataFeed = ''' +  @DataFeed  + ''''
	EXEC [core].[p_LogDebug] @ProcedureName, @Message

    --Split out hierarchy
	select
		 V.NodeID
		,V.NodeName
		,V.NodeType
		,V.BookSystem
		,V.SourceKey
		,ParsedData.*
		,V.Reporting
		,V.BookLegalEntity
		,V.RingFenced
		,V.HierarchyTag
		,V.NodeParentID
		,V.Ordinality
		,H.*
		,n1.*
		,n2.*
		,n3.*
		,n4.*
		,n5.*
		,n6.*
		,n7.*
		,n8.*
		,n9.*
		,n10.*
		,n11.*
		,n12.*
	into
		#levels
	from
		[staging].Hierarchy V
		cross apply ( select str = V.HierarchyString + '/////////////' ) f1
		cross apply ( select p1 = charindex( '/', str ) ) ap1
		cross apply ( select p2 = charindex( '/', str, p1 + 1 ) ) ap2
		cross apply ( select p3 = charindex( '/', str, p2 + 1 ) ) ap3
		cross apply ( select p4 = charindex( '/', str, p3 + 1 ) ) ap4
		cross apply ( select p5 = charindex( '/', str, p4 + 1 ) ) ap5
		cross apply ( select p6 = charindex( '/', str, p5 + 1 ) ) ap6
		cross apply ( select p7 = charindex( '/', str, p6 + 1 ) ) ap7
		cross apply ( select p8 = charindex( '/', str, p7 + 1 ) ) ap8
		cross apply ( select p9 = charindex( '/', str, p8 + 1 ) ) ap9
		cross apply ( select p10 = charindex( '/', str, p9 + 1 ) ) ap10
		cross apply ( select p11 = charindex( '/', str, p10 + 1 ) ) ap11
		cross apply ( select p12 = charindex( '/', str, p11 + 1 ) ) ap12
		cross apply ( select p13 = charindex( '/', str, p12 + 1 ) ) ap13
		cross apply ( SELECT
				  lvl1 = substring( str, p1+1, p2-p1-1 )
				, lvl2 = substring( str, p2+1, p3-p2-1 )
				, lvl3 = substring( str, p3+1, p4-p3-1 )
				, lvl4 = substring( str, p4+1, p5-p4-1 )
				, lvl5 = substring( str, p5+1, p6-p5-1 )
				, lvl6 = substring( str, p6+1, p7-p6-1 )
				, lvl7 = substring( str, p7+1, p8-p7-1 )
				, lvl8 = substring( str, p8+1, p9-p8-1 )
				, lvl9 = substring( str, p9+1, p10-p9-1 )
				, lvl10 = substring( str, p10+1, p11-p10-1 )
				, lvl11 = substring( str, p11+1, p12-p11-1 )
				, lvl12 = substring( str, p12+1, p13-p12-1 )
			  ) ParsedData
		cross apply ( SELECT
				  hs1 = substring( str, p1, p2 )
				, hs2 = substring( str, p1, p3 )
				, hs3 = substring( str, p1, p4 )
				, hs4 = substring( str, p1, p5 )
				, hs5 = substring( str, p1, p6 )
				, hs6 = substring( str, p1, p7 )
				, hs7 = substring( str, p1, p8 )
				, hs8 = substring( str, p1, p9 )
				, hs9 = substring( str, p1, p10 )
				, hs10 = substring( str, p1, p11 )
				, hs11 = substring( str, p1, p12 )
				, hs12 = substring( str, p1, p13 )
			  ) H
	CROSS APPLY
		(SELECT nid1 = (SELECT CASE WHEN Lvl1<>'' AND Lvl2='' THEN V.NodeID
		ELSE (CASE WHEN Lvl1<>'' AND Lvl2<>'' AND Lvl3='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs1 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n1	
	CROSS APPLY
		(SELECT nid2 = (SELECT CASE WHEN Lvl2<>'' AND Lvl3='' THEN V.NodeID
		ELSE (CASE WHEN Lvl2<>'' AND Lvl3<>'' AND Lvl4='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs2 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n2
	CROSS APPLY
		(SELECT nid3 = (SELECT CASE WHEN Lvl3<>'' AND Lvl4='' THEN V.NodeID
		ELSE (CASE WHEN Lvl3<>'' AND Lvl4<>'' AND Lvl5='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs3 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n3
	CROSS APPLY
		(SELECT nid4 = (SELECT CASE WHEN Lvl4<>'' AND Lvl5='' THEN V.NodeID
		ELSE (CASE WHEN Lvl4<>'' AND Lvl5<>'' AND Lvl6='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs4 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n4
	CROSS APPLY
		(SELECT nid5 = (SELECT CASE WHEN Lvl5<>'' AND Lvl6='' THEN V.NodeID
		ELSE (CASE WHEN Lvl5<>'' AND Lvl6<>'' AND Lvl7='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs5 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n5
	CROSS APPLY
		(SELECT nid6 = (SELECT CASE WHEN Lvl6<>'' AND Lvl7='' THEN V.NodeID
		ELSE (CASE WHEN Lvl6<>'' AND Lvl7<>'' AND Lvl8='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs6 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n6
	CROSS APPLY
		(SELECT nid7 = (SELECT CASE WHEN Lvl7<>'' AND Lvl8='' THEN V.NodeID
		ELSE (CASE WHEN Lvl7<>'' AND Lvl8<>'' AND Lvl9='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs7 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n7
	CROSS APPLY
		(SELECT nid8 = (SELECT CASE WHEN Lvl8<>'' AND Lvl9='' THEN V.NodeID
		ELSE (CASE WHEN Lvl8<>'' AND Lvl9<>'' AND Lvl10='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs8 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n8
	CROSS APPLY
		(SELECT nid9 = (SELECT CASE WHEN Lvl9<>'' AND Lvl10='' THEN V.NodeID
		ELSE (CASE WHEN Lvl9<>'' AND Lvl10<>'' AND Lvl11='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs9 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n9
	CROSS APPLY
		(SELECT nid10 = (SELECT CASE WHEN Lvl10<>'' AND Lvl11='' THEN V.NodeID
		ELSE (CASE WHEN Lvl10<>'' AND Lvl11<>'' AND Lvl12='' THEN V.NodeParentID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs10 and v.HierarchyTag = v1.HierarchyTag)
		END)END)) n10
	CROSS APPLY
		(SELECT nid11 = (SELECT CASE WHEN Lvl11<>'' AND Lvl12='' THEN V.NodeID
		ELSE (SELECT DISTINCT V1.NodeId FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs11 and v.HierarchyTag = v1.HierarchyTag)
		END)) n11
	OUTER APPLY
		(SELECT DISTINCT V1.NodeId nid12 FROM [staging].Hierarchy V1 WHERE V1.HierarchyString = H.hs11 and v.HierarchyTag = v1.HierarchyTag) n12
		
	SET @Message = 'HierarchyStrings split and transposed into' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows in #levels'
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

--select * from #levels    
--select * from staging.Hierarchy where NodeName like 'unknown%'

	EXEC [core].[p_LogDebug] @ProcedureName, '[Step 3A]. Done'
	--/*
	IF @DataFeed <> 'Hierarchy' AND @DataFeed <> 'HierarchyT'
	BEGIN
        -- Seed the start of any node IDs that have not been supplied (note we use -ve to avaoid possible clash)
		SET @MinNodeID = (SELECT MIN(ISNULL(NodeID,0)) FROM Staging.Hierarchy)

		--#------------------------------------------------ 'Update Staging Table' ----------------------------------------------#--
        EXEC [core].[p_LogDebug] @ProcedureName, '[Step 3B]. Updating Staging Table'
		UPDATE
			H
		set
			H.[Reporting] 		= COALESCE(H.[Reporting], L.Reporting,	1),
			H.[RingFenced] 		= COALESCE(H.[RingFenced], L.[RingFenced],	null),
			H.[SubGroup] 		= COALESCE(H.[SubGroup],		sg.NodeName, NULL),
			H.[BookLegalEntity] = COALESCE(H.[BookLegalEntity], L.[BookLegalEntity],	null),
			--H.[Trading]			= COALESCE(H.[Trading],		1),
			H.[Ordinality] 		= COALESCE(H.[Ordinality],	L.Ordinality),
			H.[Group] 			= COALESCE(H.[Group],			gr.NodeName),
			H.[Business]		= COALESCE(H.[Business],		bu.NodeName),
			H.[BusinessArea]	= COALESCE(H.[BusinessArea],	ba.NodeName),
			H.[Division]		= COALESCE(H.[Division],		dv.NodeName),
			H.[Desk]			= COALESCE(H.[Desk],			de.NodeName),
			H.[SubDesk]			= COALESCE(H.[Subdesk],			sd.NodeName),
			H.[Book]			= COALESCE(H.[Book],			bo.NodeName),
			H.[NodeParentID]	= COALESCE(H.NodeParentId,		L.NodeParentId,ISNULL(L.nid12,ISNULL(L.nid11,ISNULL(L.nid10,ISNULL(L.nid9,ISNULL(L.nid8,ISNULL(L.nid7,ISNULL(L.nid6,ISNULL(L.nid5,ISNULL(L.nid4,ISNULL(L.nid3,ISNULL(L.nid2,L.nid1)))))))))))),
			H.[NodeId]			= ISNULL(L.nodeid, @MinNodeID), 
			@MinNodeID = @MinNodeID - 1
		FROM
			[Staging].Hierarchy H
			JOIN
			#levels L
			ON
-- RD Fix for failure to enumerate hierarchy levels for non-Hierarchy sourced books, note they are negative and not null
				--H.NodeId IS Null 
				(H.NodeId IS Null OR H.NodeId < 0)
-- /RD
				AND
				H.NodeName = L.NodeName 
				AND 
				H.NodeType = L.NodeType 
				AND
				H.HierarchyTag = L.HierarchyTag 
				AND 
				H.BookSystem = L.BookSystem
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'GR' AND L.hierarchytag = H2.HierarchyTag  AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) gr
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'SG' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) sg
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BU' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) bu
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BA' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) ba
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'DV' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) dv
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'DE' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) de
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'SD' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) sd
				OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BO' AND L.hierarchytag = H2.HierarchyTag AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) bo
        
        SET @Message = CAST(@@ROWCOUNT AS VARCHAR) + ' rows updated in ' + @StagingTable + ' when joined with #levels'
		EXEC [core].[p_LogInfo] @ProcedureName, @Message
        
        EXEC [core].[p_LogDebug] @ProcedureName, '[Step 3B]. Done'

	END  

--select * from staging.Hierarchy where NodeName like 'unknown%'

	IF @DataFeed = 'Hierarchy'
	BEGIN
		--#------------------------------------------------ 'Update Staging Table' ----------------------------------------------#--
		--#---------------------------- 'This is the Golden Source and so we have the definitive hierarchy' ---------------------#--
 
        SET @Message = '[Step 4A]. Updating Staging Table for DataFeed= ''' +  @DataFeed  + ''''
        EXEC [core].[p_LogDebug] @ProcedureName, @Message

		update
			H
		set
			H.[Group] 			= COALESCE(H.[Group],			gr.NodeName),
			H.[SubGroup] 		= COALESCE(H.[SubGroup],		sg.NodeName, 'NRFB'),
			H.[Business]		= COALESCE(H.[Business],		bu.NodeName),
			H.[BusinessArea]	= COALESCE(H.[BusinessArea],	ba.NodeName),
			H.[Division]		= COALESCE(H.[Division],		dv.NodeName),
			H.[Desk]			= COALESCE(H.[Desk],			de.NodeName),
			H.[SubDesk]			= COALESCE(H.[Subdesk],			sd.NodeName),
			H.[Book]			= COALESCE(H.[Book],			bo.NodeName)
		FROM
			[Staging].Hierarchy H
			JOIN
			#levels L
			ON
				H.NodeId = L.NodeId
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'GR' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) gr
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'SG' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) sg
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BU' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) bu
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BA' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) ba
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'DV' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) dv
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'DE' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) de
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'SD' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) sd
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BO' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) bo
		WHERE NOT (H.NodeName = 'LBG' and H.NodeType = 'GR')
		
	END
    ELSE IF @DataFeed = 'HierarchyT'
	BEGIN
		--#------------------------------------------------ 'Update Staging Table' ----------------------------------------------#--
		--#---------------------------- 'This is the Golden Source and so we have the definitive hierarchy' ---------------------#--

        SET @Message = '[Step 4B]. Updating Staging Table for DataFeed= ''' +  @DataFeed  + ''''
        EXEC [core].[p_LogDebug] @ProcedureName, @Message

		UPDATE
			H
		set
			H.[Group] 			= COALESCE(H.[Group],			gr.NodeName),
            H.[SubGroup] 		= COALESCE(H.[SubGroup],		sg.NodeName),
			H.[Business]		= COALESCE(H.[Business],		bu.NodeName),
			H.[BusinessArea]	= COALESCE(H.[BusinessArea],	ba.NodeName),
			H.[Division]		= COALESCE(H.[Division],		dv.NodeName),
			H.[Desk]			= COALESCE(H.[Desk],			de.NodeName),
			H.[SubDesk]			= COALESCE(H.[Subdesk],			sd.NodeName),
			H.[Book]			= COALESCE(H.[Book],			bo.NodeName)
		FROM
			[Staging].Hierarchy H
			JOIN
			#levels L
			ON
				H.NodeId = L.NodeId
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'GR' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) gr
            OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'SG' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) sg
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BU' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) bu
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BA' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) ba
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'DV' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) dv
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'DE' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) de
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'SD' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) sd
			OUTER apply (SELECT NodeName FROM [staging].Hierarchy H2 WHERE H2.NodeType = 'BO' AND H2.NodeId IN (L.nid1, L.nid2, L.nid3, L.nid4, L.nid5, L.nid6, L.nid7, L.nid8, L.nid9, L.nid10, L.nid11, L.nid12)) bo
	END
    ELSE
	BEGIN
        EXEC [core].[p_LogDebug] @ProcedureName, '[Step 4]. Skipped'
	END

	IF OBJECT_ID('tempdb..#levels') IS NOT NULL DROP TABLE #levels

	---------------------------------------UPDATE BOOK references regardless of the source ----------------------------------------------	
    EXEC [core].[p_LogDebug] @ProcedureName, '[Step 5]. Update Book references'

	UPDATE
		H
	SET
		H.HierarchyBookKey = B.HierarchyBookKey
	FROM
		[Staging].Hierarchy  H
		JOIN
		[target].HierarchyBook B
		ON
		COALESCE(B.NodeName,'') = COALESCE(H.NodeName,'') AND
		COALESCE(B.NodeType,'') = COALESCE(H.NodeType,'') AND
		COALESCE(B.BookSystem,'') = COALESCE(H.BookSystem,'') --AND staging.HierarchyTag
	WHERE H.NodeType = 'BO' AND B.Finish = '9999-12-31'   -- only compare to records that are life

	SET @Message = 'HierarchyBookKey updated for ' + CAST(@@ROWCOUNT AS VARCHAR) + ' rows within ' + @StagingTable 
	EXEC [core].[p_LogInfo] @ProcedureName, @Message
        
	EXEC [core].[p_LogDebug] @ProcedureName,  '[Step 6]. End of conform'

	-- STAGING TO TARGET - Update the bitemporal TARGET with the new consolidated view provided in STAGING
    EXEC [core].p_LogInfo @ProcedureName , 'Processing staging to target for hierarchy' 
    
    
	EXEC	@return_value					= [core].[p_Staging2Target]
			@StagingTable					= @StagingTable,
			@StagingKeyColumn				= @CoreKeyColumn,
			@StagingBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@StagingIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@StagingRefDateTime				= @NowDate,
			@TargetTable					= @TargetTable,
			@TargetKeyColumn				= @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@TargetRefDateTime				= @NowDate,
			@ExpireDimensionData			= @ExcludeDeprecatedFlag,
			@ReStatement					= 0,
			@SessionID						= @SessionID

	SET @Message = CAST(@return_value AS VARCHAR) + ' rows inserted into ' + @TargetTable + ' from Staging'
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

	EXEC target.p_Set_HierarchyMode @hierarchyTag

	SET @Message = CAST(@return_value AS VARCHAR) + ' set hierarchMode back to ' + cast(@hierarchyTag as varchar)
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

	

	--#--------------------------------------------------- 'Apply Rules' ------------------------------------------------#--

	--Check everything is still valid by looking for any duplicates	
	SELECT HierarchyTag, NodeID 
	into #Problems FROM [target].[Hierarchy]
	WHERE Start <= GETUTCDATE() and Finish > GETUTCDATE()
	GROUP BY HierarchyTag, NodeID
	HAVING COUNT(NodeID) > 1
	
	if (select count(1) from #problems) > 0 
	begin		
		declare @NodeId varchar(1000)		
		select @NodeId = COALESCE(@NodeId + ', ', '') + cast(NodeId as varchar) FROM #Problems		
		SET @Message = 'Hiererachy Integrity Compromised, Can not Roll Back!. Duplicate nodes are as follows: ' + @nodeid
		EXEC [core].p_LogWarning @ProcedureName, @Message
		--RAISERROR( @Message,11,-1, @ProcedureName)
	end

	drop table #Problems

	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
    
    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END
GO
