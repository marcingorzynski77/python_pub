IF OBJECT_ID ('core.p_CreateStar_SimraPnLs') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_SimraPnLs
GO

CREATE PROC [core].[p_CreateStar_SimraPnLs]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT			= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@InitialTranCount	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@RejectedCount		BIGINT,
		@UTCDate			DATETIME2;

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	--First empty the star ready for new data
	TRUNCATE TABLE [core].SimraPnLs_Source
	TRUNCATE TABLE [core].SimraPnLs_Hierarchy
	TRUNCATE TABLE [core].SimraPnLs_HierarchyBook
	TRUNCATE TABLE [core].SimraPnLs_ScenarioHierarchy
	TRUNCATE TABLE [core].SimraPnLs_RiskMeasureType
	TRUNCATE TABLE [core].SimraPnLs_RiskFactorType
	TRUNCATE TABLE [core].SimraPnLs_RiskFactor
	TRUNCATE TABLE [core].SimraPnLs_InstrumentType
	TRUNCATE TABLE [core].SimraPnLs_Fact

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_Source'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_Hierarchy'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_ScenarioHierarchy'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_RiskMeasureType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_RiskFactorType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_RiskFactor'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_InstrumentType'

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraPnLs_Fact'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'staging', @IndexTableName = 'PnL_Fact'

	--#--------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT into [core].SimraPnLs_Source (
		 [InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	)
	SELECT
		 @datafeed as [InterfaceName]
		,@env as [Environment]
		,'SIMRA' as [Source]
		,'SIMRA' as [Origin]	-- CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_Source dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--

	-- Record Books and their hierarchical categories

	CREATE TABLE #Hierarchy (
		  CoreHierarchyKey		BIGINT IDENTITY NOT NULL
		, CoreSourceKey			BIGINT
		, NodeName				VARCHAR (50)
		, NodeType				CHAR (2)
		, BookLegalEntity		VARCHAR (20)
		, BookCad2				BIT
		, BusinessHierarchyPath	VARCHAR (900) NOT NULL
		, HierarchyString		VARCHAR (900)
		, BookSystem			VARCHAR (50) NOT NULL
		, HierarchyTag			INT NULL
	)
	
	DECLARE @hierarchytag as INT;
	-- build cursor 
	DECLARE @hierarchyCursor as CURSOR;
	
	SET @hierarchyCursor = CURSOR FOR
	SELECT distinct HierarchyTag FROM target.hierarchy where finish = '9999-12-31';
	OPEN @hierarchyCursor;
    FETCH NEXT FROM @hierarchyCursor INTO @hierarchytag
	--Hierarchy Dimension
	
	WHILE @@FETCH_STATUS = 0
	BEGIN


	INSERT INTO #Hierarchy (
		  CoreSourceKey
		, NodeType
		, BookLegalEntity
		, BookCad2
		, BusinessHierarchyPath
		, BookSystem
		, HierarchyTag
	)
	SELECT
		 S.CoreSourceKey
		,'BO' AS [NodeType]
		,R.[LegalEntity]
		,R.[Cad2]
		,R.[BusinessHierarchyPath]
		,CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'Risk Management' else R.[SourceSystemName] END
		,@hierarchytag
	FROM
		[raw].SimraPnLs R
		join
		core.SimraPnLs_Source S
		on
			S.Origin = 'SIMRA' -- CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END
	GROUP BY
		 S.[CoreSourceKey]
		,R.[LegalEntity]
		,R.[Cad2]
		,R.[BusinessHierarchyPath]
		,CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'Risk Management' else R.[SourceSystemName] END

	select @InsertedCount = @@ROWCOUNT

	UPDATE
		H
	SET
		 [NodeName] = node.NN
		,[HierarchyString] = path1.P1
	FROM
		(select * from #Hierarchy where HierarchyTag = @hierarchytag) H
		CROSS APPLY (SELECT P0 = replace(H.[BusinessHierarchyPath], '\', '/')) path0
		CROSS APPLY (SELECT P1 = CASE WHEN LEFT(P0, 5) = 'Root/' THEN RIGHT(P0, len(P0) - 4) ELSE P0 END ) path1
		CROSS APPLY (SELECT RP = REVERSE(P1)) rpath
		CROSS APPLY (SELECT NN = REVERSE(LEFT(RP, CHARINDEX('/', RP) - 1))) node
		
	FETCH NEXT FROM @hierarchyCursor INTO @hierarchytag

	END
	
	CLOSE @hierarchyCursor;
	DEALLOCATE @hierarchyCursor;
	
	
	INSERT INTO [core].SimraPnLs_Hierarchy (
		 [CoreHierarchyKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookLegalEntity]
		--,[BookCad2]
		,[HierarchyString]
		,[BookSystem]
		,[HierarchyTag]
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		,BookLegalEntity
		--,BookCad2
		,HierarchyString + '/'
		,BookSystem
		,HierarchyTag
	FROM
		#Hierarchy H

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_Hierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
		INSERT INTO [core].SimraPnLs_HierarchyBook (
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookCad2]
		,[BookSystem]
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		--,BookLegalEntity
		,BookCad2
		--,HierarchyString + '/'
		,BookSystem
	FROM
		#Hierarchy H where NodeType = 'BO' and HierarchyTag = 0 -- we will have data for all hierarchies created and previous step but for books we can only need one , hence using default one
 
    select @InsertedCount = @@ROWCOUNT
    
	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_HierarchyBook dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the ScenarioHierarchy Dimension ----------------------------------------#--

	-- Record Books and their hierarchical categories

	CREATE TABLE #ScenarioHierarchy (
		  [CoreSourceKey]				BIGINT
		, [NodeID]	 					BIGINT
		, [ScenarioNodeName]			VARCHAR (50)
		, [Level]						INT
		, [AggregationType]				VARCHAR (255)
		, [ScenarioHierarchyString]		VARCHAR (900)
	)

	INSERT INTO #ScenarioHierarchy (
		  CoreSourceKey
		, ScenarioNodeName
	)
	SELECT
		 S.CoreSourceKey
		,R.ScenarioName as ScenarioNodeName
	FROM
		[raw].SimraPnLs R
		join
		core.SimraPnLs_Source S
		on
			S.Origin = 'SIMRA' -- CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END
	GROUP BY
		 S.[CoreSourceKey]
		,R.[ScenarioName]

	select @InsertedCount = @@ROWCOUNT

	UPDATE
		H
	SET
		 [ScenarioHierarchyString] = ISNULL(T.ScenarioHierarchyString, '`LBG`' + H.ScenarioNodeName)
		,[NodeID] = ISNULL(T.NodeID, -1)
		,[Level] = ISNULL(T.[Level], 2)
		,[AggregationType] = ISNULL(T.[AggregationType], 'None')
	FROM
		#ScenarioHierarchy H
		left join
		target.ScenarioHierarchy T
		on
			H.ScenarioNodeName = T.ScenarioNodeName


	INSERT INTO [core].SimraPnLs_ScenarioHierarchy (
		 [CoreSourceKey]
		,[NodeID]
		,[ScenarioNodeName]
		,[Level]
		,[AggregationType]
		,[ScenarioHierarchyString]
	)
	SELECT
		 [CoreSourceKey]
		,[NodeID]
		,[ScenarioNodeName]
		,[Level]
		,[AggregationType]
		,[ScenarioHierarchyString]
	FROM
		#ScenarioHierarchy H

	DROP TABLE #ScenarioHierarchy

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_ScenarioHierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the RiskMeasureType Dimension ----------------------------------------#--

	--RiskMeasure Dimension

	INSERT INTO [core].SimraPnLs_RiskMeasureType (
		 [CoreSourceKey]
		,[RiskMeasureTypeName]
		,[RiskMeasureFamily]
	)
	SELECT
		 S.CoreSourceKey
		,R.RiskMeasureTypeName
		,R.RiskMeasureTypeName		-- for now, this is mapped to the right thing using the DataMapper
	FROM
		[raw].SimraPnLs R
		join
		core.SimraPnLs_Source S
		on
			S.Origin = 'SIMRA' --CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END
	GROUP BY
		 R.RiskMeasureTypeName
		,S.[CoreSourceKey]

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_RiskMeasureType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the RiskFactorType Dimension ----------------------------------------#--

--	--RiskFactorType Dimension
--
	INSERT INTO [core].SimraPnLs_RiskFactorType (
		 [CoreSourceKey]
		,[RiskFactorTypeName]
	) VALUES (1,'UnAvailable')
--	SELECT DISTINCT
--		 S.CoreSourceKey
--		,R.RiskFactorType
--	FROM
--		[raw].SimraPnLs R
--		join
--		core.SimraPnLs_Source S
--		on
--			S.Origin = CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END
--	GROUP BY
--		 R.[RiskFactorType]
--		,S.[CoreSourceKey]
--
--
--	--Log affected rows
--	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_RiskFactorType dimension'
--	EXEC [core].p_LogInfo @ProcedureName, @Message
--
--
--	--#------------------------------------------ Populate the RiskFactor Dimension ----------------------------------------#--
--
--	--RiskFactor Dimension
--
	INSERT INTO [core].SimraPnLs_RiskFactor (
		 [CoreSourceKey]
		,[RiskFactorName]
	) VALUES (1,'UnAvailable')
--	SELECT DISTINCT
--		 S.CoreSourceKey
--		,R.RiskFactorName
--	FROM
--		[raw].SimraPnLs R
--		join
--		core.SimraPnLs_Source S
--		on
--			S.Origin = CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END
--	GROUP BY
--		 R.[RiskFactorName]
--		,S.[CoreSourceKey]
--
--
--	--Log affected rows
--	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_RiskFactor dimension'
--	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the InstrumentType Dimension ----------------------------------------#--

	--Instrument Dimension

	INSERT INTO [core].SimraPnLs_InstrumentType (
		 [CoreSourceKey]
		,[InstrumentType]
		,[InstrumentSubType]
	)
	SELECT DISTINCT
		 S.CoreSourceKey
		,R.InstrumentType
		,''
	FROM
		[raw].SimraPnLs R
		join
		core.SimraPnLs_Source S
		on
			S.Origin = 'SIMRA' --CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraPnLs_InstrumentType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#----------------------------------------------- Populate the SimraPnLValue Fact ---------------------------------------------#--

	-- Risk Measure Values
	INSERT INTO [core].[SimraPnLs_Fact] (
		 [BusDate]
		,[CoreSourceKey]
		,[CoreHierarchyKey]
		,[CoreScenarioHierarchyKey]
		,[CoreRiskMeasureTypeKey]
		,[CoreRiskFactorTypeKey]
		,[CoreRiskFactorKey]
		,[CoreInstrumentTypeKey]
		,[AnalysisTypeName]
		,[PnLFunctionID]
		,[InstrumentTypeBlipSize]
		,[LegalEntity]
		,[Cad2]
		,[ScenarioDate]
		,[ValueCurrency]
		,[Value]
		,[ValueGBP]
	)
	SELECT
		 R.[BusinessDate]
		,S.[CoreSourceKey]
		,H.[CoreHierarchyKey]
		,SH.[CoreScenarioHierarchyKey]
		,RM.[CoreRiskMeasureTypeKey]
		,ISNULL(RFT.[CoreRiskFactorTypeKey],1)
		,ISNULL(RF.[CoreRiskFactorKey],1)
		,I.[CoreInstrumentTypeKey]
		,R.[AnalysisTypeName]
		,R.[PnLFunctionID]
		,R.[InstrumentTypeBlipSize]
		,R.[LegalEntity]
		,CONVERT(BIT, R.[Cad2]) as [Cad2]
		,R.[Scenario Date]
		,R.[ValueCurrency]
		,SUM(R.[sum Value])
		,SUM(R.[sum Value GBP])
	FROM
		[raw].SimraPnLs R
		LEFT JOIN
		[core].SimraPnLs_Source S
		ON
			S.Origin = 'SIMRA' -- CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'SIMRA' else R.[SourceSystemName] END
		LEFT JOIN
		(select * from #Hierarchy where HierarchyTag = 0) H -- it does not matter which hierarchy we choose here as book are independent of hierarchy
		ON
			R.[BusinessHierarchyPath]= H.BusinessHierarchyPath
			AND
			H.BookSystem = CASE when R.[SourceSystemName] is null or R.[SourceSystemName]  = '' then 'Risk Management' else R.[SourceSystemName] END
			AND
			S.CoreSourceKey = H.CoreSourceKey
		LEFT JOIN
		[core].SimraPnLs_ScenarioHierarchy SH
		ON
			R.ScenarioName = SH.ScenarioNodeName
		LEFT JOIN
		[core].SimraPnLs_RiskMeasureType RM
		ON
			R.RiskMeasureTypeName = RM.[RiskMeasureTypeName]
			AND
			S.CoreSourceKey = RM.CoreSourceKey
		LEFT JOIN
		[core].SimraPnLs_RiskFactorType RFT
		ON
			R.RiskFactorType = RFT.[RiskFactorTypeName]
			AND
			S.CoreSourceKey = RFT.CoreSourceKey
		LEFT JOIN
		[core].SimraPnLs_RiskFactor RF
		ON
			R.RiskFactorName = RF.[RiskFactorName]
			AND
			S.CoreSourceKey = RF.CoreSourceKey
		LEFT JOIN
		[core].SimraPnLs_InstrumentType I
		ON
			R.InstrumentType = I.[InstrumentType]
			AND
			S.CoreSourceKey = I.CoreSourceKey
	WHERE
		PNLStrip_DataStatusId <> 3 -- 'The value 3 in this field represents an error. Ignore this value.
	GROUP BY
		 R.[BusinessDate]
		,S.[CoreSourceKey]
		,H.[CoreHierarchyKey]
		,SH.[CoreScenarioHierarchyKey]
		,RM.[CoreRiskMeasureTypeKey]
		,RFT.[CoreRiskFactorTypeKey]
		,RF.[CoreRiskFactorKey]
		,I.[CoreInstrumentTypeKey]
		,R.[AnalysisTypeName]
		,R.[PnLFunctionID]
		,R.[InstrumentTypeBlipSize]
		,R.[LegalEntity]
		,R.[Cad2]
		,R.[Scenario Date]
		,R.[ValueCurrency]

	SET @InsertedCount = @@ROWCOUNT

	DROP TABLE #Hierarchy

	-- Generate a warning for data which has been ignored
	SELECT @RejectedCount = count(*) FROM [raw].SimraPnLs R WHERE PNLStrip_DataStatusId = 3		-- 'The value 3 an error.
	IF @RejectedCount > 0
	BEGIN
		SET @Message = CAST(@RejectedCount as varchar(30)) + ' P&Ls ignored as SIMRA indicated bad PnL Strip values'
		EXEC [core].p_LogInfo @ProcedureName, @Message
	END

	--Log affected rows
	SET @Message = 'Split out ' + CAST(@InsertedCount as VARCHAR(30)) + ' rows into core.SimraPnLs_Fact fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#---------------------------------------------- END OF STAR CODE -----------------------------------------------#--
--#===============================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END
GO