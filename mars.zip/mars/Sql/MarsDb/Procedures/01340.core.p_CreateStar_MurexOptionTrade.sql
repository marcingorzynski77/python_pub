IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_CreateStar_MurexOptionTrade]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [core].[p_CreateStar_MurexOptionTrade]
GO

CREATE PROC [core].[p_CreateStar_MurexOptionTrade]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@Debug      INT         = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName			NVARCHAR(128),
		@Message				NVARCHAR(MAX),
		@CommentID				INT,
		@SourceInsertedCount	BIGINT,
		@HierarchyInsertedCount	BIGINT,
		@HierarchyUpdateCount	BIGINT, 
		@MurexOptionTradeCount	BIGINT,
		@MaxRow					BIGINT,
		@UTCDate				DATETIME2	= getutcdate()

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 

--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

	BEGIN TRY

		DECLARE
				@CoreSourceKey				BIGINT
			,	@BookSystem					VARCHAR(max) = 'GDIMUREX'
			,	@BaseCurrency				VARCHAR(max) = 'GBP'
			,	@LiveTradeState				VARCHAR(max) = 'LIVE'
			,	@FXSpotRate					VARCHAR(max) = 'Foreign Exchange Spot Rate'
			,	@InstrumentPrefix			VARCHAR(max) = 'FX Option '
			,	@NodeType					VARCHAR(max) = 'BO';

		--First empty the star ready for new data
		TRUNCATE TABLE [core].MurexOption_Source
		TRUNCATE TABLE [core].MurexOption_Trade
	
		--#-------------------------------------------- Populate the Source Dimension ------------------------------------------#--
		BEGIN --Source Dimension

			INSERT INTO [core].MurexOption_Source (
				[InterfaceName],
				[Environment],
				[Source],
				[Origin]
			)
			VALUES (
				@DataFeed,
				@Env,
				@BookSystem,
				@BookSystem
			)

			select @SourceInsertedCount = @@ROWCOUNT
			
			SELECT @CoreSourcekey = SourceKey 
			FROM target.source
			WHERE 1 = 1
			AND   origin		= @BookSystem
			AND   interfaceName	= @DataFeed

	
			if @Debug = 1
			begin
				select * from [core].[MurexOption_Source] 
			end

			--Log affected rows
			SET @Message = 'Split out ' + CAST((@SourceInsertedCount)AS VARCHAR(30)) + ' rows into [core].[MurexOption_Source] dimension'
			EXEC [core].p_LogInfo @ProcedureName, @Message
		END
		
		--#--------------------------------------------- Populate the Trade Dimension ------------------------------------------#--
		BEGIN --Trade Dimension		

			;WITH DistinctSource AS 
			(
				SELECT DISTINCT 	
					[MIRRORED],
					[TRADEVERSION],
					[TRADESTATE],
					CAST(RIGHT(TRADEDATETIME,2)+SUBSTRING(TRADEDATETIME,4,2)+ LEFT(TRADEDATETIME,2)  + ' ' + MKTLINKCAPTUREDATE_TIME AS DATETIME2) [TRADEDATETIME],
					CAST(SUBSTRING(CAPTUREDATE_TIME,7,4)+SUBSTRING(CAPTUREDATE_TIME,4,2)+ LEFT(CAPTUREDATE_TIME,2) + ' ' + RIGHT(CAPTUREDATE_TIME,8) AS DATETIME2)	[CAPTUREDDATETIME],
					CASE WHEN AMENDDATE != '../../..' THEN cast(substring(AMENDDATE,7,2)+substring(AMENDDATE,4,2)+ left(AMENDDATE,2) + ' ' + [AMENDTIME] as datetime2)  ELSE '01-JAN-1900' END [AMENDDATETIME],
					[AMENDMENTAREA],
					[AMENDMENTREASON],
					[NettingMode],
					CASE WHEN PORS = 'P' THEN 'B' ELSE 'S' END	[BUYSELL],
					CAST(SUBSTRING(EXPIRYDATE,7,4)+SUBSTRING(EXPIRYDATE,4,2)+ LEFT(EXPIRYDATE,2) AS DATETIME2) [EXPIRYDATE],
					[EXERCISE_TYPE],
					[PUTORCALL],
					CAST(SUBSTRING(MATURITYDATE,7,2)+SUBSTRING(MATURITYDATE,4,2)+ LEFT(MATURITYDATE,2) AS DATETIME2) MATURITYDATE,
					CAST(SUBSTRING(EXCERCISEDDATETIME,7,4)+SUBSTRING(EXCERCISEDDATETIME,4,2)+ LEFT(EXCERCISEDDATETIME,2) AS DATETIME2) [EXERCISEDATETIME],
					[STRIKERATE],
					CAST(SUBSTRING(VALUEDATE,7,2)+SUBSTRING(VALUEDATE,4,2)+ LEFT(VALUEDATE,2) AS DATETIME2)	[VALUEDATE],
					[PRICE],
					[BOUGHTCCY],
					[BOUGHTAMT],
					[SOLDCCY],
					[SOLDAMT],
					[MAINCCY],
					[FORWARDRATE],
					[PREMIUMCCY],
					[PREMIUMAMOUNT],
					TRADE_TYPE + ' - ' + TRADESUBTYPE [TRADETYPESUBTYPE]
				FROM raw.MurexPositions_C_omi_opt	
				WHERE TRADESTATE = @LiveTradeState
			) 
			, DistinctKey As
			(
				SELECT 
					[MIRRORED],
					MAX([AMENDDATETIME]) [MAXAMENDDATETIME]
				FROM DistinctSource		
				GROUP BY 
					[MIRRORED]
			)			
			INSERT INTO core.MurexOption_Trade (	
				[CoreSourceKey],
				[TradeReference],
				[TradeVersion],
				[TradeState],
				[TradeDateTime],
				[CaptureDateTime],
				[AmendDateTime],
				[AmendArea],
				[AmendReason],
				[BorS],
				[ExpiryDate],
				[Exercisetype],
				[PutOrCall],
				[MaturityDate],
				[ExerciseDate],
				[Strike],
				[ValueDate],
				[Price],
				[ReceiveCurrency],
				[ReceiveAmount],
				[PayCurrency],
				[PayAmount],
				[MainCurrency],
				[ForwardRate],
				[PremiumCurrency],
				[PremiumAmount],
				[TradeTypeSubType]
			)	
			SELECT  		
					1,
					S.[MIRRORED],
					S.[TRADEVERSION],
					S.[TRADESTATE],
					S.[TRADEDATETIME],
					S.[CAPTUREDDATETIME],
					S.[AMENDDATETIME],
					S.[AMENDMENTAREA],
					S.[AMENDMENTREASON],
					S.[BUYSELL],
					S.[EXPIRYDATE],
					S.[EXERCISE_TYPE],
					S.[PUTORCALL],
					S.[MATURITYDATE],
					S.[EXERCISEDATETIME],
					S.[STRIKERATE],
					S.[VALUEDATE],
					S.[PRICE],
					S.[BOUGHTCCY],
					S.[BOUGHTAMT],
					S.[SOLDCCY],
					S.[SOLDAMT],
					S.[MAINCCY],
					S.[FORWARDRATE],
					S.[PREMIUMCCY],
					S.[PREMIUMAMOUNT],
					S.[TRADETYPESUBTYPE]
			FROM DistinctKey k 
			JOIN DistinctSource s ON s.[MIRRORED] = k.[MIRRORED]
								  AND s.[AMENDDATETIME] = k.[MAXAMENDDATETIME]			


			SELECT @MurexOptionTradeCount = @@ROWCOUNT

			IF @Debug = 1
			BEGIN
				SELECT * FROM [core].[MurexOption_Trade] 
			END

			-- Log affected rows
			SET @Message = ' ' + CAST((@MurexOptionTradeCount)AS VARCHAR(30)) + ' rows into [core].[MurexOption_Trade] dimension'
			EXEC [core].p_LogInfo @ProcedureName, @Message

		END
		--#--------------------------------------------- ----------------------------- ------------------------------------------#--
		
	
--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--
	END TRY	

	BEGIN CATCH

		DECLARE
			@ErrorNumber		INT,
			@ErrorSeverity		INT,
			@ErrorState			INT,
			@ErrorLine			INT,
			@ErrorMessage		NVARCHAR(4000),
			@ErrorProcedure		NVARCHAR(128);

   		SELECT
			@ErrorNumber    = ERROR_NUMBER(),
			@ErrorSeverity  = ERROR_SEVERITY(),
			@ErrorState     = ERROR_STATE(),
			@ErrorMessage   = ERROR_MESSAGE(),
			@ErrorProcedure = ERROR_PROCEDURE(),
			@ErrorLine		= ERROR_LINE();

		EXEC [core].p_LogError 
			@ProcedureName 	= @ProcedureName,
			@Message 		= @ErrorMessage,
			@ErrorNumber 	= @ErrorNumber,
			@ErrorProcedure = @ProcedureName,
			@ErrorSeverity 	= @ErrorSeverity,
			@ErrorState 	= @ErrorState,
			@ErrorLine 		= @ErrorLine,
			@NESTLEVEL 		= @@NESTLEVEL;

		RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

	END CATCH;

RETURN 0;

END

GO