IF OBJECT_ID ('target.p_Set_LimitDate') IS NOT NULL
	DROP PROCEDURE target.p_Set_LimitDate
GO

CREATE PROC [target].[p_Set_LimitDate] 
(
	@LimitDate DATE = Null --DATETIME2 = Null
)
WITH EXECUTE AS OWNER
AS 	
BEGIN

	DECLARE @SessionContextBinary   VARBINARY(128)	
	--DECLARE @SessionContext			VARchar(300)	
	DECLARE @SessionDateTime		VARCHAR(19)
	DECLARE @BusDate				VARCHAR(11)	
	DECLARE @TargetDate				VARCHAR(19)	
	DECLARE @XML					varchar(max)	
    DECLARE @Hierarchy				INT 
	--Get other dates		
	SET @BusDate = (select BusDate from target.vTimeTravel)
	SET @TargetDate = (select VersionDateTime from target.vTimeTravel)
	SET @SessionDateTime = convert(VARCHAR(19), GETUTCDATE(), 120)
	SET @Hierarchy =  (select * from [target].[f_Hierarchy]())
	
		SET @xml = '<C><S>' + convert(varchar(19),@SessionDateTime,120) + '</S><T>' 
					 	 + ISNULL(convert(varchar(19),@TargetDate,120),'') + '</T><B>'
					  	 + ISNULL(convert(varchar(10),@BusDate,120),'') + '</B><L>' 
						 + ISNULL(convert(varchar(10),@LimitDate,120),' ') + '</L><H>'
						  + ISNULL(convert(varchar(10),@Hierarchy),' ') + '</H></C>'


	print @xml


	SET @SessionContextBinary = convert(varbinary(128), @XML)
	print @SessionContextBinary


	--Set
	SET CONTEXT_INFO @SessionContextBinary

END

GO
