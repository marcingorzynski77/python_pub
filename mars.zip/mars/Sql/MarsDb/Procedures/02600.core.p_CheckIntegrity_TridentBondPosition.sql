IF OBJECT_ID ('core.p_CheckIntegrity_TridentBondPosition') IS NOT NULL
	DROP PROCEDURE core.p_CheckIntegrity_TridentBondPosition
GO

CREATE PROC [core].[p_CheckIntegrity_TridentBondPosition] 
(
	@CheckWhat varchar(20),
	@SessionID	int = 0	
)
AS 

BEGIN
    SET NOCOUNT ON;

    DECLARE
		@return_status		int,
        @ProcedureName      nvarchar(128),
		@Message			nvarchar(MAX),
        @InitialTranCount   INT,
        @BusinessLogicSev	INT;
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
        @InitialTranCount   = @@TRANCOUNT;
        
	SET @Message = 'Invoking ' + @ProcedureName
	exec [core].p_LogInfo @ProcedureName, @Message
  
--#------------------------------------------ END OF STANDARD INEGRITY HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY	
			
	declare @rowCount bigint
	
	if @CheckWhat = 'core.Bond_Position'	
	begin
		--Need to check that all of the rows imported into ETL are accounted for
		
		declare @ETL_count as int
		declare @SnowFlake_Count as int
		
		set @ETL_count = (select COUNT(1) as 'ETL_Count' from raw.TridentBondPosition)
		set @SnowFlake_Count = 		(select COUNT(1) as 'SnowFlake_Count' from
									(select CoreKey from core.TridentBondCDS_Trade
									union all
									select CoreKey from core.TridentBondPosition)a)
		
		select @ETL_count - @SnowFlake_Count
		
	end
	
END TRY


--#--------------------------------------------------- END OF Checks --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

     DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

      
    --TRANASCTION REVERSE (IF POSSIBLE)
    IF @@TRANCOUNT > 0 AND @InitialTranCount=0
		ROLLBACK TRANSACTION @ProcedureName;
    ELSE
        IF @@TRANCOUNT > 0 AND XACT_STATE() <> -1
        ROLLBACK TRANSACTION @ProcedureName;
    ELSE
    IF @@TRANCOUNT > 0 

    --LOG
    SET @Message = 'The transaction is uncommittable, a rollback to the savepoint is not allowed, roll back the outer transaction'      
    exec [core].p_LogInfo @ProcedureName, @Message
                
	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
