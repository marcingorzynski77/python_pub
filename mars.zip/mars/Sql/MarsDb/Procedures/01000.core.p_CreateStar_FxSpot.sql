IF OBJECT_ID ('core.p_CreateStar_FxSpot') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_FxSpot
GO

CREATE PROC [core].[p_CreateStar_FxSpot]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),  -- Fx datafeed is "MarketData" 
	@Env		VARCHAR(6),
	@SessionID	INT		= 0
)
AS

BEGIN

    SET NOCOUNT ON;

    DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT,
		@MaxRow			BIGINT,
		@UTCDate		DATETIME2;

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @FxSpotSourceId as int
	SET @FxSpotSourceId = 1

	--First empty the star ready for new data
	truncate table [core].[FxSpot_Source];
	truncate table [core].[FxSpot_Fact];

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'FxSpot_Source'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'FxSpot_Fact'

	--#------------------------------------------------ Populate the Source ---------------------------------------------#--

	--Source Limit_source
	INSERT INTO [core].FxSpot_Source  (
			 CoreSourceKey
			,[InterfaceName]
			,Environment
			,[Origin]
			,[Source]
		) Values (
			 @FxSpotSourceId
			,'FxSpot'
			,@Env
			,'SMDS'
			,'TRIDENT'
		)
	
	--#----------------------------------------------- Populate the FXSpot Fact ---------------------------------------------#--

	--FXSpot Facts for GBPGBP
	INSERT INTO [core].FxSpot_Fact (
		 BusDate
		,BaseCurrency
		,VariableCurrency
		,Rate
		,CoreSourceKey
	)
	SELECT
		@BusDate,
		'GBP',
		'GBP',
		1,
		1

	--Log affected rows
	SET @Message = 'Added GBPGBP row into core.FxSpot_Fact fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--FXSpot Facts from ETL
	INSERT INTO [core].FxSpot_Fact (
		 BusDate
		,BaseCurrency
		,VariableCurrency
		,Rate
		,CoreSourceKey
	)
	SELECT
		@BusDate,
		E.[BaseCurrency],
		E.[VariableCurrency],
		E.[Rate],
		1
	FROM
		[raw].FXSpot E

	UNION ALL

	select
		@BusDate,
		E.[VariableCurrency],
		E.[BaseCurrency],
		1.0 / E.[Rate],
		1
	from
		[raw].FXSpot E
		left join
		[raw].FXSpot E1
		on
			E1.[VariableCurrency] = E.[BaseCurrency]
			and
			E1.[BaseCurrency] = E.[VariableCurrency]
	where
		E1.BaseCurrency IS NULL
		and
		E.VariableCurrency = 'GBP'

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into core.FXRate fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END
GO