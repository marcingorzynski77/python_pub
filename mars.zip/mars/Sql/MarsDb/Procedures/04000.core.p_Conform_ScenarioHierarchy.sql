IF OBJECT_ID ('core.p_Conform_ScenarioHierarchy') IS NOT NULL
	DROP PROCEDURE core.p_Conform_ScenarioHierarchy
GO

CREATE PROC [core].[p_Conform_ScenarioHierarchy]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6)
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName			NVARCHAR(128),
		@Message				NVARCHAR(MAX),
		@InitialTranCount		BIGINT,
		@Origin					VARCHAR(30),
		@EndDate				DATETIME2,
		@InsertedCount			BIGINT,
		@return_value			BIGINT,
		@ReStatement			BINARY = 0,
		@RowCount				BIGINT,
		@SQL					nvarchar(MAX);

	-- Legacy Core2Target
	DECLARE
		@TargetMaxRow				BIGINT,
		@AffectedRowsCount			BIGINT

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@EndDate			= CAST('9999-12-31' AS DATETIME2),
		@Message			= 'Invoking ' + @ProcedureName

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	-- Core Synchronisation Parameters
	SELECT @CoreStarPrefix = target.f_CoreStarPrefix (@DataFeed)

	-- Common Staging & Target Syncronisation Parameters
	SET @TableToSync = 'ScenarioHierarchy'			 							-- Ommit schemas
	INSERT INTO @TargetBusinessKeyColumns VALUES ('ScenarioHierarchyString')	-- Must be logically Unique from a business perspective
	INSERT INTO @TargetDimensionKeyColumns VALUES ('NOTHING_FOR DIMENSIONS')	-- How This table references other Dimensions. NULL for Dimensions
	SET @CoreSourceKeyColumn	= 'CoreSourceKey'
	-- Remainder are computed
	SET @StagingTable		= @TableToSync
	SET @TargetTable		= @StagingTable
	SET @TargetKeyColumn	= @TableToSync + 'Key'
	SET @CoreTable			= @CoreStarPrefix + @TableToSync
	SET @CoreSourceTable	= @CoreStarPrefix + 'Source'
	SET @CoreKeyColumn		= 'Core' + @TableToSync + 'Key'
--	breaks CORE2STAGING INSERT INTO @CoreIgnoreColumns VALUES (@CoreSourceKeyColumn)
	INSERT INTO @CoreBusinessKeyColumns SELECT id from @TargetBusinessKeyColumns
	INSERT INTO @TargetIgnoreColumns VALUES (@CoreSourceKeyColumn)

	-- CORE TO STAGING - Merge new data with existing in TARGET from other sources

	EXEC	@return_value				= [core].[p_Core2Staging]
			@Datafeed					= @Datafeed,
			@Environment				= @Env,
			@CoreTable					= @CoreTable,
			@CoreSourceTable			= @CoreSourceTable,
			@CoreKeyColumn				= @CoreKeyColumn,
			@CoreSourceKeyColumn		= @CoreSourceKeyColumn,
			@CoreBusinessKeyColumns		= @CoreBusinessKeyColumns,
			@CoreIgnoreColumns			= @CoreIgnoreColumns,
			@StagingTable				= @StagingTable,
			@TargetTable				= @TargetTable,
			@TargetKeyColumn			= @TargetKeyColumn,
			@TargetBusinessKeyColumns	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumns		= @TargetIgnoreColumns,
			@TargetRefDateTime			= @NowDate,
			@ExcludeDeprecatedFlag		= @ExcludeDeprecatedFlag

	SET @Message = CAST(@return_value AS VARCHAR(10)) + ' rows inserted into ' + @StagingTable + ' from ' + @TargetTable + ' and ' + @CoreTable
	EXEC [core].p_LogInfo @ProcedureName, @Message

	-- FOR FACTS....
	-- Complete all the Target Source References in Staging (for the data that just came from Core),
	-- ready to be merged into Target
	-- TIP - Needed for all Core BusinessKeys (see parameter definition above)


	--#------------------------------------------------ 'Update Staging Table' ----------------------------------------------#--
	--#---------------------------- 'This is the Golden Source and so we have the definitive hierarchy' ---------------------#--

	update
		H
	set
		H.[NameLevel1]	= ParsedData.lvl1,
		H.[NameLevel2]	= ParsedData.lvl2,
		H.[NameLevel3]	= ParsedData.lvl3,
		H.[NameLevel4]	= ParsedData.lvl4,
		H.[NameLevel5]	= ParsedData.lvl5,
		H.[NameLevel6]	= ParsedData.lvl6,
		H.[NameLevel7]	= ParsedData.lvl7,
		H.[NameLevel8]	= ParsedData.lvl8,
		H.[NameLevel9]	= ParsedData.lvl9
	FROM
		[staging].ScenarioHierarchy H
		cross apply ( select str = H.ScenarioHierarchyString + '``````````') f1
		cross apply ( select p1 = charindex('`', str ) ) ap1
		cross apply ( select p2 = charindex('`', str, p1 + 1 ) ) ap2
		cross apply ( select p3 = charindex('`', str, p2 + 1 ) ) ap3
		cross apply ( select p4 = charindex('`', str, p3 + 1 ) ) ap4
		cross apply ( select p5 = charindex('`', str, p4 + 1 ) ) ap5
		cross apply ( select p6 = charindex('`', str, p5 + 1 ) ) ap6
		cross apply ( select p7 = charindex('`', str, p6 + 1 ) ) ap7
		cross apply ( select p8 = charindex('`', str, p7 + 1 ) ) ap8
		cross apply ( select p9 = charindex('`', str, p8 + 1 ) ) ap9
		cross apply ( select p10 = charindex('`', str, p9 + 1 ) ) ap10
		cross apply ( SELECT
				  lvl1 = substring( str, p1+1, p2-p1-1 )
				, lvl2 = substring( str, p2+1, p3-p2-1 )
				, lvl3 = substring( str, p3+1, p4-p3-1 )
				, lvl4 = substring( str, p4+1, p5-p4-1 )
				, lvl5 = substring( str, p5+1, p6-p5-1 )
				, lvl6 = substring( str, p6+1, p7-p6-1 )
				, lvl7 = substring( str, p7+1, p8-p7-1 )
				, lvl8 = substring( str, p8+1, p9-p8-1 )
				, lvl9 = substring( str, p9+1, p10-p9-1 )
			  ) ParsedData

	-- STAGING TO TARGET - Update the bitemporal TARGET with the new consolidated view provided in STAGING

	EXEC	@return_value					= [core].[p_Staging2Target]
			@StagingTable					= @StagingTable,
			@StagingKeyColumn				= @CoreKeyColumn,
			@StagingBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@StagingIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@StagingRefDateTime				= @NowDate,
			@TargetTable					= @TargetTable,
			@TargetKeyColumn				= @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@TargetRefDateTime				= @NowDate,
			@ExpireDimensionData			= @ExcludeDeprecatedFlag,
			@ReStatement					= 0

	SET @Message = CAST(@return_value AS VARCHAR(10)) + ' rows inserted into ' + @TargetTable + ' from Staging'
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#--------------------------------------------------- 'Apply Rules' ------------------------------------------------#--

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END
GO