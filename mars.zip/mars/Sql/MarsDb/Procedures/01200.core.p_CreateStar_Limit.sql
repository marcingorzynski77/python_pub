IF OBJECT_ID ('core.p_CreateStar_Limit') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_Limit
GO

CREATE PROCEDURE [core].[p_CreateStar_Limit]
(
	@AsOfDate		DATETIME,
	@BusDate		DATETIME,
	@DataFeed		VARCHAR(64),
	@Env			VARCHAR(6),
    @HierarchyTag   INT = 0
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@MaxRow				BIGINT,
		@UTCDate			DATETIME2,
		@AllLoaded			TINYINT

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @LimitSourceId as int
	SET @LimitSourceId = 1

	-- clear core tables
	truncate table [core].[Limit_Source];
	truncate table [core].[Limit_Hierarchy];
	truncate table [core].[Limit_HierarchyBook];
	truncate table [core].[limit_RiskMeasureType];
	truncate table [core].[Limit_Fact];

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'Limit_Fact'
	if(@HierarchyTag = 0)
	begin
	--Source Limit_source
	INSERT INTO [core].Limit_Source  (
			 CoreSourceKey
			,[InterfaceName]
			,Environment
			,[Origin]
			,[Source]
		) Values (
			 @LimitSourceId
			,'Limit'
			,@Env
			,'Limit'
			,'Limit'
		)
	end
	else
	begin
	--Source Limit_source
	INSERT INTO [core].Limit_Source  (
			 CoreSourceKey
			,[InterfaceName]
			,Environment
			,[Origin]
			,[Source]
		) Values (
			 @LimitSourceId
			,'LimitT'
			,@Env
			,'Limit'
			,'Limit'
		)
	end
	
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Limit_Source dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--
	
	INSERT INTO [core].[Limit_Hierarchy] (
		 [HierarchyString]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookSystem]
        ,[HierarchyTag]
	)
	SELECT DISTINCT
		 A.HierarchyPath
		,1
		,RiskNodeName
		,RiskNodeType
		,BookSystem
        ,@HierarchyTag
	FROM
		[raw].[Limit] A
	
	
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[Limit_Hierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message 
	
	INSERT INTO [core].Limit_HierarchyBook (
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookSystem]
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		,BookSystem
	FROM
	[core].Limit_Hierarchy H where NodeType = 'BO' 
	
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[Limit_Hierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	--#----------------------------------- Populate the RiskMeasureType Dimension ----------------------------------------#--

	INSERT INTO [core].[Limit_RiskMeasureType] (
		 [RiskMeasureTypeName]
		,[RiskMeasureFamily]
		,[CoreSourceKey])
	SELECT DISTINCT
		 A.RiskMeasureTypeName
		,A.RiskMeasureTypeGroup
		,@LimitSourceId
	FROM
		[raw].[Limit] A

	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[Limit_RiskMeasureType] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	--#---------------------------------------- Populate the LIMIT Fact table --------------------------------------------#--

	INSERT INTO [core].[Limit_Fact] (
		    [CoreHierarchyKey],
		    [CoreRiskMeasureTypeKey],
		    [CoreSourceKey],
		    [Name],
		    [LimitId],
		    [CategoryName],
		    [CategoryPriority],
		    [Value],
		    [IsOverride],
		    [LimitStartDate],
		    [LimitEndDate],
		    [LimitOwner],
		    [RiskApprover],
		    [LimitApprover],
		    [ApprovedFlag])
	SELECT H.CoreHierarchyKey,
		   M.CoreRiskMeasureTypeKey,
		   @LimitSourceId as CoreSourceKey,
		   L.LimitName,
		   L.LimitId,
		   L.LimitCategory,
		   L.LimitCategoryPriority,
		   L.LimitValue,
		   L.IsOverride,
		   L.LimitStartDate,
		   L.LimitEndDate,
		   L.LimitOwner,
		   L.RiskApprover,
		   L.LimitApprover,
		   L.ApprovedFlag
	  FROM [raw].[Limit] L
      LEFT JOIN	[core].[Limit_Hierarchy] H
		ON L.HierarchyPath = H.HierarchyString
      LEFT JOIN	[core].[Limit_RiskMeasureType] M
		ON L.RiskMeasureTypeName = M.RiskMeasureTypeName

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[Limit_Fact] fact'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	EXEC [core].p_LogInfo @ProcedureName,  'Success. End of processing.'  

END TRY

--#---------------------------------------------- END OF STAR CODE -----------------------------------------------#--
--#===============================================================================================================#--

BEGIN CATCH
    
	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
		
END CATCH;

RETURN 0;

END



GO