IF OBJECT_ID ('core.p_UpdateFact_MarketData') IS NOT NULL
	DROP PROCEDURE [core].[p_UpdateFact_MarketData]
GO

CREATE PROC [core].[p_UpdateFact_MarketData]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName  			NVARCHAR(128),
		@Message 	    			NVARCHAR(MAX),
		@return_value				BIGINT,
		@rowcount					INT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
	DECLARE
		@BusinessKeyColumns		core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns			core.Core2TargetParameter

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName;

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'

	PRINT 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter

	INSERT INTO @CoreIndexColumns VALUES ('BusDate'), ('CoreRiskFactorTypeKey'), ('CoreRiskFactorKey')

	EXEC core.p_CreateIndex
		@IndexName 		= 'IX_MarketData_Fact_BusinessKeys',
		@SchemaName		= 'core',
		@TableName		= 'SimraMarketData_Fact',
		@TableOfColumns	= @CoreIndexColumns

	SELECT DISTINCT @LoadInterface = S.InterfaceName
	FROM [core].[SimraMarketData_Fact] F
	join [core].[SimraMarketData_Source] S on F.CoreSourceKey = S.CoreSourceKey

	BEGIN TRANSACTION

	print 'Clear out any temp tables'
	---------------------------------------------------------------------------------------------------
	IF OBJECT_ID ('tempdb..#C2T_Source') IS NOT NULL DROP TABLE #C2T_Source;
	IF OBJECT_ID ('tempdb..#C2T_RiskFactorType') IS NOT NULL DROP TABLE #C2T_RiskFactorType;
	IF OBJECT_ID ('tempdb..#C2T_RiskFactor') IS NOT NULL DROP TABLE #C2T_RiskFactor;
	IF OBJECT_ID ('tempdb..#C2T_Tenor') IS NOT NULL DROP TABLE #C2T_Tenor;
	IF OBJECT_ID ('tempdb..#C2T_Fact_Updates') IS NOT NULL DROP TABLE #C2T_Fact_Updates;


	-- Do the Data Mapping in the core table
	exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = '[core].[SimraMarketData_Fact]', @FactOrDimTable = 'MarketData', @SessionID = @SessionID

	print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);

	INSERT #C2T_Source (CoreDimKey, TargetDimKey)
		SELECT DISTINCT C.CoreSourceKey, T.SourceKey
		FROM [CORE].[SimraMarketData_Source] C JOIN [TARGET].[Source] T ON
			C.InterfaceName = T.InterfaceName
			AND C.Environment = T.Environment
			AND C.[Source] = T.[Source]
			AND C.Origin = T.Origin
			AND T.Start <= @NowDate
			AND T.Finish > @NowDate

	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_RiskFactorType (CoreDimKey BIGINT NULL, RiskFactorTypeName VARCHAR(255), TargetDimKey BIGINT NULL);

	INSERT #C2T_RiskFactorType (CoreDimKey, RiskFactorTypeName, TargetDimKey)
		SELECT DISTINCT C.CoreRiskFactorTypeKey, C.RiskFactorTypeName, T.RiskFactorTypeKey
		FROM [CORE].[SimraMarketData_RiskFactorType] C JOIN [TARGET].[RiskFactorType] T ON
			C.RiskFactorTypeName = T.RiskFactorTypeName
			AND T.Start <= @NowDate
			AND T.Finish > @NowDate

	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_RiskFactor (CoreDimKey BIGINT NULL, RiskFactorName VARCHAR(255), TargetDimKey BIGINT NULL);

	INSERT #C2T_RiskFactor (CoreDimKey, RiskFactorName, TargetDimKey)
		SELECT DISTINCT C.CoreRiskFactorKey, C.RiskFactorName, T.RiskFactorKey
		FROM [CORE].[SimraMarketData_RiskFactor] C JOIN [TARGET].[RiskFactor] T ON
			C.RiskFactorName = T.RiskFactorName
			AND T.Start <= @NowDate
			AND T.Finish > @NowDate

	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_Tenor (CoreDimKey BIGINT NULL, TenorName VARCHAR(255), TargetDimKey BIGINT NULL);

	INSERT #C2T_Tenor (CoreDimKey, TenorName, TargetDimKey)
		SELECT DISTINCT C.CoreTenorKey, C.TenorName, T.TenorKey
		FROM [CORE].[SimraMarketData_Tenor] C JOIN [TARGET].[Tenor] T ON
			C.TenorName = T.TenorName
			AND T.Start <= @NowDate
			AND T.Finish > @NowDate

	-------------------------------------------------------------------------------------------------
	SET @Message = 'Perform the actual Merge.'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_Fact_Updates (CoreMarketDataKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);

	INSERT #C2T_Fact_Updates (CoreMarketDataKey, FactKey, IsAttributeMatch)
	SELECT
		[C].CoreMarketDataKey,
		[TARGET].FactKey,
		CASE
			WHEN 1 = 1
				AND COALESCE([C].[Index], '') = COALESCE([TARGET].[Index],'')
				AND COALESCE([C].Curve, '') = COALESCE([TARGET].Curve, '')
				AND COALESCE([C].Currency1, '') = COALESCE([TARGET].Currency1, '')
				AND COALESCE([C].Currency2, '') = COALESCE([TARGET].Currency2, '')
				AND COALESCE([C].[Value], 0) = COALESCE([TARGET].[Value], 0)
			THEN 1
			ELSE 0
		END AS IsAttributeMatch
	FROM [CORE].[SimraMarketData_Fact] [C]
	JOIN #C2T_Source			ON #C2T_Source.[CoreDimKey] = [C].[CoreSourceKey]
	JOIN #C2T_RiskFactorType	ON #C2T_RiskFactorType.[CoreDimKey] = [C].[CoreRiskFactorTypeKey]
	JOIN #C2T_RiskFactor		ON #C2T_RiskFactor.[CoreDimKey] = [C].[CoreRiskFactorKey]
	JOIN #C2T_Tenor IT			ON IT.[CoreDimKey] = [C].[CoreInstrumentTenorKey]
	JOIN #C2T_Tenor UT			ON UT.[CoreDimKey] = [C].[CoreUnderlyingTenorKey]
	JOIN #C2T_Tenor FT			ON FT.[CoreDimKey] = [C].[CoreFixingTenorKey]
	FULL OUTER JOIN (
			SELECT
				F.*,
				RFT.RiskFactorTypeName,
				RF.RiskFactorName,
				IT.TenorName AS InstrumentTenorName,
				UT.TenorName AS UnderlyingTenorName,
				FT.TenorName AS FixingTenorName
			FROM [TARGET].[MarketData_Fact] F 
			JOIN #C2T_Source S					ON F.SourceKey = S.TargetDimKey
			JOIN [TARGET].[RiskFactorType] RFT	ON F.RiskFactorTypeKey = RFT.RiskFactorTypeKey
			JOIN [TARGET].[RiskFactor] RF		ON F.RiskFactorKey = RF.RiskFactorKey
			JOIN [TARGET].[Tenor] IT			ON F.InstrumentTenorKey = IT.TenorKey
			JOIN [TARGET].[Tenor] UT			ON F.UnderlyingTenorKey = UT.TenorKey
			JOIN [TARGET].[Tenor] FT			ON F.FixingTenorKey = FT.TenorKey
			WHERE 1 = 1
				AND F.BusDate in (select distinct BusDate from [CORE].[SimraMarketData_Fact])
				AND F.Finish > @NowDate
		) [TARGET]
		ON 1 = 1
			AND [TARGET].[BusDate]				= [C].[BusDate]
			AND ISNULL([TARGET].[Index], '')	= ISNULL([C].[Index], '')
			AND ISNULL([TARGET].Curve, '')		= ISNULL([C].Curve, '')
			AND ISNULL([TARGET].Currency1, '')	= ISNULL([C].Currency1, '')
			AND ISNULL([TARGET].Currency2, '')	= ISNULL([C].Currency2, '')
			AND [TARGET].[RiskFactorTypeKey]	= #C2T_RiskFactorType.[TargetDimKey]
			AND [TARGET].[RiskFactorKey]		= #C2T_RiskFactor.[TargetDimKey]
			AND [TARGET].[InstrumentTenorKey]	= IT.[TargetDimKey]
			AND [TARGET].[UnderlyingTenorKey]	= UT.[TargetDimKey]
			AND [TARGET].[FixingTenorKey]		= FT.[TargetDimKey]


--    Print 'Adding the index'
--    -------------------------------------------------------------------------------------------------
--    CREATE CLUSTERED INDEX IX_C2T_Fact_Updates_FactKey ON #C2T_Fact_Updates(FactKey,CoreMarketDataKey)


    SET @Message = 'Expire previous and replaced records'
	EXEC [core].p_LogInfo @ProcedureName, @Message
    -------------------------------------------------------------------------------------------------
    UPDATE
    	[TARGET].[MarketData_Fact]
   	SET
		[Finish] = @NowDate
    FROM [TARGET].[MarketData_Fact] AS FACT
	JOIN #C2T_Fact_Updates C2T	on FACT.FactKey = C2T.FactKey
	JOIN [TARGET].[Source] S	on S.SourceKey = FACT.SourceKey
	WHERE 1 = 1
		AND FACT.BusDate IN (SELECT DISTINCT BusDate FROM [CORE].[SimraMarketData_Fact])
		AND (  (C2T.CoreMarketDataKey IS NULL AND C2T.FactKey IS NOT NULL)
			OR (C2T.CoreMarketDataKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0))
		AND S.InterfaceName = @LoadInterface


	SET @Message = 'Expire and replace records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows.'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	SET @Message = 'Adding new and updated records'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	-------------------------------------------------------------------------------------------------
	INSERT [TARGET].[MarketData_Fact]
	(
		  Busdate
		, Start
		, Finish
		, SourceKey
		, RiskFactorTypeKey
		, RiskFactorKey
		, InstrumentTenorKey
		, UnderlyingTenorKey
		, FixingTenorKey
		, [Index]
		, Curve
		, Currency1
		, Currency2
		, Value
	)
	SELECT
		  [CORE].[BUSDATE]
		, @NowDate
		, @finish
		, #C2T_Source.[TargetDimKey] [SourceKey]
		, #C2T_RiskFactorType.[TargetDimKey] [RiskFactorTypeKey]
		, #C2T_RiskFactor.[TargetDimKey] [RiskFactorKey]
		, IT.[TargetDimKey] [InstrumentTenorKey]
		, UT.[TargetDimKey] [UnderlyingTenorKey]
		, FT.[TargetDimKey] [FixingTenorKey]
		, [Core].[Index]
		, [Core].[Curve]
		, [Core].[Currency1]
		, [Core].[Currency2]
		, [Core].[Value]
	FROM [CORE].[SimraMarketData_Fact] [Core]
	JOIN [CORE].[SimraMarketData_Source] CS ON Core.[CoreSourceKey] = CS.[CoreSourceKey]
	JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [Core].[CoreSourceKey]
	JOIN #C2T_RiskFactorType ON #C2T_RiskFactorType.[CoreDimKey] = [Core].[CoreRiskFactorTypeKey]
	JOIN #C2T_RiskFactor ON #C2T_RiskFactor.[CoreDimKey] = [Core].[CoreRiskFactorKey]
	JOIN #C2T_Tenor IT ON IT.[CoreDimKey] = [Core].[CoreInstrumentTenorKey]
	JOIN #C2T_Tenor UT ON UT.[CoreDimKey] = [Core].[CoreUnderlyingTenorKey]
	JOIN #C2T_Tenor FT ON FT.[CoreDimKey] = [Core].[CoreFixingTenorKey]
	JOIN #C2T_Fact_Updates C2T ON [Core].CoreMarketDataKey = C2T.CoreMarketDataKey
	WHERE 
		(C2T.CoreMarketDataKey IS NOT NULL AND C2T.FactKey IS NULL)
		OR
		(C2T.CoreMarketDataKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)

	SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	SET @Message = 'Success. End of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	COMMIT TRAN

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();
		
		
	IF @@TRANCOUNT > 0
	BEGIN
		-- The transaction uncommittable transaction.
		ROLLBACK TRANSACTION; --@MyTranID;

		SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName
		EXEC [core].p_LogInfo @ProcedureName, @Message
		
	END		

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END

GO