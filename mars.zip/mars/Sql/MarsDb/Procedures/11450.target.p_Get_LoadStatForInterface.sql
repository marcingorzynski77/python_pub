IF OBJECT_ID ('[target].[p_Get_LoadStatForInterface]') IS NOT NULL
	DROP PROCEDURE [target].[p_Get_LoadStatForInterface]
GO
-- EXEC [target].[p_Get_LoadStatForInterface] '2017-05-18', 'SimraFORiskMeasures', 20
CREATE PROCEDURE [target].[p_Get_LoadStatForInterface]
(
	@BusDate AS DATETIME2,
    @InterfaceName AS VARCHAR(100),
	@WindowLength AS INT = 20
)
AS
BEGIN
    
	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX)

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName
		
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

    SET NOCOUNT ON;

    EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'
    SET @Message = 'Params: @BusDate = ' + CAST(@BusDate AS VARCHAR(10))
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'Params: @WindowLength = ' + CAST(@WindowLength AS VARCHAR(10))
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'Params: @InterfaceName = ' + @InterfaceName 
    EXEC [core].[p_LogDebug] @ProcedureName, @Message

    CREATE TABLE #LoadStats
    (   
        BusDate DATETIME2, 
        SourceKey BIGINT,
        [DateRowCount] INT, 
        [AverageRowCount] FLOAT, 
        [StandardDevation] FLOAT, 
        [StandardDevationDiff] FLOAT,
        [InterfaceName] VARCHAR(100), 
        [Origin] VARCHAR(50), 
        [Source] VARCHAR(50) 
    )
   
    INSERT #LoadStats (BusDate, SourceKey, [DateRowCount], AverageRowCount, StandardDevation, StandardDevationDiff, [InterfaceName], [Origin], [Source])
     EXEC [target].[p_Get_LoadStats] @BusDate, @WindowLength, 1

    IF NOT EXISTS (SELECT 1 FROM #LoadStats WHERE InterfaceName = @InterfaceName)
    BEGIN
        SET @Message = 'No stats data found for interface: ''' + @InterfaceName + ''' and BusDate: ''' + CAST(@BusDate AS VARCHAR(10)) + ''''
        RAISERROR (@Message, 10, 1);
    END

    DECLARE @Threshold AS FLOAT 
    SELECT @Threshold = CAST(FFI.Value AS FLOAT) 
      FROM [target].[FlexFact] FF
     INNER JOIN [target].[Source] S ON FF.SourceKey = S.SourceKey
     INNER JOIN [target].FlexFactHierarchy FFH ON FF.FlexFactHierarchyKey = FFH.FlexFactHierarchyKey
     INNER JOIN [target].FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
     WHERE FFH.Description = 'FeedLoadCheck.Threshold.Data' 
       AND S.InterfaceName = @InterfaceName
       AND FFI.[Key] = 'ThresholdValue' 
       AND FF.Start < GETUTCDATE()
       AND FF.Finish > GETUTCDATE()
       AND S.Start < GETUTCDATE()
       AND S.Finish > GETUTCDATE()

    IF @Threshold IS NULL
    BEGIN
        SET @Message = 'There is no threshold for ''' + @InterfaceName + ''''
        EXEC [core].[p_LogWarning] @ProcedureName, @Message

        SELECT BusDate, 
               [DateRowCount] AS [RowCount], 
               AverageRowCount, 
               0 AS Threshold,
               0 AS OverThreshold
          FROM #LoadStats
         WHERE InterfaceName = @InterfaceName
    END
    ELSE

        SELECT BusDate, 
               [DateRowCount] AS [RowCount], 
               AverageRowCount, 
               @Threshold AS Threshold,
               CASE WHEN StandardDevationDiff > @Threshold THEN 1 ELSE 0 END AS OverThreshold
          FROM #LoadStats
         WHERE InterfaceName = @InterfaceName

    EXEC [core].[p_LogInfo] @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

RETURN 0;

END