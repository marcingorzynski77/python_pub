IF OBJECT_ID ('target.p_Get_LimitActiveDates') IS NOT NULL
	DROP PROCEDURE target.p_Get_LimitActiveDates
GO


CREATE PROC [target].[p_Get_LimitActiveDates] 

AS 

BEGIN

----#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
----#====================================================================================================================#--

	Set nocount on;

	--Create the slice of limits data that we're interested in
	WITH r1 (factkey, approvedflag, isoverride, limitid, app_rank) 
	   AS (SELECT factkey, 
				  approvedflag, 
				  isoverride, 
				  limitid, 
				  Rank() 
					OVER ( 
					  partition BY limitid, approvedflag, approvedflag 
					  ORDER BY isoverride, approvedflag) Ranking 
		   FROM   target.limit_fact 
				  INNER JOIN target.vtimetravel t 
						  ON start <= t.versiondatetime 
							 AND finish > t.versiondatetime 
							 AND limitstartdate <= t.versiondatetime 
							 AND limitenddate > t.versiondatetime 
		   GROUP  BY factkey, 
					 approvedflag, 
					 isoverride, 
					 limitid), 
	   c1(limitid, approvedflag, app_count) 
	   AS (SELECT limitid, 
				  approvedflag, 
				  Count(approvedflag) 
		   FROM   target.limit_fact 
				  INNER JOIN target.vtimetravel tt 
						  ON start <= tt.versiondatetime 
							 AND finish > tt.versiondatetime 
							 AND limitstartdate <= tt.versiondatetime 
							 AND limitenddate > tt.versiondatetime 
		   GROUP  BY limitid, 
					 approvedflag) 
	SELECT ISNULL(F.limitstartdate,' ') AS limitstartdate,
		 ISNULL(F.limitenddate,' ') AS limitenddate         		 
	FROM   target.limit_fact F 
		 INNER JOIN target.vHierarchyConsolidated H 
				 ON F.hierarchykey = H.hierarchykey 
		 INNER JOIN target.riskmeasuretype RMT 
				 ON F.riskmeasuretypekey = RMT.riskmeasuretypekey 
		 INNER JOIN target.vtimetravel T 
				 ON F.start <= T.versiondatetime 
					AND F.finish > T.versiondatetime 
					--AND F.limitstartdate <= T.limitdate 
					--AND F.limitenddate >= T.limitdate 
	WHERE  limitid IN (SELECT r1.factkey 
					 FROM   r1 
							INNER JOIN c1 
									ON r1.limitid = c1.limitid 
									   AND r1.approvedflag = c1.approvedflag 
									   AND r1.app_rank = c1.app_count) 


END

GO