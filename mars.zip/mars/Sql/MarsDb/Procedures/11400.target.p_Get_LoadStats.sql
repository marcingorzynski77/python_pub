IF OBJECT_ID ('[target].[p_Get_LoadStats]') IS NOT NULL
	DROP PROCEDURE [target].[p_Get_LoadStats]
GO

-- exec [target].[p_Get_LoadStats] '2017-05-18', 20, 10
CREATE PROCEDURE [target].[p_Get_LoadStats]
(
	@BusDate AS DATETIME2,
	@WindowLength AS INT, -- moving window size (e.g. 20 for 20-day moving average)
    @DaysInOuput AS INT -- number of days in the past to be returned (e.g. 1 means only @BusDate will be returned)
)
AS
BEGIN
    
	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX)

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName
		
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

    EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'
    SET @Message = 'Params: @BusDate = ' + CAST(@BusDate AS VARCHAR(10))
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'Params: @WindowLength = ' + CAST(@WindowLength AS VARCHAR(10))
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'Params: @DaysInOuput = ' + CAST(@DaysInOuput AS VARCHAR(10))
    EXEC [core].[p_LogDebug] @ProcedureName, @Message

    SET ANSI_WARNINGS ON

    -- this part needs to have ANSI_WARNINGS ON (on production server only[!] - env settings)
    DECLARE @VersionDateTime DATETIME2
    SET @VersionDateTime = (SELECT TOP 1 TargetDate
                              FROM [target].f_TargetDate() 
                             ORDER BY TargetDate);

	SET ANSI_WARNINGS OFF

    DECLARE @Dates TABLE 
    (
        BusDate DATETIME2,
        [Sequence] BIGINT 
    )

    INSERT INTO @Dates
    SELECT [Date] BusDate, [Sequence] 
    FROM ( 
          SELECT WorkingDays.[Date], ROW_NUMBER() OVER (ORDER BY [Date] DESC) [Sequence]
          FROM (
                SELECT [Date],
                      CASE WHEN DATEADD(day,1,C.[Date]) <> C.NextWorkingDate AND C.WorkingDay = 'Y' THEN 1 ELSE 0 END LastWeekDay 
                FROM target.Calendar C
                WHERE C.[DATE] > DATEADD(day,@WindowLength*-10,@BusDate)
                      AND C.[DATE] <= @BusDate
                      AND C.WorkingDay = 'Y'
                ) WorkingDays
          WHERE WorkingDays.LastWeekDay = 
                (SELECT CASE WHEN DATEADD(day,1,@BusDate) <> C.NextWorkingDate AND C.WorkingDay = 'Y' THEN 1 ELSE 0 END LastWeekDay
                FROM target.Calendar C
                WHERE C.Date = @BusDate)
          ) Candidates
    WHERE [Sequence] <= (@WindowLength + @DaysInOuput)

    --SELECT * FROM @Dates 

    DECLARE @CutOffDate DATETIME2
    SELECT @CutOffDate = BusDate 
      FROM @Dates
     WHERE [Sequence] = @DaysInOuput

    DECLARE @Summary TABLE 
    (
        BusDate DATETIME2
       ,SourceKey BIGINT
       ,[Count] INT
       ,Fact VARCHAR(50)
    )
    --Get past @WindowLength + @DaysInOuput days activity
    INSERT INTO @Summary
    SELECT BusDate, 
           SourceKey, 
           SUM(CAST([Raw.Count] AS INT)) AS [Count], 
           [Fact] 
      FROM (
             SELECT F.busdate, 
                   S.[SourceKey], 
                   I.[key], 
                   I.value, 
                   Replace(Replace(H.[description], 'FeedLoadCheck.', ''), '.Data', '') AS [Fact] 
              FROM [target].flexfactinstance I 
             INNER JOIN [target].FlexFact F 
                ON I.FlexFactKey = F.FlexFactKey 
             INNER JOIN [target].FlexFactHierarchy H 
                ON F.FlexFactHierarchyKey = H.FlexFactHierarchyKey 
             INNER JOIN @Dates AS TT 
                ON F.BusDate = TT.BusDate
              LEFT OUTER JOIN [target].[source] AS S
                ON F.[SourceKey] = S.[sourcekey] 
             WHERE H.[Description] LIKE ('FeedLoadCheck.%')
               AND I.[Key] = 'Raw.Count'
               AND F.Start <= @VersionDateTime
               AND F.Finish > @VersionDateTime
            ) x 
       PIVOT (Max([value]) FOR [key] IN ([Raw.Count])) p
       GROUP BY [BusDate], 
                [Fact], 
                SourceKey; 

    --SELECT * FROM @Summary

    DECLARE @MovingAverage TABLE 
    (
        RowNumber BIGINT
       ,[Rank] BIGINT
       ,BusDate DATETIME2
       ,SourceKey BIGINT
       ,DateRowCount INT
       ,MovingAverage FLOAT
    )

    ;WITH CTE (RowNumber, [Rank], BusDate, SourceKey, DateRowCount) AS 
    (
       SELECT ROW_NUMBER() OVER (ORDER BY BusDate, SourceKey DESC) AS RowNumber, 
         RANK() OVER (PARTITION BY SourceKey ORDER BY BusDate) AS [Rank], 
         BusDate, 
         SourceKey, 
         [Count] AS DateRowCount from @Summary
    )
    INSERT INTO @MovingAverage 
    SELECT RowNumber, 
            [Rank], 
            BusDate, 
            SourceKey, 
            DateRowCount,
            MovingAverage = (SELECT AVG(DateRowCount) 
                                FROM CTE AS INNER_REF 
                                WHERE INNER_REF.[Rank] BETWEEN OUTER_REF.[Rank]-@WindowLength AND OUTER_REF.[Rank] 
                                AND INNER_REF.SourceKey = OUTER_REF.SourceKey)
    FROM CTE AS OUTER_REF
    
    --SELECT * FROM  @MovingAverage

    ;WITH CTE2 (RowNumber, [Rank], BusDate, SourceKey, DateRowCount, MovingAverage) AS 
    (
       SELECT * FROM @MovingAverage 
    )
    SELECT T.BusDate, 
           T.SourceKey, 
           T.DateRowCount, 
           T.MovingAverage, 
           ISNULL(T.StandardDevation,1) As StandardDevation, 
           ABS(T.DateRowCount - T.MovingAverage)/(CASE WHEN ISNULL(T.StandardDevation,1) = 0 THEN 1 ELSE ISNULL(T.StandardDevation, 1) END ) AS StandardDevationDiff,
           S.InterfaceName,
           S.Origin,
           S.Source 
    FROM (
            SELECT RowNumber,
                   [Rank],  
                   BusDate, 
                   SourceKey, 
                   DateRowCount, 
                   MovingAverage,
                   StandardDevation = (SELECT STDEVP(DateRowCount) FROM CTE2 AS INNER_REF 
                                        WHERE INNER_REF.[Rank] BETWEEN OUTER_REF.[Rank] -@WindowLength AND OUTER_REF.[Rank] 
                                            AND INNER_REF.SourceKey = OUTER_REF.SourceKey)
              FROM CTE2 AS OUTER_REF 
             WHERE BusDate >= @CutOffDate
        ) AS T
    INNER JOIN target.Source AS S ON T.SourceKey = S.SourceKey
     

    EXEC [core].[p_LogInfo] @ProcedureName, 'Success. End of processing.'

    END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

	SET ANSI_WARNINGS ON

RETURN 0;

END

GO