IF OBJECT_ID ('target.p_IU_QueryCatalogue') IS NOT NULL
	DROP PROCEDURE target.p_IU_QueryCatalogue
GO

CREATE PROC [target].[p_IU_QueryCatalogue] 
(
	@Name varchar(100),		
	@Alias varchar(100),		
	@Query varchar(MAX),
	@QueryComment varchar(1000),
	@QuestionAsked varchar(MAX) = '',
	@LegoXML varchar(MAX) = '',
	@HierarchyNode int = 0,
	@DesignedBy varchar(20) = '',
	@Owner varchar(50) = '',
	@Event varchar(10) = 'NEW',
	@VersionID int = 0,
	@NewHierarchyNode int = 0
)
AS 

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE
		@return_status		int,
        @ProcedureName      NVARCHAR(128),
        @Message 	        NVARCHAR(MAX),
        @BusinessLogicSev	INT,
        @SessionID  		BIGINT ,
        @VersionPath		varchar(100);
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
        @Message            = 'Invoking ' + @ProcedureName;

	exec [core].p_LogInfo @ProcedureName, @Message
	set @SessionID = @@IDENTITY	
  
--#---------------------------------------- END OF STANDARD TRANSACTION HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY	

set nocount on

	if @Event= 'NEW'
	begin
		if (select COUNT(1) from core.QueryCatalogue
		where Name  = @Name
		and HierarchyNode = @HierarchyNode
		and Query = @query) = 0
		begin		 
		
			--Deduce hierarchynode
			if @HierarchyNode = 0
			begin
				set @HierarchyNode = (select nodeid from core.QueryCatalogue_Hierarchy where NodeName = 'My Scripts' and [Owner] = @Owner)
			end;
						
			--Recursive loop to determine all parent nodes
			WITH NodesCTE AS
			( 
				--anchor select
				select  NodeName, NodeID, ParentNodeID 
				from core.QueryCatalogue_Hierarchy
				where NodeID = @HierarchyNode		
				UNION ALL
				--recursive select, recursive until you reach a leaf (a node which is not a parent of any other node)
				select  a.NodeName, a.NodeID, a.ParentNodeID 
				from core.QueryCatalogue_Hierarchy a
				INNER JOIN NodesCTE s ON a.NodeID = s.ParentNodeID 
			) 
			
			--Add row number and order in reverse 
			select ROW_NUMBER() OVER (ORDER BY (SELECT 100)) AS SNO ,* into #Data from NodesCTE order by SNO desc;
			
			--Concatenate
			select @VersionPath = (Select N.nodename + '/'  
									From #Data N			
									For XML PATH (''))	
				
			drop table #data

			--Deduce version number			
			set @VersionID = (select isnull(MAX(versionID),0) from core.QueryCatalogue where Name = @Name and HierarchyNode = @HierarchyNode) + 1

			--Handle bi-temporal
			if @VersionID > 1
			begin
				update [core].querycatalogue 
				set Finish = GETDATE()
				where Name = @Name
				and HierarchyNode = @HierarchyNode
				and Finish > GETDATE()	
			end

			--insert into catalogue
			insert into [core].querycatalogue
				(Start
				,Finish
				,HierarchyNode
				,Name
				,Alias
				,[VersionID]
				,[Query]
				,Comment
				,DesignedBy
				,QuestionAsked
				,LegoXML
				,Active
				,UserName
				,VersionPath)
			select GETDATE()
					,'99991231' as 'Finish'
					,@HierarchyNode
					,@Name
					,@Alias
					,@VersionID
					,@Query
					,@QueryComment     
					,@DesignedBy				
					,@QuestionAsked
					,@LegoXML
					,1
					,@Owner
					,@VersionPath
			
            SET @Message = 'Query Catalogue: Inserted new query for alias ' + @Name
			exec [core].p_LogInfo @ProcedureName, @Message

			--Get versionID for querytable
			select 'Query saved as version ' + cast(versionID as varchar(5)) + ' : ' + cast(ID as varchar(6)) as 'Result' from core.QueryCatalogue where Name = @Name and Query = @query and HierarchyNode = @HierarchyNode
		end
		else
		begin
			--Get versionID for querytable
			select 'Nothing saved as the query is the same as version ' + cast(versionID as varchar(5)) + ' : ' + cast(ID as varchar(6)) as 'Result' from core.QueryCatalogue where Name = @Name and Query = @query and HierarchyNode = @HierarchyNode	
		end
	END
	
	if @Event= 'DELETE'
	begin
		if @VersionID > 0 
		begin
			DELETE FROM core.QueryCatalogue 
			where Name = @Name
				and HierarchyNode = @HierarchyNode				
				and VersionID = @VersionID
		end
		else
		begin
			DELETE FROM core.QueryCatalogue 
			where Name = @Name
				and HierarchyNode = @HierarchyNode								
		end
				
		select 'Success' as 'Result'
	END 
	
	if @Event= 'DISABLE'
	begin
		UPDATE core.QueryCatalogue 
		set Active = 0
		where Name = @Name
			and HierarchyNode = @HierarchyNode
		
		select 'Success' as 'Result'
	END 
	
	if @Event= 'MOVE'
	begin
	
			--Recursive loop to determine all parent nodes
			WITH NodesCTE AS
			( 
				--anchor select
				select  NodeName, NodeID, ParentNodeID 
				from core.QueryCatalogue_Hierarchy
				where NodeID = @HierarchyNode		
				UNION ALL
				--recursive select, recursive until you reach a leaf (a node which is not a parent of any other node)
				select  a.NodeName, a.NodeID, a.ParentNodeID 
				from core.QueryCatalogue_Hierarchy a
				INNER JOIN NodesCTE s ON a.NodeID = s.ParentNodeID 
			) 
			
			--Add row number and order in reverse 
			select ROW_NUMBER() OVER (ORDER BY (SELECT 100)) AS SNO ,* into #MoveData from NodesCTE order by SNO desc;
			
			--concatenate
			select @VersionPath = (Select N.nodename + '/'  
									From #MoveData N			
									For XML PATH (''))			
			
			drop table #MoveData
			
			--Finally make the update
			UPDATE core.QueryCatalogue 
				set HierarchyNode = @NewHierarchyNode,
					VersionPath = @VersionPath
			where Name = @Name
				and HierarchyNode = @HierarchyNode
		
		select 'Success' as 'Result'
	END 

	
	
	return

set nocount off

END TRY

--#---------------------------------------------------- END OF IUSP ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
