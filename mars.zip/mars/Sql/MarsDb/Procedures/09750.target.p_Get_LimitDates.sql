/****** Object:  StoredProcedure [target].[p_Get_LimitDates]    Script Date: 03/23/2017 14:38:22 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_LimitDates]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Get_LimitDates]
GO


CREATE PROC [target].[p_Get_LimitDates] 

AS 

BEGIN

----#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
----#====================================================================================================================#--

	Set nocount on;

	create table #dates
	(
		LimitStartDate datetime2(7),
		LimitEndDate datetime2(7)
	)
	
	insert into #dates
	exec target.[p_Get_LimitActiveDates]

	--Extract the distinct dates
	select distinct limitDate from
	(
		select distinct LimitStartDate as limitDate
		from #dates 
		Union 
		select distinct NextWorkingDate as limitDate
		from #dates L 
		join target.calendar C 
		on C.[date] = L.LimitEndDate
	)A 
	order by limitDate asc
	
	--Tidy
	drop table #dates

END
GO


