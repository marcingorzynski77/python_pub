IF OBJECT_ID ('core.p_Staging2Target') IS NOT NULL
	DROP PROCEDURE core.p_Staging2Target
GO

CREATE PROCEDURE [core].[p_Staging2Target]
(
	@StagingTable						nVARCHAR(50),
	@StagingKeyColumn					nVARCHAR(50),
	@StagingBusinessKeyColumnsPARAM		Core2TargetParameter READONLY,
	@StagingIgnoreColumnsPARAM			Core2TargetParameter READONLY,
	@StagingRefDateTime					DATETIME2(7),
	@TargetTable						nVARCHAR(50),
	@TargetKeyColumn					nVARCHAR(50),
	@TargetBusinessKeyColumnsPARAM		Core2TargetParameter READONLY,
	@TargetIgnoreColumnsPARAM			Core2TargetParameter READONLY,
	@TargetRefDateTime					DATETIME2(7),
	@ExpireDimensionData				INTEGER		= 0,
	@ReStatement						BINARY		= 0,
	@SessionID							INT		= 0
)
AS

BEGIN
    SET NOCOUNT ON;

    DECLARE
        @ProcedureName		NVARCHAR(128),
		@Message		    NVARCHAR(MAX),
        @BusinessLogicSev	INT;

    DECLARE @MyTran			BIT			= CASE WHEN @@trancount = 0 THEN 0 ELSE 1 END
    DECLARE @MyTranID		VARCHAR(32)	= REPLACE(CONVERT(CHAR(36), NEWID()), '-','')

    SELECT
		@SessionID 			= @@IDENTITY,    
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@Message 			= 'Invoking ';
		
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'

	DECLARE @DEBUG BINARY=1

	DECLARE @StagingBusinessKeyColumns Core2TargetParameter
	DECLARE @StagingIgnoreColumns Core2TargetParameter
	DECLARE @TargetBusinessKeyColumns Core2TargetParameter
	DECLARE @TargetIgnoreColumns Core2TargetParameter

	DECLARE @MatchSQL VARCHAR(MAX)='';
	DECLARE @nSQL nvarchar(MAX)='';
	DECLARE @nSQLTarget nvarchar(MAX)='';

	DECLARE @StagingBusinessKeyColumnList as nvarchar(200)
	DECLARE @TargetBusinessKeyColumnList as nvarchar(200)
	DECLARE @ChecksumStagingColumns VARCHAR(MAX)
	DECLARE @ChecksumTargetColumns VARCHAR(MAX)
	DECLARE @StagingColumns VARCHAR(MAX)
	DECLARE @TargetColumns VARCHAR(MAX)
	DECLARE @NakedTargetColumns VARCHAR(MAX)
	DECLARE @TargetColumns_EX_StartFinish VARCHAR(MAX)
	DECLARE @FactTable as int
	DECLARE @BusdateInFactTable as int
	DECLARE @CheckSumCode as varchar(MAX)
	DECLARE @InvCheckSumCode as varchar(MAX)
	DECLARE @OrigStagingTable as varchar(50)
	DECLARE @StagingIndexName as varchar(100)

	DECLARE @TargetRefDateStrNOTIME nVarchar(19)
	DECLARE @COUNTER integer

	DECLARE @EndDateTime as nVarchar(10); SET @EndDateTime = '9999-12-31'

	--If outside a transaction, begin one otherwise create a savepoint
	IF @MyTran = 0
	BEGIN
		BEGIN TRANSACTION @MyTranID
		SET @Message = 'New Transaction Started - ' + @MyTranID
		EXEC [core].[p_LogInfo] @ProcedureName, @Message
	END
	ELSE
	BEGIN
		SAVE TRANSACTION @MyTranID
		EXEC [core].[p_LogInfo] @ProcedureName, 'Transaction Already in Progress. Save Point Established.'
	END

	IF @DEBUG=1
	BEGIN
		SET @Message = 'Params: @StagingTable = ' + @StagingTable + ', @StagingKeyColumn = ' + @StagingKeyColumn 
		EXEC [core].[p_LogDebug] @ProcedureName, @Message
		SET @Message = 'Params: @StagingRefDateTime	=  ' + CONVERT(nVARCHAR(19),@StagingRefDateTime)
		EXEC [core].[p_LogDebug] @ProcedureName, @Message
		SET @Message = 'Params: @TargetTable = ' + @TargetTable + ', @TargetKeyColumn = ' + @TargetKeyColumn
		EXEC [core].[p_LogDebug] @ProcedureName, @Message
		SET @Message = 'Params: @TargetRefDateTime = ' + CONVERT(nVARCHAR(19),@TargetRefDateTime) + ', @ExpireDimensionData = ' + CONVERT(nVARCHAR(1),@ExpireDimensionData)
		EXEC [core].[p_LogDebug] @ProcedureName, @Message

		/* This should be parsed and send to the logger
		SELECT
			A.*
		FROM
			(
				SELECT '@StagingBusinessKeyColumns      = ' Parameter, ID FROM @StagingBusinessKeyColumnsPARAM
				UNION ALL
				SELECT '@@StagingIgnoreColumnsPARAM     = ' Parameter, ID FROM @StagingIgnoreColumnsPARAM
				UNION ALL
				SELECT '@@TargetBusinessKeyColumnsPARAM = ' Parameter, ID FROM @TargetBusinessKeyColumnsPARAM
				UNION ALL
				SELECT '@@TargetIgnoreColumnsPARAM      = ' Parameter, ID FROM @TargetIgnoreColumnsPARAM
			) A
		*/
	END

	-- Add system suffixs to table names
	SET @OrigStagingTable		= @StagingTable
	SET @StagingTable			= '[Staging].[' + @StagingTable + ']'
	SET @TargetTable			= '[Target].[' + @TargetTable + ']'

	INSERT @StagingBusinessKeyColumns SELECT * FROM @StagingBusinessKeyColumnsPARAM
	INSERT @StagingIgnoreColumns SELECT * FROM @StagingIgnoreColumnsPARAM
	INSERT @TargetBusinessKeyColumns SELECT * FROM @TargetBusinessKeyColumnsPARAM
	INSERT @TargetIgnoreColumns SELECT * FROM @TargetIgnoreColumnsPARAM

	-- Ensure that the core key does not factor in this sync
	INSERT @StagingIgnoreColumns SELECT @StagingKeyColumn
	INSERT @TargetIgnoreColumns SELECT @StagingKeyColumn

	SET @TargetRefDateStrNOTIME = CONVERT(nVarchar(19),@TargetRefDateTime,121)			-- Was 102, lose time component

	-- Build the Staging table Business Key column list
	SET @StagingBusinessKeyColumnList = Null

	SELECT
		@StagingBusinessKeyColumnList = COALESCE(@StagingBusinessKeyColumnList + ', ', '') + ID
	FROM
		@StagingBusinessKeyColumns
		
	SET @Message = 'Staging Business Key Columns = ' + @StagingBusinessKeyColumnList
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	-- Extend the comparison ignore Column List
	INSERT INTO @StagingIgnoreColumns VALUES ('Start'), ('Finish') --,('AppliedRules')

	SET @FactTable = 0
	IF UPPER(RIGHT(RTRIM(@TargetTable),5)) = '_FACT' SET @FactTable = 1

	--IF BUSDATEs are present (normally for FACT tables) ensure they are matched on both sides

	SET @BusdateInFactTable = 0
	IF @FactTable = 1 AND
		(SELECT count(name) FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable) AND name = 'BUSDATE')=1
		SET @BusdateInFactTable = 1

	IF @BusdateInFactTable = 1
	BEGIN
		INSERT @StagingBusinessKeyColumns VALUES ('BUSDATE')
		INSERT @TargetBusinessKeyColumns VALUES ('BUSDATE')
	END


	SET @MatchSQL = NULL;
	SELECT @MatchSQL = COALESCE(@MatchSQL + ' AND ', '')  + 'COALESCE (S.' + ID + ',"") = COALESCE(T.' + ID + ',"")'
		FROM @TargetBusinessKeyColumns
	--SET @MatchSQL = SUBSTRING(@MatchSQL,6,LEN(@MatchSQL)-5)
	SET @Message = 'Columns to be matched on = ' + @MatchSQL
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @StagingColumns = Null
	SELECT @StagingColumns = COALESCE(@StagingColumns + ', ', '')  + 'S.[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@StagingTable)
			and not name = @StagingKeyColumn
			and not name = @TargetKeyColumn
			and not name in (select * from @StagingIgnoreColumns)
			and not name in (select * from @TargetIgnoreColumns)
			order by name
	SET @Message = 'Staging Columns to be Read = ' + isnull(@StagingColumns, 'No Source Columns to read from')
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	PRINT @StagingKeyColumn
	PRINT @StagingColumns
	
	SET @TargetColumns = Null
	SELECT @TargetColumns = COALESCE(@TargetColumns + ', ', '')  + 'T.[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable)
			and not name = @TargetKeyColumn
			and not name in (select * from @StagingIgnoreColumns)
			and not name in (select * from @TargetIgnoreColumns)
			order by name
	SET @Message = 'Target Columns to be Populated = ' + isnull(@TargetColumns, 'No Target Columns to write to')
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @NakedTargetColumns = Null
	SELECT @NakedTargetColumns = COALESCE(@NakedTargetColumns + ', ', '')  + 'N.[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable)
			and not name = @TargetKeyColumn
			and not name in (select * from @StagingIgnoreColumns)
			and not name in (select * from @TargetIgnoreColumns)
			order by name
    SET @Message = 'Target Columns to be Populated = ' + isnull(@NakedTargetColumns, 'No Target Columns to write to')
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @TargetColumns_EX_StartFinish = Null
	SELECT @TargetColumns_EX_StartFinish = COALESCE(@TargetColumns_EX_StartFinish + ', ', '')  + '[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable)
			and not name = @TargetKeyColumn
			and not name in (select * from @StagingIgnoreColumns)
			and not name in (select * from @TargetIgnoreColumns)
			and not name in ('Start','Finish')
--			and not (name in ('SourceKey') )--and @OrigStagingTable = 'Source')
			and not name = @TargetKeyColumn -- The Key is auto generated in Target
			order by name
	SET @Message = 'Target Columns to be Populated minus Time Traveling= ' + isnull(@TargetColumns_EX_StartFinish, 'No Target Columns to write to')
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @ChecksumTargetColumns = Null
	SELECT @ChecksumTargetColumns = COALESCE(@ChecksumTargetColumns + ', ', '')  + NullAlias
	FROM
		(SELECT COL.name name, 
			CASE	WHEN CHARINDEX('char',TYPES.name,1) > 0		THEN 'COALESCE([T].['+ COL.name +'],"")' 
					WHEN CHARINDEX('decimal',TYPES.name,1) > 0	THEN 'COALESCE([T].['+ COL.name +'],0.0)' 
																ELSE 'COALESCE([T].['+ COL.name +'],"")' 
			END NullAlias
		FROM sys.columns as COL
		JOIN sys.types AS TYPES ON COL.system_type_id = TYPES.system_type_id 
		WHERE COL.object_id = OBJECT_ID(@TargetTable)) TT	
		
			WHERE not name = @TargetKeyColumn
			and not name in (select * from @TargetBusinessKeyColumns)
			and not name in (select * from @TargetIgnoreColumns)
			and not name in ('Start','Finish' ) --,'AppliedRules')
			order by name
	SET @Message = 'Target Columns to be CRC matched = ' + isnull(@ChecksumTargetColumns, 'No Attributes to Compare')
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message
	SET @ChecksumStagingColumns = replace (@ChecksumTargetColumns,'[T].[','[S].[')

	SET @CheckSumCode = ''
	if @ChecksumStagingColumns is not null and @ChecksumTargetColumns is not null
	BEGIN
		SET @CheckSumCode = @CheckSumCode + ' AND BINARY_CHECKSUM(' + @ChecksumStagingColumns + ') = '
		SET @CheckSumCode = @CheckSumCode + ' BINARY_CHECKSUM(' + @ChecksumTargetColumns + ')'

		SET @InvCheckSumCode = ' AND NOT ('
		SET @InvCheckSumCode = @InvCheckSumCode + ' BINARY_CHECKSUM(' + @ChecksumStagingColumns + ') = '
		SET @InvCheckSumCode = @InvCheckSumCode + ' BINARY_CHECKSUM(' + @ChecksumTargetColumns + '))'
	END
	ELSE
	BEGIN
		set @InvCheckSumCode = ' AND 99=99'		-- If we don't have CheckSum columns then never allow Expires?
	END

	-- THE MERGE LOGIC (Moves New & Revised data to Target)

	SET @nSQL = '';
	SET @nSQL = @nSQL + ' MERGE ' + @TargetTable + ' T '
	SET @nSQL = @nSQL + ' USING ' + @StagingTable + ' S '
	SET @nSQL = @nSQL + ' ON ( ' + @MatchSQL
	SET @nSQL = @nSQL + @CheckSumCode + ' AND '
	SET @nSQL = @nSQL + ' T.START <= "' + @TargetRefDateStrNOTIME + '" AND T.FINISH > "' + @TargetRefDateStrNOTIME + '" ) '
	SET @nSQL = @nSQL + ' WHEN NOT MATCHED THEN	'
	SET @nSQL = @nSQL + ' INSERT ( Start, Finish, ' + @TargetColumns_EX_StartFinish
	SET @nSQL = @nSQL + ' ) '
	SET @nSQL = @nSQL + ' VALUES ( '
	SET @nSQL = @nSQL + '  "' + @TargetRefDateStrNOTIME + '", "' + @EndDateTime + '", ' + @StagingColumns
	SET @nSQL = @nSQL + ' );'
	SET @nSQL = @nSQL + ' Select @COUNTER = @@rowcount;'

	set @nSQLTarget = '';
	SET @nSQLTarget = @nSQLTarget + replace (@nSQL,'"',char(39))
	SET @Message = 'INSERT SQL = ' + @nSQLTarget
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message
	EXEC sp_executesql @nSQLTarget, N'@COUNTER INT OUTPUT', @Counter OUTPUT

	SET @Message = 'Merged rows : ' + CONVERT(VARCHAR,@COUNTER)
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message

	-- THE EXPIRE LOGIC (Expires Superceeded data - by the insertion of new replacements above - in Target)

	SET @nSQL = '';
	SET @nSQL = @nSQL + ' UPDATE ' + @TargetTable + ' SET FINISH = "' + @TargetRefDateStrNOTIME + '" '
	SET @nSQL = @nSQL + ' WHERE ' + @TargetKeyColumn + ' IN ('
	SET @nSQL = @nSQL + ' SELECT T.' + @TargetKeyColumn
	SET @nSQL = @nSQL + ' FROM ' +  + @TargetTable + ' T '
	SET @nSQL = @nSQL + ' JOIN ' + @StagingTable + ' S '
	SET @nSQL = @nSQL + ' ON ( ' + @MatchSQL
	SET @nSQL = @nSQL + @InvCheckSumCode + ' AND '
	SET @nSQL = @nSQL + ' T.START <> "' + @TargetRefDateStrNOTIME + '" AND T.FINISH = "' + @EndDateTime + '" ));'
	SET @nSQL = @nSQL + ' Select @UpdateCount = @@ROWCOUNT;'

	set @nSQLTarget = '';
	SET @nSQLTarget = @nSQLTarget + replace (@nSQL,'"',char(39))
	
	DECLARE @UpdateCount INT;
	SET @Message = 'Expiry Update SQL = ' + @nSQLTarget
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message
	EXEC sp_executesql @nSQLTarget, N'@UpdateCount INT OUTPUT', @UpdateCount OUTPUT

	SET @Message = 'Expiry Updated rows : ' + CONVERT(VARCHAR,@UpdateCount)
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message
	
	-- THE REMOVE LOGIC (Expires data which is no longer in the latest version in staging)
	-- DIMENSTIONS are normally our universe (i.e. a sub-set of the public universe, e.g. the INSTRUMENTS DIMENSION)
	IF @ExpireDimensionData = 1
	BEGIN
		SET @nSQL = '';
		SET @nSQL = @nSQL + ' UPDATE ' + @TargetTable + ' SET FINISH = "' + @TargetRefDateStrNOTIME + '"'
		SET @nSQL = @nSQL + ' WHERE ' + @TargetKeyColumn + ' IN ( '
		SET @nSQL = @nSQL + ' SELECT T.' + @TargetKeyColumn + ' FROM ( '
		SET @nSQL = @nSQL + ' SELECT ' +  @NakedTargetColumns + ', ' + @TargetKeyColumn
		SET @nSQL = @nSQL + ' FROM ' + @TargetTable + ' N JOIN [Target].[SOURCE] TS ON N.[SourceKey] = TS.[SourceKey]'
		SET @nSQL = @nSQL + ' WHERE N.START < "' + @TargetRefDateStrNOTIME + '" AND N.FINISH = "' + @EndDateTime + '" '
							-- this line handles the fact that both hierarchy and hierarchyT feeds can expire this table. So only expire nodes that were originally inserted by the current feed. Table will oscillate otherwise.
		SET @nSQL = @nSQL + ' AND N.SOURCEKEY IN (SELECT DISTINCT SourceKey FROM ' + @StagingTable + ' WHERE SourceKey IS NOT NULL AND CoreSourceKey IS NOT NULL)'
		SET @nSQL = @nSQL + ' ) T'
		SET @nSQL = @nSQL + ' LEFT OUTER JOIN ' + @StagingTable + ' S '
		SET @nSQL = @nSQL + ' ON ( ' + @MatchSQL
		SET @nSQL = @nSQL + @CheckSumCode + ') '
		SET @nSQL = @nSQL + ' WHERE S.' + @StagingKeyColumn + ' IS NULL'

		-- The below restricts the window of records in Target to a single day, i.e. because otherbusiness days are 
		-- outside this scope, does not cause them to be expired becuase they are outside of the business date being inserted.
		IF @BusdateInFactTable = 1 SET @nSQL = @nSQL + ' AND S.BusDate = (SELECT CONVERT(nvarchar(10),MAX(BUSDATE),121) FROM ' + @StagingTable + ' ) '
		SET @nSQL = @nSQL + ' ) ;'

		set @nSQLTarget = '';
		SET @nSQLTarget = @nSQLTarget + replace (@nSQL,'"',char(39))
		SET @Message = 'REMOVE SQL = ' + @nSQLTarget
		If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, @Message
		EXEC sp_executesql @nSQLTarget
	END

	SET @Message = 'Finished Target Population'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--	--Check integrity
--	if @TargetTable = '[target].[Hierarchy]'
--	BEGIN
--		--set @SQL =  'exec [core].p_CheckIntegrity_' + @TargetTable + ' @SessionID=' + cast(@SessionID as varchar(3)) + ',@Return_status=' + @return_status + ' OUTPUT';
--		--execute (@SQL)
--
--		EXEC [core].[p_CheckIntegrity_Hierarchy] @SessionID=@SessionID, @NowDate=@NowDate, @return_status =@return_status OUTPUT
--		-- Note that control will be returned if Integrity is good, Otherwise control will be passed to the error handler.
--
--		IF @return_status <> 1
--			RAISERROR( 'THIS SHOULD NOT HAPPEN ??? Hiererachy Integrity Compromised, Rolling Back',11,-1, @ProcedureName)
--
--	-- Other Checks for other synchronisations to go here.
--
--
--	END
	SET @Message = 'Checking ' + @TargetTable + ' integrity'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	  --check integrity 
     Declare @Result INT
		SET @nSQL = 'If EXISTS ( ';
		SET @nSQL = @nSQL + ' SELECT 1 FROM ' + @TargetTable
		SET @nSQL = @nSQL + ' GROUP BY ' + @TargetKeyColumn
		SET @nSQL = @nSQL + ' HAVING COUNT(*) > 1'
		SET @nSQL = @nSQL + ' )'
		SET @nSQL = @nSQL + ' BEGIN'
		SET @nSQL = @nSQL + ' SET @Result=1'
		SET @nSQL = @nSQL + ' END'
	EXEC [core].p_LogInfo @ProcedureName, @nSQL
    EXEC sp_executesql @nSQL, N'@Result INT', @Result;

   if(@Result = 1)
   begin 
   ROLLBACK TRANSACTION @MyTranID
    Set @Message = 'Dimension Integrity compromised for ' + @TargetTable
	RAISERROR( @Message,11,-1, @ProcedureName)
   end
   else
   begin
	EXEC [core].p_LogInfo @ProcedureName, 'Commit Transaction.'
	COMMIT TRANSACTION @MyTranID
   end

	SET @Message = 'Finished Target synchronisation ' + @ProcedureName
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	RETURN ISNULL(@COUNTER,0)

END TRY

--#------------------------------------------------- END OF PROCEDURE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		nvarchar(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	IF @@TRANCOUNT > 0
	BEGIN
		-- The transaction uncommittable transaction.
		ROLLBACK TRANSACTION @MyTranID;

		SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName
		EXEC [core].p_LogInfo @ProcedureName, @Message
		
	END

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
