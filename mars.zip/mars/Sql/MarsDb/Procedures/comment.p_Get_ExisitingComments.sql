IF OBJECT_ID ('comment.p_Get_ExisitingComments') IS NOT NULL
	DROP PROCEDURE comment.p_Get_ExisitingComments
GO

Create PROC [comment].[p_Get_ExisitingComments] 
(
	@BusDate datetime2(7), --(yyyy-MM-dd)
	@TemplateID varchar(50),	
	@Version INT
)
AS 

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets FROM interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE		
        @ProcedureName      NVARCHAR(128),
        @ErrorNumber        INT,
        @ErrorSeverity      INT,
        @ErrorState         INT,
        @ErrorLine          INT,
        @ErrorMessage       VARCHAR(MAX),
        @ErrorProcedure     NVARCHAR(128),        
        @Comment 	        VARCHAR(1000),
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@MaxRow				BIGINT,
		@UTCDate			DATETIME2;
		 
    SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),       
        @ErrorNumber		= 0,           
		@Message			= 'Invoking ' + @ProcedureName;
		
	--EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY


	--Return the latest comments for today
	select * from 
	(
		Select *,
			RANK() OVER (PARTITION BY commentCatalogueKey ORDER BY version DESC ) AS RankResult				 
		from comment.Comment
		where left(cast(start as varchar(20)),10) <= @BusDate --'2016-09-15'
	)A
	where rankresult = 1	
		
	
END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
