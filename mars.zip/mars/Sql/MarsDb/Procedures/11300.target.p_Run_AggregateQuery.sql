/****** Object:  StoredProcedure [target].[p_Run_AggregateQuery_RANK_V2]    Script Date: 03/23/2017 14:35:33 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Run_AggregateQuery]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Run_AggregateQuery]
GO


--This procedure generates a 'cross-tab' (or 'pivot table') result set from (almost) any query, even a stored procedure and optionally allows you to specify a column sort order. 
--The procedure makes extensive use dynamic SQL and hence 'sp_executesql'. Because the scope of temporary tables does not extend outside of an sp_executesql transaction, I've had to use global temporary tables, which means that this procedure could become a bottleneck if used too frequently by multiple sessions.
 
--This stored procedure is provided 'as is' and without any warranty - I've only tested it on a relatively small number of queries. For more information (and my contact details) see http://nwsoft.blogspot.com/2006/05/generic-cross-tab-pivot-table-query.html
--This work is licensed under a Creative Commons Attribution 2.5 License.
CREATE PROCEDURE [target].[p_Run_AggregateQuery]
	 -- @tableSpec
	 --   A comma delimited list of columns with datatypes (and null constraints, if required)
	 --   e.g. 'col1 INT, col2 VARCHAR(255) NULL'
	 --   N.B. You only need provide this list if the source of the data is a stored procedure
	 @tableSpec    NVARCHAR(4000) = '',
		 -- @sqlSelect
		 --   The SELECT clause (or 'EXEC ' statement) for the input data
		 --   e.g. 'SELECT a.au_id, a.au_fname, a.au_lname, a.phone, LEFT(t.title, 10) AS [title], LEFT(s.stor_name, 10) AS [store], sales.qty'
		 --   e.g. 'EXEC dbo.myStoredProcedure , '
	 @sqlSelect    NVARCHAR(max),
		 -- @sqlFromWhere
		 --   The FROM and WHERE clauses for the input data (if a SELECT statement)
		 --   e.g. 'FROM authors a, titleauthor ta, titles t, stores s, sales WHERE a.au_id = ta.au_id AND ta.title_id = t.title_id AND t.title_id = sales.title_id AND s.stor_id = sales.stor_id'
		 --   N.B. Leave this blank if the source of the data is a stored procedure
	 @sqlFromWhere NVARCHAR(4000)  = '',
		 -- @pivotExpr
		 --   The column name or expression to use as the pivot (specifies which values are the column headings for the crosstabbed data)
		 --   e.g. 'store' or '''Store: '' + [store]'
	 @pivotExpr    NVARCHAR(255),
		 -- @valueExpr
		 --   A column name or expression to use as the values in the crosstabbed data
		 --   e.g. 'qty'
	 @pivotCols NVARCHAR(512),
	 @valueExpr    NVARCHAR(512),
		 -- @function
		 --   The aggregation function to use to combine values in the crosstabbed data
		 --   e.g. 'MIN'
		 --   N.B. If this parameter is left blank, the procedure will count up occurences and create additional column headings as necessary, e.g. '[X], [Y], [Y (2)], [Z]' if there are two occurences for label 'Y'
	 @function     NVARCHAR(20)   = '',
		 -- @groupBy
		 --   The column list to group by (these columns will appear to the left of the crosstabbed data)
		 --   e.g. 'au_id, au_fname, au_lname, phone'
	-- @groupBy      NVARCHAR(512),
		 -- @sortLookup
		 --   A table or view which can be queried to provide a sort order for the columns in the crosstabbed data
		 --   e.g. 'days_of_the_week'
		 --   N.B. The specified table or view must have 'label' and 'sort_order' columns
		 --   N.B. If column order is irrelevant, leave this parameter blank
		 --   N.B. Feature: if @sortLookup is given as '*', the columns are placed in ascending alphabetical order
	 @GrandTotal BIT = 0,
		 --	  Give a grand total row 	
	 @sortLookup   NVARCHAR(40)   = '',
		 -- @collation
		 --   The collation sequence
		 --   e.g. 'Latin1_general_CI_AS'
	 @collation   NVARCHAR(40)   = 'Latin1_general_CI_AS',
		 -- @verbose
		 --   Set to 1 if you want debug messages
	 @verbose     BIT            = 0,
	 @getDimensions BIT = 0,	 
	 @SliceFilter nvarchar(900) = '',
	 @RankOrder nvarchar(10) = '',
	 @RowOrder nvarchar(100) = '',
	 @PartitionCols nvarchar(900)=''
AS
BEGIN

	set nocount on
	
	DECLARE @Str NVARCHAR(MAX)
			 ,@field NVARCHAR(500)
			 ,@Part NVARCHAR(MAX)
			 ,@IND    INT
			 ,@EIND INT 
			 ,@selectCols nvarchar(max)
			 ,@CleanedCols nvarchar(max)
			 ,@ISNullCols nvarchar(max)
			 ,@SelectBefore nvarchar(max)
			 ,@castPivotCols nvarchar(max)
			 ,@RankPivotCols nvarchar(max)
			 ,@RankedCols nvarchar(max)
			 ,@RankSlice  nvarchar(max)
			 ,@SpecificRankPivotCols nvarchar(max)	
			 ,@pivotFields nvarchar(max)	
			 ,@groupBy  NVARCHAR(max)
			 ,@operator nvarchar(200)	
			 ,@coreSQL nvarchar(max) 
			 ,@SpecificRankPivotColsShowRank nvarchar(max) 
			 ,@RankNames nvarchar(max) 
			 ,@showRank bit
			 ,@rank	  nvarchar(4)
			 ,@i      INTEGER
			 ,@sql    NVARCHAR(max)
			 ,@sqlX   NVARCHAR(max)
			 ,@col    NVARCHAR(max)
			 ,@pivot  NVARCHAR(max)
			 ,@indx   NVARCHAR(10)
			 ,@cols   NVARCHAR(max)
			 ,@where  NVARCHAR(max)
			 ,@update NVARCHAR(max)
			 ,@value  NVARCHAR(532)
			 ,@select NVARCHAR(max)
			 ,@virtual bit = 0;
	
	declare @fact varchar(50)
		
	-- Drop the global temporary tables we will use (if they already exist)
	-- N.B. we have to use global temp tables, as local temp tables are dropped at the end of a batch (so are not accessible outside of the sp_executesql context)
	-- This syntax is a bit long winded because I couldn't make the substitution syntax for sp_executesql work (for this example only! - a bug in T-SQL?)
	SELECT @sql = N'IF EXISTS (SELECT 1 FROM tempdb.dbo.sysobjects WHERE name = ''@table'' AND xtype = ''U'') DROP TABLE @table'
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##input')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##data')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##coreData')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##grpCount')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##colList')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##lookup')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##results')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##temp')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##RankedData')
	EXEC sp_executesql @sqlX
	
	
	
	
	IF @verbose = 1 SELECT 'Global temporary tables dropped (if present).' AS [Message]
	

	--#-------------------------------------- Create different slices of select cols --------------------------------------#--
	--#--------------------------------------------------------------------------------------------------------------------#--

	--Deduce the groupby from the select and removing the pivotexpr and valueexpr
	SET @Str = ',' + replace(@SQLselect,'SELECT ','') + ','
	SET @groupBy = ''
	Set @selectCols = ''
	set @CleanedCols = ''
	set @IsNullCols = ''
	set @RankedCols = ''
	set @SpecificRankPivotCols  = ''
	set @pivotFields = ''
	set @SpecificRankPivotColsShowRank  = ''
	set @RankNames = '' 
	set @ShowRank = 0
	set @EIND = 0
	SET @IND = CHARINDEX(',',@str)

	print 'str:' + @str
	print 'sql select:' + @sqlselect
	print @fact
	
	--Handle virtualised columns
	if CHARINDEX('TenorDays',@str,1) > 0 and CHARINDEX('dbo.',@sqlFromWhere,1) = 0 
	begin
		
		print 'virtualised cols detected.'
		
		if CHARINDEX('target.RiskMeasure',@sqlFromWhere,1) > 0 set @fact = 'RiskMeasure'
		if CHARINDEX('target.MarketData',@sqlFromWhere,1) > 0 set @fact = 'MarketData'
	
		set @str = Replace(@str, ' ISNULL(CASE WHEN D_InstrumentTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_InstrumentTenor.TenorName, target.' + @fact + '_Fact.BusDate) ' +
									  'ELSE DATEDIFF(day, target.' + @fact + '_Fact.BusDate, D_InstrumentTenor.TenorDate) END, '' '') AS InstrumentTenorDays','[InstrumentTenorDays]');
		set @str = Replace(@str, ' ISNULL(CASE WHEN D_UnderlyingTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_UnderlyingTenor.TenorName, target.' + @fact + '_Fact.BusDate) ' +
									  'ELSE DATEDIFF(day, target.' + @fact + '_Fact.BusDate, D_UnderlyingTenor.TenorDate) END, '' '') as [UnderlyingTenorDays]','[UnderlyingTenorDays]');
		set @str = Replace(@str, ' ISNULL(CASE WHEN D_FixingTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_FixingTenor.TenorName, target.' + @fact + '_Fact.BusDate) ' +
								  'ELSE DATEDIFF(day, target.' + @fact + '_Fact.BusDate, D_FixingTenor.TenorDate) END, '' '') as [FixingTenorDays]','[FixingTenorDays]');
	end
	
	print 'str:' + @str
	print 'sql select:' + @sqlselect
	
	--Loop through and strip out selected cols
	WHILE(@IND != LEN(@STR))
	BEGIN
		SET  @EIND = ISNULL(((CHARINDEX(',', @Str, @IND + 1)) - @IND - 1), 0)
		set @field = (SUBSTRING(@Str, (@IND  + 1),  @EIND))
		set @field = REPLACE(@field,'[','')
		set @field = REPLACE(@field,']','')
		set @field = LTRIM(@field)
		set @field = RTRIM(@field)
		
		if CHARINDEX('.',@field,1) > 0 set @field = REPLACE(@field,'.','].[')
					   	
		--select @field 
		if @field <> @pivotExpr and @field <> @valueExpr
		begin
	 		--select @pivotcols
	 		if CHARINDEX(' AS ',@field,1) > 0
	 		begin
	 			set @groupBy = @groupBy  + left(@field,CHARINDEX(' AS ',@field,1)) + ','
	 			set @selectCols = @selectCols  + @field + ','
	 			set @IsNullCols =  @IsNullCols + 'isNULL(' + '[' + right(@field,len(@field) - (CHARINDEX(' AS ',@field,1)+3)) + ']' + ','''') AS ' + '[' + right(@field,len(@field) - (CHARINDEX(' AS ',@field,1)+3)) + '],' 
	 			set @CleanedCols = @CleanedCols + '[' + right(@field,len(@field) - (CHARINDEX(' AS ',@field,1)+3)) + '],' 
	 			set @RankedCols = @RankedCols + 'D.[' + right(@field,len(@field) - (CHARINDEX(' AS ',@field,1)+3)) + '] = E.[' + right(@field,len(@field) - (CHARINDEX(' AS ',@field,1)+3)) + '] AND '
	 		
	 		end
			else
			begin
				set @groupBy = @groupBy + '[' + @field + '],'
				set @selectCols = @selectCols + '[' + @field + '],'
				set @CleanedCols = @CleanedCols + '[' + @field + '],'
				set @IsNullCols = @IsNullCols + 'isNULL([' + @field + '],'''') AS [' + @field + '],'
				set @RankedCols = @RankedCols + 'D.[' + @field + '] = E.[' + @field + '] AND '
			end			
		end 
		
		SELECT @IND = ISNULL(CHARINDEX(',', @STR, @IND + 1), 0)
	END
	
	print 'select cols:' + @selectcols
	print 'groupby cols:' + @groupby
	print 'cleaned cols:' + @cleanedcols
	print 'IsNull cols:' + @IsNullcols
	print 'Ranked cols:' + @Rankedcols
	
	--Remove the trailing commas
	set @groupBy = SUBSTRING(@groupBy,1,len(@groupBy)-1)
	set @selectCols = SUBSTRING(@selectCols,1,len(@selectCols)-1)
	set @CleanedCols = SUBSTRING(@CleanedCols,1,len(@CleanedCols)-1)
	set @IsNullCols = SUBSTRING(@IsNullCols,1,len(@IsNullCols)-1)
	set @RankedCols = SUBSTRING(@RankedCols,1,len(@RankedCols)-4)

	print 'select cols:' + @selectcols

	--handle virtual dimensions
	if (CHARINDEX('tenorname',@sqlSelect,1) > 0 or CHARINDEX('tenordays',@sqlSelect,1) > 0) and CHARINDEX('dbo.',@sqlFromWhere,1) = 0 
	begin	
		print 'virtualised'
		set @virtual = 1
		
		print ''
		print 'isnullcols before: ' + @ISNullCols
		if charindex('InstrumentTenorName',@ISNullCols,1) = 0 set @isnullcols = Replace(@isnullcols, '[D_InstrumentTenor].[tenorName]','[InstrumentTenorName]');
		if charindex('UnderlyingTenorName',@ISNullCols,1) = 0 set @isnullcols = Replace(@isnullcols, '[D_UnderlyingTenor].[tenorName]','[UnderlyingTenorName]');
		if charindex('FixingTenorName',@ISNullCols,1) = 0 set @isnullcols = Replace(@isnullcols,     '[D_FixingTenor].[tenorName]','[FixingTenorName]');
		if charindex('InstrumentTenorDays',@ISNullCols,1) = 0 set @isnullcols = Replace(@isnullcols, '[D_InstrumentTenor].[tenorDays]','[InstrumentTenorDays]');
		if charindex('UnderlyingTenorDays',@ISNullCols,1) = 0 set @isnullcols = Replace(@isnullcols, '[D_UnderlyingTenor].[tenorDays]','[UnderlyingTenorDays]');
		if charindex('FixingTenorDays',@ISNullCols,1) = 0 set @isnullcols = Replace(@isnullcols,     '[D_FixingTenor].[tenorDays]','[FixingTenorDays]');      
		print 'isnullcols after:  ' + @ISNullCols
		print ''

		print '@CleanedCols before: ' + @CleanedCols
		if charindex('InstrumentTenorName',@CleanedCols,1) = 0 set @CleanedCols = Replace(@CleanedCols, '[D_InstrumentTenor].[tenorName]','[InstrumentTenorName]');
		if charindex('UnderlyingTenorName',@CleanedCols,1) = 0 set @CleanedCols = Replace(@CleanedCols, '[D_UnderlyingTenor].[tenorName]','[UnderlyingTenorName]');
		if charindex('FixingTenorName',@CleanedCols,1) = 0 set @CleanedCols = Replace(@CleanedCols,     '[D_FixingTenor].[tenorName]','[FixingTenorName]');
		if charindex('InstrumentTenorDays',@CleanedCols,1) = 0 set @CleanedCols = Replace(@CleanedCols, '[D_InstrumentTenor].[tenorDays]','[InstrumentTenorDays]');
		if charindex('UnderlyingTenorDays',@CleanedCols,1) = 0 set @CleanedCols = Replace(@CleanedCols, '[D_UnderlyingTenor].[tenorDays]','[UnderlyingTenorDays]');
		if charindex('FixingTenorDays',@CleanedCols,1) = 0 set @CleanedCols = Replace(@CleanedCols,     '[D_FixingTenor].[tenorDays]','[FixingTenorDays]');      																						        
		print '@CleanedCols after:  ' + @CleanedCols
		print ''

		print '@selectcols before: ' + @groupBy
		if charindex('D_InstrumentTenor].[tenorName AS InstrumentTenorName',@groupBy,1) > 0 set @groupBy = Replace(@groupBy, 'D_InstrumentTenor].[tenorName AS InstrumentTenorName','[D_InstrumentTenor].[tenorName] AS [InstrumentTenorName]');
		if charindex('D_UnderlyingTenor].[tenorName AS UnderlyingTenorName',@groupBy,1) > 0 set @groupBy = Replace(@groupBy, 'D_UnderlyingTenor].[tenorName AS UnderlyingTenorName','[D_UnderlyingTenor].[tenorName] AS [UnderlyingTenorName]');
		if charindex('D_FixingTenor].[tenorName AS FixingTenorName',@groupBy,1) > 0		   set @groupBy = Replace(@groupBy, 'D_FixingTenor].[tenorName AS FixingTenorName','[D_FixingTenor].[tenorName] AS [FixingTenorName]');
		if charindex('D_InstrumentTenor].[tenorName AS InstrumentTenorDays',@groupBy,1) > 0 set @groupBy = Replace(@groupBy, 'D_InstrumentTenor].[tenorDays AS InstrumentTenorDays','[InstrumentTenorDays]');
		if charindex('D_UnderlyingTenor].[tenorName AS UnderlyingTenorDays',@groupBy,1) > 0 set @groupBy = Replace(@groupBy, 'D_UnderlyingTenor].[tenorDays AS UnderlyingTenorDays','[UnderlyingTenorDays]');
		if charindex('D_FixingTenor].[tenorName AS FixingTenorDays',@groupBy,1) > 0		   set @groupBy = Replace(@groupBy, 'D_FixingTenor].[tenorDays AS FixingTenorDays','[FixingTenorDays]');    
		print '@selectcols after:  ' + @groupBy
		print ''


		print '@selectcols before: ' + @selectcols
		if charindex('D_InstrumentTenor].[tenorName AS InstrumentTenorName',@selectcols,1) > 0 set @selectcols = Replace(@selectcols, 'D_InstrumentTenor].[tenorName AS InstrumentTenorName','[D_InstrumentTenor].[tenorName] AS [InstrumentTenorName]');
		if charindex('D_UnderlyingTenor].[tenorName AS UnderlyingTenorName',@selectcols,1) > 0 set @selectcols = Replace(@selectcols, 'D_UnderlyingTenor].[tenorName AS UnderlyingTenorName','[D_UnderlyingTenor].[tenorName] AS [UnderlyingTenorName]');
		if charindex('D_FixingTenor].[tenorName AS FixingTenorName',@selectcols,1) > 0		   set @selectcols = Replace(@selectcols, 'D_FixingTenor].[tenorName AS FixingTenorName','[D_FixingTenor].[tenorName] AS [FixingTenorName]');
		if charindex('D_InstrumentTenor].[tenorName AS InstrumentTenorDays',@selectcols,1) > 0 set @selectcols = Replace(@selectcols, 'D_InstrumentTenor].[tenorDays AS InstrumentTenorDays','[InstrumentTenorDays]');
		if charindex('D_UnderlyingTenor].[tenorName AS UnderlyingTenorDays',@selectcols,1) > 0 set @selectcols = Replace(@selectcols, 'D_UnderlyingTenor].[tenorDays AS UnderlyingTenorDays','[UnderlyingTenorDays]');
		if charindex('D_FixingTenor].[tenorName AS FixingTenorDays',@selectcols,1) > 0		   set @selectcols = Replace(@selectcols, 'D_FixingTenor].[tenorDays AS FixingTenorDays','[FixingTenorDays]');    
		print '@selectcols after:  ' + @selectcols
		print ''

		print '@selectcols before: ' + @selectcols
		if charindex('[D_InstrumentTenor].[tenorName] AS [InstrumentTenorName]',@selectcols,1) = 0 set @selectcols = Replace(@selectcols, '[D_InstrumentTenor].[tenorName]','[D_InstrumentTenor].[tenorName] AS [InstrumentTenorName]');
		if charindex('[D_UnderlyingTenor].[tenorName] AS [UnderlyingTenorName]',@selectcols,1) = 0 set @selectcols = Replace(@selectcols, '[D_UnderlyingTenor].[tenorName]','[D_UnderlyingTenor].[tenorName] AS [UnderlyingTenorName]');
		if charindex('[D_FixingTenor].[tenorName] AS [FixingTenorName]',@selectcols,1) = 0		   set @selectcols = Replace(@selectcols, '[D_FixingTenor].[tenorName]','[D_FixingTenor].[tenorName] AS [FixingTenorName]');
		if charindex('[D_InstrumentTenor].[tenorName] AS [InstrumentTenorDays]',@selectcols,1) = 0 set @selectcols = Replace(@selectcols, '[D_InstrumentTenor].[tenorDays]','[InstrumentTenorDays]');
		if charindex('[D_UnderlyingTenor].[tenorName] AS [UnderlyingTenorDays]',@selectcols,1) = 0 set @selectcols = Replace(@selectcols, '[D_UnderlyingTenor].[tenorDays]','[UnderlyingTenorDays]');
		if charindex('[D_FixingTenor].[tenorName] AS [FixingTenorDays]',@selectcols,1) = 0		   set @selectcols = Replace(@selectcols, '[D_FixingTenor].[tenorDays]','[FixingTenorDays]');        
		print '@selectcols after:  ' + @selectcols
		print ''

		print '@selectcols before: ' + @selectcols
		if charindex('[InstrumentTenorDays]',@selectcols,1) > 0 set @selectcols = Replace(@selectcols, '[InstrumentTenorDays]',' (ISNULL(CASE WHEN D_InstrumentTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_InstrumentTenor.TenorName, target.' + @fact + '_Fact.BusDate) ' +
																															   'ELSE DATEDIFF(day, target.' + @fact + '_Fact.BusDate, D_InstrumentTenor.TenorDate) END, '' '')) AS InstrumentTenorDays');
		if charindex('[UnderlyingTenorDays]',@selectcols,1) > 0 set @selectcols = Replace(@selectcols, '[UnderlyingTenorDays]',' (ISNULL(CASE WHEN D_UnderlyingTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_UnderlyingTenor.TenorName, target.' + @fact + '_Fact.BusDate) ' +
																								  							   'ELSE DATEDIFF(day, target.' + @fact + '_Fact.BusDate, D_UnderlyingTenor.TenorDate) END, '' '')) as [UnderlyingTenorDays]');
		if charindex('[FixingTenorDays]',@selectcols,1) > 0		set @selectcols = Replace(@selectcols, '[FixingTenorDays]',    ' (ISNULL(CASE WHEN D_FixingTenor.TenorDate IS NULL THEN target.f_TenorDiff(D_FixingTenor.TenorName, target.' + @fact + '_Fact.BusDate) ' +
																														       'ELSE DATEDIFF(day, target.' + @fact + '_Fact.BusDate, D_FixingTenor.TenorDate) END, '' '')) as [FixingTenorDays]');      			
		print '@selectcols after:  ' + @selectcols																														      
		print ''
	end     

	print 'select cols:' + @selectcols
	print 'isnullcols:' + @isnullcols
	print 'CleanedCols: ' + @CleanedCols
	print 'ranked cols:' + @rankedcols
	
	-- Check that the mandatory parameters are not empty strings
	IF LEN(RTRIM(ISNULL(@sqlSelect, ''))) = 0
	BEGIN
		RAISERROR ('The @sqlSelect parameter cannot be an empty string.', 16, 1)
		ROLLBACK TRANSACTION
	END
	IF LEN(RTRIM(ISNULL(@valueExpr, ''))) = 0
	BEGIN
		RAISERROR ('The @valueExpr parameter cannot be an empty string.', 16, 1)
		ROLLBACK TRANSACTION
	END
	IF LEN(RTRIM(ISNULL(@groupBy, ''))) = 0
	BEGIN
		RAISERROR ('The @groupBy parameter cannot be an empty string.', 16, 1)
		ROLLBACK TRANSACTION
	END
		
	--Deduce the rank slice
	if @SliceFilter <> ''	
	begin
		--Deduce whether to show the ranks
		if RIGHT(rtrim(@SliceFilter),5) = ',TRUE' 	
		begin
			set @showRank = 1
			set @SliceFilter = LEFT(rtrim(@slicefilter),len(rtrim(@slicefilter))-5)
		end
		
		set @rank = right(rtrim(ltrim(@SliceFilter)), charindex(' ',reverse(rtrim(ltrim(@SliceFilter))),1)-1)
		set @operator = LTRIM(rtrim(replace(@slicefilter,'RANK','')))
		set @operator = LTRIM(rtrim(replace(@operator,@rank,'')))
	end
	
	print 'rank ' + @rank
	print 'operator ' + @operator
	print 'showrank ' + cast(@showRank as char(1))

	--Are we breaking out columns or doing a straight aggregation	
	if @pivotExpr <> ''
	begin
		--BREAKOUT COLUMNS
		set @sqlSelect =  'SELECT ' + @selectCols + ',' + @valueExpr + ',' + @pivotExpr 
		print @sqlselect
		
		--#------------------------------------------- Extract raw data into ##Input ------------------------------------------#--
		--#--------------------------------------------------------------------------------------------------------------------#--
		
		-- The real work starts here. First store the input dataset
		IF LEN(RTRIM(@tableSpec)) = 0
		BEGIN
			-- Create and populate the temporary table in one step
			if CHARINDEX(' WHERE ',@sqlfromwhere,1) > 0 and @pivotCols <> ''
				--Add where clause against @pivotcols so we can work with smaller dataset
				SELECT @sql = 'SELECT ' + @ISNullCols + ',isnull(' + @valueExpr + ',0) AS [' + @valueExpr + ']' + ',isnull(cast([' + @pivotExpr + '] as varchar(100)) ,''UNKNOWN'') AS [' + @pivotExpr + ']  INTO ##input FROM (' + @sqlSelect + ' ' + @sqlFromWhere + ' AND ' + @pivotExpr + ' in (''' + replace(replace(replace(@pivotcols,',',''','''),'[',''),']','') + '''))A'
				--SELECT @sql = 'SELECT ' + @ISNullCols + ',isnull(' + @valueExpr + ',0) AS [' + @valueExpr + ']' + ',isnull(cast([' + @pivotExpr + '] as varchar(100)) ,'''') AS [' + @pivotExpr + ']  INTO ##input FROM (' + @sqlSelect + ' ' + @sqlFromWhere + ' AND ' + @pivotExpr + ' in (' + @pivotcols + '))A'
			else if @pivotCols <> ''
				--Add where clause against @pivotcols so we can work with smaller dataset
				SELECT @sql = 'SELECT ' + @ISNullCols + ',isnull(' + @valueExpr + ',0) AS [' + @valueExpr + ']' + ',isnull(cast([' + @pivotExpr + '] as varchar(100)) ,''UNKNOWN'') AS [' + @pivotExpr + ']  INTO ##input FROM (' + @sqlSelect + ' ' + @sqlFromWhere + ' WHERE ' + @pivotExpr + ' in (''' + replace(replace(replace(@pivotcols,',',''','''),'[',''),']','') + '''))A'
				--SELECT @sql = 'SELECT ' + @ISNullCols + ',isnull(' + @valueExpr + ',0) AS [' + @valueExpr + ']' + ',isnull(cast([' + @pivotExpr + '] as varchar(100)) ,'''') AS [' + @pivotExpr + ']  INTO ##input FROM (' + @sqlSelect + ' ' + @sqlFromWhere + ' WHERE ' + @pivotExpr + ' in (' + @pivotcols + '))A'
			else
				--Work with full dataset
				SELECT @sql = 'SELECT ' + @ISNullCols + ',isnull(' + @valueExpr + ',0) AS [' + @valueExpr + ']' + ',isnull(cast([' + @pivotExpr + '] as varchar(100)) ,''UNKNOWN'') AS [' + @pivotExpr + ']  INTO ##input FROM (' + @sqlSelect + ' ' + @sqlFromWhere + ')A'
			print @sql
			IF @verbose = 1 SELECT @sql AS [Create and populate the temporary table in one step]
			EXEC sp_executesql @sql
		END		
		ELSE
		BEGIN		
			-- Create the temporary table first (the only method that can be used if the data is coming from a stored proc)
			SELECT @sql = 'CREATE TABLE ##input (' + @tableSpec + ')'
			IF @verbose = 1 SELECT @sql AS [Create the temporary table]
			EXEC sp_executesql @sql
			
			-- Populate it
			SELECT @sql = 'INSERT INTO ##input ' + @sqlSelect + ' ' + @sqlFromWhere
			IF @verbose = 1 SELECT @sql AS [Populate the temporary table]
			EXEC sp_executesql @sql
		END
	
		--Handle blank columns
		--SELECT @sql = 'UPDATE ##INPUT SET ' + @pivotExpr + ' = ''UNKNOWN'' WHERE ' + @pivotExpr + ' = '''''
		--IF @verbose = 1 SELECT @sql AS [Handle blank breakout columns]
		----print @sql
		--EXEC sp_executesql @sql
	
	
		IF @verbose = 1 SELECT * FROM ##input
		
		if (SELECT COUNT(1) FROM ##input) > 0 
		begin
			
			-- Does the query we want to cross-tab already have a column called 'crossTabRowID'? This is a reserved column name!
			IF EXISTS(SELECT 1 FROM tempdb.dbo.sysobjects o, tempdb.dbo.syscolumns c WHERE o.id = c.id AND o.name = '##input' AND c.name = 'crossTabRowID')
			BEGIN
				RAISERROR ('The query passed to the [genericCrosstab] procedure uses a reserved column name (''crossTabRowID'').', 16, 1)
				ROLLBACK TRANSACTION
			END
			
			-- Add an identity column (we need a 'row ID')
			ALTER TABLE ##input ADD crossTabRowID NUMERIC(9, 0) IDENTITY NOT NULL
			
			--#------------------------------------------------ Populate ##ColList ------------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			
			-- Generate the column list
			SELECT @sql = 'SELECT ' + @CleanedCols + ' INTO ##colList FROM ##input WHERE 1 = 0'
			IF @verbose = 1 SELECT @sql AS [Generate the column list]
			print @sql
			EXEC sp_executesql @sql
			IF @verbose = 1 SELECT * FROM ##colList
		
			--#------------------------------------------------ Populate ##grpCount -----------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
		
			-- If no aggregation function is specified, we have to check first that there are no duplicates, and - if there are - we need to handle them
			IF RTRIM(ISNULL(@function, '')) = ''
			BEGIN
				SELECT @sql = 'SELECT ' + @CleanedCols + ', ' + @pivotExpr + ' COLLATE ' + @collation + ' AS [pivot], COUNT(1) AS [count] INTO ##grpCount FROM ##input GROUP BY ' + @CleanedCols + ', ' + @pivotExpr + ' COLLATE ' + @collation
			END
			ELSE
			BEGIN
				SELECT @sql = 'SELECT ' + @CleanedCols + ', ' + @pivotExpr + ' COLLATE ' + @collation + ' AS [pivot], 1 AS [count] INTO ##grpCount FROM ##input GROUP BY ' + @CleanedCols + ', ' + @pivotExpr + ' COLLATE ' + @collation
			END
			
			IF @verbose = 1 SELECT @sql AS [Create the ##grpCount table]
			EXEC sp_executesql @sql
			IF @verbose = 1 SELECT * FROM ##grpCount
			
			--#------------------------------------------------ Populate ##lookup ------------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			-- Create a temporary table that will act as a lookup (containing all of the non-pivot / non-group columns names)
			SELECT [pivot], [count] AS [index], [pivot] AS [column_name] INTO ##lookup FROM ##grpCount WHERE 1 = 0
			
			
			--#------------------------------------------------ Populate ##results ------------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			-- Build the results table; one row per group
			SELECT @sql = 'SELECT ' + @CleanedCols + ' INTO ##results FROM ##grpCount GROUP BY ' + @CleanedCols
			IF @verbose = 1 SELECT @sql AS [Create the ##results table]
			EXEC sp_executesql @sql
			IF @verbose = 1 SELECT * FROM ##results
			
			-- Build the column list, taking into account duplicate occurences of pivotal values
			DECLARE xcursor CURSOR FOR SELECT [pivot], MAX([count]) FROM ##grpCount GROUP BY [pivot]
			OPEN xcursor
			FETCH NEXT FROM xcursor INTO @pivot, @indx
			
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
				SELECT @i = 1
				
				-- Loop over indx
				WHILE @i <= @indx
				BEGIN
				-- Build the column list
					SELECT @col = CASE @i WHEN 1 THEN @pivot ELSE @pivot + ' (' + CAST(@i AS VARCHAR(10)) + ')' END
					if @col = '' select @col = 'UNKNOWN'
					
					
					INSERT INTO ##lookup VALUES (@pivot, @i, @col)
					SELECT @col = '[' + @col + '] NVARCHAR(255) NULL'
					SELECT @cols =  ISNULL(@cols + ', ', '') + @col
			
					-- Add the column to the results table
					SELECT @sql = 'ALTER TABLE ##results ADD ' + @col
					IF @verbose = 1 SELECT @sql AS [Add column to the ##results table]
					
					EXEC sp_executesql @sql
				
					-- Continue
					SELECT @i = @i + 1
				END
				FETCH NEXT FROM xcursor INTO @pivot, @indx
			END
			
			CLOSE xcursor
			DEALLOCATE xcursor 
			IF @verbose = 1 SELECT * FROM ##lookup
			IF @verbose = 1 SELECT * FROM ##results
			
			
			--#------------------------------------------------ Build the Where Clause ---------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			print 'where loop'
			
			-- Loop over the column list (using the syscolumns table in the temp database) to build the WHERE clause
			DECLARE xcursor CURSOR FOR SELECT DISTINCT c.[colid], c.[name] FROM tempdb.dbo.sysobjects o, tempdb.dbo.syscolumns c WHERE o.[id] = c.[id] AND o.[name] = '##colList' ORDER BY c.[colid]
			OPEN xcursor
			FETCH NEXT FROM xcursor INTO @indx, @col
			WHILE @@FETCH_STATUS = 0
			BEGIN
				-- Build the WHERE clause
				SELECT @where = ISNULL(@where + ' AND ', '') + 'ISNULL(t1.[' + @col + '], '''') = ISNULL(t3.[' + @col + '], '''')'
				FETCH NEXT FROM xcursor INTO @indx, @col
			END
			
			CLOSE xcursor
			DEALLOCATE xcursor 
			IF @verbose = 1 SELECT @where AS [WHERE clause]
			
			
			--#-------------------------------------------------- Populate ##Temp -------------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			print 'update'
			
			-- Create a temp table that will help us build the UPDATE statements to set the values in the pivot table, and the SELECT statement (with columns in preferred order) afterwards
			IF RTRIM(ISNULL(@sortLookup, '')) = ''
			BEGIN
				-- If no sorting table was specified, just select all columns
				SELECT @select = '*'
				-- Sort alphabetically
				SELECT @sql = 'SELECT DISTINCT t5.[index], c.[name], t5.[pivot] INTO ##temp FROM tempdb.dbo.sysobjects o, tempdb.dbo.syscolumns c, ##lookup t5 WHERE o.[id] = c.[id] AND o.[name] = ''##results'' AND c.[name] COLLATE ' + @collation + ' = t5.[column_name] COLLATE ' + @collation + ' ORDER BY c.[name], t5.[index]'
			END  
			ELSE 
			BEGIN
				-- The 'group by' column(s) always come(s) first
				SELECT @select = @CleanedCols
				-- Sort in proscribed order
				SELECT @sql = 'SELECT DISTINCT t5.[index], c.[name], t5.[pivot], l.[sort_order] INTO ##temp FROM tempdb.dbo.sysobjects o, tempdb.dbo.syscolumns c, ##lookup t5, ' + @sortLookup + ' l WHERE o.[id] = c.[id] AND o.[name] = ''##results'' AND t5.[pivot] COLLATE ' + @collation + ' *= l.[label] COLLATE ' + @collation + ' AND c.[name] COLLATE ' + @collation + ' = t5.[column_name] COLLATE ' + @collation + ' ORDER BY l.[sort_order], c.[name], t5.[index]'
			END
			
			IF @verbose = 1 SELECT @sql AS [Build the ##temp table]
			EXEC sp_executesql @sql 
			IF @verbose = 1 SELECT * FROM ##temp
			
			-- The value expression
			SELECT @value = @valueExpr
			
			-- If a function has been specified
			IF RTRIM(ISNULL(@function, '')) != ''
			BEGIN
				SELECT @value = @function + '(' + @value + ')'
			END
			
			--#------------------------------------------------- Populate ##Results  ------------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			print 'another loop'

			DECLARE xcursor CURSOR FOR SELECT [index], [name], [pivot] FROM ##temp
			OPEN xcursor
			FETCH NEXT FROM xcursor INTO @indx, @col, @pivot
			
			WHILE @@FETCH_STATUS = 0
			BEGIN
				-- Build the SELECT expression
				IF @select != '*' SELECT @select = @select + ', isnull(' + @col + ','' '')'
				
				-- Create the SET clause of the UPDATE sql
				IF RTRIM(ISNULL(@function, '')) = ''
				BEGIN
					-- No function specified
					SELECT @update = '[' + @col + '] = (SELECT isnull(' + @value + ','' '' ) FROM ##input t1 WHERE ' + @where + ' AND ' + @pivotExpr + ' COLLATE ' + @collation + ' = ''' + @pivot + ''' COLLATE ' + @collation + ' AND t1.crossTabRowID = (SELECT MIN(t0.crossTabRowID) FROM ##input t0 WHERE ' + REPLACE(@where, 't3.', 't0.') + ' AND ' + @pivotExpr + ' COLLATE ' + @collation + ' = ''' + @pivot + '''' + ' COLLATE ' + @collation + ') + (' + CAST(@indx AS VARCHAR(3)) + ' - 1))'
				END
				ELSE
				BEGIN
					-- Function specified
					SELECT @update = '[' + @col + '] = (SELECT isnull(' + @value + ','' '') FROM ##input t1 WHERE ' + @where + ' AND ' + @pivotExpr + ' COLLATE ' + @collation + ' = ''' + @pivot + ''' COLLATE ' + @collation + ' AND t1.crossTabRowID IN (SELECT t0.crossTabRowID FROM ##input t0 WHERE ' + REPLACE(@where, 't3.', 't0.') + ' AND ' + @pivotExpr + ' COLLATE ' + @collation + ' = ''' + @pivot + '''' + ' COLLATE ' + @collation + '))'
				END
				
				SELECT @sql = 'UPDATE ##results SET ' + @update + ' FROM ##results t3'
				IF @verbose = 1 SELECT @sql AS [Create the SET clause of the UPDATE sql]
				--print @sql
				EXEC sp_executesql @sql

				FETCH NEXT FROM xcursor INTO @indx, @col, @pivot
			END

			CLOSE xcursor
			DEALLOCATE xcursor 

			
			
			IF @verbose = 1 SELECT * FROM ##results
				
			--select * from ##results
			--#------------------------------------------------ Handle Pivot Columns ----------------------------------------------#--
			--#--------------------------------------------------------------------------------------------------------------------#--
			print 'return'

			--Clean the select string
			set @select = @cleanedcols + ','+ @valueExpr
			set @select = replace(@select,'[[','[')
			set @select = replace(@select,']]',']')
			set @select = replace(@select,'SELECT','')		
			set @SelectBefore = @Select			
			print @select
			
			set @castPivotCols = ''
			set @RankPivotCols = ''		
			if @PartitionCols = '' set @PartitionCols = @cleanedcols

			--Has user specified only certain pivoted cols to be returned?
			if @pivotCols <> '' 
			begin		
				--Only return specific pivoted cols
				set @pivotcols = ','+@pivotCols+','
				set @pivotcols = replace(@pivotcols,',,',',')
				
				--Clear so we can rebuild
				set @SliceFilter = ''
				
				--Loop through and build a list of pivoted columns casted to floats
				SET @Str = @pivotcols
				SET @IND = CHARINDEX(',',@str)		
				set @EIND = 0
				WHILE(@IND != LEN(@STR))
				BEGIN
					SET  @EIND = ISNULL(((CHARINDEX(',', @Str, @IND + 1)) - @IND - 1), 0)
					set @field = (SUBSTRING(@Str, (@IND  + 1),  @EIND))
					set @field = REPLACE(@field,'[','')
					set @field = REPLACE(@field,']','')
					set @field = rtrim(ltrim(@field))
					 if(select COUNT(1) from (select name from tempdb.sys.columns where object_id =object_id('tempdb..##results'))A
					 where A.name = @field)=0 
					 begin
		 				--remove pivot cols that have no data
						set @pivotcols = replace(@pivotcols,'[' + @field + ']','')
						set @pivotcols = replace(@pivotcols,',,',',')					
					 end  
					 else 
					 begin
						--add the casted pivoted col
						set @castPivotCols = @castPivotCols + 'Cast([' + @field + '] AS Float) as [' + @field + '],'
						--set @RankPivotCols = @RankPivotCols + '[' + @field + '],ROW_NUMBER() OVER (Order by [' + @field + ']) as [rank_' + @field +'],'					
						set @RankPivotCols = @RankPivotCols + '[' + @field + '],ROW_NUMBER() OVER (Partition by ' + @PartitionCols + ' Order by [' + @field + ']) as [rank_' + @field +'],'										
						set @RankNames = @RankNames + '[rank_' + @field +'],'
						set @SpecificRankPivotCols = @SpecificRankPivotCols + 'isnull((select TOP 1 [' + @field + '] from ##data E where [rank_' + @field +'] ' + @operator + ' ' + @rank + ' AND ' + @RankedCols + '),'''') as [' + @field + '],'
						set @SpecificRankPivotColsShowRank = @SpecificRankPivotColsShowRank + 'isnull((case when [rank_' + @field +'] ' + @operator + ' ' + @rank + ' then [rank_' + @field +'] else null end),'' '') as [rank_' + @field + '],isnull((select TOP 1 [' + @field + '] from ##data E where [rank_' + @field +'] ' + @operator + ' ' + @rank  + ' AND ' + @RankedCols + '),'''') as [' + @field + '],'
						set @SliceFilter = @SliceFilter + '[rank_' + @field +'] ' + @operator + ' ' + @rank + ' OR '
						set @pivotFields = @pivotFields + @field + ','
						--set @RankPivotCols = @RankPivotCols + '[' + @field + '],ROW_NUMBER() OVER (Partition by ' + @CleanedCols + '  Order by [' + @field + ']) as [rank_' + @field +'],'
					 end
					--select (SUBSTRING(@Str, (@IND  + 1),  @EIND))	
					SELECT @IND = ISNULL(CHARINDEX(',', @STR, @IND + 1), 0)
				END

				--Did the data return any pivot cols?
				if REPLACE(@pivotCols,' ','') = ','
				begin
					print 'no pivot cols'
					--no pivot cols returned
					set @pivotCols = ''
					set @cols = @pivotCols
				end
				else
				begin
					--pivot cols returned
					set @pivotCols = SUBSTRING(@pivotcols,2,len(@pivotcols)-2)
					set @cols = @pivotCols
					
					--cast the pivot cols to return as numbers				
					print 'cols: ' + @castPivotCols
					set @select = @CleanedCols + ', ' +  substring(@castPivotCols,1,LEN(@castPivotCols)-1)
				end			
			end
			ELSE
			BEGIN
				--Clear so we can rebuild
				set @SliceFilter = ''
				
				--Return all pivoted cols
				--Loop through and build a list of pivoted columns casted to floats
				SET @Str = ',' + REPLACE(@cols, 'NVARCHAR(255) NULL','')+','
				PRINT @STR
				SET @IND = CHARINDEX(',',@str)		
				set @EIND = 0
				WHILE(@IND != LEN(@STR))
				BEGIN
					SET  @EIND = ISNULL(((CHARINDEX(',', @Str, @IND + 1)) - @IND - 1), 0)
					set @field = (SUBSTRING(@Str, (@IND  + 1),  @EIND))
					set @field = REPLACE(@field,'[','')
					set @field = REPLACE(@field,']','')
					set @field = rtrim(ltrim(@field))
					
					--add the casted pivoted col
					set @castPivotCols = @castPivotCols + 'Cast([' + @field + '] AS Float) as [' + @field + '],'
					--set @RankPivotCols = @RankPivotCols + '[' + @field + '],ROW_NUMBER() OVER (Order by [' + @field + ']) as [rank_' + @field +'],'				
					set @RankPivotCols = @RankPivotCols + '[' + @field + '],ROW_NUMBER() OVER (Partition by ' + @PartitionCols + ' Order by [' + @field + ']) as [rank_' + @field +'],'								
					set @RankNames = @RankNames + '[rank_' + @field +'],'
					set @SpecificRankPivotCols = @SpecificRankPivotCols + 'isnull((select TOP 1 [' + @field + '] from ##data E where [rank_' + @field +'] ' + @operator + ' ' + @rank  + ' AND ' + @RankedCols + '),'''') as [' + @field + '],'
					set @SpecificRankPivotColsShowRank = @SpecificRankPivotColsShowRank + 'isnull((case when [rank_' + @field +'] ' + @operator + ' ' + @rank + ' then [rank_' + @field +'] else null end),'' '') as [rank_' + @field + '],isnull((select TOP 1 [' + @field + '] from ##data E where [rank_' + @field +'] ' + @operator + ' ' + @rank  + ' AND ' + @RankedCols + '),'''') as [' + @field + '],'
					set @SliceFilter = @SliceFilter + '[rank_' + @field +'] ' + @operator + ' ' + @rank + ' OR '
					set @pivotFields = @pivotFields + @field + ','
					
					--set @RankPivotCols = @RankPivotCols + '[' + @field + '],ROW_NUMBER() OVER (Partition by ' + @CleanedCols + '  Order by [' + @field + ']) as [rank_' + @field +'],'
					SELECT @IND = ISNULL(CHARINDEX(',', @STR, @IND + 1), 0)
				END
				
				--finish the select statement
				set @select = @CleanedCols + ', ' +  substring(@castPivotCols,1,LEN(@castPivotCols)-1)	
				
			END
			
			--remove last commas
			set @RankPivotCols = substring(@RankPivotCols,1,LEN(@RankPivotCols)-1)
			set @SpecificRankPivotCols = substring(@SpecificRankPivotCols,1,LEN(@SpecificRankPivotCols)-1)
			set @SliceFilter = substring(@SliceFilter,1,LEN(@SliceFilter)-3)
			set @pivotFields = substring(@pivotFields,1,LEN(@pivotFields)-1)
			set @SpecificRankPivotColsShowRank = substring(@SpecificRankPivotColsShowRank,1,LEN(@SpecificRankPivotColsShowRank)-1)
			set @RankNames = substring(@RankNames,1,LEN(@RankNames)-1)
			
			print 'pre rank: ' + @sql
			
					
			--Check if any pivot cols have data and if not, just return a message instead of data
			if @SelectBefore <> @select
			begin
				--Lastly add the ranking functionality
				if @SliceFilter <> '' 
				begin
					print 'Cleaned cols: ' + @cleanedcols
					print 'is null cols: ' + @IsNullCols
					print 'rank pivot cols: ' + @RankPivotCols
					print 'specific' + @SpecificRankPivotCols
				
					select @sql = 'select * into ##data from (select ' + @CleanedCols +','+ @RankPivotCols + ' from ##results A)B WHERE ' + @SliceFilter
					
					--select @sql = 'select * into ##data from (select ' + @CleanedCols +','+ @RankPivotCols + ' from(' + @sql + ')A)B WHERE ' + @SliceFilter				
					print 'mid rank: ' + @sql
					EXEC sp_executesql @sql
					
					if @verbose = 1 select * from ##data
					
									
					if @getDimensions = 0
						if @showRank = 0
							select @sql = 'select ' + @CleanedCols + ',' + @SpecificRankPivotCols + ' from ##DATA D group by ' + @CleanedCols 
										--	EXEC sp_executesql @sql
							
							--select B.[rank], C.AED,d.aoa
							--from						
							--(
							--	select distinct [rank]  from 
							--	( 
							--		select rank_AED as [rank]
							--		from ##RankedData 
							--		where rank_AED <> 0
							--		union 
							--		select rank_AOA as [rank]
							--		from ##RankedData 
							--		where rank_AOA <> 0
							--	)A
							--)B
							--join ##RankedData C
							--	on B.[rank] = c.[rank_aed]
							--join ##RankedData D
							--	on B.[rank] = d.[rank_aoa]
							
								
							--where rank_AED <> 0 and rank_AOA <> 0 and  rank_ARS   <> 0 and rank_AUD <> 0
	  

							
						else
							select @sql = 'select ' + @CleanedCols + ',' + @SpecificRankPivotColsShowRank + ' from ##DATA D group by ' + @CleanedCols + ',' + @RankNames
						--select @sql = 'select * from ##DATA D group by ' + @CleanedCols 
					else
						if @showRank = 0
							select @sql = 'SELECT count(1) as [RowCount], (SELECT LEN(''' + @CleanedCols + ',' + @pivotFields + ''') - LEN(REPLACE(''' + @CleanedCols + ',' + @pivotFields + ''','','', ''''))) +1 as [colCount] from (select ' + @CleanedCols + ',' + @SpecificRankPivotCols + ' from ##DATA D group by ' + @CleanedCols + ')A' 
						else
							select @sql = 'SELECT count(1) as [RowCount], (SELECT LEN(''' + @CleanedCols + ',' + @pivotFields + ',' + @RankNames + ''') - LEN(REPLACE(''' + @CleanedCols + ',' + @pivotFields + ',' + @RankNames + ''','','', ''''))) +1 as [colCount] from (select ' + @CleanedCols + ',' + @SpecificRankPivotCols + ' from ##DATA D group by ' + @CleanedCols + ')A' 
				
				--select @sql = 'select * from (select ' + @CleanedCols +','+ @RankPivotCols + ' from ##results A)B '
				
					print 'final: ' + substring(@Sql,1,4000)
					print 'final: ' + substring(@Sql,4001,4000)

				end
				else
				begin
					if @getDimensions = 0	SELECT @sql = 'SELECT ' + @select + ' FROM ##results '
					else SELECT @sql = 'SELECT count(1) as [RowCount], (SELECT LEN(''' + @select + ''') - LEN(REPLACE(''' + @select + ''','','', ''''))) +1 as [colCount] FROM ##results '
				end
			end
			else
			begin
				--No pivot data returned
				if @getDimensions = 0	SELECT @sql = 'SELECT ''No breakout columns returned'''
				else SELECT @sql = 'SELECT 1 as [RowCount], 1 as [colCount] FROM ##results '		
			end		
		end
		else
		begin
				--No pivot data returned
				if @getDimensions = 0	SELECT @sql = 'SELECT ''No Data Returned'' as ''No Data Returned'''
				else SELECT @sql = 'SELECT 1 as [RowCount], 1 as [colCount]'		
		end
	end
	else
	begin
		--No need to pivot cols, just return an aggregate query
		--create the query
		print 'No pivot required. Build final query'
		if @virtual = 1
			SELECT @sql = 'SELECT ' + @CleanedCols + ', ' + @function + '(' + @valueExpr + ') as ' + @valueExpr + ' From (SELECT ' + @selectCols + ', ' + @valueExpr + ' ' + @sqlFromWhere + ') A group by ' + @CleanedCols
		else
			SELECT @sql = 'SELECT ' + @selectCols + ', ' + @function + '(' + @valueExpr + ') as ' + @valueExpr + ' ' + @sqlFromWhere + ' group by ' + @groupBy
			
		--Add the dimensions code
		if @SliceFilter <> '' select @sql = 'SELECT * FROM (select * ,ROW_NUMBER() OVER (Order by ' + @valueExpr + ' ' + @RankOrder + ') as [rank] from(' + @sql + ')A)B WHERE ' + @SliceFilter
		
		--Wrap to just return dimensions
		if @getDimensions = 1 
		begin			
			--Add the slice filtering code
			SELECT @sql = 'SELECT count(1) as [RowCount], (SELECT LEN(''' + @CleanedCols + ''') - LEN(REPLACE(''' + @CleanedCols + ''','','', ''''))) +2 as [colCount] FROM (' + @sql + ')A ' 			
		end
	end
	
	--Add Ordering
	if @RowOrder <> '' and @getDimensions = 0
		set @sql = @sql + ' ORDER BY ' + @RowOrder
	

--	select @sql = 'select * from (select ' + @CleanedCols +','+ @RankPivotCols + ' from ##results A)B' -- WHERE ' + @SliceFilter

	print @sql	
	IF @verbose = 1 SELECT @sql AS [Create the SELECT statement that will return the results]

	print 'try'
	EXEC sp_executesql @sql
	print 'made it'
	
	-- Tidy up: drop the global temporary tables
	SELECT @sql = N'IF EXISTS (SELECT 1 FROM tempdb.dbo.sysobjects WHERE name = ''@table'' AND xtype = ''U'') DROP TABLE @table'
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##input')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##data')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##coreData')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##grpCount')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##colList')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##lookup')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##results')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##temp')
	EXEC sp_executesql @sqlX
	SELECT @sqlX = REPLACE(@sql, N'@table', N'##RankedData')
	EXEC sp_executesql @sqlX
	

END


GO


