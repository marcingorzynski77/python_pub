IF OBJECT_ID ('core.p_CreateStar_SummitBondPosition') IS NOT NULL

	DROP PROCEDURE core.p_CreateStar_SummitBondPosition

GO



CREATE PROC [core].[p_CreateStar_SummitBondPosition]

(

	@BusDate	DATETIME2,

	@DataFeed	VARCHAR(64),

	@Env		VARCHAR(6),

	@SessionID	INT			= 0

)

AS



BEGIN

	SET NOCOUNT ON;



	DECLARE

		@ProcedureName		NVARCHAR(128),

		@ErrorNumber		INT		= 0,

		@ErrorSeverity		INT,

		@ErrorState			INT,

		@ErrorLine			INT,

		@ErrorMessage		VARCHAR(MAX),

		@ErrorProcedure		NVARCHAR(128),

		@Comment			VARCHAR(1000),

		@CommentID			INT,

		@InsertedCount		BIGINT,

		@MaxRow				BIGINT,

		@UTCDate			DATETIME2	= getutcdate()



	SELECT

		@ProcedureName	= OBJECT_NAME(@@PROCID),

		@Comment		= 'Invoking ' + @ProcedureName;



	EXEC [core].p_LogInfo @ProcedureName, @Message

	EXEC [core].[p_MonitorEvent]  @sessionID, @Env, @DataFeed, @BusDate, @Comment, 'G', 0



--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--

--#====================================================================================================================#--



BEGIN TRY



	--First empty the star ready for new data

	TRUNCATE TABLE [core].SummitBondPosition_Source

	TRUNCATE TABLE [core].SummitBondPosition_Hierarchy

	TRUNCATE TABLE [core].SummitBondPosition_Instrument

	TRUNCATE TABLE [core].SummitBondPosition_InstrumentType	

	TRUNCATE TABLE [core].SummitBondPosition_Fact

	TRUNCATE TABLE [core].SummitBondInstrument_Fact

	TRUNCATE TABLE [core].SummitBondPosition_Rating 

	TRUNCATE TABLE [core].SummitBondPosition_Country



	--select * from raw.summitbondposition

	--select * from [core].SummitBondPosition_Source

	--select * from [core].SummitBondPosition_Hierarchy

	--select * from [core].SummitBondPosition_Instrument

	--select * from [core].SummitBondPosition_InstrumentType

	--select * from [core].SummitBondPosition_Fact

	--select * from [core].SummitBondInstrument_Fact

	--select * from [core].SummitBondPosition_Rating

	--select * from [core].SummitBondPosition_Country



--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SummitBondPosition_Source'

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SummitBondPosition_Hierarchy'

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SummitBondPosition_Instrument'

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SummitBondPosition_Fact'

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SummitBondPosition_Fact'

	

	--#-------------------------------------------- Populate the Source Dimension ------------------------------------------#--



	--Source Dimension

	INSERT INTO  [core].SummitBondPosition_Source (

		[InterfaceName],

		[Environment],

		[Source],

		[Origin]

	)

	SELECT

		@DataFeed,

		@Env,

		isnull([Summit],'UNKNOWN') as 'Source',

		isnull([Summit],'UNKNOWN') as 'Origin'

	FROM

		[raw].SummitBondPosition V

	GROUP BY

		[Summit]



	--Log affected rows

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[SummitBondPosition_Source] dimension'

	EXEC [core].p_LogInfo @ProcedureName, @Message



	--#------------------------------------------ Populate the Hierarchy Dimension -----------------------------------------#--



	--Hierarchy Dimension

	INSERT INTO [core].SummitBondPosition_Hierarchy (

		  CoreSourceKey

		, NodeType

--		, NodeDesk

		, NodeName

		, BookSystem

	)

	SELECT

		 S.CoreSourceKey

		,'BO' AS [NodeType]

--		,R.Desk

		,R.Book

		,isnull(R.[Summit], 'Risk Management')

	FROM

		[raw].SummitBondPosition R

		join

		[core].SummitBondPosition_Source S

		on

			S.Source = isnull(R.[Summit],'UNKNOWN')

			and

			S.Origin = isnull(R.[Summit],'UNKNOWN')

	GROUP BY

		 S.CoreSourceKey

--		,R.Desk

		,R.Book

		,isnull(R.[Summit], 'Risk Management')



	set @InsertedCount = @@ROWCOUNT



	update

		T

	set

		T.HierarchyString = H.HierarchyString

	from

		[core].TridentBondPosition_Hierarchy T

		join

		[target].Hierarchy H

		on

			H.NodeName = T.NodeName

			and

			H.NodeType = T.NodeType

			and

			H.BookSystem = T.BookSystem

			and

			H.Start <= @UTCDate

			and

			H.Finish > @UTCDate



	--Log affected rows

	SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].[SummitBondPosition_Hierarchy] dimension'

	EXEC [core].p_LogInfo @ProcedureName, @Message



	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--



	-- Country Dimension

	INSERT into [core].SummitBondPosition_Country (

		 [CoreSourceKey]

		,[IssuerPhysicalCountry]

		,[IssuerLogCountry]

		,[SecCountry]

	)

	SELECT DISTINCT

		 S.[CoreSourceKey]

		,R.[Issuer Physical Country]

		,R.[Issue Log Country]

		,COALESCE(R.[SecCountry], R.[Issuer Physical Country], R.[Issue Log Country]) AS 'SecCountry'

	FROM

		[raw].SummitBondPosition R

		join

		[core].SummitBondPosition_Source S

		on

			S.Source = isnull(R.[Summit],'UNKNOWN')

			and

			S.Origin = isnull(R.[Summit],'UNKNOWN')



			

	--Log affected rows

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SummitBondPosition_Country dimension'

	EXEC [core].p_LogInfo @ProcedureName, @Message



	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--



	-- Rating Dimension

	INSERT into [core].SummitBondPosition_Rating (

		 [CoreSourceKey]

		,[SecSandP_RISKRATE]

		,[SECMoodys_RISKRATE]

		,[INTERNAL_RISKRATE]

		,[SecECAI_RiskRate]

		,[SecHBOS_RiskRate]

		,[Fitch_RiskRate]

	)

	SELECT DISTINCT

		 isnull(S.[CoreSourceKey],'')

		,isnull(R.[SecS&P_RISKRATE],'')

		,isnull(R.[SECMoodys_RISKRATE],'')

		,isnull(R.[INTERNAL_RISKRATE],'')

		,isnull(R.[SecECAI_RiskRate],'')

		,isnull(R.[SecHBOS_RiskRate],'')

		,isnull(R.[Fitch_RiskRate],'')

	FROM

		[raw].SummitBondPosition R

		join

		[core].SummitBondPosition_Source S

		on

			S.Source = isnull(R.[Summit],'UNKNOWN')

			and

			S.Origin = isnull(R.[Summit],'UNKNOWN')





	--Log affected rows

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SummitBondPosition_Rating dimension'

	EXEC [core].p_LogInfo @ProcedureName, @Message





	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--



	-- Instrument Dimension

	INSERT into [core].SummitBondPosition_Instrument (

		 [CoreSourceKey]

		,[Issue Date]

		,[InstrumentIDType]

		,[InstrumentID]		

		,[Product]

		,[Currency]

		,[Eff Date]

		,[Maturity]

		,[Issuer]

		,[IssuerName]

		,[FixedFRN]

		,[SeniorityLevel]

		,[Day Basis]

		,[PayFrequency]

		,[ISIN]

		,[Settle Ccy]

		,[CUSIP]

		,[Issue Price]

		,[RedemptionPrice]

		,[Ref Guarantor]

		,[Notes_LongName1]

		,[SIC2007]

		,[Index Linked Bond]

	)

	SELECT DISTINCT

		 S.[CoreSourceKey]

		,CASE WHEN R.[Issue Date] <> '' THEN convert(DATETIME2, R.[Issue Date], 103) ELSE NULL end as [Issue Date]

		,CASE WHEN R.[ISIN] <> '' THEN 'ISIN' ELSE 'CUSIP' end as [InstrumentIDType]

		,CASE WHEN R.[ISIN] <> '' THEN isnull(ISIN,'') ELSE isnull(CUSIP,'') end as [InstrumentID]

		,R.[Security Id]

		,R.[Ccy]

		,CASE WHEN R.[Eff Date] <> '' THEN CONVERT(DATETIME2, R.[Eff Date], 103) ELSE NULL END as [Eff Date]

		,CASE WHEN R.[Mat Date] <> '' THEN CONVERT(DATETIME2, R.[Mat Date], 103) ELSE NULL END as [Mat Date]

		,R.[Issuer]

		,R.[Issuer Full Name]

		,R.[Fix/Float]

		,R.[Seniority Level]

		,R.[Day Basis]

		,R.[PayFrequency]

		,R.[ISIN]

		,R.[Settle Ccy]

		,R.[CUSIP]

		,R.[Issue Price]

		,R.[RedemptionPrice]

		,R.[Ref Guarantor]

		,R.[Notes_LongName1]

		,R.[SIC2007]

		,R.[Index Linked Bond]

	FROM

		[raw].SummitBondPosition R

		join

		[core].SummitBondPosition_Source S

		on

			S.Source = isnull(R.[Summit],'UNKNOWN')

			and

			S.Origin = isnull(R.[Summit],'UNKNOWN')

			

	----Clean out empty market price data and null periods

	--delete from core.SummitBondPosition_Instrument

	--where CoreInstrumentKey in 

	--(

	--	select CoreInstrumentKey from core.SummitBondPosition_Instrument 

	--	where [Security Id] in (select [Security Id] from core.SummitBondPosition_Instrument group by [Security Id] having COUNT(1) >1)

	--	and (MarketPrice = 0 or MarketPrice = 1 or [Period Start] is null)

	--)

				

	----Clean out different periods for same instrument by taking the most recent	

	--delete from core.SummitBondPosition_Instrument

	--where CoreInstrumentKey in 

	--(

	--	select CoreInstrumentKey  from 

	--	(

	--		select CoreInstrumentKey, [Security Id],RANK() over(partition by [security id] order by [period start] desc) as [Ranking] from core.SummitBondPosition_Instrument

	--		where [Security Id] in (select [Security Id] from core.SummitBondPosition_Instrument group by [Security Id] having COUNT(1) >1)

	--	)a 

	--	where a.Ranking > 1

	--)	

		

	----Update table with the averages of the market prices

	--update I

	--	set I.MarketPrice = A.MarketPrice

	--from [core].SummitBondPosition_Instrument I

	--join 

	--(

	--	select [Security Id], AVG(MarketPrice) as MarketPrice

	--	from [core].SummitBondPosition_Instrument

	--	where [Security Id] in (select [Security Id] from [core].SummitBondPosition_Instrument group by [Security Id] having COUNT(1) > 1)

	--	group by [Security Id]

	--)A

	--on a.[Security Id] = i.[Security Id]

				

	----Delete remaining duplicates 

	--delete from core.SummitBondPosition_Instrument

	--where CoreInstrumentKey in 

	--(

	--	select CoreInstrumentKey from

	--	(

	--		select CoreInstrumentKey, [Security Id],ntile(2) over(partition by [security id] order by [period start] desc) as [Ranking] 

	--		from [core].SummitBondPosition_Instrument

	--		where [Security Id] in (select [Security Id] from [core].SummitBondPosition_Instrument group by [Security Id] having COUNT(1) > 1)

	--	)A

	--	where a.Ranking > 1

	--)		

	

	--Log affected rows

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SummitBondPosition_Instrument dimension'

	EXEC [core].p_LogInfo @ProcedureName, @Message

	

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	

	-- Instrument Type Dimension

	INSERT into [core].SummitBondPosition_InstrumentType (

		[coreSourceKey]

		,[InstrumentType] 

		,[InstrumentSubType]

	)

	SELECT DISTINCT

		S.CoreSourceKey

		 ,isnull(R.[Security Type],'')

		 ,isnull(R.[Security Sub Type],'')

	FROM

		[raw].SummitBondPosition R

	join

		[core].SummitBondPosition_Source S

		on

			S.Source = isnull(R.[Summit],'UNKNOWN')

			and

			S.Origin = isnull(R.[Summit],'UNKNOWN')

	

		

	--Log affected rows

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SummitBondPosition_InstrumentType dimension'

	EXEC [core].p_LogInfo @ProcedureName, @Message



	--#----------------------------------------------- Populate the SummitBondPosition Fact ---------------------------------------------#--





	INSERT INTO [core].SummitBondPosition_Fact (

		  [CoreSourceKey]

		, [CoreHierarchyKey]

		, [CoreInstrumentKey]

		, [CoreInstrumentTypeKey]

		, [CoreCountryKey]

		, [CoreRatingKey]

		, [BusDate]

		, [Trade Type]

		, [TradeOrValuePerspective]

		, [Position_TradeDate]

		, [Position_ValueDate]

		, [WABP]

		, [StartAccrual]

		, [EndAccrual]

		, [ValueDateAccrual]

		, [Daily Amort]

		, [Amortised]

		, [Unamortised]

		, [PurchaseIntTVD]

		, [PremiumDiscountTVD]

		, [BookValue]

		, [BookValueGBP]

		, [MarketValue]

		, [MarketValueGBP]

		, [MarketValueDP]

		, [MarketValueDPGBP]

		, [dmAssetId]

		, [Realised PnL]

		, [NPV]

		, [FXRate12]

		, [PosValDateNPV]

		, [Company]

		, [Notiona_Quantity]

		, [PorR]

		, [Interest_Days]

		, [Coupon_Amount]

		, [OUR_Custodian]

		, [OUR_Nostro]

		, [Hard_Call_Date]

		, [Notes_Remarks1]

		, [Notes_Remarks2]

		, [CaptureSystem]

		, [LastTradedDate]

		, [LastTradedNotional]

	)



	SELECT

		 isnull(S.[CoreSourceKey],0) as [CoreSourceKey]		

		,isnull(H.[CoreHierarchyKey],0)as [CoreHierarchyKey]

		,isnull(I.[coreInstrumentKey],0) as [CoreInstrumentKey]

		,isnull(T.[coreInstrumentTypeKey],0) as [CoreInstrumentTypeKey]

		,isnull(C.[CoreCountryKey],0) as [CoreCountryKey]

		,isnull(R.[CoreRatingKey],0) as [CoreRatingKey]

		,CONVERT(DATETIME2, P.[COB Date], 103) as [BusDate]

		,P.[Trade Type]

		,'T'

		,P.[Position_TradeDate]

		,P.[Position_ValueDate]

		,P.[WABP]

		,P.[StartAccrual]

		,P.[EndAccrual]

		,P.[ValueDateAccrual]

		,P.[Daily Amort]

		,P.[Amortised]

		,P.[Unamortised]

		,P.[PurchaseIntTVD]

		,P.[PremiumDiscountTVD]

		,P.[BookVal]

		,P.[BookValGBP]

		,P.[MarkeVal]

		,P.[MarketValGBP]

		,P.[MarkeValDP]

		,P.[MarketValDPGBP]

		,P.[dmAssetId]

		,P.[Realised PnL]

		,P.[NPV]

		,P.[FXRate12]

		,P.[PosValDateNPV]

		,P.[Company]

		,P.[Notional_Quantity]

		,P.[PorR]

		,P.[Interest_Days]

		,P.[Coupon_Amount]

		,P.[OUR_Custodian]

		,P.[OUR_Nostro]

		,CASE WHEN P.[Hard_Call_Date] <> '' THEN CONVERT(DATETIME2, P.[Hard_Call_Date], 103) ELSE NULL END as [Hard_Call_Date]

		,P.[Notes_Remarks1]

		,P.[Notes_Remarks2]

		,P.[CaptureSystem]

		,CASE WHEN P.[LastTradedDate] <> '' THEN CONVERT(DATETIME2, P.[LastTradedDate], 103) ELSE NULL END as [LastTradedDate]

		,P.[LastTradedNotional]

	FROM

		[raw].SummitBondPosition P

		LEFT JOIN

		[core].SummitBondPosition_Source S

		ON

			S.[Source] = isnull(P.[Summit],'UNKNOWN')

			and

			S.[Origin] = isnull(P.[Summit],'UNKNOWN')

		LEFT JOIN

		[core].SummitBondPosition_Hierarchy H

		ON 

			H.[NodeName] = P.[Book]

			and	

			H.[BookSystem] = ISNULL(P.[Summit], 'Risk Management')

		LEFT JOIN

		[core].SummitBondPosition_Instrument I

		ON 

			P.[Security Id] = I.[Product]

		LEFT JOIN

		[core].SummitBondPosition_InstrumentType T

		ON 

			isnull(P.[Security Type],'') = T.[InstrumentType]

			AND isnull(P.[Security Sub Type],'')  = T.[InstrumentSubType]		 

		LEFT JOIN

		[core].SummitBondPosition_Country C 

		ON 

			P.[Issuer Physical Country] = C.[IssuerPhysicalCountry]

			and P.[Issue Log Country] = C.[IssuerLogCountry]

			and COALESCE(P.[SecCountry], P.[Issuer Physical Country], P.[Issue Log Country]) = C.[SecCountry]

		LEFT JOIN

		[core].SummitBondPosition_Rating R 

		ON 

			isnull(P.[SecS&P_RISKRATE],'') = R.[SecSandP_RISKRATE]

			and isnull(P.[SECMoodys_RISKRATE],'') = R.[SECMoodys_RISKRATE]

			and isnull(P.[INTERNAL_RISKRATE],'') = R.[INTERNAL_RISKRATE]

			and isnull(P.[SecECAI_RiskRate],'') = R.[SecECAI_RiskRate]

			and isnull(P.[SecHBOS_RiskRate],'') = R.[SecHBOS_RiskRate]

			and isnull(P.[Fitch_RiskRate],'') = R.[Fitch_RiskRate]

	



	--Log affected rows

	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(10)) + ' rows into core.SummitBondPosition fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--Log completion
	EXEC [core].[p_MonitorEvent]  @sessionID, @Env, @DataFeed, @BusDate,'SummitBondPosition data successfully split into a star.','G', @insertedCount

END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH


	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
