/****** Object:  StoredProcedure [core].[p_CreateStar_Hierarchy]    Script Date: 11/17/2017 15:29:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_CreateStar_Hierarchy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_CreateStar_Hierarchy]
GO

CREATE PROC [core].[p_CreateStar_Hierarchy]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@HierarchyTag INT,
	@SessionID	INT		= 0
)
AS

BEGIN
 
	--SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE
		@return_status		INT,
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@BusinessLogicSev	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@maxrow				BIGINT;
 
	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@Message			= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message

--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	 
	--First empty the snowflake ready for new data
	TRUNCATE TABLE [core].Hierarchy_Source
	TRUNCATE TABLE [core].Hierarchy_Hierarchy
	TRUNCATE TABLE [core].Hierarchy_HierarchyBook

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'Hierarchy_Source'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'Hierarchy_Hierarchy'
    
    SET @Message = 'Param: HierarchyTag = ''' + cast(@HierarchyTag as varchar(10)) + ''''
	EXEC [core].p_LogDebug @ProcedureName, @Message

    SET @Message = 'Param: DataFeed = ''' + @DataFeed + ''''
	EXEC [core].p_LogDebug @ProcedureName, @Message

	--#--------------------------------------------- Populate the Source Dimension -----------------------------------------#--

	--Source Dimension
	INSERT INTO [core].Hierarchy_Source (
		 [CoreSourceKey]
		,[InterfaceName]
		,[Environment]
		,[Source]
		,[Origin])
	VALUES (
		1
		,@DataFeed
		,@Env
		,'Hierarchy'
		,'Hierarchy'
	)
	INSERT INTO [core].Hierarchy_Source (
		 [CoreSourceKey]
		,[InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	)
	select 
			ROW_NUMBER() OVER (ORDER BY ISNULL([SourceOrigin],'UNKNOWN')) + 1
			,@DataFeed
			,@Env
			,@DataFeed
			,ISNULL([SourceOrigin],'UNKNOWN')
	from 
	(

			SELECT SourceOrigin FROM [raw].Hierarchy 
			UNION
			select 'UNKNOWN_RFB'
			UNION
			select 'UNKNOWN_NRFB'
	)V		
	GROUP BY
		ISNULL([SourceOrigin],'UNKNOWN')
	

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Hierarchy_Source dimension';
	EXEC [core].p_LogInfo @ProcedureName, @Message;
	
	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--
	WITH TradingRiskNodes (RiskNodeID, RiskNodeParentID)
	AS
	(
		-- Anchor
		SELECT
			RiskNodeID,
			RiskNodeParentID
		FROM
			raw.Hierarchy
		WHERE
			RiskNodeType = 'BO'
			
		UNION ALL

		-- Recursive, for all the parents, grandparents, etc to the anchor
		SELECT
			H.RiskNodeID,
			H.RiskNodeParentID
		FROM
			raw.Hierarchy H
			JOIN
			TradingRiskNodes T
			ON
				H.RiskNodeID = T.RiskNodeParentID
	)

	--Transfor the raw Hierarchy data into core
	INSERT INTO [core].Hierarchy_Hierarchy (
		 [CoreHierarchyKey]
		,[CoreSourceKey]
		,[NodeId]
		,[NodeParentID]
		,[NodeName]
		,[NodeType]
		,[BookLegalEntity]
		--,[BookCad2]
		,[Reporting]
		,[Ordinality]
		--,[Trading]
		,[RingFenced]
        ,[Group]
        ,[SubGroup]
		,[Business]
		,[BusinessArea]
		,[Division]
		,[Desk]
		,[SubDesk]
		,[Book]
		,[BookSystem]
		,[HierarchyString]
		,[HierarchyTag]
	)
	SELECT
		 ROW_NUMBER() OVER (ORDER BY A.NodeID)
		,A.*
	FROM (
		SELECT distinct
			 S.CoreSourceKey
			,V.RiskNodeId NodeID
			,isnull(V.RiskNodeParentID,0) NodeParentID
			,V.RiskNodeName
			,V.RiskNodeType
			,V.LegalEntity
			--,ISNULL(V.CAD, 0) [CAD]
			,ISNULL(V.Reporting, 0) [Reporting]
			,V.Ordinality
			--,1 Trading
            ,V.RingFenced
			,(CASE WHEN V.RiskNodeType = 'GR' THEN RiskNodeName END) [Group]
            ,(CASE WHEN V.RiskNodeType = 'SG' THEN RiskNodeName END) [SubGroup]
			,(CASE WHEN V.RiskNodeType = 'BU' THEN RiskNodeName END) [Business]
			,(CASE WHEN V.RiskNodeType = 'BA' THEN RiskNodeName END) [BusinessArea]
			,(CASE WHEN V.RiskNodeType = 'DV' THEN RiskNodeName END) [Division]
			,(CASE WHEN V.RiskNodeType = 'DE' THEN RiskNodeName END) [Desk]
			,(CASE WHEN V.RiskNodeType = 'SD' THEN RiskNodeName END) [SubDesk]
			,(CASE WHEN V.RiskNodeType = 'BO' THEN RiskNodeName END) [Book]
			,isnull(V.SourceOrigin, 'Risk Management') [BookSystem]					-- this shouldn't happen, but if it does blame Risk Platforms
			,V.HierarchyString [HierarchyString]
			,@HierarchyTag as [HierarchyTag]
		FROM
			[raw].Hierarchy V
			JOIN
			TradingRiskNodes T
			ON
				V.RiskNodeID = T.RiskNodeID
			JOIN
			[core].[Hierarchy_Source] S
			ON
				@DataFeed = S.Source
				AND
				ISNULL(V.[SourceOrigin],'UNKNOWN') = S.Origin
				AND S.Environment = @Env
				And S.InterfaceName = @DataFeed
	) A

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Hierarchy_Hierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message;
	    
       --Get Max key for use in offsetting new keys          
      set @MaxRow = (select ISNULL(Min([NodeID]),0) from [target].[Hierarchy])-1;


	  -- Only inserts unknowns if they don't already appear within target.hierarchy
      -- To be run as the last step in the process of splitting out the star from the RAW Hierarchy data.      
       WITH Unknowns (
                  [CoreHierarchyKey]
                  ,[CoreSourceKey]
                  ,[NodeName]
                  ,[NodeType]
                  ,[BookLegalEntity]
                  ,[Ordinality]
                  ,[Reporting]
                  ,[RingFenced]
                  ,[Group]
                  ,[SubGroup]
                  ,[Business]
                  ,[BusinessArea]
                  ,[Division]
                  ,[Desk]
                  ,[SubDesk]
                  ,[Book]     
                  ,[BookSystem]
                  ,[HierarchyString]
                  ,[HierarchyTag])
            AS
            (
				-- Manufacture UNKNOWN default nodes for the Official Hierarchy (i.e. HierarchyTag = 0)
				(
				SELECT
					  (UnknownNodes.Seq-1)*-1 [CoreHierarchyKey]
					  ,1 [CoreSourceKey]
					  ,'UNKNOWN_' + UnknownNodes.NodeType NodeName
					  ,UnknownNodes.NodeType
						,'UNKNOWN' [BookLegalEntity]
					  ,1 [Ordinality]
					  ,1 [Reporting]
					  ,0  [RingFenced]
					  ,CASE WHEN UnknownNodes.Seq >=1 THEN 'LBG' END [Group]
					  --,'' [SubGroup]
					  ,CASE WHEN UnknownNodes.Seq >=2 THEN 'UNKNOWN_SG' END [SubGroup]
					  ,CASE WHEN UnknownNodes.Seq >=3 THEN 'UNKNOWN_BU' END [Business]
					  ,CASE WHEN UnknownNodes.Seq >=4 THEN 'UNKNOWN_BA' END [BusinessArea]
					  ,CASE WHEN UnknownNodes.Seq >=5 THEN 'UNKNOWN_DV' END [Division]
					  ,CASE WHEN UnknownNodes.Seq >=6 THEN 'UNKNOWN_DE' END [Desk]
					  ,CASE WHEN UnknownNodes.Seq >=7 THEN 'UNKNOWN_SD' END [SubDesk]
					  ,'' [Book]
					  ,'UNKNOWN' [BookSystem]
					  , '/LBG/'
					  + SUBSTRING('UNKNOWN_SG/UNKNOWN_BU/UNKNOWN_BA/UNKNOWN_DV/UNKNOWN_DE/UNKNOWN_SD/UNKNOWN_BO/',1,(Seq-1)*11) + ''[HierarchyString]
					 --, '/LBG' +  + SUBSTRING('/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/',1,(Seq*8)-8) + ''[HierarchyString]        
					  , @HierarchyTag  [HierarchyTag]
				FROM (SELECT 1 Seq, 'GR' NodeType UNION SELECT 2,'SG' UNION SELECT 3,'BU' UNION SELECT 4,'BA' UNION SELECT 5,'DV' UNION SELECT 6,'DE' 
					UNION SELECT 7,'SD' ) UnknownNodes
				WHERE @HierarchyTag = 0 AND UnknownNodes.Seq > 1
				)
				UNION
				
				-- Manufacture UNKNOWN default nodes for the AdHoc Hierarchy (i.e. HierarchyTag = 1)
				(
				SELECT * FROM (
					SELECT TOP 1000
						  ((UnknownNodes.Seq-2)*3 + SubGroups.Seq)*-1 [CoreHierarchyKey] 
						  ,1 [CoreSourceKey]
						  ,'UNKNOWN_' + UnknownNodes.NodeType NodeName
						  ,UnknownNodes.NodeType
							,'UNKNOWN' [BookLegalEntity]
						  ,1 [Ordinality]
						  ,1 [Reporting]
						  ,CASE WHEN SubGroups.SubGroup = 'RFB' THEN 1 ELSE 0 END [RingFenced]
						  ,CASE WHEN UnknownNodes.Seq >=1 THEN 'LBG' END [Group]
						  ,CASE WHEN UnknownNodes.Seq >=2 THEN SubGroups.SubGroup END [SubGroup]
						  ,CASE WHEN UnknownNodes.Seq >=3 THEN 'UNKNOWN_BU' END [Business]
						  ,CASE WHEN UnknownNodes.Seq >=4 THEN 'UNKNOWN_BA' END [BusinessArea]
						  ,CASE WHEN UnknownNodes.Seq >=5 THEN 'UNKNOWN_DV' END [Division]
						  ,CASE WHEN UnknownNodes.Seq >=6 THEN 'UNKNOWN_DE' END [Desk]
						  ,CASE WHEN UnknownNodes.Seq >=7 THEN 'UNKNOWN_SD' END [SubDesk]
						  ,CASE WHEN UnknownNodes.Seq >=8 THEN 'UNKNOWN_BO' END [Book]
						  ,SubGroups.SubGroup [BookSystem]
						  , '/LBG/' + SubGroups.SubGroup + '/'
						  + SUBSTRING('UNKNOWN_BU/UNKNOWN_BA/UNKNOWN_DV/UNKNOWN_DE/UNKNOWN_SD/UNKNOWN_BO/',1,(UnknownNodes.Seq-2)*11) + ''[HierarchyString]
						 --, '/LBG' +  + SUBSTRING('/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/UNKNOWN/',1,(Seq*8)-8) + ''[HierarchyString]        
						  , @HierarchyTag [HierarchyTag]
					FROM (SELECT 1 Seq, 'GR' NodeType UNION SELECT 2,'SG' UNION SELECT 3,'BU' UNION SELECT 4,'BA' UNION SELECT 5,'DV' UNION SELECT 6,'DE' 
					UNION SELECT 7,'SD' ) UnknownNodes
						  CROSS JOIN (SELECT 1 Seq, 'RFB' SubGroup UNION SELECT 2, 'NRFB' UNION SELECT 3, 'UNKNOWN_SG') SubGroups
					WHERE @HierarchyTag = 1 AND UnknownNodes.Seq > 1
					ORDER BY SubGroups.Seq Desc
				) SubGroup_Grouping_Of_Output
				WHERE HIERARCHYSTRING NOT IN ('/LBG/RFB/','/LBG/NRFB/') -- not required as already valid nodes for these
				)			
		)
	   	INSERT INTO [core].[Hierarchy_Hierarchy](
            [CoreHierarchyKey]
			,[CoreSourceKey]
            ,[NodeId]
            ,[NodeParentID]
            ,[NodeName]
            ,[NodeType]
            ,[BookLegalEntity]
            ,[Ordinality]
            ,[Reporting]
            ,[RingFenced]
            ,[Group]
            ,[SubGroup]
            ,[Business]
            ,[BusinessArea]
            ,[Division]
            ,[Desk]
            ,[SubDesk]
            ,[Book]     
            ,[BookSystem]
            ,[HierarchyString]
            ,[HierarchyTag]
        )
		SELECT		
          [CoreHierarchyKey]
          ,[CoreSourceKey]
          ,(ROW_NUMBER() OVER(ORDER BY U.HierarchyString) - @MaxRow )*-1 [NodeID]
		  ,CASE U.NodeType
				WHEN 'SG' THEN (SELECT NODEID FROM CORE.Hierarchy_Hierarchy WHERE NodeType = 'GR' AND NodeName = 'LBG') 
				WHEN 'BU' THEN (CASE WHEN @HierarchyTag=0 THEN [CoreHierarchyKey] + @MaxRow + 1
					 				 ELSE (CASE WHEN U.SUBGROUP <> 'UNKNOWN_SG' THEN (SELECT SG.NODEID FROM CORE.Hierarchy_Hierarchy SG WHERE SG.NodeType = 'SG' AND SG.NodeName = U.SubGroup)
									  		    ELSE (ROW_NUMBER() OVER(ORDER BY U.HierarchyString) + ABS(@MaxRow)-1)*-1
											 	END)
									 END)
				ELSE (ROW_NUMBER() OVER(ORDER BY U.HierarchyString) + ABS(@MaxRow)-1)*-1
				END [NodeParentID]	
          ,U.[NodeName]
          ,U.[NodeType]
          ,U.[BookLegalEntity]
          ,U.[Ordinality]
          ,U.[Reporting]
          ,U.[RingFenced]
          ,U.[Group]
          ,U.[SubGroup]
          ,U.[Business]
          ,U.[BusinessArea]
          ,U.[Division]
          ,U.[Desk]
          ,U.[SubDesk]
          ,U.[Book]     
          ,U.[BookSystem]
          ,U.[HierarchyString]
          ,U.[HierarchyTag]
      FROM Unknowns U
      left outer join target.hierarchy H
		  on u.NodeName = h.NodeName
		  and u.NodeType = h.NodeType
		  and u.BookSystem = h.BookSystem
		  and u.BookLegalEntity = h.BookLegalEntity
		  and u.HierarchyTag = h.HierarchyTag
		  and h.Finish = '99991231'
	  where h.HierarchyKey is null
      ORDER BY ROW_NUMBER() OVER(ORDER BY U.HierarchyString)
      
     -- select * from core.Hierarchy_Hierarchy where NodeName like '%unknown%'
      
	--Log affected rows
 	SET @Message = 'Create Deafault UNKNOWN nodes for orphaned Books '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Hierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message;
	
	------------------------------------ populate hierarchy books----------------------------------

	WITH TradingRiskNodes (RiskNodeID, RiskNodeParentID)
	AS
	(
		-- Anchor
		SELECT
			RiskNodeID,
			RiskNodeParentID
		FROM
			raw.Hierarchy
		WHERE
			RiskNodeType = 'BO'
			
		UNION ALL

		-- Recursive, for all the parents, grandparents, etc to the anchor
		SELECT
			H.RiskNodeID,
			H.RiskNodeParentID
		FROM
			raw.Hierarchy H
			JOIN
			TradingRiskNodes T
			ON
				H.RiskNodeID = T.RiskNodeParentID
	)

	insert into core.Hierarchy_HierarchyBook 
	(
	     [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeId]
		,[NodeName]
		,[NodeType]
		,[BookCad2]
		,[Trading]
		,[BookSystem]
	)
	select ROW_NUMBER() OVER (ORDER BY H.RiskNodeID)
	 ,1
	  ,H.[RiskNodeId]
      ,H.[RiskNodeName]
      ,H.[RiskNodeType]
      ,H.[Cad]
      ,H.[Trading]
      ,H.SourceOrigin
      
     from raw.Hierarchy H 
     JOIN
			(select distinct * from TradingRiskNodes) T
			ON
				H.RiskNodeID = T.RiskNodeID
   --  JOIN
			--[core].[Hierarchy_Source] S
			--ON
			--	@DataFeed = S.Source
			--	AND
			--	ISNULL(H.[Source],'UNKNOWN') = S.Origin
			--	AND S.Environment = @Env
			--	And S.InterfaceName = @DataFeed
     where RiskNodeType = 'BO'
		
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Hierarchy_Book dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
END TRY

--#---------------------------------------------- END OF SNOWFLAKE CODE -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END



GO


