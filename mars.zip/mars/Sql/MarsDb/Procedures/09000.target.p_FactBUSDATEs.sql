IF OBJECT_ID ('target.p_FactBUSDATEs') IS NOT NULL
	DROP PROCEDURE target.p_FactBUSDATEs
GO

CREATE PROCEDURE [target].[p_FactBUSDATEs]
	( 
	@FactName AS VARCHAR(50),	-- The name of a Fact table (excluding the '_Fact' postfix or NULL for all tables
	@TimeTravel BIT				-- Use 1 for valid business dates in the Timetraveling range, else 0 for all available dates
	)
AS 
BEGIN
	DECLARE @Facts table(ID varchar(50))
	DECLARE @i bigint
	DECLARE @FactTableName nvarchar(50)
	DECLARE @nSQL nvarchar(MAX)
	
	IF @FactName IS NOT NULL
		IF @TimeTravel = 0
			EXECUTE('SELECT DISTINCT BUSDATE FROM [target].[' + @FactName + '_Fact]')
		ELSE
			EXECUTE('SELECT DISTINCT F.BUSDATE FROM [target].[' + @FactName + '_Fact] F 
						JOIN TimeTravel T 
						ON F.START <= T.VersionDateTime AND F.FINISH > T.VersionDateTime')
	ELSE
	BEGIN
		INSERT @Facts EXECUTE [target].[p_FactNames]
		SET @I = 1
		SET @nSQL = ''
		WHILE @I<= (SELECT COUNT(*) FROM @Facts)
		BEGIN
			SET @FactTableName = (SELECT X.ID + '_Fact' FROM (SELECT ID, RANK() OVER (ORDER BY ID) POS FROM @Facts) X WHERE X.POS = @I)
			SET @nSQL = @nSQL + 'SELECT DISTINCT F.BUSDATE FROM [target].[' + @FactTableName + '] F '
			IF @TimeTravel = 1
				SET @nSQL = @nSQL + 'JOIN TimeTravel T 
										ON F.START <= T.VersionDateTime AND F.FINISH > T.VersionDateTime '
			IF @I<> (SELECT COUNT(*) FROM @Facts) SET @nSQL = @nSQL + 'UNION '
			--EXECUTE('SELECT DISTINCT BUSDATE FROM [target].[' + @FactTableName + ']')
			SET @I=@I+1
		END	
		EXECUTE(@nSQL)
	END
	
   RETURN

END
GO
