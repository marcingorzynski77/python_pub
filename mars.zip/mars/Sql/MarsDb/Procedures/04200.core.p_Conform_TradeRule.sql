/****** Object:  StoredProcedure [core].[p_Conform_TradeRule]    Script Date: 08/29/2017 15:44:57 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Conform_TradeRule]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_Conform_TradeRule]
GO

CREATE PROC [core].[p_Conform_TradeRule]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT	= 0
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE
		@ProcedureName				NVARCHAR(128),
		@InitialTranCount			BIGINT,
		@Message					NVARCHAR(MAX),
		@Origin						VARCHAR(30),
		@EndDate					DATETIME2,
		@InsertedCount				BIGINT,
		@return_value				BIGINT,
		@ReStatement				BINARY		= 0,
		@RowCount					BIGINT,
		@SQL						nvarchar(MAX);

    -- Legacy Core2Target
    DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7),
		@ExpireDimensionData		BINARY,
		@MaxRow						BIGINT

    -- Core, Staging & Target Synchronisation Parameters
    DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@FactTableSync				INT		= 0,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0

    SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
    	@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName,
		@EndDate			= CAST('9999-12-31' AS DATETIME2);


    --Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY


--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
--Expiring standard conformation logic due to the time it takes for the ~8m rules. Plus, this table will only ever be used by the RRR source and 
--also the rows will always be new to the 'firedat' field. Therefore merging is pointless. Best to save the time and just to a straight expire  
--and insert.
--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


	declare @SourceKey as int
	set @SourceKey = (Select SourceKey from target.Source where InterfaceName = 'RRR' and Environment = @Env and Source = 'RRR' and Origin = 'Simra')
		

	--expire previous versions of the busdate
	update target.TradeRule
		set Finish = @NowDate
	where Finish = '99991231'
		and BusDate = @BusDate
	
	SET @Message = CAST(@@ROWCOUNT AS VARCHAR(30)) + ' rows expired in ' + @TargetTable 
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	
	--insert the new rules
	insert into target.TradeRule
	(
		Start
		,Finish
		,BusDate
		,TradeReference
		,RuleName
		,FiredAt
--		,RuleType	
--		,RuleValue
		,SourceKey
		,AppliedRules
	)
	select @NowDate
			,'99991231'
			,busdate
			,TradeReference
			,RuleName
			,FiredAt
--			,RuleType	
--			,RuleValue
			,@SourceKey
			,''
	from core.RRR_TradeRule
	
	SET @Message = CAST(@@ROWCOUNT AS VARCHAR(30)) + ' rows inserted into ' + @TargetTable 
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	
END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#--------------------------------------------------------------------------------------------------------------------#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END



GO


