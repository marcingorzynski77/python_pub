IF OBJECT_ID ('core.p_Control_GDIRiskMeasureTrade') IS NOT NULL
	DROP PROCEDURE core.p_Control_GDIRiskMeasureTrade
GO

CREATE PROC [core].[p_Control_GDIRiskMeasureTrade]
(
	@Datafeed			VARCHAR(64),
	@AsOfBusDate		DATETIME2,
	@Env				VARCHAR(6),
	@ExecutionTime		DATETIME2(7)	= NULL,
	@Debug				INT				= 0
)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@SourceKey			BIGINT,
		@NowDate			DATETIME2;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;
		

	--Start logging session
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	SET @Message = 'Start of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--Split raw data into a star
	EXEC [core].p_CreateStar_GDIRiskMeasureTrade	@AsOfBusDate, @NowDate, @DataFeed, @Env

	-- Conform the raw star dimensions with Target dimensions
	EXEC [core].p_Conform_Source					@AsOfBusDate, @NowDate, @DataFeed, @Env	
	EXEC [core].p_Conform_HierarchyBook				@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_Hierarchy					@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_RiskMeasureType			@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_RiskFactor				@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_InstrumentType			@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_Counterparty				@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_Tenor						@AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_Trade						@AsOfBusDate, @NowDate, @DataFeed, @Env, @Debug = @Debug
	
	--Update the Target facts with the star dimensions
	EXEC [core].p_UpdateFact_RiskMeasureTrade		@AsOfBusDate, @NowDate, @DataFeed, @Env

	--Take note of load date
	EXEC [core].[p_Insert_TimeTravellingInstance]	@AsOfBusDate, @NowDate, @DataFeed, @Env, 'RiskMeasureTrade'

	DECLARE @Stats Flex_LoadStatsParameters

	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT * FROM [core].f_RiskMeasureTradeFactMonitor (
		 'RiskMeasureTrade' 		--		 @FactType	VARCHAR(64)
		,@DataFeed 			--		,@Interface	VARCHAR(64)
		,@Env
		,@AsOfBusDate 		--		,@BusDate	DATETIME2
		,@NowDate			--		,@Now		DATETIME2
	)

	EXEC [core].p_Flex_UpdateLoadStats @AsOfBusDate, @NowDate, 'RiskMeasureTrade', @Stats

	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
	
    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO