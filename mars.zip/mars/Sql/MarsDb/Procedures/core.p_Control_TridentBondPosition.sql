IF OBJECT_ID ('core.p_Control_TridentBondPosition') IS NOT NULL
	DROP PROCEDURE core.p_Control_TridentBondPosition
GO

CREATE PROC [core].[p_Control_TridentBondPosition] 
(
	@DataFeed		VARCHAR(64),
	@AsOfBusDate	DATETIME2,
	@Env			VARCHAR(6)
)
AS 

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@ErrorNumber		INT,
		@ErrorSeverity      INT,
		@ErrorState			INT,
		@ErrorLine			INT,
		@ErrorMessage		VARCHAR(MAX),
		@ErrorProcedure		NVARCHAR(128),
		@Comment			VARCHAR(1000),
		@SessionID			BIGINT,
		@SourceKey			BIGINT,	
		@NowDate			DATETIME2;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= GETUTCDATE(),  	
		@ErrorNumber	= 0,
		@SourceKey		= (SELECT SourceKey 
				             FROM target.Source 
				            WHERE InterfaceName = @DataFeed 
					          AND [Source] is null 
					          AND Environment = @env
					          AND @NowDate >= Start
					          AND @NowDate < Finish
			);

	--Start logging session		
	EXEC [core].p_LogInfo @ProcedureName, @Message
	SET @SessionID = @@IDENTITY

	--Log to Monitor
	EXEC [core].p_MonitorEvent  @SessionID, @Env, @DataFeed, @AsOfBusDate, @Comment, 'G', 0

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	EXEC [core].p_LogEvent @Comment = 'Start of processing', @SessionID = @SessionID, @procedureName = @procedureName

	--Split raw data into a star
	EXEC [core].p_CreateStar_TridentBondPosition @AsOfBusDate, @DataFeed, @Env, @SessionID

	--Conform the raw star dimensions with Target dimensions	
	EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env, @SessionID 	
	Exec [core].p_Conform_Hierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env, @SessionID 
	EXEC [core].p_Conform_Instrument @AsOfBusDate, @NowDate, @DataFeed, @Env, @SessionID

	--Update the Target facts with the star dimensions
	EXEC [core].p_UpdateFact_Position @AsOfBusDate, @NowDate, @DataFeed, @Env, @SessionID
--	EXEC [core].p_UpdateFact_CDSTrades @AsOfBusDate, @NowDate, @DataFeed, @Env, @SessionID

	--Finish logging
	EXEC [core].p_LogEvent @UpdateType = 'Finish', @SessionID = @SessionID,  @ProcedureName = @ProcedureName

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    SELECT 
        @ErrorNumber	= ERROR_NUMBER()    ,
        @ErrorSeverity	= ERROR_SEVERITY()  ,
        @ErrorState	= ERROR_STATE()     ,
        @ErrorMessage	= ERROR_MESSAGE()   ,
        @ErrorLine	= ERROR_LINE()	    ;

    --Log error
    EXEC [core].p_LogEvent
		 @SessionID = @SessionID
		,@ErrorNumber = @ErrorNumber
		,@ProcedureName=@ProcedureName
		,@ProcID = @@ProcID
		,@ErrorProcedure = @ProcedureName
		,@ErrorSeverity = @ErrorSeverity
		,@ErrorState = @ErrorState
		,@ErrorMessage = @ErrorMessage
		,@NESTLEVEL = @@NESTLEVEL
		,@ErrorLine = @ErrorLine
		,@Comment = 'There has been an Error'
		,@messageTypeId = 3
		,@UpdateType = 'Error'		
	
	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT
	
END CATCH;

RETURN @ErrorNumber

END
GO