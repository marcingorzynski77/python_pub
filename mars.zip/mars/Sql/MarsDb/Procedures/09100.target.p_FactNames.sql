IF OBJECT_ID ('target.p_FactNames') IS NOT NULL
	DROP PROCEDURE target.p_FactNames
GO

CREATE PROCEDURE [target].[p_FactNames]
AS 
BEGIN

	DECLARE @nSQL nVARCHAR(4000)
	SET @nSQL = ''
	SET @nSQL = @nSQL + ' DECLARE @genSQL nVARCHAR(4000); '
	SET @nSQL = @nSQL + 'SET @genSQL = ~SELECT SUBSTRING(T.Name,1,LEN(T.Name)-5) Fact
		FROM SYS.columns C
		JOIN SYS.tables T ON C.object_id = T.object_id
		JOIN SYS.schemas S ON S.schema_id = T.schema_id
		WHERE S.name = #TARGET#
			AND T.name LIKE #%_FACT# AND type_desc = #USER_TABLE#
			AND C.name in (#Start#,#Finish#) and system_type_id = 42 -- Datetime2
		GROUP BY T.Name
		HAVING COUNT(T.Name)=2 ~;'
	SET @nSQL = @nSQL + ' SET @genSQL = replace (@genSQL,char(35),char(39)); ' -- Exchange # for quote
	SET @nSQL = @nSQL + ' exec sp_executesql @genSQL'
	--PRINT @nSQL
	SET @nSQL = replace (@nSQL,char(126),char(39))
	EXECUTE(@nSQL)
	
   RETURN

END
GO
