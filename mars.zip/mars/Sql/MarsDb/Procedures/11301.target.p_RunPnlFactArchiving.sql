IF OBJECT_ID ('target.p_RunPnlFactArchiving') IS NOT NULL
	DROP PROCEDURE target.p_RunPnlFactArchiving
GO

-- exec [target].[p_RunPnlFactArchiving] '2017-03-01'
CREATE PROC [target].[p_RunPnlFactArchiving] 
(
	@BusinessDate DATETIME2
)
AS 

	SET NOCOUNT ON
	
	DECLARE		
        @ProcedureName  	NVARCHAR(128),
        @Message 	    	VARCHAR(1000),   
        @SQL 	    	    NVARCHAR(4000),        
		@return_value		BIGINT		
       
	SET @Message = 'Invoking p_RunPnlFactArchiving with ' + CAST(@BusinessDate as varchar(30)) 
	
BEGIN TRY

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--
Print 'Preparing commands'
		--Recursive loop to determine all parent nodes
IF EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_PnL_Fact_History]') AND parent_object_id = OBJECT_ID(N'[target].[PnL_Fact_History]'))
ALTER TABLE [target].[PnL_Fact_History] DROP CONSTRAINT [CHK_PnL_Fact_History]

SET @SQL = 'ALTER TABLE [target].[PnL_Fact_History] ADD CONSTRAINT [CHK_PnL_Fact_History] CHECK  (([BusDate]<='''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
EXEC sp_executesql @SQL

--ALTER TABLE [target].[PnL_Fact_History] CHECK CONSTRAINT [CHK_PnL_Fact_History]

IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_PnL_Fact]') AND parent_object_id = OBJECT_ID(N'[target].[PnL_Fact]'))
ALTER TABLE [target].[PnL_Fact] DROP CONSTRAINT CHK_PnL_Fact

SET @SQL = 'ALTER TABLE [target].[PnL_Fact] ADD CONSTRAINT CHK_PnL_Fact CHECK  (([BusDate]>'''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
 EXEC sp_executesql @SQL
 
 ------------ RiskMeasure_Fact_History---------------------------------

 IF EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_RiskMeasure_Fact_History]') AND parent_object_id = OBJECT_ID(N'[target].[RiskMeasure_Fact_History]'))
ALTER TABLE [target].[RiskMeasure_Fact_History] DROP CONSTRAINT [CHK_RiskMeasure_Fact_History]

SET @SQL = 'ALTER TABLE [target].[RiskMeasure_Fact_History] ADD CONSTRAINT [CHK_RiskMeasure_Fact_History] CHECK  (([BusDate]<='''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
EXEC sp_executesql @SQL



IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_RiskMeasure_Fact]') AND parent_object_id = OBJECT_ID(N'[target].[RiskMeasure_Fact]'))
ALTER TABLE [target].[RiskMeasure_Fact] DROP CONSTRAINT CHK_RiskMeasure_Fact

SET @SQL = 'ALTER TABLE [target].[RiskMeasure_Fact] ADD CONSTRAINT CHK_RiskMeasure_Fact CHECK  (([BusDate]>'''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
 EXEC sp_executesql @SQL
 
  ------------ MarketData_Fact_History---------------------------------

IF EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_MarketData_Fact_History]') AND parent_object_id = OBJECT_ID(N'[target].[MarketData_Fact_History]'))
ALTER TABLE [target].[MarketData_Fact_History] DROP CONSTRAINT [CHK_MarketData_Fact_History]

SET @SQL = 'ALTER TABLE [target].[MarketData_Fact_History] ADD CONSTRAINT [CHK_MarketData_Fact_History] CHECK  (([BusDate]<='''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
EXEC sp_executesql @SQL



IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_MarketData_Fact]') AND parent_object_id = OBJECT_ID(N'[target].[MarketData_Fact]'))
ALTER TABLE [target].[MarketData_Fact] DROP CONSTRAINT CHK_MarketData_Fact

SET @SQL = 'ALTER TABLE [target].[MarketData_Fact] ADD CONSTRAINT CHK_MarketData_Fact CHECK  (([BusDate]>'''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
 EXEC sp_executesql @SQL
 
   ------------ VaR_Fact_History---------------------------------

IF EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_VaR_Fact_History]') AND parent_object_id = OBJECT_ID(N'[target].[VaR_Fact_History]'))
ALTER TABLE [target].[VaR_Fact_History] DROP CONSTRAINT [CHK_VaR_Fact_History]

SET @SQL = 'ALTER TABLE [target].[VaR_Fact_History] ADD CONSTRAINT [CHK_VaR_Fact_History] CHECK  (([BusDate]<='''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
EXEC sp_executesql @SQL


IF  EXISTS (SELECT * FROM sys.check_constraints WHERE object_id = OBJECT_ID(N'[target].[CHK_VaR_Fact]') AND parent_object_id = OBJECT_ID(N'[target].[VaR_Fact]'))
ALTER TABLE [target].[VaR_Fact] DROP CONSTRAINT CHK_VaR_Fact

SET @SQL = 'ALTER TABLE [target].[VaR_Fact] ADD CONSTRAINT CHK_VaR_Fact CHECK  (([BusDate]>'''+cast(@BusinessDate as varchar(10))+'''))'
Print @SQL
 EXEC sp_executesql @SQL
	
END TRY

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH

GO
