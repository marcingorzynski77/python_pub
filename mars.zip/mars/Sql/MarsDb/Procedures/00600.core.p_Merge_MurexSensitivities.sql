IF OBJECT_ID ('core.p_Merge_MurexSensitivities') IS NOT NULL
	DROP PROCEDURE core.p_Merge_MurexSensitivities
GO

CREATE PROC [core].[p_Merge_MurexSensitivities]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT		= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--First empty the star ready for new data
	TRUNCATE TABLE [raw].MurexSensitivities_Merged

--#--------------------------------------------- Merge  ------------------------------------------#--

	Insert into raw.MurexSensitivities_Merged
	(
		BusDate,
		FINANCIAL_CONTRACT,
		TRADEDATETIME,
		Product,
		[Index],
		Portfolio,
		TradeType,
		[Buy/Sell],
		MIRRORED,
		TP_CMIQ0,
		Nominal_CCY,
		Nominal,
		Nominal_GBP,
		Maturity_date,
		Delivery_date,
		[P&L_CCY],
		Closing_MTM,
		Delta,
		Delta_GBP,
		Gamma,
		Gamma_GBP,
		Vega,
		Vega_GBP,
		Theta,
		Theta_GBP,
		Rho,
		Rho_GBP,
		[Rho(f)],
		Rhof_GBP,
		Swap_points,
		Instrument,
		Call_Put,
		Strike,
		[Status],
		[Booking Units],
		Units
	)
	SELECT DISTINCT
		C.GrkDate,
		T.FINANCIAL_CONTRACT,
		T.TRADEDATETIME,
		ISNULL(D.TP_CMDFYS0, 'UNKNOWN'),
		ISNULL(D.TP_CMILAB0, 'UNKNOWN'),
		S.Portfolio AS Portfolio,
		T.TRADESUBTYPE,
		S.[Buy/Sell],
		T.MIRRORED,
		ISNULL(D.TP_CMIQ0, 'UNKNOWN'),
		S.Nominal_CCY,
		cast(S.Nominal as float),
		cast(S.Nominal_GBP as float),
		S.Maturity_date,
		S.Delivery_date,
		S.[P&L_CCY],
		S.Closing_MTM,
		S.Delta,
		S.Delta_GBP,
		S.Gamma,
		S.Gamma_GBP,
		S.Vega,
		S.Vega_GBP,
		S.Theta,
		S.Theta_GBP,
		S.Rho,
		S.Rho_GBP,
		S.[Rho(f)],
		S.Rhof_GBP,
		S.Swap_points,
		S.Instrument,
		S.Call_Put,
		S.Strike,
		S.[Status],
		ISNULL(D.TP_CMLDU0, 'UNKNOWN'),
		CASE WHEN D.[TP_CMIQ0] IS NULL THEN 'UNKNOWN' ELSE Right(D.[TP_CMIQ0],Len(D.[TP_CMIQ0])- charindex('/',D.[TP_CMIQ0],0)) END
	FROM
		[raw].MurexSensitivities_Control C,		-- ONLY 1 ROW SO CARTESIAN JOIN IS OK
		[raw].MurexSensitivities_Com_grk S
		INNER JOIN 
		raw.MurexSensitivities_C_omi_commod T
		ON
			S.Trd_num = T.TRADEID
		LEFT JOIN 
		raw.MurexSensitivities_Comdata31 D
		ON
			T.MIRRORED = D.NB

	set @insertedCount = @@ROWCOUNT
	
	--Log affected rows
	SET @Message = 'Inserted '+ CAST((@insertedCount)AS VARCHAR(30)) + ' rows into [raw].[MurexSensitivies_Merged] table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#------------------------------------------------ END OF MERGE CODE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

RETURN 0;

END

GO