/****** Object:  StoredProcedure [target].[p_Get_FlexFactSchema]    Script Date: 03/29/2017 13:50:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_FlexFactSchema]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Get_FlexFactSchema]
GO

CREATE PROC [target].[p_Get_FlexFactSchema]
(
	 @FlexFact as varchar(50)
)
AS
BEGIN

SET NOCOUNT ON

	--Populate from data dictionary
	create table #Dictionary
	(
		[DataSetType] varchar(30)
		,[Data Set] varchar(30)
		,[Fact/Dimension] varchar(9)
		,[OriginalTable] varchar(30)
		,[Table] varchar(30)
		,[Field] varchar(30)
		,[OriginalDataType] varchar(20)
		,[DataType] varchar(20)
		,[Description] varchar(900)
	)	
	insert into #Dictionary
	exec [target].[p_Get_DataDictionary] '','ALL'
	
	select [Field] as 'COLUMN_NAME'
			,[DataType] as 'Data_Type'
			,'true' as 'IS_NULLABLE'			
	from #Dictionary 
	where [Data Set] = @FlexFact
	
	drop table #Dictionary
	
End

GO


