IF OBJECT_ID ('target.p_Get_QueryCatalogueHierarchy') IS NOT NULL
	DROP PROCEDURE target.p_Get_QueryCatalogueHierarchy
GO

CREATE PROC [target].[p_Get_QueryCatalogueHierarchy] 
(
	@Owner varchar(30)
)
AS 

BEGIN

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--

	SET NOCOUNT ON;

	--Recursive SQL to extract 
	WITH Hierarchy(ChildId, ChildName, Generation, ParentId, ParentName)
	AS
	(
		SELECT FirtGeneration.NodeId, FirtGeneration.NodeName, 0, FirtGeneration.ParentNodeId, H2.NodeName
			FROM core.QueryCatalogue_Hierarchy AS FirtGeneration
			left join core.QueryCatalogue_Hierarchy H2
			on H2.NodeID = FirtGeneration.ParentNodeID
			WHERE FirtGeneration.ParentNodeID IS NULL    
			and FirtGeneration.[Owner] = @Owner
		UNION ALL
		SELECT NextGeneration.NodeId, NextGeneration.NodeName, Parent.Generation + 1, Parent.ChildId, Parent.ChildName
			FROM core.QueryCatalogue_Hierarchy AS NextGeneration
			INNER JOIN Hierarchy AS Parent ON NextGeneration.ParentNodeId = Parent.ChildId    
	)
	SELECT *
		FROM Hierarchy
		ORDER BY Generation asc
		OPTION(MAXRECURSION 32767)
	 
	RETURN

--#-------------------------------------------------- END OF HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

END

GO
