IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Flex_InsertComment]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [core].[p_Flex_InsertComment]
GO

-- exec [target].[p_Flex_InsertComment] '2017-05-01', 'TEST', '2017-05-03', 'Comment', 'Blackcurrent beauty is delicious', 2
-- exec [target].[p_Flex_InsertComment] '2017-05-01', 'TEST', '2017-05-04', 'Comment', 'Camomile honey is even better', 2
CREATE PROCEDURE [target].[p_Flex_InsertComment]
( 
	  @BusDate DATETIME2, 
      @UserName VARCHAR(255), 
	  @NowDate DATETIME2,  
	  @Schema VARCHAR(128), 
	  @Comment VARCHAR(100), 
	  @SourceKey BIGINT
)
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE
        @ProcedureName		NVARCHAR(128),
		@Message		    NVARCHAR(MAX),
        @BusinessLogicSev	INT;

    SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@Message = 'Invoking ' + @ProcedureName;
		
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--    

BEGIN TRY
    
	SET @Message = 'Params: ''' + CONVERT(VARCHAR(20), @BusDate) + ''',''' + CONVERT(VARCHAR(20), @NowDate) + ''',''' +  @Schema + ''''
	EXEC [core].p_LogInfo @ProcedureName, @Message 
    
    DECLARE @EndDate DATETIME2 = CAST('9999-12-31' AS DATETIME2);

    DECLARE @FlexFactHierarchyKey AS BIGINT
    SELECT @FlexFactHierarchyKey = FlexFactHierarchyKey
      FROM target.FlexFactHierarchy
     WHERE [Description] = 'FeedLoadCheck.'+@Schema+'.Data'

    IF @FlexFactHierarchyKey IS NULL 
    BEGIN
        SET @Message = 'Unknown Flex Schema: ''FeedLoadCheck.' + @Schema+ '.Data'''
        RAISERROR (@Message, 10, 1);  
    END
	
	IF EXISTS (SELECT 1 
                 FROM target.FlexFact 
                WHERE BusDate = @BusDate 
                  AND SourceKey = @SourceKey 
                  AND FlexFactHierarchyKey = @FlexFactHierarchyKey 
                  AND Start < @NowDate 
                  AND Finish > @NowDate)
	BEGIN
		--expire existing fact 
		UPDATE target.FlexFact 
		   SET Finish = @NowDate
		 WHERE BusDate = @BusDate 
		   AND SourceKey = @SourceKey 
		   AND FlexFactHierarchyKey = @FlexFactHierarchyKey
		   AND Finish > @NowDate
	END
	
	SET @Message = 'Add Flex Fact: ' + CONVERT(VARCHAR(20), @SourceKey) + ',' + CAST(@BusDate AS VARCHAR(100))
	EXEC [core].p_LogDebug @ProcedureName, @Message

	DECLARE @FlexFactKey AS BIGINT
	INSERT INTO target.FlexFact (Start, Finish, BusDate, FlexFactHierarchyKey, SourceKey, UserName)
	VALUES (@NowDate, @EndDate, @BusDate, @FlexFactHierarchyKey, @SourceKey, @UserName)
    SET @FlexFactKey = SCOPE_IDENTITY()
	
	INSERT INTO target.FlexFactInstance (FlexFactKey,[Key],Value) values (@FlexFactKey,'Comment', @Comment)
	
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing' 
	
END TRY

--#------------------------------------------------- END OF PROCEDURE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0

END


