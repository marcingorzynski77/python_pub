IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_MergeStagingColumnData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [core].[p_MergeStagingColumnData]
GO

 
CREATE PROC [core].[p_MergeStagingColumnData]
(
	@NowDate					DATETIME2, 
	@DataFeed					VARCHAR(64), 
	@CoreTable					VARCHAR(100), 
	@TargetTable				VARCHAR(100), 
	@TargetBusinessKeyColumns	CORE.Core2TargetParameter READONLY,
	@Debug						INT = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE		@ColumnList				VARCHAR(MAX)
	,			@UnionColumnList		VARCHAR(MAX)
	,			@UnionCoreColumnList	VARCHAR(MAX)
	,			@BusinessKeyList		VARCHAR(MAX)
	,			@UnionBusinessKeyList	VARCHAR(MAX)
	,			@SqlMerge				NVARCHAR(MAX) = ''
	,			@StagingUpdatedCount	INT
	,			@CoalesceVarcharColumns VARCHAR(MAX)
	,			@Padding				INT = 30; 

		
	SET @Message =  ' @DataFeed: ' + @DataFeed + '; '
	IF (@Debug = 1) EXEC [core].p_LogDebug @ProcedureName, @Message
	SET @Message =  '@CoreTable : ' + @CoreTable + '; @TargetTable : ' + @TargetTable 
	IF (@Debug = 1) EXEC [core].p_LogDebug @ProcedureName, @Message

	
	SELECT		@ColumnList = NULL,	@UnionColumnList = NULL
	SELECT		@ColumnList = COALESCE(@ColumnList + ' ', '  ') + RIGHT(REPLICATE(' ',@Padding) + '[' + ColumnName + ']', @Padding) + ' = [TT].[' + ColumnName + ']
	'
	,			@UnionColumnList = COALESCE(@UnionColumnList + ', ', '  ') + '[TT].[' + ColumnName + ']'
	FROM		[core].[f_Target2CoreGetColumnGroups]('target.'+ @TargetTable, 'core.' + @CoreTable)
	WHERE		[Grouping] = 'Common'
	ORDER BY	ColumnName;
	
	;WITH columnList as
	(
		SELECT 
			ColumnName 
		FROM		[core].[f_Target2CoreGetColumnGroups]('target.'+ @TargetTable, 'core.' + @CoreTable)
		WHERE		[Grouping] = 'Common'
		EXCEPT
		SELECT 
			ID ColumnName
		FROM @TargetBusinessKeyColumns
	)	
	SELECT		@UnionCoreColumnList =  COALESCE(@UnionCoreColumnList + ', ', '') + '
		 [' + ColumnName + '] = [TT].[' + ColumnName + ']'
	FROM		columnList
	ORDER BY	ColumnName;

	SELECT	@BusinessKeyList = COALESCE(@BusinessKeyList, '') + '
		AND [TT].[' + ID + '] = [ST].[' + ID + ']'
	,		@UnionBusinessKeyList = COALESCE(@UnionBusinessKeyList + ', ', '') + '[TT].[' + ID + ']'
	FROM @TargetBusinessKeyColumns

	SET @Message =  '@Column List :	' + @ColumnList + '; @BusinessKeyList : ' + @BusinessKeyList + '@UnionColumn List :	' + @UnionColumnList
	IF (@Debug = 1) EXEC [core].p_LogInfo @ProcedureName, @Message
	
	-- 1) Data was not golden, so insert data from core

	
	SET			@SqlMerge = '
	;WITH updateData AS (
		SELECT 
			' + @UnionColumnList + '
		FROM	core.' + @CoreTable + ' TT
		EXCEPT
		SELECT
			' + @UnionColumnList + '
		FROM	staging.' + @TargetTable + ' TT
	)
	UPDATE staging.' + @TargetTable + ' 
	SET 
		 [SourceKey] = [ST].[SourceKey],' 
		 + @UnionCoreColumnList  + '
	FROM	core.' + @CoreTable + ' TT
	JOIN    target.' + @TargetTable + ' ST on 1 = 1 
		AND ST.Start <= @NowDate
		AND ST.Finish > @NowDate '
	+ @BusinessKeyList + '		
	JOIN	staging.' + @TargetTable + ' [stagT] ON 1 = 1 '
		+ REPLACE(@BusinessKeyList,'[TT]','[stagT]') + '		
	JOIN    updateData UD ON 1 = 1 ' 
	+ REPLACE(@BusinessKeyList,'[ST]','[UD]') + ';
	SELECT @InsertedCount = @@ROWCOUNT;
	'

	SET @Message =  'updating none golden data rows : ' + @SqlMerge
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	EXEC sp_executesql @SqlMerge, N'@NowDate DateTime2, @InsertedCount INT OUTPUT', @NowDate, @InsertedCount OUTPUT
	if(@Debug=1) execute ('select  * from staging.' + @targetTable);

	SET @Message =  'insert ' + @DataFeed + ' fields from core ;' + CONVERT(VARCHAR,@InsertedCount) + ' staging rows updated for ' + @DataFeed
	EXEC [core].p_LogInfo @ProcedureName, @Message


	-- 2)  update Non @DataFeed columns for @DataFeed from target
	
	SELECT		@ColumnList = NULL,	@UnionColumnList = NULL
	SELECT		@UnionColumnList = COALESCE(@UnionColumnList + ', ', '  ') + '[TT].[' + ColumnName + ']'
	FROM		[core].[f_Target2CoreGetColumnGroups]('target.'+@TargetTable, 'core.'+@CoreTable)
	WHERE		[Grouping] = 'Common'
	ORDER BY	ColumnName;

	SELECT		@ColumnList = COALESCE(@ColumnList + ', ', '  ') + RIGHT(REPLICATE(' ',@Padding) + '[' + ColumnName + ']', @Padding) + ' = [TT].[' + ColumnName + ']
	'
	FROM		[core].[f_Target2CoreGetColumnGroups]('target.'+@TargetTable, 'core.'+@CoreTable)
	WHERE		[Grouping] = 'UniqueToTarget'
	ORDER BY	ColumnName;
	
	SET @Message = '@Column List :	' + isnull(@ColumnList , '<null>')
	IF (@Debug = 1) EXEC [core].p_LogInfo @ProcedureName, @Message
	SET @Message = ' @BusinessKeyList :' + isnull(@BusinessKeyList, '<null>') 
	IF (@Debug = 1) EXEC [core].p_LogInfo @ProcedureName, @Message
	SET @Message = ' @UnionColumn List :	' + isnull(@UnionColumnList, '<null>')
	IF (@Debug = 1) EXEC [core].p_LogInfo @ProcedureName, @Message
	

	SET			@SqlMerge = '
	UPDATE	staging.' + @TargetTable + '
	SET
	' + @ColumnList + '
	FROM	target.' + @TargetTable + ' TT
	JOIN    staging.' +  @TargetTable + ' ST ON 1 = 1 ' 
	+ @BusinessKeyList + '
	WHERE	1 = 1
	AND		TT.Start			<= @NowDate 
	AND		TT.finish			> @NowDate;
	SELECT @StagingUpdatedCount = @@ROWCOUNT;
	'
	SET @Message =  'Merge of columns: ' + @SqlMerge
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
	EXEC sp_executesql @SqlMerge, N'@NowDate DateTime2, @StagingUpdatedCount INT OUTPUT', @NowDate, @StagingUpdatedCount OUTPUT
	if(@Debug=1) execute ('select  * from staging.' + @targetTable);

	SET @Message =  'update Non' + @DataFeed + ' fields from target ;' + CONVERT(VARCHAR,@StagingUpdatedCount) + ' staging rows updated for ' + @DataFeed
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

	-- 3)  Reset the SourceKey to target.SourceKey where no data has changed
	
	SELECT		@CoalesceVarcharColumns = NULL;
	SELECT		@CoalesceVarcharColumns = COALESCE(@CoalesceVarcharColumns + ', ', '  ') + 'COALESCE(CONVERT(VARCHAR,[TT].[' + ColumnName + ']),'''')'
	FROM		[core].[f_Target2CoreGetColumnGroups]('target.'+@TargetTable, 'staging.'+@TargetTable)
	WHERE		[Grouping] = 'Common'
	ORDER BY	ColumnName;

	SET @Message = ' @BusinessKeyList :' + isnull(@BusinessKeyList, '<null>') 
	IF (@Debug = 1) EXEC [core].p_LogInfo @ProcedureName, @Message
	SET @Message = ' @@CoalesceVarcharColumns List :	' + isnull(@CoalesceVarcharColumns, '<null>')
	IF (@Debug = 1) EXEC [core].p_LogInfo @ProcedureName, @Message

	SET			@SqlMerge = '
	;WITH updateData AS (
		SELECT '
		+ @UnionBusinessKeyList + '
		FROM	target.' + @TargetTable + ' TT
		JOIN    staging.' + @TargetTable + ' ST ON 1 = 1 '
		+ @BusinessKeyList + '
		WHERE	1 = 1
		AND		TT.Start			<= @NowDate 
		AND		TT.finish			> @NowDate		
		AND     TT.SourceKey		!= ST.SourceKey
		AND		BINARY_CHECKSUM(' + @CoalesceVarcharColumns + ') =
				BINARY_CHECKSUM(' + REPLACE(@CoalesceVarcharColumns,'[TT]','[ST]') + ')
	)
	UPDATE	staging.' + @TargetTable + '
	SET SourceKey = TT.SourceKey
	FROM	target.' + @TargetTable + ' TT
	JOIN	staging.' + @TargetTable + ' ST ON 1 = 1 '
	+ @BusinessKeyList + '
	JOIN    updateData UD ON 1 = 1 '
	+ REPLACE(@BusinessKeyList,'[ST]','[UD]') + '
	WHERE	1 = 1
	AND		TT.Start			<= @NowDate 
	AND		TT.finish			> @NowDate;

	SELECT @StagingUpdatedCount = @@ROWCOUNT;
	'
	SET @Message =  'Reset SourceKey For Unchanged Data : ' + @SqlMerge
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
	EXEC sp_executesql @SqlMerge, N'@NowDate DateTime2, @StagingUpdatedCount INT OUTPUT', @NowDate, @StagingUpdatedCount OUTPUT
	if(@Debug=1) execute ('select  * from staging.' + @targetTable);

	SET @Message =  'Source Keys update for ' + @DataFeed + ' ;' + CONVERT(VARCHAR,@StagingUpdatedCount) + ' staging rows updated '
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#------------------------------------------------ END OF MERGE CODE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN 0;

END
GO


