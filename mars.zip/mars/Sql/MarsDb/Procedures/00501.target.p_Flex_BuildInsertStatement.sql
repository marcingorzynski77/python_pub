IF OBJECT_ID ('[target].[p_Flex_BuildInsertStatement]') IS NOT NULL
	DROP PROCEDURE [target].[p_Flex_BuildInsertStatement]
GO

-- exec [target].[p_Flex_BuildInsertStatement] 'Reconciliation.Pnl', 'PROD'
-- exec [target].[p_Flex_BuildInsertStatement] 'VaR.Historical-1D', 'PROD'
-- exec [target].[p_Flex_BuildInsertStatement] 'UnitTestSchema', 'PROD'
-- exec [target].[p_Flex_BuildInsertStatement] 'FeedLoadCheck.Threshold', 'PROD'

CREATE PROC [target].[p_Flex_BuildInsertStatement]
(
	@Schema		VARCHAR(250),
	@Env		VARCHAR(6)
)
AS

BEGIN

    SET NOCOUNT ON;

    DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@SessionID		BIGINT;

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].[p_LogInfo] @ProcedureName, @Message
	
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	
	EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'

	CREATE TABLE #Columns
    (
        ColumnName VARCHAR(255),
        DataType VARCHAR(255),
        FieldType CHAR(1)
    )
    
    INSERT INTO #Columns
    EXEC [target].[p_Flex_GetSchemaDefinition] @Schema

	DECLARE @SQL NVARCHAR(4000) 

	IF OBJECT_ID('tempdb..#TempSqlBuilder') IS NOT NULL DROP TABLE #TempSqlBuilder
	CREATE TABLE #TempSqlBuilder (SqlName varchar(250), SqlValue varchar(max))

	SET @SQL ='CREATE TABLE #TempStorage ( CoreKey INT IDENTITY(1,1) NOT NULL, '

	IF (SELECT CURSOR_STATUS('global','column_cursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','column_cursor')) > -1
		BEGIN
			CLOSE column_cursor
		END
		DEALLOCATE column_cursor
	END
	
    DECLARE @ColumnName VARCHAR(255)
    DECLARE @DataType VARCHAR(255)

	DECLARE column_cursor CURSOR FOR   
	SELECT ColumnName, DataType FROM #Columns 

	OPEN column_cursor
	FETCH NEXT FROM column_cursor   
	INTO @ColumnName, @DataType

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
        IF @DataType = 'VARCHAR' 
    		SET @SQL = @SQL + @ColumnName+' VARCHAR(255),'
        ELSE IF @DataType = 'DECIMAL' 
            SET @SQL = @SQL + @ColumnName+' DECIMAL(22,6),'
        ELSE
            SET @SQL = @SQL + @ColumnName+' ' + @DataType + ','
		
		FETCH NEXT FROM column_cursor   
	    INTO @ColumnName, @DataType
	END

	CLOSE column_cursor  
	DEALLOCATE column_cursor 


    -- get keys
    IF (SELECT CURSOR_STATUS('global','key_cursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','key_cursor')) > -1
		BEGIN
			CLOSE key_cursor
		END
		DEALLOCATE key_cursor
	END

    DECLARE column_cursor CURSOR FOR   
     SELECT Name FROM [target].[FlexFactHierarchy] 
      WHERE [Description] = @Schema + '.MetaData.Dimension.Name'
        AND Name NOT IN ('BusDate', 'UserName')
	
    OPEN column_cursor
	FETCH NEXT FROM column_cursor   
	INTO @ColumnName

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
        SET @SQL = @SQL + 'Resolved' + @ColumnName + ' BIGINT,'
		
		FETCH NEXT FROM column_cursor   
	    INTO @ColumnName
	END

	CLOSE column_cursor  
	DEALLOCATE column_cursor 

	-- remove last and
	SET @SQL = substring(@SQL, 1, (len(@SQL) - 1))
	-- remove last comma
	SET @SQL = @SQL + ') '

	EXEC [core].[p_LogDebug] @ProcedureName, @SQL

	INSERT INTO #TempSqlBuilder VALUES('TempTable', @SQL)

    DECLARE @SQLVALUES NVARCHAR(4000) 

	-- BUILD INSERT STATMENT
	SET @SQL ='INSERT INTO #TempStorage ( '
	SET @SQLVALUES ='VALUES ( '

	--------- metrics ------------------

    DECLARE column_cursor CURSOR FOR   
	SELECT ColumnName FROM #Columns 

	OPEN column_cursor
	FETCH NEXT FROM column_cursor   
	INTO @ColumnName

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
        SET @SQL = @SQL + @ColumnName+','
        SET @SQLVALUES = @SQLVALUES + '@'+@ColumnName +','

		FETCH NEXT FROM column_cursor   
	    INTO @ColumnName
	END

	CLOSE column_cursor  
	DEALLOCATE column_cursor
	
	-- remove last comma
	SET @SQL = substring(@SQL, 1, (len(@SQL) - 1))
	SET @SQLVALUES = substring(@SQLVALUES, 1, (len(@SQLVALUES) - 1))

    -- merge two parts
	SET @SQL = @SQL + ') ' + @SQLVALUES + ') '
	
	EXEC [core].[p_LogDebug] @ProcedureName, @SQL

	INSERT INTO #TempSqlBuilder VALUES('InsertSql', @SQL)
	SELECT * FROM #TempSqlBuilder

	----Finish logging
	EXEC [core].[p_LogInfo] @ProcedureName, 'Success. End of processing.' 

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	 DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL; 
	
	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN 0

END

GO



