/****** Object:  StoredProcedure [core].[p_Control_Hierarchy]    Script Date: 11/17/2017 16:28:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Control_Hierarchy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_Control_Hierarchy]
GO


-- exec [core].[p_Control_Hierarchy] 'Hierarchy', '2017-MAY-24', 'PROD', '2017-MAY-25'
CREATE PROC [core].[p_Control_Hierarchy] 
(	
	@DataFeed VARCHAR(64),
	@AsOfBusDate DATETIME2,
	@Env VARCHAR(6),
	@ExecutionTime	DATETIME2(7) = NULL,
	@HierarchyTag INT = 0
)
AS 

BEGIN

    SET NOCOUNT ON;

    DECLARE @ProcedureName		NVARCHAR(128),
            @Message		VARCHAR(1000),
	        @NowDate		DATETIME2;
   
    SELECT  @ProcedureName	= OBJECT_NAME(@@PROCID),
	        @NowDate	= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;
 
  	--Start logging session		
    SET @Message = 'Invoking ' + @ProcedureName
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
    SET @Message = 'Param: DataFeed = ''' + @DataFeed + ''''
	EXEC [core].p_LogInfo @ProcedureName, @Message
    SET @Message = 'Param: HierarchyTag = ''' + cast(@HierarchyTag as varchar(10)) + ''''
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
     
	--Start logging event
    SET @Message = 'Start of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	-- Default to the correct Hierarchy using the context (used by vHierarchyConsolidated later to filter all the hierarchies in Target)
	EXEC [target].p_Set_HierarchyMode @Hierarchy = @HierarchyTag
    
	--Split raw data into a star
	EXEC [core].p_CreateStar_Hierarchy @AsOfBusDate, @DataFeed, @Env, @HierarchyTag
	
	--Conform the raw star dimensions with Target dimensions	
	EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env 	
	EXEC [core].p_Conform_HierarchyBook @AsOfBusDate, @NowDate, @DataFeed, @Env	
	EXEC [core].p_Conform_Hierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env, @SessionID = 0, @hierarchyMode = @HierarchyTag

	--Take note of load date
	EXEC [core].[p_Insert_TimeTravellingInstance] @AsOfBusDate, @NowDate, @DataFeed, @Env, 'Hierarchy'

	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
    
    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState		    INT,
        @ErrorLine		    INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

    SELECT 
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
        @ErrorLine		= ERROR_LINE();
    
	--Log error        
    EXEC [core].p_LogError 
				  @ErrorNumber = @ErrorNumber
				  ,@ProcedureName=@ProcedureName
				  ,@ErrorProcedure = @ProcedureName
				  ,@ErrorSeverity = @ErrorSeverity
				  ,@ErrorState = @ErrorState
				  ,@Message = @ErrorMessage
				  ,@NESTLEVEL = @@NESTLEVEL
				  ,@ErrorLine = @ErrorLine;
	
	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT
				
END CATCH;

RETURN 0;

END



GO


