IF OBJECT_ID ('core.p_Control_SimraPnLs') IS NOT NULL
	DROP PROCEDURE core.p_Control_SimraPnLs
GO

-- Stored Procedure

CREATE PROC [core].[p_Control_SimraPnLs]
(
	@Datafeed		VARCHAR(64),
	@AsOfBusDate	DATETIME2,
	@Env			VARCHAR(6),
	@ExecutionTime	DATETIME2(7) = NULL,
	@ExternalRef	VARCHAR(255) = NULL,
	@ExternalRef2	VARCHAR(255) = NULL
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@SessionID			BIGINT,
		@SourceKey			BIGINT,
		@NowDate			DATETIME2;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;
		
	--Start logging session
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	EXEC [core].p_LogInfo @ProcedureName, 'Start of processing'

	--Split raw data into a star
	EXEC [core].p_CreateStar_SimraPnLs @AsOfBusDate, @NowDate, @DataFeed, @Env

	--Conform the raw star dimensions with Target dimensions
	EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_HierarchyBook @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_Hierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_ScenarioHierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_RiskMeasureType @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_RiskFactorType @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_RiskFactor @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_InstrumentType @AsOfBusDate, @NowDate, @DataFeed, @Env

	--Update the Target facts with the star dimensions
	EXEC [core].p_UpdateFact_PnLs @AsOfBusDate, @NowDate, @DataFeed, @Env

	--Take note of load date
	EXEC [core].[p_Insert_TimeTravellingInstance] @AsOfBusDate, @NowDate, @DataFeed, @Env, 'PnL', @ExternalRef, @ExternalRef2

	DECLARE @Stats Flex_LoadStatsParameters

	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT * FROM [core].f_PnLFactMonitor(
		 'PnL'		 		--		 @FactType	VARCHAR(64)
		,@DataFeed 			--		,@Interface	VARCHAR(64)
		,@Env
		,@AsOfBusDate 		--		,@BusDate	DATETIME2
		,@NowDate			--		,@Now		DATETIME2
	)

	EXEC [core].p_Flex_UpdateLoadStats @AsOfBusDate, @NowDate, 'PnL', @Stats

    --invoke VaR calculation
    --EXEC [raw].p_VarCalculation @ExternalRef, @Datafeed, @AsOfBusDate, @NowDate, 0
    --EXEC [core].[p_Control_MarsVaRs] 'MarsVaRs', @AsOfBusDate, @Env, @NowDate, 0, @ExternalRef,@ExternalRef2

	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO

GO