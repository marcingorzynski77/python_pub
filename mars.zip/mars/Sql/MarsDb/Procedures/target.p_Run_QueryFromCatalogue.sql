IF OBJECT_ID ('target.p_Run_QueryFromCatalogue') IS NOT NULL
	DROP PROCEDURE target.p_Run_QueryFromCatalogue
GO

CREATE PROC [target].[p_Run_QueryFromCatalogue] 
(
	@TrackerCRC VARCHAR(6),
	@FilePath VARCHAR(300),
	@FileName VARCHAR(100),	
	@UserName varchar(50),
	@ID INT,
	@Query AS VARCHAR(MAX) = ''
)
AS 
	DECLARE @ProcedureName  		    NVARCHAR(128),
			@ErrorNumber    		    INT,
			@ErrorSeverity  		    INT,
			@ErrorState     		    INT,
			@ErrorLine      		    INT,
			@ErrorMessage   		    VARCHAR(MAX),
			@ErrorProcedure 		    NVARCHAR(128),			
			@Public						varchar(50);

	SET NOCOUNT ON
	
BEGIN TRY

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--


	--SQL provided or just the ID?
	IF @Query = '' 	
	BEGIN		
		SET @Query = (SELECT Query FROM core.QueryCatalogue WHERE ID = @ID)
	END
	
	
	--Get owner because we only want to track public queries
	set @Public = (select [owner] 
					from core.QueryCatalogue_Hierarchy  H
					join core.QueryCatalogue C
					on C.HierarchyNode = h.NodeID
					where C.ID = @ID)
	

	--If a public query, update the tracker to log activity
	IF @Public = 'Public'
		EXEC [target].[p_IU_QueryTracker] @FilePath, @FileName, @UserName, @ID, 'INSERT'


	--Do IT!
	EXECUTE(@Query)
	
	
	--If a public query, finalise the tracker
	IF @Public = 'Public'
		EXEC [target].[p_IU_QueryTracker] @FilePath, @FileName, @UserName, @ID, 'FINISH'
	

END TRY

BEGIN CATCH

    SELECT 
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),        
		@ErrorProcedure = ERROR_PROCEDURE(),        
        @ErrorLine		= ERROR_LINE();
		
        EXEC [core].p_LogError @SessionID = 0
					  ,@ErrorNumber = @ErrorNumber
					  ,@ProcedureName=@ProcedureName
					  ,@ProcID = @@ProcID
					  ,@ErrorProcedure = @ErrorProcedure
					  ,@ErrorSeverity = @ErrorSeverity
					  ,@ErrorState = @ErrorState
					  ,@ErrorMessage = @ErrorMessage
					  ,@NESTLEVEL = @@NESTLEVEL
					  ,@ErrorLine = @ErrorLine;

END CATCH
GO
