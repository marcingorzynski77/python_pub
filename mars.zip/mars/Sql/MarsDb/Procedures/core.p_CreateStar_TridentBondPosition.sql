IF OBJECT_ID ('core.p_CreateStar_TridentBondPosition') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_TridentBondPosition
GO

CREATE PROC [core].[p_CreateStar_TridentBondPosition]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT		= 0
)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@ErrorNumber		INT,
		@ErrorSeverity		INT,
		@ErrorState			INT,
		@ErrorLine			INT,
		@ErrorMessage		VARCHAR(MAX),
		@ErrorProcedure		NVARCHAR(128),
		@Comment			VARCHAR(1000),
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@MaxRow				BIGINT,
		@UTCDate			DATETIME2	= getutcdate()

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@ErrorNumber	= 0,  -- ok we are in an error for transaction purposes (ie post roll back)
		@Comment		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogEvent @SessionID = @SessionID, @procedureName = @procedureName, @Comment = @Comment, @NestLevel = 2
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	--First empty the star ready for new data
	TRUNCATE TABLE [core].TridentBondPosition_Instrument
	TRUNCATE TABLE [core].TridentBondPosition_Hierarchy
	TRUNCATE TABLE [core].TridentBondPosition_Source
	TRUNCATE TABLE [core].TridentBondCDSTrade_Fact
	TRUNCATE TABLE [core].TridentBondPosition_Fact

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'TridentBondPosition_Instrument'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'TridentBondPosition_RiskNode'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'TridentBondPosition_Source'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'TridentBondCDSTrade_Fact'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'TridentBondPosition_Fact'

	--#-------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT INTO  [core].TridentBondPosition_Source (
		[InterfaceName],
		[Environment],
		[Source],
		[Origin])
	SELECT
        @DataFeed,
		@Env,
		'Trident' as [Source],
		'GDI' as [Origin]
		--isnull([Source],'UNKNOWN') as 'Source',
		--isnull([Origin],'UNKNOWN') as 'Origin'
	--FROM
	--	[raw].TridentBondPosition V
	--GROUP BY
	--	[source],
	--	[Origin]

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[TridentBondPosition_Source] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Hierarchy Dimension -----------------------------------------#--

	--Hierarchy Dimension
	INSERT INTO [core].TridentBondPosition_Hierarchy (
		  CoreSourceKey
		, NodeType
		, NodeName
		, BookSystem
	)
	SELECT
		 S.CoreSourceKey
		,'BO' AS [NodeType]
		,R.Book
		,isnull(R.[Origin],'Risk Management')
	FROM
		[raw].TridentBondPosition R
		join
		[core].TridentBondPosition_Source S
		on
			S.Source = 'Trident' --isnull(R.[Source],'UNKNOWN')
			and
			S.Origin = 'GDI' --isnull(R.[Origin],'UNKNOWN')
			AND
			S.Environment = @Env
	GROUP BY
		 R.Book
		,S.CoreSourceKey
		,isnull(R.[Origin], 'Risk Management')

	set @InsertedCount = @@ROWCOUNT

	update
		T
	set
		T.HierarchyString = H.HierarchyString
	from
		[core].TridentBondPosition_Hierarchy T
		join
		[target].Hierarchy H
		on
			H.NodeName = T.NodeName
			and
			H.NodeType = T.NodeType
			and
			H.BookSystem = T.BookSystem
			and
			H.Start <= @UTCDate
			and
			H.Finish > @UTCDate

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].[TridentBondPosition_Hierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Instrument Dimension -----------------------------------------#--

	INSERT INTO [core].TridentBondPosition_Instrument (
		  [CoreSourceKey]
		, [Product]
		, [InstrumentIdType]
		, [InstrumentID]
		, [ISIN]
		, [ProductName]
		, [IssueCountry]
		, [Ticker]
		, [Maturity]
		, [FixedFRN]
		, [Sector]
		, [Currency]
		, [IssueRating]
		, [Seniority]
		, [SeniorityLevel]
		, [IssuerName]
	)
	SELECT
		  [CoreSourceKey]
		, [Product]
		, [InstrumentIdType]
		, [InstrumentID]
		, [ISIN]
		, [ProductName]
		, [IssueCountry]
		, [Ticker]
		, [Maturity]
		, [FixedFRN]
		, [Sector]
		, [Currency]
		, [IssueRating]
		, [Seniority]
		, [SeniorityLevel]
		, [IssuerName]
	FROM
	(
		SELECT
			RANK() OVER (PARTITION BY ISIN ORDER BY CoreSourceKey, ChangeDate DESC ) AS RankResult,
			S.CoreSourceKey,
			'BOND' AS [Product],
			'ISIN' AS [InstrumentIdType],
			[ISIN] AS [InstrumentID],
			[ISIN],
			[InstrumentName] AS [ProductName],
			[CountryofRisk] AS [IssueCountry],
			(CASE WHEN COALESCE(Ticker_For_Bond, Ticker_For_CDS)IS NOT NULL THEN CONVERT(VARCHAR(100),COALESCE(Ticker_For_Bond, Ticker_For_CDS)) ELSE '' END) AS [Ticker],
			[BondMaturity] as [Maturity],
			ISNULL(CONVERT(VARCHAR(100),FixFloat),'') AS [FixedFRN],
			(case WHEN IsGoverment = 1 AND [Sector] IS null THEN 'Sovereign' ELSE [Sector] END) AS [Sector],
			[Currency],
			'' as [IssueRating],
			[Seniority],
			'' AS [SeniorityLevel],
			[IssuerName]
		FROM
			[raw].TridentBondPosition V
			LEFT JOIN
			[core].TridentBondPosition_Source S
			ON
				--ISNULL(V.Source,'UNKNOWN') = 
				S.[Source] = 'Trident'
				AND
				--ISNULL(V.Origin,'UNKNOWN') = 
				S.[Origin] = 'GDI'
				AND
				S.Environment = @Env
		WHERE
			[Product] in ('BOND','BOND INDEX LINKED')
	) A
	where
		RankResult = 1
	GROUP BY
		  [CoreSourceKey]
		, [Product]
		, [InstrumentIdType]
		, [InstrumentID]
		, [ISIN]
		, [ProductName]
		, [IssueCountry]
		, [Ticker]
		, [Maturity]
		, [FixedFRN]
		, [Sector]
		, [Currency]
		, [IssueRating]
		, [Seniority]
		, [SeniorityLevel]
		, [IssuerName]

	set @InsertedCount = @@ROWCOUNT

	--Add unnderlying CDS Instruments
	INSERT INTO [core].TridentBondPosition_Instrument (
		  [CoreSourceKey]
		, [Product]
		, [InstrumentIdType]
		, [InstrumentID]
		, [ISIN]
		, [ProductName]
		, [IssueCountry]
		, [Ticker]
		, [Maturity]
		, [FixedFRN]
		, [Sector]
		, [Currency]
		, [IssueRating]
		, [Seniority]
		, [SeniorityLevel]
		, [IssuerName]
	)
	SELECT
		  [CoreSourceKey]
		, [Product]
		, [InstrumentIdType]
		, [InstrumentID]
		, [ISIN]
		, [ProductName]
		, [IssueCountry]
		, [Ticker]
		, [Maturity]
		, [FixedFRN]
		, [Sector]
		, [Currency]
		, [IssueRating]
		, [Seniority]
		, [SeniorityLevel]
		, [IssuerName]
	FROM
	(
		SELECT
			RANK() OVER (PARTITION BY ISIN ORDER BY CoreSourceKey, changedate DESC ) AS RankResult,
			S.[CoreSourceKey],
			[Product],
			'ISIN' as [InstrumentIdType],
			[ISIN] as [InstrumentID],
			[ISIN],
			[InstrumentName] as [ProductName],
			'' AS [IssueCountry],
			'' AS [Ticker],
			'' AS [Maturity],
			ISNULL(CONVERT(VARCHAR(100),FixFloat),'') AS 'FixedFRN',
			'' AS [Sector],
			'' AS [Currency],
			'' AS [IssueRating],
			'' AS [Seniority],
			'' AS [SeniorityLevel],
			'' AS [IssuerName]
		FROM
			[raw].TridentBondPosition V
			LEFT JOIN
			[core].TridentBondPosition_Source S
			ON
				--ISNULL(V.Source,'UNKNOWN') = 
				S.[Source] = 'Trident'
				AND
				--ISNULL(V.Origin,'UNKNOWN') = 
				S.[Origin] = 'GDI'
				AND
				S.Environment = @Env
		WHERE
			[Product] in ('CDS')
			AND
			ISIN <> ''
			AND
			ISIN not in (SELECT ISIN FROM [core].TridentBondPosition_Instrument)
	) A
	where
		RankResult = 1
	GROUP BY
		  [CoreSourceKey]
		, [Product]
		, [InstrumentIdType]
		, [InstrumentID]
		, [ISIN]
		, [ProductName]
		, [IssueCountry]
		, [Ticker]
		, [Maturity]
		, [FixedFRN]
		, [Sector]
		, [Currency]
		, [IssueRating]
		, [Seniority]
		, [SeniorityLevel]
		, [IssuerName]

	set @InsertedCount = @InsertedCount + @@ROWCOUNT

	--Log affected rows
	SET @Message = 'Split out ' + cast(@InsertedCount AS VARCHAR(30)) + ' rows into [core] [TridentBondPosition_Instrument] dimension'
	EXEC [core].p_LogEvent @SessionID = @SessionID, @Comment = @Comment, @ProcedureName = @ProcedureName, @NestLevel = 2


	--#--------------------------------------------- Populate the Position Fact -------------------------------------------#--


	--Position Facts - Structured this way to sniff out intruments with 2 entries that net to zero

	INSERT INTO [core].[TridentBondPosition_Fact] (
		[BusDate],
		[CoreHierarchyKey],
		[CoreInstrumentKey],
		[CoreSourceKey],
		[Nominal],
		[NominalGBP],
		[MarketValue],
		[MarketValueGBP],
		[Price],
		[ZSpread],
		[CS01],
		[StandardisedCS01],
		[TradeOrValuePerspective]
	)
	SELECT
		*
	FROM
		(
			SELECT
				@busdate AS 'BusDate',
				ISNULL(B.CoreHierarchyKey,0)AS CoreHierarchyKey,
				ISNULL(B.CoreInstrumentKey,0)AS CoreInstrumentKey,
				ISNULL(B.CoreSourceKey,0)AS CoreSourceKey,
				SUM(CAST(B.[Notional] AS FLOAT)) AS [Nominal],
				SUM(CAST(B.[NotionalGBP] AS FLOAT)) AS [NominalGBP],				
				SUM(CAST(B.[MarketValue]AS FLOAT)) AS [MarketValue],
				SUM(CAST(B.[MarketValueGBP]AS FLOAT)) AS [MarketValueGBP],
				CAST(B.[BondPrice]AS FLOAT)AS Price,
				CAST(B.[Spread]AS FLOAT)AS ZSpread,
				SUM(CAST(B.[CS01]AS FLOAT))AS CS01,
				SUM(CAST(B.[StandardisedCS01] AS FLOAT))AS StandardisedCS01,
				'VD' AS [TradeOrValuePerspective] --Add up all instrument entries with value date of busdate
			FROM
				(
					SELECT
						I.CoreInstrumentKey,
						H.CoreHierarchyKey,
						S.CoreSourceKey,
						A.*
					FROM
					(
						SELECT
							*
						FROM
							[raw].TridentBondPosition
						WHERE
							Product in ('BOND','BOND INDEX LINKED')
							AND
							RIGHT(TradeID,2) <> '|B'
							AND
							RIGHT(TradeID,2) <> '|S'

						UNION ALL

						SELECT
							*
						FROM
							[raw].TridentBondPosition
						WHERE
							Product in ('BOND','BOND INDEX LINKED')
							AND
							(
								RIGHT(TradeID,2) = '|B'
								OR
								RIGHT(TradeID,2) = '|S'
							)
							AND
							SUBSTRING(rtrim(TradeID),LEN(rtrim(tradeid))-9,8) <= CAST(@busdate AS VARCHAR(10)) --Check value date is less than or equal to today
					) A
					JOIN
					[core].TridentBondPosition_Instrument I
					ON
						A.Product = I.Product
						AND
						A.ISIN = I.ISIN
					JOIN
					[core].TridentBondPosition_Hierarchy H
					ON
						A.Book = H.NodeName
						AND
						H.NodeType = 'BO'
					JOIN
					[core].TridentBondPosition_Source S
					ON
						--ISNULL(A.Source,'UNKNOWN') = 
						S.[Source] = 'Trident'
						AND
						--ISNULL(A.Origin,'UNKNOWN') = 
						S.[Origin] = 'GDI'
						AND
						S.Environment = @Env
				) B
			GROUP BY
				B.ReportDate,
				B.CoreHierarchyKey,
				B.CoreInstrumentKey,
				B.CoreSourceKey,
				B.Book,
				B.BondPrice,
				B.Spread
		) C


	set @InsertedCount = @@ROWCOUNT

	INSERT INTO [core].[TridentBondPosition_Fact] (
		[BusDate],
		[CoreHierarchyKey],
		[CoreInstrumentKey],
		[CoreSourceKey],
		[Nominal],
		[NominalGBP],
		[MarketValue],
		[MarketValueGBP],
		[Price],
		[ZSpread],
		[CS01],
		[StandardisedCS01],
		[TradeOrValuePerspective]
	)
	SELECT
		*
	FROM
		(
			SELECT
				@BusDate AS 'BusDate',	--CAST(left(B.[ReportDate],8) AS DATETIME2)AS [BusDate],
				ISNULL(B.CoreHierarchyKey,0)AS CoreHierarchyKey,
				ISNULL(B.CoreInstrumentKey,0)AS CoreInstrumentKey,
				ISNULL(B.CoreSourceKey,0)AS CoreSourceKey,
				ROUND(SUM(CAST(B.[Notional] AS FLOAT)),0) AS [Nominal],
				0 as NominalGBP,
				ROUND(SUM(CAST(B.[MarketValue]AS FLOAT)),0) AS [MarketValue],
				0 as MarketValueGBP,
				MAX(CAST(B.[BondPrice]AS FLOAT))AS Price,
				MAX(CAST(B.[Spread]AS FLOAT))AS ZSpread,
				SUM(CAST(B.[CS01]AS FLOAT))AS CS01,
				SUM(CAST(B.[StandardisedCS01] AS FLOAT))AS StandardisedCS01,
				'TD' AS [TradeOrValuePerspective]--Add up all intrument entries
			FROM
				(
					SELECT
						I.CoreInstrumentKey,
						H.CoreHierarchyKey,
						S.CoreSourceKey,
						A.*
					FROM
						(
							SELECT
								*
							FROM
								raw.TridentBondPosition
							WHERE
								Product in ('BOND','BOND INDEX LINKED')
								AND
								RIGHT(TradeID,2) <> '|B'
								AND
								RIGHT(TradeID,2) <> '|S'

							UNION ALL

							SELECT
								*
							FROM
								raw.TridentBondPosition
							WHERE
								Product in ('BOND','BOND INDEX LINKED')
								AND
								(
									RIGHT(TradeID,2) = '|B'
									OR
									RIGHT(TradeID,2) = '|S'
								)
						)A
						JOIN
						[core].TridentBondPosition_Instrument I
						ON
							A.Product = I.Product
							AND
							A.ISIN = I.ISIN
						JOIN
						[core].TridentBondPosition_Hierarchy H
						ON
							A.Book = H.NodeName
							AND
							H.NodeType = 'BO'
						JOIN
						[core].TridentBondPosition_Source S
						ON
							--ISNULL(A.Source,'UNKNOWN') = 
							S.[Source] = 'Trident'
							AND
							--ISNULL(A.Origin,'UNKNOWN') = 
							S.[Origin] = 'GDI'
							AND
							S.Environment = @Env
				) B
			GROUP BY
				B.ReportDate,
				B.CoreHierarchyKey,
				B.CoreInstrumentKey,
				B.CoreSourceKey,
				B.Book
		) C

	set @InsertedCount = @InsertedCount + @@ROWCOUNT

	--Log affected rows
	SET @Message = 'Split out '+ CAST(@InsertedCount AS VARCHAR(30)) + ' rows into [core].[TridentBondPosition_Fact] fact'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#--------------------------------------------- Populate the CDS Fact -------------------------------------------#--

	--CDS Facts
	INSERT INTO [core].[TridentBondCDSTrade_Fact] (
		[BusDate],
		[TradeRef],
		[CoreHierarchyKey],
		[CoreInstrumentKey_ForBond],
		[CoreSourceKey],
		[BuySell],
		[Nominal],
		[MarketValue],
		[CS01],
		[Maturity],
		[Currency]
	)
	SELECT
		CAST(left(p.[ReportDate],8) AS DATETIME2),
		(CASE
			WHEN SingleNameIndex = 'Index' THEN TradeID
			WHEN SingleNameIndex = 'SingleName' THEN LEFT(tradeID, PATINDEX('%[^0-9]%', TradeId) - 1)
			ELSE ''
			END
		),
		ISNULL(H.CoreHierarchyKey,0),
		ISNULL(I.[CoreInstrumentKey],0),
		ISNULL(I.[CoreSourceKey],0),
		(case WHEN LEFT(Notional,1) = '-' THEN 'S' ELSE 'B' END),
		CAST(P.[Notional] AS FLOAT),
		CAST(P.[MarketValue]AS FLOAT),
		CAST(P.[CS01]AS FLOAT),
		P.Maturity,
		P.Currency
	FROM
		[raw].TridentBondPosition P
		JOIN
		[core].TridentBondPosition_Instrument I
		on
			P.Product = I.Product
			and
			P.ISIN = I.ISIN
		JOIN
		[core].TridentBondPosition_Source S
		ON
			--ISNULL(P.Source,'UNKNOWN') = 
			S.[Source] = 'Trident'
			AND
			--ISNULL(P.Origin,'UNKNOWN') = 
			S.[Origin] = 'GDI'
			AND
			S.Environment = @Env
		JOIN
		(
			select
				CoreHierarchyKey,
				NodeName,
				NodeType
			from
				(
					select
						RANK() OVER (PARTITION BY NodeName,NodeType ORDER BY CoreHierarchyKey DESC ) AS RankResult,
						CoreHierarchyKey,
						NodeName,
						NodeType
					from
						[core].TridentBondPosition_Hierarchy
				) A
			where
				RankResult = 1
			group by
				CoreHierarchyKey,
				NodeName,
				NodeType
		) H
		ON
			P.Book = H.NodeName
		WHERE
			P.Product in ('CDS')

	--Log affected rows
	SET @Message = 'Split out '+ cast(@@ROWCOUNT as varchar(30)) + ' rows into [core].[TridentBondCDSTrade_Fact] fact'
	EXEC [core].p_LogEvent @SessionID = @SessionID, @Comment = @Comment, @ProcedureName = @ProcedureName, @NestLevel = 2

	--Log completion
	EXEC [core].[p_MonitorEvent]  @sessionID, @Env, @DataFeed, @BusDate,'Bond_Position data successfully split into a star.','G', @insertedCount

END TRY

--#---------------------------------------------- END OF SNOWFLAKE CODE -----------------------------------------------#--
--#====================================================================================================================#--


BEGIN CATCH

    SELECT
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
        @ErrorLine	    = ERROR_LINE()		;

        --LOG
        EXEC [core].p_LogEvent @SessionID = @SessionID
					  ,@ErrorNumber = @ErrorNumber
					  ,@ProcedureName=@ProcedureName
					  ,@ProcID = @@ProcID
					  ,@ErrorProcedure = @ProcedureName
					  ,@ErrorSeverity = @ErrorSeverity
					  ,@ErrorState = @ErrorState
					  ,@ErrorMessage = @ErrorMessage
					  ,@NESTLEVEL = @@NESTLEVEL
					  ,@ErrorLine = @ErrorLine




		RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN @ErrorNumber

END
GO
