IF OBJECT_ID ('core.p_CreateStar_SimraFORiskMeasures') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_SimraFORiskMeasures
GO

CREATE PROC [core].[p_CreateStar_SimraFORiskMeasures]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT	 = 0
)
AS

BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@InitialTranCount	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@RejectedCount		BIGINT,
		@UTCDate			DATETIME2;

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	--First empty the star ready for new data
	TRUNCATE TABLE [core].SimraFORiskMeasures_Source
	TRUNCATE TABLE [core].SimraFORiskMeasures_Hierarchy
	TRUNCATE TABLE [core].SimraFORiskMeasures_HierarchyBook
	TRUNCATE TABLE [core].SimraFORiskMeasures_RiskMeasureType
	TRUNCATE TABLE [core].SimraFORiskMeasures_RiskFactorType
	TRUNCATE TABLE [core].SimraFORiskMeasures_RiskFactor
	TRUNCATE TABLE [core].SimraFORiskMeasures_InstrumentType
	TRUNCATE TABLE [core].SimraFORiskMeasures_Tenor
	TRUNCATE TABLE [core].SimraFORiskMeasures_Fact

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_Source'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_Hierarchy'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_RiskMeasureType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_RiskFactorType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_RiskFactor'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_InstrumentType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_Tenor'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraFORiskMeasures_Fact'

	--#--------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT into [core].SimraFORiskMeasures_Source (
		 [CoreSourceKey]
		,[InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	) VALUES (
		 1
		,@Datafeed
		,@Env
		,'SIMRA'
		,'SIMRA'
	)

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_Source dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--

	CREATE TABLE #Hierarchy (
		  CoreHierarchyKey		BIGINT IDENTITY NOT NULL
		, CoreSourceKey			BIGINT
		, NodeName				VARCHAR (50)
		, NodeType				CHAR (2)
		, BookLegalEntity		VARCHAR (20)
		, BookCad2				BIT
		, BusinessHierarchyPath	VARCHAR (900) NOT NULL
		, HierarchyString		VARCHAR (900)
		, BookSystem			VARCHAR (50) NOT NULL
		, HierarchyTag			INT NULL
	)

	-- Make a list of the books for the base Hierarchy i.e. 0
	
	INSERT INTO #Hierarchy (
		  CoreSourceKey
		, NodeName
		, NodeType
		, BookLegalEntity
		, BookCad2
		, BusinessHierarchyPath
		, HierarchyString
		, BookSystem
		, HierarchyTag
	)
	SELECT 
		 1
		,REVERSE(LEFT(REVERSE(R.[BusinessHierarchyPath]), CHARINDEX('\', REVERSE(R.[BusinessHierarchyPath])) - 1)) NodeName
		,'BO' AS [NodeType]
		,R.[LegalEntity] BookLegalEntity
		,R.[Cad2] BookCad2
		,R.[BusinessHierarchyPath]
		,REPLACE( CASE WHEN LEFT(R.[BusinessHierarchyPath], 5) = 'Root\' 
			THEN RIGHT(R.[BusinessHierarchyPath], len(R.[BusinessHierarchyPath]) - 4) 
			ELSE R.[BusinessHierarchyPath] END,'\','/') + '/'HierarchyString
		,ISNULL(R.[SourceSystemName], 'Risk Management') HierarchyString
		,0
	FROM
		[raw].SimraFORiskMeasures R
	GROUP BY
		 R.[LegalEntity]
		,R.[Cad2]
		,R.[BusinessHierarchyPath]
		,R.SourceSystemName
		,ISNULL(R.[SourceSystemName], 'Risk Management')

	-- Add to this list, the Book Nodes for any other Hierarchies by looking up, the path of the book, 
	-- in the respective Hiearrchy, in target

	INSERT INTO #Hierarchy (
		  CoreSourceKey
		, NodeName
		, NodeType
		, BookLegalEntity
		, BookCad2
		, BusinessHierarchyPath
		, HierarchyString
		, BookSystem
		, HierarchyTag
	)
		SELECT 
			 1 [CoreSourceKey]
			,Book.NodeName
			,'BO' AS [NodeType]
			,Book.LegalEntity BookLegalEntity
			,Book.[Cad2]
			,Book.BusinessHierarchyPath
			,ISNULL(T.HierarchyString, '/LBG/UNKNOWN_SG/UNKNOWN_BU/UNKNOWN_BA/UNKNOWN_DV/UNKNOWN_DE/' + Book.NodeName + '/') HierarchyString
			,Book.BookSystem
			,Book.HierarchyTag
		FROM (
			SELECT DISTINCT R.[BusinessHierarchyPath], R.SourceSystemName BookSystem, Node.NodeName , R.LegalEntity, 
				R.CAD2, NonBaseHierarchyTags.HierarchyTag
			FROM [raw].SimraFORiskMeasures R
			CROSS APPLY (SELECT HierarchyString = REVERSE(R.[BusinessHierarchyPath])) revPath
			CROSS APPLY (SELECT NodeName = REVERSE(LEFT(revPath.HierarchyString, CHARINDEX('\', revPath.HierarchyString) - 1))) Node
			CROSS JOIN (SELECT DISTINCT HierarchyTag 
				FROM Target.Hierarchy 
				WHERE HierarchyTag <> 0 AND Start <= @NowDate AND Finish > @NowDate) NonBaseHierarchyTags		
			) Book
		LEFT JOIN Target.Hierarchy T 
			ON Book.NodeName = T.Book AND T.BookSystem = Book.BookSystem AND T.HierarchyTag = Book.HierarchyTag AND T.NodeType = 'BO'
			AND Start <= @NowDate AND Finish > @NowDate

	-- Now populate the Core Hierarchy Dimension with the above list of nodes (Hiearchy 0 + the other Hierarchies too)

	INSERT INTO [core].SimraFORiskMeasures_Hierarchy  (
		 [CoreHierarchyKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookLegalEntity]
		--,[BookCad2]
		,[HierarchyString]
		,[BookSystem]
		,HierarchyTag
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		,BookLegalEntity
		--,BookCad2
		,HierarchyString
		,BookSystem
		,HierarchyTag
	FROM
		#Hierarchy H

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_Hierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	-- Only the base Hiearchy (i.e. Hiearchy 0) is needed in the HierarchyBook table
	
	INSERT INTO [core].SimraFORiskMeasures_HierarchyBook(
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookSystem]
		,BookCad2
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		,BookSystem
		,BookCad2
	FROM
	#Hierarchy H where NodeType = 'BO' and H.HierarchyTag = 0  -- we will have data for all hierarchies created and previous step but for books we can only need one , hence using default one
	
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_HierarchyBook dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the RiskMeasureType Dimension ----------------------------------------#--

	--RiskMeasure Dimension

	INSERT INTO [core].SimraFORiskMeasures_RiskMeasureType (
		 [CoreSourceKey]
		,[RiskMeasureTypeName]
		,[RiskMeasureFamily]
	)
	SELECT DISTINCT
		1 CoreSourceKey,
		R.RiskMeasureTypeName,
		CASE
			WHEN R.RiskMeasureTypeName = 'Interest Rate Inflation Cross Gamma' THEN 'Inflation'
			ELSE R.RiskFactorFamily
		END RiskMeasureFamily
	FROM
		[raw].SimraFORiskMeasures R

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_RiskMeasureType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the RiskFactorType Dimension ----------------------------------------#--

	--RiskFactor Dimension

	INSERT INTO [core].SimraFORiskMeasures_RiskFactorType (
		 [CoreSourceKey]
		,[RiskFactorTypeName]
	)
	SELECT DISTINCT
		 1
		,R.RiskFactorType
	FROM
		[raw].SimraFORiskMeasures R

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_RiskFactorType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the RiskFactor Dimension ----------------------------------------#--

	--RiskFactor Dimension

	INSERT INTO [core].SimraFORiskMeasures_RiskFactor (
		 [CoreSourceKey]
		,[RiskFactorName]
	)
	SELECT DISTINCT
		 1
		,R.RiskFactorName
	FROM
		[raw].SimraFORiskMeasures R


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(10)) + ' rows into [core].SimraFORiskMeasures_RiskFactor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the InstrumentType Dimension ----------------------------------------#--

	--Instrument Dimension

	INSERT INTO [core].SimraFORiskMeasures_InstrumentType (
		 [CoreSourceKey]
		,[InstrumentType]
		,[InstrumentSubType]
	)
	SELECT DISTINCT
		 1
		,R.InstrumentType
		,ISNULL(R.InstrumentSubType, '')
	FROM
		[raw].SimraFORiskMeasures R


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_InstrumentType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the Tenor Dimension ----------------------------------------#--

	--Tenor Dimension

	INSERT INTO [core].SimraFORiskMeasures_Tenor (
		 [CoreSourceKey]
		,[TenorName]
	)
	SELECT
		 1 CoreSourceKey
		,R.TenorName
	FROM
		(
			select distinct
				 M.[Instrument Tenor] as TenorName
			from
				[raw].SimraFORiskMeasures M
			where
				M.[Instrument Tenor] is not null

			union

			select distinct
				 M.[Underlying Tenor]
			from
				[raw].SimraFORiskMeasures M
			where
				M.[Underlying Tenor] is not null

			union

			select distinct
				 M.[Fixing Tenor]
			from
				[raw].SimraFORiskMeasures M
			where
				M.[Fixing Tenor] is not null
		) R
	GROUP BY
		 R.TenorName

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraFORiskMeasures_Tenor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#----------------------------------------------- Populate the SimraRiskMeasureValue Fact ---------------------------------------------#--

	-- Risk Measure Values
	INSERT INTO [core].[SimraFORiskMeasures_Fact] (
		 [BusDate]
		,[CoreSourceKey]
		,[CoreHierarchyKey]
		,[CoreRiskMeasureTypeKey]
		,[CoreRiskFactorTypeKey]
		,[CoreRiskFactorKey]
		,[CoreInstrumentTypeKey]
		,[CoreInstrumentTenorKey]
		,[CoreUnderlyingTenorKey]
		,[CoreFixingTenorKey]
		,[ProformaShift]
		,[ProformaShiftValue]
		,[LegalEntity]
		,[Cad2]
		,[ValueCurrency]
		,[Value]
		,[ValueGBP]
	)
	SELECT
		 R.[BusinessDate]
		,1 CoreSourceKey
		,H.[CoreHierarchyKey]
		,RM.[CoreRiskMeasureTypeKey]
		,RFT.[CoreRiskFactorTypeKey]
		,RF.[CoreRiskFactorKey]
		,I.[CoreInstrumentTypeKey]
		,IT.[CoreTenorKey]
		,UT.[CoreTenorKey]
		,FT.[CoreTenorKey]
		,R.[ScenarioName]
		,CONVERT(FLOAT, R.[ProformaShiftValue])
		,R.[LegalEntity]
		,R.[Cad2]
		,R.[ValueCurrency]
		,SUM(R.[Sum Value])
		,SUM(R.[Sum Value GBP])
	FROM
		[raw].SimraFORiskMeasures R
		LEFT JOIN
		(select * from #Hierarchy where HierarchyTag = 0) H
		ON
			R.[BusinessHierarchyPath]= H.BusinessHierarchyPath
			AND
			R.SourceSystemName = H.BookSystem
		LEFT JOIN
		[core].SimraFORiskMeasures_RiskMeasureType RM
		ON
			R.RiskMeasureTypeName = RM.[RiskMeasureTypeName]
		LEFT JOIN
		[core].SimraFORiskMeasures_RiskFactorType RFT
		ON
			R.RiskFactorType = RFT.[RiskFactorTypeName]
		LEFT JOIN
		[core].SimraFORiskMeasures_RiskFactor RF
		ON
			R.RiskFactorName = RF.[RiskFactorName]
		LEFT JOIN
		[core].SimraFORiskMeasures_InstrumentType I
		ON
			R.InstrumentType = I.[InstrumentType]
			AND
			COALESCE(R.InstrumentSubType, 'XXX') = COALESCE(I.[InstrumentSubType], 'XXX')
		LEFT JOIN
		[core].SimraFORiskMeasures_Tenor IT
		ON
			R.[Instrument Tenor] = IT.TenorName
		LEFT JOIN
		[core].SimraFORiskMeasures_Tenor UT
		ON
			R.[Underlying Tenor] = UT.TenorName
		LEFT JOIN
		[core].SimraFORiskMeasures_Tenor FT
		ON
			R.[Fixing Tenor] = FT.TenorName
	WHERE
		FO_DataStatusID in (1,2)
	GROUP BY
		 R.[BusinessDate]
		,H.[CoreHierarchyKey]
		,RM.[CoreRiskMeasureTypeKey]
		,RFT.[CoreRiskFactorTypeKey]
		,RF.[CoreRiskFactorKey]
		,I.[CoreInstrumentTypeKey]
		,IT.[CoreTenorKey]
		,UT.[CoreTenorKey]
		,FT.[CoreTenorKey]
		,R.[ScenarioName]
		,CONVERT(FLOAT, R.[ProformaShiftValue])
		,R.[LegalEntity]
		,R.[Cad2]
		,R.[ValueCurrency]

	SET @InsertedCount = @@ROWCOUNT

	-- Generate a warning for data which has been ignored
	SELECT @RejectedCount = count(*) FROM [raw].SimraFORiskMeasures R WHERE FO_DataStatusID = 3		-- 'The value 3 an error.
	IF @RejectedCount > 0 
	BEGIN
		SET @Message = CAST(@RejectedCount as varchar(30)) + ' rows ignored as SIMRA indicated bad RiskMeasure values'
		EXEC [core].p_LogInfo @ProcedureName, @Message
	END

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into core.SimraFORiskMeasures_Fact fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	DROP TABLE #Hierarchy

END TRY

--#---------------------------------------------- END OF STAR CODE -----------------------------------------------#--
--#===============================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

