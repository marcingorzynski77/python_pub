/****** Object:  StoredProcedure [target].[p_Run_PnL_Recon]    Script Date: 11/27/2017 08:48:06 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Run_PnL_Recon]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Run_PnL_Recon]
GO


--  exec core.p_Run_PnL_Recon @Datafeed='SimraSVaR1DPnLs', @Env='PROD', @AsOfBusDate='2017-02-15' , @ExternalRef='SSF00003570'
CREATE PROC [target].[p_Run_PnL_Recon]
(
	@DataFeed		VARCHAR(50),
	@AsOfBusDate	DATETIME2,
	@Env			VARCHAR(6),
	@ExternalRef	VARCHAR(50),
    @ExternalRef2	VARCHAR(50),
    @ExecutionTime	DATETIME2(7) = null
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(1000),
		@SourceKey			BIGINT,
		@NowDate			DATETIME2;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;

	--Start logging session
    EXEC [core].[p_LogInfo] @ProcedureName, @Message
    SET @Message = 'Params: ExternalRef=''' + @ExternalRef + ''', ExternalRef2=''' + @ExternalRef2 + ''', Data Feed=''' + @DataFeed + ''', Business Date=''' + cast(@AsOfBusDate as VARCHAR(30)) + ''''
	EXEC [core].[p_LogInfo] @ProcedureName, @Message
	
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

    DECLARE @EndDate DATETIME2 = CAST('9999-12-31' AS DATETIME2);
	--Start logging event
	EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'

    DECLARE @DataType varchar(50)
    SET @Message = '@AsOfBusDate = ''' + cast(@AsOfBusDate as varchar(30)) + ''''
    EXEC [core].[p_LogInfo] @ProcedureName, @Message
    
	DECLARE @Start DATETIME2
		
	SELECT @Start=MAX(Start) 
	  FROM target.TimeTravellingInstance
     WHERE ExternalReference = @ExternalRef 
	   AND ExternalReference2 = @ExternalRef2
	   AND FactTable = 'PnL' 
	   AND BusDate = @AsOfBusDate 
	   AND Datafeed = @DataFeed 
	   AND Env = @Env
		
	IF(@Start IS null)
	BEGIN
		SET @Message= 'Reconciliation-Unable to locate @Start (Import) time in target.TimeTravellingInstance for ExternalReference:' + @ExternalRef + ' and ExternalReference2:' + @ExternalRef2 + ' and  DataFeed:' + @DataFeed + ' and Env:' + @Env + ' and BusDate: ''' + CAST(@AsOfBusDate as varchar(max)) + ''''
		RAISERROR (@Message, 16, 1);  
	END

	SET @Message = 'Instance (import) time: ' + CAST(@Start AS VARCHAR(255))
	EXEC [core].[p_LogInfo] @ProcedureName, @Message
		
	DECLARE @FlexFactHierarchyKey bigint

	SET @FlexFactHierarchyKey =(SELECT top 1 FlexFactHierarchyKey FROM target.FlexFactHierarchy WHERE [Description] = 'Reconciliation.Pnl.Data' and Finish = '9999-12-31')
	SET @SourceKey =(SELECT top 1 SourceKey FROM target.Source WHERE InterfaceName like @Datafeed and Finish = '9999-12-31')

	SET @Message = 'SourceKey that has been determined is ' + CAST(@SourceKey as VARCHAR(255))
	EXEC [core].[p_LogInfo] @ProcedureName, @Message 
		
	IF(@FlexFactHierarchyKey is null)
	BEGIN
		SET @Message = 'Reconciliation-Unable to locate FlexFactHierarchyKey in target.FlexFactHierarchy for Reconciliation.Pnl.Data'
		RAISERROR (@Message, 16, 1);  
	END
			
	IF(@SourceKey is null)
	BEGIN
		SET @Message = 'Reconciliation-Unable to locate Source in target.Source ' + @Datafeed
		RAISERROR (@Message, 16, 1);  
	END
		
	DECLARE @difference float, @businessArea varchar(250), @Cad2 bit, @hasBreak bit, @hierarchyKey bigint, @ScenarioHierarchyKey bigint
	SET @hasBreak = 0
	   
	IF (SELECT CURSOR_STATUS('global','rec_cursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','rec_cursor')) > -1
		BEGIN
			CLOSE rec_cursor
		END
		DEALLOCATE rec_cursor
	END
		
	SET @Message = 'SELECT [Difference], IsNull(MarsBusinessArea,BridgeBusinessArea) as BusinessArea, IsNull(MarsCad2,BridgeCad2) as Cad2, *  FROM [target].[f_PnlBusinessAreaRec] (0.01, '''+cast(@AsOfBusDate as varchar(max))+''','''+cast(@NowDate as varchar(max))+''', '''+@DataFeed+''', '''+@Env+''','''+@ExternalRef2+''', '''+cast(@Start as varchar(max))+ ''',' +  cast(@SourceKey as varchar(10)) + ')' 
	EXEC [core].[p_LogDebug] @ProcedureName, @Message
	   
	DECLARE @root BIGINT
	DECLARE rec_cursor CURSOR FOR   
	SELECT [Difference], IsNull(MarsBusinessArea,BridgeBusinessArea) as BusinessArea, IsNull(MarsCad2,BridgeCad2) as Cad2  from [target].[f_PnlBusinessAreaRec] (0.01, @AsOfBusDate, @NowDate, @DataFeed, @Env, @ExternalRef2, @Start, @SourceKey)

	UPDATE target.FlexFact set Finish = @NowDate 
	FROM target.FlexFact where BusDate = @AsOfBusDate and FlexFactHierarchyKey = @FlexFactHierarchyKey and SourceKey = @SourceKey
			
	OPEN rec_cursor
	FETCH NEXT FROM rec_cursor   
	INTO @difference, @businessArea, @Cad2

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		SET @HierarchyKey = (SELECT TOP 1 HierarchyKey 
	                           FROM target.vHierarchyConsolidated 
			     			  WHERE NodeName = @businessArea 
							    AND NodeType = 'BA'
					    		AND target.vHierarchyConsolidated.Start <= @Start 
						    	AND target.vHierarchyConsolidated.Finish > @Start )
	   
		SET @root = (SELECT TOP 1 HierarchyKey FROM Hierarchy WHERE NodeName LIKE 'root')
	   
		IF(@HierarchyKey IS NULL)
		BEGIN
			IF(@root is null)
			BEGIN
				SET @root = -1
				SET @Message = 'Unable to locate root node, setting root to -1'
				EXEC [core].p_LogInfo @ProcedureName, @Message
			END
	   
			SET @HierarchyKey = @root
			SET @Message = 'Unable to locate HierarchyKey for business area ' + @businessArea+ ' , setting it to the root ' + cast(@HierarchyKey as varchar(max))
			EXEC [core].p_LogInfo @ProcedureName, @Message
		END
	   
		SET @hasBreak = 1
			INSERT INTO [target].[FlexFact] (Start,Finish,BusDate,FlexFactHierarchyKey,HierarchyKey, SourceKey)
			VALUES (@NowDate,@EndDate,@AsOfBusDate,@FlexFactHierarchyKey,@HierarchyKey,@SourceKey)
			INSERT INTO [target].[FlexFactInstance] ([FlexFactKey],[Key],Value)
			VALUES (SCOPE_IDENTITY(),'Difference', @difference)
	   
	   FETCH NEXT FROM rec_cursor INTO @difference,@businessArea, @Cad2
	END
	   
	CLOSE rec_cursor  
	DEALLOCATE rec_cursor  
	   
	IF(@hasBreak = 0)
	BEGIN
		EXEC [core].p_LogInfo @ProcedureName, 'No Breaks detected'
		INSERT INTO target.FlexFact (Start,Finish,BusDate,FlexFactHierarchyKey,HierarchyKey, SourceKey)
		VALUES (@NowDate,@EndDate,@AsOfBusDate,@FlexFactHierarchyKey,null,@SourceKey)
		INSERT INTO target.FlexFactInstance (FlexFactKey,[Key],Value)
		VALUES (SCOPE_IDENTITY(),'Difference', 0)
	END
	ELSE
	BEGIN
		EXEC [core].p_LogInfo @ProcedureName, 'Breaks detected'
	END

	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO