﻿IF OBJECT_ID ('core.p_CreateStar_GDIRiskMeasureTrade') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_GDIRiskMeasureTrade
GO

CREATE PROC [core].[p_CreateStar_GDIRiskMeasureTrade]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT	 = 0
)
AS

BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@InitialTranCount	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@RejectedCount		BIGINT,
		@UTCDate			DATETIME2;

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	--First empty the star ready for new data
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_Source
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_Hierarchy
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_HierarchyBook
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_Counterparty
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_RiskFactor
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_Tenor
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_RiskMeasureType
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_InstrumentType
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_Trade
	TRUNCATE TABLE [core].GDIRiskMeasureTrade_Fact

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'GDIRiskMeasureTrade_Fact'

	--#--------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT into [core].GDIRiskMeasureTrade_Source (
		 [CoreSourceKey]
		,[InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	) VALUES (
		 1
		,@Datafeed
		,@Env
		,'GDISUMMIT'
		,'GDISUMMIT'
	)

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_Source dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--
	--Hierarchy Dimension 

	;WITH TTHierarchy AS
	(	
		SELECT *
		FROM Target.Hierarchy H
		WHERE 1 = 1
			AND Start <= @NowDate
			AND Finish > @NowDate
	)
	, BookSystemTag AS
	(
		SELECT DISTINCT R.[Book Identifier] NodeName, 'GDISUMMIT' BookSystem, H.HierarchyTag HierarchyTag
		FROM [raw].GDIInflation_Deal R			
		,	 TTHierarchy H 
	)		
	INSERT INTO [core].GDIRiskMeasureTrade_Hierarchy  (
		 [CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookLegalEntity]
		,[HierarchyString]
		,[BookSystem]
		,HierarchyTag
	)
		SELECT 
			 1 [CoreSourceKey]
			,R.NodeName
			,'BO' AS [NodeType]
			,H.BookLegalEntity
			,ISNULL(H.HierarchyString, '/LBG/UNKNOWN_SG/UNKNOWN_BU/UNKNOWN_BA/UNKNOWN_DV/UNKNOWN_DE/' + R.NodeName + '/') HierarchyString
			,R.BookSystem
			,R.HierarchyTag
		FROM BookSystemTag R
		LEFT JOIN TTHierarchy H ON 1 = 1
			AND R.NodeName		= H.Book 
			AND R.BookSystem	= H.BookSystem 
			AND R.HierarchyTag	= H.HierarchyTag 
		WHERE 1 = 1
			AND H.NodeType = 'BO'

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_Hierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#------------------------------------------ Populate the HierarchyBook Dimension ----------------------------------------#--

	-- Only the base Hiearchy (i.e. Hiearchy 0) is needed in the HierarchyBook table
	INSERT INTO [core].GDIRiskMeasureTrade_HierarchyBook(
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookCad2]
		,[Trading]
		,[BookSystem]
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,H.NodeName
		,H.NodeType
		,HB.BookCad2
		,HB.Trading
		,H.BookSystem
	FROM	[core].GDIRiskMeasureTrade_Hierarchy H
	LEFT JOIN target.hierarchybook hb on h.NodeName = hb.NodeName and h.BookSystem = hb.BookSystem and h.NodeType = hb.NodeType
	WHERE 1 = 1
		AND H.NodeType = 'BO' 
		AND H.HierarchyTag = 0  
		AND HB.Start <= @NowDate AND @NowDate < HB.Finish
	
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_HierarchyBook dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#------------------------------------------ Populate the Counterparty Dimension ----------------------------------------#--

	--Counterparty Dimension
	INSERT INTO  [core].GDIRiskMeasureTrade_Counterparty(
		[CoreSourceKey]
		,[CounterpartyCode]
		,[CounterpartyCodeType]
	)
	SELECT DISTINCT 
		1 
		,[Counterparty Identifier]
		,[Counterparty Identifier]
	FROM
		[raw].GDIInflation_Deal

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_Counterparty dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#------------------------------------------ Populate the RiskFactor Dimension ----------------------------------------#--

	--RiskFactor Dimension

	INSERT INTO [core].GDIRiskMeasureTrade_RiskFactor (
		 [CoreSourceKey]
		,RiskFactorName
	)
	SELECT DISTINCT
		 1
		,'Inflation ' + R.[Underlying] 
	FROM
		[raw].[GDIInflation_Result] R
	WHERE 1 = 1 
		AND	Cast(r.[Sensitivity Value] as decimal(20,8)) != 0
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_RiskFactor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Tenor Dimension ----------------------------------------#--

	--Tenor Dimension

	INSERT INTO [core].GDIRiskMeasureTrade_Tenor (
		 [CoreSourceKey]
		,[TenorName]
	)
	SELECT
		 1 CoreSourceKey
		,R.TenorName
	FROM
		(
			/* VEGA, IL DELTA, IL SEASONAL DELTA, IL VEGA, IL VOL SMILE, IR IL CORR DELTA */
			select '' TenorName
			union
			select distinct 
				SUBSTRING(R.GridCell,0,CHARINDEX('|',R.GridCell)) TenorName
			from [raw].[GDIInflation_Result] R
			where 1 = 1
				and Cast(r.[Sensitivity Value] as decimal(20,8)) != 0
			union
			select distinct 
				R.GridCell
			from [raw].[GDIInflation_Result] R
			where 1 = 1
				and Cast(r.[Sensitivity Value] as decimal(20,8)) != 0
				and R.[Risk Factor Name] = 'IR IL CORR DELTA'
			union
			select distinct 
				SUBSTRING(R.GridCell,CHARINDEX('|',R.GridCell)+1,10) TenorName
			from [raw].[GDIInflation_Result] R
			where 1 = 1
				and CAST(r.[Sensitivity Value] as decimal(20,8)) != 0
				and R.[Risk Factor Name] = 'VEGA'
		) R
	GROUP BY
		 R.TenorName

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_Tenor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the RiskMeasureType Dimension ----------------------------------------#--

	--RiskMeasure Dimension

	INSERT INTO [core].GDIRiskMeasureTrade_RiskMeasureType (
		 [CoreSourceKey]
		,[RiskMeasureTypeName]
		,[RiskMeasureFamily]
	)
	SELECT DISTINCT
		1 CoreSourceKey,
		CASE WHEN [Risk Factor Name] = 'IL VOL SMILE' THEN [Risk Factor Name] + ' ' + SUBSTRING(R.[GridCell],CHARINDEX('|',R.GridCell,CHARINDEX('|',R.GridCell)+1)+1,15) 
		     ELSE [Risk Factor Name] END RiskMeasureType,
		'Inflation'
	FROM
		[raw].[GDIInflation_Result] R
		

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_RiskMeasureType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the InstrumentType Dimension ----------------------------------------#--

	--Instrument Dimension

	INSERT INTO [core].GDIRiskMeasureTrade_InstrumentType (
		 [CoreSourceKey]
		,[InstrumentType]
		,[InstrumentSubType]
	)
	SELECT DISTINCT
		 1
		,R.[Instrument Type]
		,R.[Instrument Family]
	FROM
		[raw].[GDIInflation_Deal] R


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_InstrumentType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Trade Dimension ----------------------------------------#--

	--Trade Dimension

	INSERT INTO [core].GDIRiskMeasureTrade_Trade (
		 [CoreSourceKey]
		 , [TradeReference]
	)
	SELECT DISTINCT
		 1
		 , R.[Trade Identifier]
	FROM
		[raw].[GDIInflation_Deal] R


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_Trade dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#----------------------------------------------- Populate the RiskMeasureValue Fact ---------------------------------------------#--

	-- Risk Measure Values
	INSERT INTO [core].[GDIRiskMeasureTrade_Fact] (
		 [BusDate]
		,[CoreSourceKey]
		,[CoreHierarchyKey]
		,[CoreCounterpartyKey]
		,[CoreRiskFactorKey]
		,[CoreInstrumentTenorKey]
		,[CoreUnderlyingTenorKey]
		,[CoreRiskMeasureTypeKey]
		,[CoreInstrumentTypeKey]
		,[CoreTradeKey]
		,[ValueCurrency]
		,[Value]
	)
	SELECT
		 @BusDate
		,1 CoreSourceKey
		,H.[CoreHierarchyKey]
		,CP.[CoreCounterpartyKey]
		,RF.[CoreRiskFactorKey]
		,IT.[CoreTenorKey]
		,ISNULL(UT.[CoreTenorKey],BlankTenor.CoreTenorKey) 
		,RM.[CoreRiskMeasureTypeKey]
		,I.[CoreInstrumentTypeKey]
		,T.[CoreTradeKey]
		,R.[Risk Currency]
		,SUM(CAST(R.[Sensitivity Value] AS DECIMAL(20,8)))
	FROM
		[RAW].[GDIInflation_Result] R
		JOIN [RAW].[GDIInflation_Deal] D ON R.[Trade Identifier] = D.[Trade Identifier]
		LEFT JOIN (SELECT * FROM core.gdiriskmeasuretrade_hierarchy WHERE HierarchyTag = 0) H ON 1 = 1
			AND D.[Book Identifier]				= H.NodeName
		LEFT JOIN [core].GDIRiskMeasureTrade_Counterparty CP ON 1 = 1
			AND D.[Counterparty Identifier]		= CP.CounterpartyCode
		LEFT JOIN [core].GDIRiskMeasureTrade_RiskFactor RF ON 1 = 1
			AND 'Inflation ' + R.[Underlying]	= RF.[RiskFactorName]
		LEFT JOIN [core].GDIRiskMeasureTrade_Tenor IT ON 1 = 1					
			AND ISNULL(SUBSTRING(R.GridCell,0,CHARINDEX('|',R.GridCell+'|')),'')		= IT.TenorName
		LEFT JOIN [core].GDIRiskMeasureTrade_Tenor UT ON 1 = 1
			AND ISNULL(SUBSTRING(R.GridCell,CHARINDEX('|',R.GridCell+'|')+1,10),'')		= UT.TenorName
		LEFT JOIN [core].GDIRiskMeasureTrade_RiskMeasureType RM ON 1 = 1
			AND CASE WHEN [Risk Factor Name] = 'IL VOL SMILE' THEN [Risk Factor Name] + ' ' + SUBSTRING(R.[GridCell],CHARINDEX('|',R.GridCell,CHARINDEX('|',R.GridCell)+1)+1,15)
					 ELSE [Risk Factor Name] END										= RM.[RiskMeasureTypeName]
		LEFT JOIN [core].GDIRiskMeasureTrade_InstrumentType I ON 1 = 1
			AND D.[Instrument Type]				= I.[InstrumentType]
			AND D.[Instrument Family]			= I.[InstrumentSubType]
		LEFT JOIN [core].GDIRiskMeasureTrade_Trade T ON 1 = 1
			AND D.[Trade Identifier]			= T.[TradeReference]
	,   ( SELECT CoreTenorKey FROM Core.GDIRiskMeasureTrade_Tenor WHERE TenorName = '') BlankTenor
	WHERE 1 = 1
		AND CAST(R.[Sensitivity Value] AS DECIMAL(20,8)) != 0
		AND LEN(r.gridcell) = LEN(REPLACE(r.gridcell,'value',''))
	GROUP BY
		H.[CoreHierarchyKey]
		,CP.[CoreCounterpartyKey]
		,RF.[CoreRiskFactorKey]
		,IT.[CoreTenorKey]
		,ISNULL(UT.[CoreTenorKey],BlankTenor.CoreTenorKey)
		,RM.[CoreRiskMeasureTypeKey]
		,I.[CoreInstrumentTypeKey]
		,T.[CoreTradeKey]
		,R.[Risk Currency]


	SET @InsertedCount = @@ROWCOUNT

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].GDIRiskMeasureTrade_Fact fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#---------------------------------------------- END OF STAR CODE -----------------------------------------------#--
--#===============================================================================================================#--

BEGIN CATCH
	
	
	DECLARE 
		@ErrorNumber		INT, 
		@ErrorSeverity		INT, 
		@ErrorState			INT, 
		@ErrorLine			INT, 
		@ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

