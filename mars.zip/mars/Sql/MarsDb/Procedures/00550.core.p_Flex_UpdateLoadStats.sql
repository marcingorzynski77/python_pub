IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Flex_UpdateLoadStats]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [core].[p_Flex_UpdateLoadStats]
GO

CREATE PROCEDURE [core].[p_Flex_UpdateLoadStats]
( 
	  @BusDate DATETIME2, 
	  @NowDate DATETIME2,  
	  @Schema VARCHAR(128), -- 'RiskMeasure', 
	  @Stats core.Flex_LoadStatsParameters READONLY, 
	  @SessionID BIGINT = 0 
)
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE
        @ProcedureName		NVARCHAR(128),
		@Message		    NVARCHAR(MAX),
        @BusinessLogicSev	INT;

    SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@Message = 'Invoking ' + @ProcedureName;
		
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--    

BEGIN TRY
    
	SET @Message = 'Params: ''' + CONVERT(VARCHAR(20), @BusDate) + ''',''' + CONVERT(VARCHAR(20), @NowDate) + ''',''' +  @Schema + ''''
	EXEC [core].p_LogInfo @ProcedureName, @Message 
    
    DECLARE @EndDate DATETIME2 = CAST('9999-12-31' AS DATETIME2);

    DECLARE @TaxonomyKey AS BIGINT
    SELECT @TaxonomyKey = FlexFactHierarchyKey
      FROM target.FlexFactHierarchy
     WHERE [Description] = 'FeedLoadCheck.'+@Schema+'.Data'

    IF @TaxonomyKey IS NULL 
    BEGIN
        SET @Message = 'Unknown Flex Schema: ''FeedLoadCheck.' + @Schema+ '.Data'''
        RAISERROR (@Message, 10, 1);  
    END

    DECLARE @Start AS DATETIME2
    DECLARE @Finish AS DATETIME2
    DECLARE @Count AS INT
    DECLARE @Status AS VARCHAR(10)  
    DECLARE @SourceKey AS BIGINT
    DECLARE @RiskMeasureTypeKey AS BIGINT
    DECLARE @InstrumentTypeKey AS BIGINT
    DECLARE @FlexFactKey AS BIGINT

    DECLARE sourceKey_cursor CURSOR FOR   
     SELECT DISTINCT SourceKey FROM @Stats

     OPEN sourceKey_cursor
    FETCH NEXT FROM sourceKey_cursor INTO @SourceKey
    WHILE @@FETCH_STATUS = 0  
	BEGIN  
        PRINT 'DEBUG [core].[p_Flex_UpdateLoadStats] Expiring Flex Facts for SourceKey: ' + CONVERT(VARCHAR(20), @SourceKey) 
        --Expire existing FlexFact for all sources with the same Interface
        UPDATE target.FlexFact
           SET Finish = @NowDate
         WHERE FlexFactHierarchyKey = @TaxonomyKey
           AND BusDate = @BusDate
           AND Finish > @NowDate
           AND SourceKey IN (SELECT SourceKey FROM [target].[Source]
                              WHERE InterfaceName = (SELECT InterfaceName FROM [target].[Source] WHERE SourceKey = @SourceKey))
        PRINT 'DEBUG [core].[p_Flex_UpdateLoadStats] Expired ' + CONVERT(VARCHAR(20),@@ROWCOUNT) + ' Flex Facts'
        FETCH NEXT FROM sourceKey_cursor INTO @SourceKey
	END
    CLOSE sourceKey_cursor  
    DEALLOCATE sourceKey_cursor 

    DECLARE flexFact_cursor CURSOR FOR   
     SELECT DISTINCT SourceKey, RiskMeasureTypeKey, InstrumentTypeKey from @Stats
    
    OPEN flexFact_cursor
    FETCH NEXT FROM flexFact_cursor INTO @SourceKey, @RiskMeasureTypeKey, @InstrumentTypeKey
    WHILE @@FETCH_STATUS = 0  
	BEGIN  
		SET @Message = 'Add Flex Fact: ' + CONVERT(VARCHAR(20), @SourceKey) + ', ' + CONVERT(VARCHAR(20), @RiskMeasureTypeKey) + ', ' + CONVERT(VARCHAR(20), @InstrumentTypeKey)
        EXEC [core].p_LogDebug @ProcedureName, @Message

        INSERT INTO target.FlexFact (Start, Finish, BusDate, FlexFactHierarchyKey, SourceKey, RiskMeasureTypeKey, InstrumentTypeKey)
		VALUES (@NowDate, @EndDate, @BusDate, @TaxonomyKey, @SourceKey, @RiskMeasureTypeKey, @InstrumentTypeKey)

        FETCH NEXT FROM flexFact_cursor INTO @SourceKey, @RiskMeasureTypeKey, @InstrumentTypeKey
	END
    CLOSE flexFact_cursor  
    DEALLOCATE flexFact_cursor
    
    DECLARE stats_cursor CURSOR FOR   
     SELECT DISTINCT [Start], [Finish], [SourceKey], [RiskMeasureTypeKey], [InstrumentTypeKey], [Count], [Status] from @Stats
    
     OPEN stats_cursor
    FETCH NEXT FROM stats_cursor INTO @Start, @Finish, @SourceKey, @RiskMeasureTypeKey, @InstrumentTypeKey, @Count, @Status
    WHILE @@FETCH_STATUS = 0  
	BEGIN  

        SELECT  @FlexFactKey = FlexFactKey FROM target.FlexFact 
                                      WHERE (SourceKey = @SourceKey OR @SourceKey IS NULL)
                                        AND (RiskMeasureTypeKey = @RiskMeasureTypeKey OR @RiskMeasureTypeKey IS NULL)
                                        AND (InstrumentTypeKey = @InstrumentTypeKey OR @InstrumentTypeKey IS NULL)
                                        AND BusDate = @BusDate
                                        AND FlexFactHierarchyKey = @TaxonomyKey

		if(@Start is not null)
		begin
			INSERT INTO target.FlexFactInstance (FlexFactKey,[Key],Value)
			values (@FlexFactKey, @Status+'.Start', @Start)
		end
		if(@Start is not null)
		begin
			INSERT INTO target.FlexFactInstance (FlexFactKey,[Key],Value)
			values (@FlexFactKey, @Status+'.Finish', @Finish)
        end
        INSERT INTO target.FlexFactInstance (FlexFactKey,[Key],Value)
        values (@FlexFactKey, @Status+'.Count', @Count)

	   
	    FETCH NEXT FROM stats_cursor 
         INTO @Start, @Finish, @SourceKey, @RiskMeasureTypeKey, @InstrumentTypeKey, @Count, @Status
	END
	   
    CLOSE stats_cursor  
    DEALLOCATE stats_cursor  
	
    EXEC [core].p_LogDebug @ProcedureName, 'Success. End of processing.'
	
END TRY

--#------------------------------------------------- END OF PROCEDURE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0

END

GO

