IF OBJECT_ID ('target.p_Flex_ValidateDimensionData') IS NOT NULL
	DROP PROCEDURE target.p_Flex_ValidateDimensionData
GO


-- exec [target].[p_Flex_ValidateDimensionData] 'Reconciliation.Pnl', 'PROD'
CREATE PROC [target].[p_Flex_ValidateDimensionData]
(
	@Schema		VARCHAR(250),
	@Env		VARCHAR(6),
	@MinBusDate	DATETIME2,
    @MaxBusDate	DATETIME2
)
AS

BEGIN

    SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@SessionID		BIGINT,
		@NowDate		DATETIME2;


    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= GETUTCDATE();

	EXEC [core].[p_LogInfo] @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'

    DECLARE @RiskFactorKey BIT, 
            @RiskFactorTypeKey BIT, 
            @RiskMeasureTypeKey BIT, 
            @ScenarioHierarchyKey BIT, 
            @HierarchyKey BIT, 
            @InstrumentKey BIT, 
            @InstrumentTypeKey BIT, 
            @SourceKey BIT, 
            @TenorKey BIT, 
            @InterfaceDimensions VARCHAR(250)
    
    SET @InterfaceDimensions = @Schema + '.MetaData.Dimension.Name'

    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'RiskFactorKey')
    BEGIN
        SET @RiskFactorKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'RiskFactorTypeKey')
    BEGIN
        SET @RiskFactorTypeKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'RiskMeasureTypeKey')
    BEGIN
        SET @RiskMeasureTypeKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'ScenarioHierarchyKey')
    BEGIN
        SET @ScenarioHierarchyKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'HierarchyKey')
    BEGIN
        SET @HierarchyKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'InstrumentKey')
    BEGIN
        SET @InstrumentKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'InstrumentTypeKey')
    BEGIN
        SET @InstrumentTypeKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'SourceKey')
    BEGIN
        SET @SourceKey=1
    END
    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @InterfaceDimensions AND Name = 'TenorKey')
    BEGIN
        SET @TenorKey=1
    END

    DECLARE @SQLTORESOLVE_DIM_KEYS nvarchar(4000)
    DECLARE @SQLTORESOLVE_DIM_KEYS_CONDITION nvarchar(4000)
    SET @SQLTORESOLVE_DIM_KEYS = 'Update #TempStorage set '
    SET @SQLTORESOLVE_DIM_KEYS_CONDITION = ' WHERE '

    DECLARE @BusinessKeyColumn varchar(100)
    IF (SELECT CURSOR_STATUS('global','businessKeys_cursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','businessKeys_cursor')) > -1
		BEGIN
		    CLOSE businessKeys_cursor
		END
		DEALLOCATE businessKeys_cursor
	END

    DECLARE @SQL NVARCHAR(4000) 
    DECLARE @SQLVALUES NVARCHAR(4000) 

    IF OBJECT_ID('tempdb..#TempDimensionResolver') IS NOT NULL 
        DROP TABLE #TempDimensionResolver

    DECLARE @MetricKeyColumn varchar(100)
    IF (SELECT CURSOR_STATUS('global','metric_cursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','metric_cursor')) > -1
        BEGIN
		    CLOSE metric_cursor
		END
		DEALLOCATE metric_cursor
	END

    SET @SQL =' ,T.* FROM #TempStorage T  '
    SET @SQLVALUES = 'SELECT'

    IF(@RiskFactorKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' RF.RiskFactorKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.RiskFactor RF on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedRiskFactorKey=T.RiskFactorKey,'
        DECLARE businessKeys_cursor CURSOR FOR   
        select id from core.f_TableOfBusKey('target','RiskFactor')

        OPEN businessKeys_cursor
        FETCH NEXT FROM businessKeys_cursor   
        INTO @BusinessKeyColumn

        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= RF.'+@BusinessKeyColumn + ' AND'
            SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
            FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
        END
        -- remove last and
        SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
        SET @SQL = @SQL + ' AND (RF.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND RF.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL

        CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor 
    END 

    IF(@RiskFactorTypeKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' RFT.RiskFactorTypeKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.RiskFactorType RFT on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedRiskFactorTypeKey=T.RiskFactorTypeKey,'
        DECLARE businessKeys_cursor CURSOR FOR   
        select id from core.f_TableOfBusKey('target','RiskFactorType')

        OPEN businessKeys_cursor
        FETCH NEXT FROM businessKeys_cursor   
        INTO @BusinessKeyColumn

        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= RFT.'+@BusinessKeyColumn + ' AND'
            SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
            FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
        END
        -- remove last and
        SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
        SET @SQL = @SQL + ' AND (RFT.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND RFT.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL

        CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor 
    END 

    IF(@RiskMeasureTypeKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' RMT.RiskMeasureTypeKey,'
	    SET @SQL = @SQL + ' LEFT OUTER JOIN target.RiskMeasureType RMT on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedRiskMeasureTypeKey=T.RiskMeasureTypeKey,'
	    DECLARE businessKeys_cursor CURSOR FOR   
        select id from core.f_TableOfBusKey('target','RiskMeasureType')

	    OPEN businessKeys_cursor
	    FETCH NEXT FROM businessKeys_cursor   
	    INTO @BusinessKeyColumn

	    WHILE @@FETCH_STATUS = 0  
	    BEGIN  
		    SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= RMT.'+@BusinessKeyColumn + ' AND'
		    SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
	        FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
	    END
	    -- remove last and
	    SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
	    SET @SQL = @SQL + ' AND (RMT.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND RMT.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
	    EXEC [core].[p_LogDebug] @ProcedureName, @SQL

	    CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor 
    END 

    IF(@ScenarioHierarchyKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' SH.ScenarioHierarchyKey,'
	    SET @SQL = @SQL + ' LEFT OUTER JOIN target.ScenarioHierarchy SH on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedScenarioHierarchyKey=T.ScenarioHierarchyKey,'
	    DECLARE businessKeys_cursor CURSOR FOR   
        SELECT id FROM core.f_TableOfBusKey('target','ScenarioHierarchy')

	    OPEN businessKeys_cursor
	    FETCH NEXT FROM businessKeys_cursor   
	    INTO @BusinessKeyColumn

	    WHILE @@FETCH_STATUS = 0  
	    BEGIN  
		    SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'=SH.'+@BusinessKeyColumn + ' AND'
		    SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
	        FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
	    END
	    -- remove last and
	    SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
	    SET @SQL = @SQL + ' AND (SH.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND SH.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL

	    CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor 
    END
     
    IF(@HierarchyKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' H.HierarchyKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.Hierarchy H on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedHierarchyKey=T.HierarchyKey,'
        DECLARE businessKeys_cursor CURSOR FOR   
        select id from core.f_TableOfBusKey('target','Hierarchy')

	    OPEN businessKeys_cursor
	    FETCH NEXT FROM businessKeys_cursor   
	    INTO @BusinessKeyColumn

	    WHILE @@FETCH_STATUS = 0  
	    BEGIN  
	        SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= H.'+@BusinessKeyColumn + ' AND'
	        SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
	        FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
	    END

	    -- remove last and
	    SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
	    SET @SQL = @SQL + ' AND (H.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND H.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL
        
	    CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor 
    END 

    IF(@InstrumentKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' I.InstrumentKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.Instrument I on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedInstrumentKey=T.InstrumentKey,'
        DECLARE businessKeys_cursor CURSOR FOR   
        select id from core.f_TableOfBusKey('target','Instrument')

        OPEN businessKeys_cursor
        FETCH NEXT FROM businessKeys_cursor   
        INTO @BusinessKeyColumn

        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= I.'+@BusinessKeyColumn + ' AND'
            SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
            FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
        END
        -- remove last and
        SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
        SET @SQL = @SQL + ' AND (I.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND I.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL

        CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor
    END 

    IF(@InstrumentTypeKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' IT.InstrumentTypeKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.InstrumentType IT on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedInstrumentTypeKey=T.InstrumentTypeKey,'
        DECLARE businessKeys_cursor CURSOR FOR   
        SELECT id FROM core.f_TableOfBusKey('target','InstrumentType')

        OPEN businessKeys_cursor
        FETCH NEXT FROM businessKeys_cursor   
        INTO @BusinessKeyColumn

        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= IT.'+@BusinessKeyColumn + ' AND'
            SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
            FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
        END
        -- remove last and
        SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
        SET @SQL = @SQL + ' AND (IT.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND IT.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL

        CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor
    END 

    IF(@SourceKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' S.SourceKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.Source S on'

	    DECLARE businessKeys_cursor CURSOR FOR   
        SELECT id FROM core.f_TableOfBusKey('target','Source')
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedSourceKey=T.SourceKey,'
	    
        OPEN businessKeys_cursor
	    FETCH NEXT FROM businessKeys_cursor   
	    INTO @BusinessKeyColumn

        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= S.'+@BusinessKeyColumn + ' AND'
            SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
            FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
	    END
	    -- remove last and
        SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
        SET @SQL = @SQL + ' AND (S.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND S.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        EXEC [core].[p_LogDebug] @ProcedureName, @SQL

        CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor 
    END 

    IF(@TenorKey > 0)
    BEGIN
        SET @SQLVALUES = @SQLVALUES + ' TN.TenorKey,'
        SET @SQL = @SQL + ' LEFT OUTER JOIN target.Tenor TN on'
        SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' ResolvedTenorKey=T.TenorKey,'
        DECLARE businessKeys_cursor CURSOR FOR   
        SELECT id FROM core.f_TableOfBusKey('target','Tenor')

        OPEN businessKeys_cursor
        FETCH NEXT FROM businessKeys_cursor   
        INTO @BusinessKeyColumn

        WHILE @@FETCH_STATUS = 0  
        BEGIN  
            SET @SQL = @SQL + ' T.'+@BusinessKeyColumn+'= TN.'+@BusinessKeyColumn + ' AND'
            SET @SQLTORESOLVE_DIM_KEYS_CONDITION = @SQLTORESOLVE_DIM_KEYS_CONDITION + ' #TempStorage.' + @BusinessKeyColumn + '=T.' + @BusinessKeyColumn + ' and '
            FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
        END
        -- remove last and
        SET @SQL = substring(@SQL, 1, (len(@SQL) - 3))
        SET @SQL = @SQL + ' AND (TN.Start<=''' +CAST(@MinBusDate as varchar(max))+ ''' AND TN.Finish >=''' + CAST(@MinBusDate as varchar(max)) + ''')'
        --PRINT @SQL
        CLOSE businessKeys_cursor  
        DEALLOCATE businessKeys_cursor
    END 

    -- remove last comma
    SET @SQLTORESOLVE_DIM_KEYS_CONDITION = substring(@SQLTORESOLVE_DIM_KEYS_CONDITION, 1, (len(@SQLTORESOLVE_DIM_KEYS_CONDITION) - 3))
    SET @SQLVALUES = substring(@SQLVALUES, 1, (len(@SQLVALUES) - 1))
    SET @SQLTORESOLVE_DIM_KEYS =  substring(@SQLTORESOLVE_DIM_KEYS, 1, (len(@SQLTORESOLVE_DIM_KEYS) - 1))
    SET @Message = ' @SQLVALUES + @SQL '+ @SQLVALUES + @SQL
    EXEC [core].[p_LogDebug] @ProcedureName, @Message

    SET @SQLTORESOLVE_DIM_KEYS = @SQLTORESOLVE_DIM_KEYS + ' FROM (' + @SQLVALUES + @SQL + ') AS T' + ' ' + @SQLTORESOLVE_DIM_KEYS_CONDITION
    SET @Message = '@SQLTORESOLVE_DIM_KEYS_CONDITION ' + @SQLTORESOLVE_DIM_KEYS_CONDITION
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'SQLTORESOLVE_DIM_KEYS ' + @SQLTORESOLVE_DIM_KEYS
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    exec sp_executesql @SQLTORESOLVE_DIM_KEYS

    -- BUILD MISSING DIMENSION RECORDS
    CREATE TABLE #TempDimensionResolver (DimensionName varchar(250),DimensionValues varchar(max), InsertSql varchar(max),  StartSql varchar(max),  FinishSql varchar(max), ParamSql varchar(max))

    DECLARE @SQLRESOLVER nvarchar(4000)
    DECLARE @SQLPACHER nvarchar(4000)
    DECLARE @SQLPACHERVALUES nvarchar(4000)
    DECLARE @SQLSTART nvarchar(4000)
    DECLARE @SQLFINISH nvarchar(4000)
    DECLARE @SQLPARAM nvarchar(4000)

    IF(@RiskFactorKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'RiskFactor', @SQLVALUES, @SQL
    
    IF(@RiskFactorTypeKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'RiskFactorType', @SQLVALUES, @SQL
    
    IF(@RiskMeasureTypeKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'RiskMeasureType', @SQLVALUES, @SQL

    IF(@ScenarioHierarchyKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'ScenarioHierarchy', @SQLVALUES, @SQL
    
    IF(@HierarchyKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'Hierarchy', @SQLVALUES, @SQL

    IF(@InstrumentKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'Instrument', @SQLVALUES, @SQL

    IF(@InstrumentTypeKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'InstrumentType', @SQLVALUES, @SQL

    IF(@SourceKey > 0)
	    EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'Source', @SQLVALUES, @SQL
	    
    IF(@TenorKey > 0)
        EXEC [target].[p_Flex_ValidateDimensionDataHelper] 'Tenor', @SQLVALUES, @SQL

    SELECT DISTINCT * FROM #TempDimensionResolver
    DROP TABLE #TempDimensionResolver
	----Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
		@ErrorNumber	INT,
		@ErrorSeverity	INT,
		@ErrorState		INT,
		@ErrorLine		INT,
		@ErrorMessage	NVARCHAR(4000);

    SELECT
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
        @ErrorLine		= ERROR_LINE()		;

    --Log error
    EXEC [core].p_LogError @ErrorNumber = @ErrorNumber
				  ,@ProcedureName=@ProcedureName
				  ,@ErrorProcedure = @ProcedureName
				  ,@ErrorSeverity = @ErrorSeverity
				  ,@ErrorState = @ErrorState
				  ,@Message = @ErrorMessage
				  ,@NESTLEVEL = @@NESTLEVEL
				  ,@ErrorLine = @ErrorLine;

	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN 0

END

GO
