IF OBJECT_ID ('target.p_Flex_InsertData') IS NOT NULL
	DROP PROCEDURE target.p_Flex_InsertData
GO

-- exec [target].[p_Flex_InsertData] 'Reconciliation.Pnl', 'PROD'
CREATE PROC [target].[p_Flex_InsertData]
(
	@Schema		VARCHAR(250),
	@Env		VARCHAR(6),
	@ExecutionTime		DATETIME2(7) = NULL
)
AS

BEGIN

    SET NOCOUNT ON;

    DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
        @NowDate            DATETIME2;

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	    = 'Invoking ' + @ProcedureName,
        @NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;
		
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'

	DECLARE @BusDate BIT,
            @UserName BIT,
            @HierarchyKey BIT,
            @RiskFactorKey BIT, 
            @RiskFactorTypeKey BIT, 
            @RiskMeasureTypeKey BIT, 
            @ScenarioHierarchyKey BIT, 
            @InstrumentKey BIT, 
            @InstrumentTypeKey BIT, 
            @SourceKey BIT, 
            @TenorKey BIT, 
            @SchemaDimensions VARCHAR(250), 
            @SchemaFacts VARCHAR(250)

	SET @SchemaDimensions = @Schema + '.MetaData.Dimension.Name'
	SET @SchemaFacts = @Schema + '.MetaData.Fact.Name'

    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaFacts AND Name = 'BusDate')
		SET @BusDate=1

    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'UserName')
		SET @UserName=1

    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'HierarchyKey')
		SET @HierarchyKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'HierarchyKey')
		SET @HierarchyKey=1

    IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'InstrumentKey')
		SET @InstrumentKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'InstrumentTypeKey')
		SET @InstrumentTypeKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'RiskFactorKey')
		SET @RiskFactorKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'RiskFactorTypeKey')
		SET @RiskFactorTypeKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'RiskMeasureTypeKey')
		SET @RiskMeasureTypeKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'ScenarioHierarchyKey')
		SET @ScenarioHierarchyKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'SourceKey')
		SET @SourceKey=1

	IF EXISTS(SELECT FlexFactHierarchyKey FROM [target].[FlexFactHierarchy] FH WHERE FH.[Description] = @SchemaDimensions AND Name = 'TenorKey')
		SET @TenorKey=1

	
	DECLARE @SQLINSERT NVARCHAR(4000) 
    DECLARE @SQLSELECT NVARCHAR(4000) 
	DECLARE @SQLRESOLVER nvarchar(4000)
	DECLARE @SQLEXPIREOLD nvarchar(4000)

    --------------INSERT DATA TO FLEX STORAGE----------------------

    DECLARE @FlexFactHierarchyKey bigint = null
    SELECT @FlexFactHierarchyKey = FlexFactHierarchyKey from target.FlexFactHierarchy where Description = @Schema + '.Data'

	if(@FlexFactHierarchyKey is null)
	begin 
		 RAISERROR ('Unable to locate FlexFactHierarchyKey', 16, 1);  
	end

	SET @SQLINSERT = 'INSERT INTO target.FlexFact ([CoreKey],[FlexFactHierarchyKey],[Start],[Finish]'
    SET @SQLSELECT = ' SELECT [CoreKey], '+ cast(@FlexFactHierarchyKey as varchar(max))+',''' + CAST(@NowDate as varchar(max)) + ''', ''9999-12-31'''

    --[InstrumentTypeKey],[RiskFactorKey],[RiskFactorTypeKey],[RiskMeasureTypeKey],[ScenarioHierarchyKey],[SourceKey],[TenorKey],[AppliedRules])'
    
    --SET @SQL = @SQL + , BusDate, UserName, '
	
    SET @SQLEXPIREOLD = ' UPDATE target.FlexFact set Finish=''' + cast(@NowDate as varchar(max)) + ''' FROM #TempStorage inner join target.FlexFact on '

    IF(@BusDate > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [BusDate] '
        SET @SQLSELECT = @SQLSELECT + ', [BusDate] '
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.BusDate=#TempStorage.BusDate AND'
	END 
	
    IF(@UserName > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [UserName]'
        SET @SQLSELECT = @SQLSELECT + ', [UserName]'
	END 

    IF(@HierarchyKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [HierarchyKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedHierarchyKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.HierarchyKey=#TempStorage.ResolvedHierarchyKey AND'
	END 
	
    IF(@InstrumentKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [InstrumentKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedInstrumentKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.InstrumentKey=#TempStorage.ResolvedInstrumentKey AND'
	END 
	

	IF(@InstrumentTypeKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [InstrumentTypeKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedInstrumentTypeKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.InstrumentTypeKey=#TempStorage.ResolvedInstrumentTypeKey AND'
	END 
	

	IF(@RiskFactorKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [RiskFactorKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedRiskFactorKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.RiskFactorKey=#TempStorage.ResolvedRiskFactorKey AND'
	END
	
	IF(@RiskFactorTypeKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [RiskFactorTypeKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedRiskFactorTypeKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.RiskFactorTypeKey=#TempStorage.ResolvedRiskFactorTypeKey AND'
	END 
	
	IF(@RiskMeasureTypeKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [RiskMeasureTypeKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedRiskMeasureTypeKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.RiskMeasureTypeKey=#TempStorage.ResolvedRiskMeasureTypeKey AND'
	END 
	
	IF(@ScenarioHierarchyKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [ScenarioHierarchyKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedScenarioHierarchyKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.ScenarioHierarchyKey=#TempStorage.ResolvedScenarioHierarchyKey AND'
	END 
	
	IF(@SourceKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [SourceKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedSourceKey'   
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.SourceKey=#TempStorage.ResolvedSourceKey AND'
	END 
	
	IF(@TenorKey > 0)
	BEGIN
        SET @SQLINSERT = @SQLINSERT + ', [TenorKey]'
        SET @SQLSELECT = @SQLSELECT + ', ResolvedTenorKey'
        SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' target.FlexFact.TenorKey=#TempStorage.ResolvedTenorKey AND'
	END 
	
    SET @SQLINSERT = @SQLINSERT + ')'

	SET @SQLEXPIREOLD = substring(@SQLEXPIREOLD, 1, (len(@SQLEXPIREOLD) - 3))	

	-- get key column if it exists
	declare @KeyColumn varchar(100)
	select @KeyColumn = Name from target.FlexFactHierarchy where Description = @SchemaFacts and ParentFlexFactHierarchyKey =  (select top 1 ParentFlexFactHierarchyKey  from target.FlexFactHierarchy where Description = @Schema+'.MetaData.Fact.UseAsKey' and Finish = '9999-12-31')
	if @KeyColumn is not null
	begin
	SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' inner join target.FlexFactInstance on target.FlexFactInstance.FlexFactKey = target.FlexFact.FlexFactKey ' 
    SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' and target.FlexFactInstance.[Key] = '''+@KeyColumn+''' and target.FlexFactInstance.[Value] = #TempStorage.'+@KeyColumn+'' 
	end
	SET @SQLEXPIREOLD = @SQLEXPIREOLD + ' where Finish = ''9999-12-31'' and target.FlexFact.FlexFactHierarchyKey = ' + cast(@FlexFactHierarchyKey as varchar(7))

	
	SET @SQLINSERT = @SQLINSERT + @SQLSELECT + ' FROM #TempStorage'
	EXEC [core].[p_LogDebug] @ProcedureName, @SQLINSERT
	EXEC [core].[p_LogDebug] @ProcedureName, @SQLEXPIREOLD

	--EXEC [core].[p_LogInfo] @ProcedureName, 'Checking if there are any records to expire'
	EXEC sp_executesql @SQLEXPIREOLD
	SET @Message = 'Expired ' + cast(@@RowCount as varchar(255))  + ' FlexFact records'
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

	EXEC [core].[p_LogInfo] @ProcedureName, 'Inserting new records to FlexFact table '
	EXEC sp_executesql @SQLINSERT
	SET @Message = 'Inserted ' + cast(@@RowCount as varchar(255))  + ' new FlexFact records'
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

    -- BUILD INSERT METRICS

    DECLARE @MetricKeyColumn varchar(100)
	IF (SELECT CURSOR_STATUS('global','metric_cursor')) >= -1
	BEGIN
		IF (SELECT CURSOR_STATUS('global','metric_cursor')) > -1
		BEGIN
		    CLOSE metric_cursor
		END
		DEALLOCATE metric_cursor
	END

    DECLARE @Counter AS INTEGER
    SET @Counter = 0

	DECLARE metric_cursor CURSOR FOR   
	SELECT Name 
	  FROM [target].[FlexFactHierarchy] 
	 WHERE [Description] = @SchemaFacts 
	   AND Name != 'BusDate'

	OPEN metric_cursor
	FETCH NEXT FROM metric_cursor   
	INTO @MetricKeyColumn

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		SET @SQLINSERT ='INSERT INTO [target].[FlexFactInstance] ([FlexFactKey],[Key],[Value],[AppliedRules]) ' 
        SET @SQLINSERT = @SQLINSERT + 'SELECT distinct T.FlexFactKey, ''' + @MetricKeyColumn + ''',TS.' + @MetricKeyColumn  +  ', NULL AS AppliedRules '
        SET @SQLINSERT = @SQLINSERT + ' FROM target.FlexFact T '
        SET @SQLINSERT = @SQLINSERT + ' INNER JOIN target.FlexFactHierarchy H ON T.FlexFactHierarchyKey = H.FlexFactHierarchyKey '
        SET @SQLINSERT = @SQLINSERT + ' INNER JOIN #TempStorage TS ON'
		
        IF(@BusDate > 0)
    		SET @SQLINSERT = @SQLINSERT + ' T.BusDate = TS.BusDate AND'

		IF(@RiskFactorKey > 0)
    		SET @SQLINSERT = @SQLINSERT + ' T.RiskFactorKey = TS.ResolvedRiskFactorKey AND'
	
		IF(@RiskFactorTypeKey > 0)
		    SET @SQLINSERT = @SQLINSERT + ' T.RiskFactorTypeKey = TS.ResolvedRiskFactorTypeKey AND'
		
		IF(@RiskMeasureTypeKey > 0)
            SET @SQLINSERT = @SQLINSERT + ' T.RiskMeasureTypeKey = TS.ResolvedRiskMeasureTypeKey AND'
		
		IF(@ScenarioHierarchyKey > 0)
		    SET @SQLINSERT = @SQLINSERT + ' T.ScenarioHierarchyKey = TS.ResolvedScenarioHierarchyKey AND'
		
		IF(@HierarchyKey > 0)
		    SET @SQLINSERT = @SQLINSERT + ' T.HierarchyKey = TS.ResolvedHierarchyKey AND'
		
		IF(@InstrumentKey > 0)
		    SET @SQLINSERT = @SQLINSERT + ' T.InstrumentKey = TS.ResolvedInstrumentKey AND'
		
		IF(@InstrumentTypeKey > 0)
		    SET @SQLINSERT = @SQLINSERT + ' T.InstrumentTypeKey = TS.ResolvedInstrumentTypeKey AND'
		
		IF(@SourceKey > 0)
			SET @SQLINSERT = @SQLINSERT + ' T.SourceKey = TS.ResolvedSourceKey AND'
		
		IF(@TenorKey > 0)
			SET @SQLINSERT = @SQLINSERT + ' T.TenorKey = TS.ResolvedTenorKey AND'
        
		SET @SQLINSERT = @SQLINSERT + ' T.Start = ''' + CONVERT(VARCHAR(50), @NowDate) + ''' AND'
        SET @SQLINSERT = @SQLINSERT + ' H.Description = ''' + @Schema + '.Data''' + ' AND T.CoreKey = TS.CoreKey AND TS.' + @MetricKeyColumn + '<>'''''
 		
        EXEC [core].[p_LogDebug] @ProcedureName, @SQLINSERT
		EXEC sp_executesql @SQLINSERT
		
        SET @Counter = @Counter + 1

	    FETCH NEXT FROM metric_cursor INTO @MetricKeyColumn
	END

	CLOSE metric_cursor  
	DEALLOCATE metric_cursor 
	
	Update target.FlexFact set CoreKey = null where CoreKey is not null
	
	--Take note of load date
	set @SQLSELECT = 'set @busdate = select BusDate from #TempStorage'
	EXEC sp_executesql @SQLSELECT	
	
	EXEC [core].[p_Insert_TimeTravellingInstance] @BusDate, @NowDate, 'Flex', @Env, 'FlexFactInstance'   
	
	--delete from target.FlexFactInstance where FlexFactKey in 
	--( 
	--	select F.FlexFactKey from target.FlexFactInstance I inner join target.FlexFact F on I.FlexFactKey=F.FlexFactKey
	--	where  Finish <> '9999-12-31'
	--)

	--delete from target.FlexFact where Finish <> '9999-12-31'

    SET @Message = 'Processed ' + CAST(@Counter AS VARCHAR(255)) + ' FlexInstance records'
    EXEC [core].p_LogInfo @ProcedureName, @Message

	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

		DECLARE
		@ErrorNumber	INT,
		@ErrorSeverity	INT,
		@ErrorState		INT,
		@ErrorLine		INT,
		@ErrorMessage	NVARCHAR(4000);

    SELECT
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
        @ErrorLine		= ERROR_LINE()		;

    --Log error
    EXEC [core].p_LogError @ErrorNumber = @ErrorNumber
				  ,@ProcedureName=@ProcedureName
				  ,@ErrorProcedure = @ProcedureName
				  ,@ErrorSeverity = @ErrorSeverity
				  ,@ErrorState = @ErrorState
				  ,@Message = @ErrorMessage
				  ,@NESTLEVEL = @@NESTLEVEL
				  ,@ErrorLine = @ErrorLine;

	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN 0

END

GO
