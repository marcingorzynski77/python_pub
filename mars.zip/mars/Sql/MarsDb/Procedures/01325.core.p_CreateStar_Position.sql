/****** Object:  StoredProcedure [core].[p_CreateStar_Position]    Script Date: 03/22/2017 14:34:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_CreateStar_Position]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_CreateStar_Position]
GO

CREATE PROC [core].[p_CreateStar_Position]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT			= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT,
		@MaxRow			BIGINT,
		@UTCDate		DATETIME2	= getutcdate()

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 

--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--First empty the star ready for new data
	TRUNCATE TABLE [core].Position_Source
	TRUNCATE TABLE [core].Position_Hierarchy
	TRUNCATE TABLE [core].Position_HierarchyBook
	TRUNCATE TABLE [core].Position_Instrument
	TRUNCATE TABLE [core].Position_InstrumentType	
	TRUNCATE TABLE [core].Position_Fact
	TRUNCATE TABLE [core].Position_Rating 
	TRUNCATE TABLE [core].Position_Country

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'Position_Fact'
	
	--#-------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT INTO  [core].Position_Source (
		[InterfaceName],
		[Environment],
		[Source],
		[Origin]
	)
	SELECT
		@DataFeed,
		@Env,
		isnull([Summit],'UNKNOWN') as 'Source',
		isnull([Summit],'UNKNOWN') as 'Origin'
	FROM
		[raw].Position_Merged V
	GROUP BY
		[Summit]

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[Position_Source] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Hierarchy Dimension -----------------------------------------#--

	DECLARE @hierarchytag as INT;
	-- build cursor 
	DECLARE @hierarchyCursor as CURSOR;
	
	SET @hierarchyCursor = CURSOR FOR
	SELECT distinct HierarchyTag FROM target.hierarchy where finish = '9999-12-31';
	OPEN @hierarchyCursor;
    FETCH NEXT FROM @hierarchyCursor INTO @hierarchytag
	--Hierarchy Dimension
	
	WHILE @@FETCH_STATUS = 0
	BEGIN


	--Hierarchy Dimension
	INSERT INTO [core].Position_Hierarchy (
		  CoreSourceKey
		, NodeType
--		, NodeDesk
		, NodeName
		, BookSystem
		, HierarchyTag
	)
	SELECT
		 S.CoreSourceKey
		,'BO' AS [NodeType]
--		,R.Desk
		,R.Book
		,'GDISUMMIT' --isnull(R.[Summit], 'Risk Management')
		,@hierarchytag
	FROM
		[raw].Position_Merged R
		join
		[core].Position_Source S
		on
			S.Source = isnull(R.[Summit],'UNKNOWN')
			and
			S.Origin = isnull(R.[Summit],'UNKNOWN')
	GROUP BY
		 S.CoreSourceKey
--		,R.Desk
		,R.Book
		,isnull(R.[Summit], 'Risk Management')

	set @InsertedCount = @@ROWCOUNT

	update
		T
	set
		T.HierarchyString = H.HierarchyString
	from
		[core].Position_Hierarchy T
		join
		[target].Hierarchy H
		on
			H.NodeName = T.NodeName
			and
			H.NodeType = T.NodeType
			and
			H.BookSystem = 'GDISUMMIT' --T.BookSystem
			and
			H.Start <= @UTCDate
			and
			H.Finish > @UTCDate
			and 
			H.HierarchyTag = @hierarchytag
		
	--ANY REMAINING BOOKS ARE BELIEVED TO BE BANKING BOOKS AND SO CAN BE IGNORED
	DELETE FROM [core].Position_Hierarchy 
	WHERE HierarchyString IS NULL
	
	
	FETCH NEXT FROM @hierarchyCursor INTO @hierarchytag

	END
	
	CLOSE @hierarchyCursor;
	DEALLOCATE @hierarchyCursor;
	--update
	--	T
	--set
	--	T.HierarchyString = H.HierarchyString + T.NodeName + '/'
	--from
	--	[core].Position_Hierarchy T
	--	join
	--	[target].vHierarchyConsolidated H
	--	on
	--		H.NodeName = T.NodeName
	--		and
	--		H.NodeType = T.NodeType
	--		and
	--		H.BookSystem = 'Risk Management' --T.BookSystem
	--		and
	--		H.Start <= @UTCDate
	--		and
	--		H.Finish > @UTCDate
	--where T.HierarchyString is null
			

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].[Position_Hierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
	INSERT INTO [core].Position_HierarchyBook (
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookSystem]
		,Trading
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		,BookSystem
		,1
	FROM
	[core].Position_Hierarchy H where NodeType = 'BO' and H.HierarchyTag = 0  -- we will have data for all hierarchies created and previous step but for books we can only need one , hence using default one
	
	
	-- update book attributes
	update
		T
	set
		T.BookCad2 = H.BookCad2
	from
		[core].Position_HierarchyBook T
		join
		[target].HierarchyBook H
		on
			H.NodeName = T.NodeName
			and
			H.NodeType = T.NodeType
			and
			H.BookSystem = 'GDISUMMIT' --T.BookSystem
			and
			H.Start <= @UTCDate
			and
			H.Finish > @UTCDate
	
	
	select @InsertedCount = @@ROWCOUNT
	
    SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].[Position_HierarchyBook] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	-- Country Dimension
	INSERT into [core].Position_Country (
		 [CoreSourceKey]
		,[IssuerPhysicalCountry]
		,[IssuerLogCountry]
		,[SecCountry]
	)
	SELECT DISTINCT
		 S.[CoreSourceKey]
		,R.[Issuer Physical Country]
		,R.[Issue Log Country]
		,COALESCE(R.[SecCountry], R.[Issuer Physical Country], R.[Issue Log Country]) AS 'SecCountry'
	FROM
		[raw].Position_Merged R
		join
		[core].Position_Source S
		on
			S.Source = isnull(R.[Summit],'UNKNOWN')
			and
			S.Origin = isnull(R.[Summit],'UNKNOWN')

			
	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Position_Country dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	-- Rating Dimension
	INSERT into [core].Position_Rating (
		 [CoreSourceKey]
		,[SecSandP_RISKRATE]
		,[SECMoodys_RISKRATE]
		,[INTERNAL_RISKRATE]
		,[SecECAI_RiskRate]
		,[SecHBOS_RiskRate]
		,[Fitch_RiskRate]
	)
	SELECT DISTINCT
		 isnull(S.[CoreSourceKey],'')
		,isnull(R.[SecS&P_RISKRATE],'')
		,isnull(R.[SECMoodys_RISKRATE],'')
		,isnull(R.[INTERNAL_RISKRATE],'')
		,isnull(R.[SecECAI_RiskRate],'')
		,isnull(R.[SecHBOS_RiskRate],'')
		,isnull(R.[Fitch_RiskRate],'')
	FROM
		[raw].Position_Merged R
		join
		[core].Position_Source S
		on
			S.Source = isnull(R.[Summit],'UNKNOWN')
			and
			S.Origin = isnull(R.[Summit],'UNKNOWN')


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Position_Rating dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	-- Instrument Dimension
	INSERT into [core].Position_Instrument (
		 [CoreSourceKey]
		,[Issue Date]
		,[InstrumentIDType]
		,[InstrumentID]		
		,[Product]
		,[Currency]
		,[Eff Date]
		,[Maturity]
		,[Issuer]
		,[IssuerName]
		,[FixedFRN]
		,[SeniorityLevel]
		,[Day Basis]
		,[PayFrequency]
		,[ISIN]
		,[Settle Ccy]
		,[CUSIP]
		,[Issue Price]
		,[RedemptionPrice]
		,[Ref Guarantor]
		,[Notes_LongName1]
		,[SIC2007]
		,[Index Linked Bond]
	)
	SELECT DISTINCT
		 S.[CoreSourceKey]
		,CASE WHEN R.[Issue Date] <> '' THEN convert(DATETIME2, R.[Issue Date], 103) ELSE NULL end as [Issue Date]
		,CASE WHEN R.[ISIN] <> '' THEN 'ISIN' ELSE 'CUSIP' end as [InstrumentIDType]
		,CASE WHEN R.[ISIN] <> '' THEN isnull(ISIN,'') ELSE isnull(CUSIP,'') end as [InstrumentID]
		,R.[Security Id]
		,R.[Ccy]
		,CASE WHEN R.[Eff Date] <> '' THEN CONVERT(DATETIME2, R.[Eff Date], 103) ELSE NULL END as [Eff Date]
		,CASE WHEN R.[Mat Date] <> '' THEN CONVERT(DATETIME2, R.[Mat Date], 103) ELSE NULL END as [Mat Date]
		,R.[Issuer]
		,R.[Issuer Full Name]
		,R.[Fix/Float]
		,R.[Seniority Level]
		,R.[Day Basis]
		,R.[PayFrequency]
		,R.[ISIN]
		,R.[Settle Ccy]
		,R.[CUSIP]
		,R.[Issue Price]
		,R.[RedemptionPrice]
		,R.[Ref Guarantor]
		,R.[Notes_LongName1]
		,R.[SIC2007]
		,R.[Index Linked Bond]
	FROM
		[raw].Position_Merged R
		join
		[core].Position_Source S
		on
			S.Source = isnull(R.[Summit],'UNKNOWN')
			and
			S.Origin = isnull(R.[Summit],'UNKNOWN')
		
	
	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Position_Instrument dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--
	
	-- Instrument Type Dimension
	INSERT into [core].Position_InstrumentType (
		[coreSourceKey]
		,[InstrumentType] 
		,[InstrumentSubType]
	)
	SELECT DISTINCT
		S.CoreSourceKey
		 ,isnull(R.[Security Type],'')
		 ,isnull(R.[Security Sub Type],'')
	FROM
		[raw].Position_Merged R
	join
		[core].Position_Source S
		on
			S.Source = isnull(R.[Summit],'UNKNOWN')
			and
			S.Origin = isnull(R.[Summit],'UNKNOWN')
	
		
	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].Position_InstrumentType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#----------------------------------------------- Populate the SummitBondPosition Fact ---------------------------------------------#--


	INSERT INTO [core].Position_Fact (
		  [CoreSourceKey]
		, [CoreHierarchyKey]
		, [CoreInstrumentKey]
		, [CoreInstrumentTypeKey]
		, [CoreCountryKey]
		, [CoreRatingKey]
		, [BusDate]
		, [PositionTradeDate]
		, [PositionValueDate]
		, [WABP]
		, [StartAccrual]
		, [EndAccrual]
		, [ValueDateAccrual]
		, [Unamortised]
		, [MarketValue]
		, [MarketValueGBP]
		, [MarketValueDP]
		, [MarketValueDPGBP]
		, [RealisedPnL]
		, [NPV]
		, [PosValDateNPV]
		, [InterestDays]
		, [CouponAmount]
		, [CS01]
		, [StandardisedCS01]
		, [ZSpread]
		, [HardCallDate]		
	)

	SELECT
		 isnull(S.[CoreSourceKey],0) as [CoreSourceKey]		
		,isnull(H.[CoreHierarchyBookKey],0)as [CoreHierarchyKey]
		,isnull(I.[coreInstrumentKey],0) as [CoreInstrumentKey]
		,isnull(T.[coreInstrumentTypeKey],0) as [CoreInstrumentTypeKey]
		,isnull(C.[CoreCountryKey],0) as [CoreCountryKey]
		,isnull(R.[CoreRatingKey],0) as [CoreRatingKey]
		,CONVERT(DATETIME2, P.[COB Date], 103) as [BusDate]
		,P.[Position_TradeDate]
		,P.[Position_ValueDate]
		,P.[WABP]
		,P.[StartAccrual]
		,P.[EndAccrual]
		,P.[ValueDateAccrual]
		,P.[Unamortised]
		,P.[MarkeVal]
		,P.[MarketValGBP]
		,P.[MarkeValDP]
		,P.[MarketValDPGBP]
		,P.[Realised PnL]
		,P.[NPV]
		,P.[PosValDateNPV]
		,P.[Interest_Days]
		,P.[CS01]
		,P.[StandardisedCS01]
		,P.[ZSpread]		
		,P.[Coupon_Amount]
		,CASE WHEN P.[Hard_Call_Date] <> '' THEN CONVERT(DATETIME2, P.[Hard_Call_Date], 103) ELSE NULL END as [Hard_Call_Date]		
	FROM
		[raw].Position_Merged P
		INNER JOIN
		[core].Position_HierarchyBook H
		ON 
			H.[NodeName] = P.[Book]
			and	
			H.[BookSystem] = 'GDISUMMIT' --ISNULL(P.[Summit], 'Risk Management')
		LEFT JOIN
		[core].Position_Source S
		ON
			S.[Source] = isnull(P.[Summit],'UNKNOWN')
			and
			S.[Origin] = isnull(P.[Summit],'UNKNOWN')
		LEFT JOIN
		[core].Position_Instrument I
		ON 
			P.[Security Id] = I.[Product]
		LEFT JOIN
		[core].Position_InstrumentType T
		ON 
			isnull(P.[Security Type],'') = T.[InstrumentType]
			AND isnull(P.[Security Sub Type],'')  = T.[InstrumentSubType]		 
		LEFT JOIN
		[core].Position_Country C 
		ON 
			P.[Issuer Physical Country] = C.[IssuerPhysicalCountry]
			and P.[Issue Log Country] = C.[IssuerLogCountry]
			and COALESCE(P.[SecCountry], P.[Issuer Physical Country], P.[Issue Log Country]) = C.[SecCountry]
		LEFT JOIN
		[core].Position_Rating R 
		ON 
			isnull(P.[SecS&P_RISKRATE],'') = R.[SecSandP_RISKRATE]
			and isnull(P.[SECMoodys_RISKRATE],'') = R.[SECMoodys_RISKRATE]
			and isnull(P.[INTERNAL_RISKRATE],'') = R.[INTERNAL_RISKRATE]
			and isnull(P.[SecECAI_RiskRate],'') = R.[SecECAI_RiskRate]
			and isnull(P.[SecHBOS_RiskRate],'') = R.[SecHBOS_RiskRate]
			and isnull(P.[Fitch_RiskRate],'') = R.[Fitch_RiskRate]
	

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(10)) + ' rows into core.Position fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message


END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO