IF OBJECT_ID ('core.p_UpdateFact_RiskMeasure') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_RiskMeasure
GO

CREATE PROC [core].[p_UpdateFact_RiskMeasure]
(
 	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT = 0
)
AS

BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName  		NVARCHAR(128),
		@Message 	    		NVARCHAR(MAX),
		@return_value			BIGINT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50),
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
	DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

    --Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter

	print 'Clear out any temp tables'
		-- Clear out any temp tables
		-------------------------------------------------------------------------------------------------
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_Source') IS NOT NULL DROP TABLE #C2T_SIMRA_Source;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_TenorIT') IS NOT NULL DROP TABLE #C2T_SIMRA_TenorIT;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_MUREX_Source') IS NOT NULL DROP TABLE #C2T_SIMRA_MUREX_Source;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_Hierarchy') IS NOT NULL DROP TABLE #C2T_SIMRA_Hierarchy;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_RiskFactor') IS NOT NULL DROP TABLE #C2T_SIMRA_RiskFactor;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_InstrumentType') IS NOT NULL DROP TABLE #C2T_SIMRA_InstrumentType;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_RiskFactorType') IS NOT NULL DROP TABLE #C2T_SIMRA_RiskFactorType;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_RiskMeasureType') IS NOT NULL DROP TABLE #C2T_SIMRA_RiskMeasureType;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_RiskMeasureFact') IS NOT NULL DROP TABLE #C2T_SIMRA_RiskMeasureFact;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_TenorUT') IS NOT NULL DROP TABLE #C2T_SIMRA_TenorUT;
	IF OBJECT_ID ('tempdb..#C2T_SIMRA_TenorFT') IS NOT NULL DROP TABLE #C2T_SIMRA_TenorFT;

	IF OBJECT_ID ('tempdb..#C2T_MUREX_Source') IS NOT NULL DROP TABLE #C2T_MUREX_Source;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_TenorIT') IS NOT NULL DROP TABLE #C2T_MUREX_TenorIT;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_Source') IS NOT NULL DROP TABLE #C2T_MUREX_Source;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_Hierarchy') IS NOT NULL DROP TABLE #C2T_MUREX_Hierarchy;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_RiskFactor') IS NOT NULL DROP TABLE #C2T_MUREX_RiskFactor;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_InstrumentType') IS NOT NULL DROP TABLE #C2T_MUREX_InstrumentType;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_RiskFactorType') IS NOT NULL DROP TABLE #C2T_MUREX_RiskFactorType;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_RiskMeasureType') IS NOT NULL DROP TABLE #C2T_MUREX_RiskMeasureType;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_RiskMeasureFact') IS NOT NULL DROP TABLE #C2T_MUREX_RiskMeasureFact;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_TenorUT') IS NOT NULL DROP TABLE #C2T_MUREX_TenorUT;
	IF OBJECT_ID ('tempdb..#C2T_MUREX_TenorFT') IS NOT NULL DROP TABLE #C2T_MUREX_TenorFT;

	IF OBJECT_ID ('tempdb..#C2T_RiskMeasureFact_Updates') IS NOT NULL DROP TABLE #C2T_RiskMeasureFact_Updates;

	-- Keep a tempory record of our deliberations

	CREATE TABLE #C2T_RiskMeasureFact_Updates (CoreKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);

	if @DataFeed in (
			 'Murex-ComData31'
			,'Murex-ComGrk'
			,'Murex-COmiCommod'
			,'Murex-ComPvbp'
		)
	begin

		-- Do the Data Mapping in the core table
		exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = '[core].[MurexSensitivities_RiskMeasure_Fact]', @FactOrDimTable = 'RiskMeasure', @SessionID = @SessionID

		print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
		-- Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision
		-------------------------------------------------------------------------------------------------

		CREATE TABLE #C2T_MUREX_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_Source (CoreDimKey, TargetDimKey)
			SELECT DISTINCT C.CoreSourceKey, T.SourceKey
			FROM [CORE].[MurexSensitivities_Source] C JOIN [TARGET].[Source] T ON
				C.InterfaceName = T.InterfaceName AND C.Environment = T.Environment AND C.Source = T.Source AND C.Origin = T.Origin
				AND T.Start <= @NowDate AND T.Finish > @NowDate

		CREATE TABLE #C2T_MUREX_TenorIT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_TenorIT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_MUREX_TenorUT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_TenorUT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_MUREX_TenorFT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_TenorFT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_MUREX_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_Hierarchy (CoreDimKey, TargetDimKey)
			SELECT [C].CoreHierarchyKey, MAX([T].HierarchyKey)											-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_Hierarchy] [C] JOIN [TARGET].vHierarchyConsolidated [T]
				ON 	COALESCE([C].[NodeName],'') = COALESCE([T].[NodeName],'')
					AND COALESCE([C].[NodeType],'') = COALESCE([T].[NodeType],'')
					AND [C].[BookSystem] = [T].[BookSystem]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreHierarchyKey

		CREATE TABLE #C2T_MUREX_RiskFactor (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_RiskFactor (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskFactorKey, MAX([T].RiskFactorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_RiskFactor] [C] JOIN [TARGET].RiskFactor [T]
				ON [C].[RiskFactorName] = [T].[RiskFactorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskFactorKey

		CREATE TABLE #C2T_MUREX_InstrumentType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_InstrumentType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreInstrumentTypeKey, MAX([T].InstrumentTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_InstrumentType] [C] JOIN [TARGET].InstrumentType [T]
				ON [C].[InstrumentType] = [T].[InstrumentType]
					AND [C].[InstrumentSubType] = [T].[InstrumentSubType]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreInstrumentTypeKey

		CREATE TABLE #C2T_MUREX_RiskFactorType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_RiskFactorType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskFactorTypeKey, MAX([T].RiskFactorTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_RiskFactorType] [C] JOIN [TARGET].RiskFactorType [T]
				ON [C].[RiskFactorTypeName] = [T].[RiskFactorTypeName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskFactorTypeKey

		CREATE TABLE #C2T_MUREX_RiskMeasureType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_MUREX_RiskMeasureType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskMeasureTypeKey, MAX([T].RiskMeasureTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[MurexSensitivities_RiskMeasureType] [C] JOIN [TARGET].RiskMeasureType [T]
				ON [C].[RiskMeasureTypeName] = [T].[RiskMeasureTypeName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskMeasureTypeKey



		PRINT 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
		--INSERT INTO @CoreIndexColumns VALUES ('ValueCurrency'),('CoreRiskFactorKey'),('CoreRiskFactorTypeKey'),('CoreRiskMeasureTypeKey'),('CoreInstrumentTypeKey'),('BusDate'), ('CoreInstrumentTenorKey')
		INSERT INTO @CoreIndexColumns VALUES ('BusDate'),('CoreHierarchyKey'),('CoreRiskMeasureTypeKey'),('CoreRiskFactorTypeKey'),('CoreRiskFactorKey'),('CoreInstrumentTypeKey'),('CoreInstrumentTenorKey'),('Product'),('ValueCurrency')
		EXEC core.p_CreateIndex
			@IndexName		= 'IX_MurexSensitivities_RiskMeasure_Fact_BusinessKeys',
			@SchemaName		= 'core',
			@TableName		= 'MurexSensitivities_RiskMeasure_Fact',
			@TableOfColumns	= @CoreIndexColumns

		SELECT DISTINCT
			@LoadInterface = S.InterfaceName
		FROM
			[core].[MurexSensitivities_RiskMeasure_Fact] F
			join
			[core].[MurexSensitivities_Source] S
			on
				F.CoreSourceKey = S.CoreSourceKey


		print 'Perform the actual merge'
		-- Perform the actual merge
		-------------------------------------------------------------------------------------------------
		INSERT #C2T_RiskMeasureFact_Updates ( CoreKey ,  FactKey, IsAttributeMatch )
	    SELECT [C].CoreRiskMeasureKey, [TARGET].FactKey,
            CASE WHEN COALESCE([C].[Value],0)=COALESCE([TARGET].[Value],0)
            AND COALESCE([C].[ValueGBP],0)=COALESCE([TARGET].[ValueGBP],0)
            THEN 1 ELSE 0 END AS IsAttributeMatch
            --,TARGET.*
                  FROM [CORE].[MurexSensitivities_RiskMeasure_Fact] [C]
					--JOIN [CORE].[MurexSensitivities_Source] CS ON C.[CoreSourceKey] = CS.[CoreSourceKey]
					JOIN #C2T_MUREX_TenorIT ON #C2T_MUREX_TenorIT.[CoreDimKey] = [C].[CoreInstrumentTenorKey]
					JOIN #C2T_MUREX_Source ON #C2T_MUREX_Source.[CoreDimKey] = [C].[CoreSourceKey]
					JOIN #C2T_MUREX_Hierarchy ON #C2T_MUREX_Hierarchy.[CoreDimKey] = [C].[CoreHierarchyKey]
					JOIN #C2T_MUREX_RiskFactor ON #C2T_MUREX_RiskFactor.[CoreDimKey] = [C].[CoreRiskFactorKey]
					JOIN #C2T_MUREX_RiskFactorType ON #C2T_MUREX_RiskFactorType.[CoreDimKey] = [C].[CoreRiskFactorTypeKey]
					JOIN #C2T_MUREX_InstrumentType ON #C2T_MUREX_InstrumentType.[CoreDimKey] = [C].[CoreInstrumentTypeKey]
					JOIN #C2T_MUREX_RiskMeasureType ON #C2T_MUREX_RiskMeasureType.[CoreDimKey] = [C].[CoreRiskMeasureTypeKey]
                  FULL OUTER JOIN (SELECT * FROM [TARGET].[RiskMeasure_Fact] F INNER JOIN #C2T_MUREX_Source S ON F.SourceKey = S.TargetDimKey where BusDate = @BusDate AND Finish > @NowDate) [TARGET] ON
                        [C].[ValueCurrency] = [TARGET].[ValueCurrency]
						AND [C].[BusDate] = [TARGET].[BusDate]											-- Will not be empty
						AND [C].[Product] = [TARGET].[Product]
						AND #C2T_MUREX_Hierarchy.[TargetDimKey] = [TARGET].[HierarchyKey]					-- And Dimension Keys - Should not be null, but just in case
						AND #C2T_MUREX_TenorIT.[TargetDimKey] = [TARGET].[InstrumentTenorKey]
						AND #C2T_MUREX_InstrumentType.[TargetDimKey] = [TARGET].[InstrumentTypeKey]
						AND #C2T_MUREX_RiskFactor.[TargetDimKey] = [TARGET].[RiskFactorKey]
						AND #C2T_MUREX_RiskFactorType.[TargetDimKey] = [TARGET].[RiskFactorTypeKey]
						AND #C2T_MUREX_RiskMeasureType.[TargetDimKey] = [TARGET].[RiskMeasureTypeKey]

		CREATE CLUSTERED INDEX IX_C2T_RiskMeasureFact_Updates_FactKey ON #C2T_RiskMeasureFact_Updates(FactKey,CoreKey)

		BEGIN TRANSACTION
    --Print 'Expire previous and replaced records'
		UPDATE
			[TARGET].[RiskMeasure_Fact]
		SET
			[Finish] = @NowDate
		FROM
			[TARGET].[RiskMeasure_Fact] AS FACT
			INNER JOIN
			#C2T_RiskMeasureFact_Updates C2T
			on
				FACT.FactKey = C2T.FactKey
			INNER JOIN
			[TARGET].[Source] S
			on
				S.SourceKey = FACT.SourceKey
		WHERE
			(
				(C2T.CoreKey IS NULL AND C2T.FactKey IS NOT NULL)
				OR
				(C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
			)
			AND
			S.InterfaceName = @LoadInterface
			AND
			FACT.BusDate = @BusDate

	SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	INSERT [TARGET].[RiskMeasure_Fact] ( /*[FactKey], */ --[AppliedRules] -- CoreFactKey & TargetFactKey
						  Busdate, Start, Finish
						, SourceKey
						, InstrumentTenorKey
						, HierarchyKey
						, InstrumentTypeKey
						, RiskFactorKey
						, RiskFactorTypeKey
						, RiskMeasureTypeKey
                        , Product
						, ValueCurrency
						, [Value]
						, [ValueGBP] )
				SELECT
					[CORE].[BUSDATE]
						, @NowDate, @finish
						,#C2T_MUREX_Source.[TargetDimKey] [SourceKey]
						,#C2T_MUREX_TenorIT.[TargetDimKey] [InstrumentTenorKey]
						,#C2T_MUREX_Hierarchy.[TargetDimKey] [HierarchyKey]
						,#C2T_MUREX_InstrumentType.[TargetDimKey] [InstrumentTypeKey]
						,#C2T_MUREX_RiskFactor.[TargetDimKey] [RiskFactorKey]
						,#C2T_MUREX_RiskFactorType.[TargetDimKey] [RiskFactorTypeKey]
						,#C2T_MUREX_RiskMeasureType.[TargetDimKey] [RiskMeasureTypeKey]
					,[Core].[Product]
					,[Core].[ValueCurrency]
					,[Core].[Value], [Core].[ValueGBP]
				FROM [CORE].[MurexSensitivities_RiskMeasure_Fact] [Core]
				--JOIN [CORE].[MurexSensitivities_Source] CS ON [CORE].[CoreSourceKey] = CS.[CoreSourceKey]
				JOIN #C2T_MUREX_TenorIT ON #C2T_MUREX_TenorIT.CoreDimKey = [Core].[CoreInstrumentTenorKey]
				JOIN #C2T_MUREX_Source ON #C2T_MUREX_Source.[CoreDimKey] = [Core].[CoreSourceKey]
				JOIN #C2T_MUREX_Hierarchy ON #C2T_MUREX_Hierarchy.[CoreDimKey] = [Core].[CoreHierarchyKey]
				JOIN #C2T_MUREX_RiskFactor ON #C2T_MUREX_RiskFactor.[CoreDimKey] = [Core].[CoreRiskFactorKey]
				JOIN #C2T_MUREX_RiskFactorType ON #C2T_MUREX_RiskFactorType.[CoreDimKey] = [Core].[CoreRiskFactorTypeKey]
				JOIN #C2T_MUREX_InstrumentType ON #C2T_MUREX_InstrumentType.[CoreDimKey] = [Core].[CoreInstrumentTypeKey]
				JOIN #C2T_MUREX_RiskMeasureType ON #C2T_MUREX_RiskMeasureType.[CoreDimKey] = [Core].[CoreRiskMeasureTypeKey]
				JOIN #C2T_RiskMeasureFact_Updates C2T ON [Core].CoreRiskMeasureKey = C2T.CoreKey
				WHERE (C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NULL)
				OR
				(C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)


		SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
		EXEC [core].p_LogInfo @ProcedureName, @Message

		COMMIT


	end
	else if @DataFeed = 'SimraFORiskMeasures'
	begin

		-- Do the Data Mapping in the core table
		exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = '[core].[SimraFORiskMeasures_Fact]', @FactOrDimTable = 'RiskMeasure', @SessionID = @SessionID

		print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
		-- Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision
		-------------------------------------------------------------------------------------------------

		CREATE TABLE #C2T_SIMRA_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_Source (CoreDimKey, TargetDimKey)
			SELECT DISTINCT C.CoreSourceKey, T.SourceKey
			FROM [CORE].[SimraFORiskMeasures_Source] C JOIN [TARGET].[Source] T ON
				C.InterfaceName = T.InterfaceName AND C.Environment = T.Environment AND C.Source = T.Source AND C.Origin = T.Origin
				AND T.Start <= @NowDate AND T.Finish > @NowDate

		CREATE TABLE #C2T_SIMRA_TenorIT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_TenorIT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_SIMRA_TenorUT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_TenorUT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_SIMRA_TenorFT (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_TenorFT (CoreDimKey, TargetDimKey)
			SELECT [C].CoreTenorKey, MAX([T].TenorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_Tenor] [C] JOIN [TARGET].Tenor [T]
				ON [C].[TenorName] = [T].[TenorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreTenorKey

		CREATE TABLE #C2T_SIMRA_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_Hierarchy (CoreDimKey, TargetDimKey)
			SELECT [C].CoreHierarchyKey, MAX([T].HierarchyKey)											-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_Hierarchy] [C] JOIN [TARGET].vHierarchyConsolidated [T]
				ON 	COALESCE([C].[NodeName],'') = COALESCE([T].[NodeName],'')
					AND COALESCE([C].[NodeType],'') = COALESCE([T].[NodeType],'')
					AND [C].[BookSystem] = [T].[BookSystem]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreHierarchyKey

		CREATE TABLE #C2T_SIMRA_RiskFactor (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_RiskFactor (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskFactorKey, MAX([T].RiskFactorKey)										-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_RiskFactor] [C] JOIN [TARGET].RiskFactor [T]
				ON [C].[RiskFactorName] = [T].[RiskFactorName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskFactorKey

		CREATE TABLE #C2T_SIMRA_InstrumentType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_InstrumentType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreInstrumentTypeKey, MAX([T].InstrumentTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_InstrumentType] [C] JOIN [TARGET].InstrumentType [T]
				ON [C].[InstrumentType] = [T].[InstrumentType]
					AND [C].[InstrumentSubType] = [T].[InstrumentSubType]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreInstrumentTypeKey

		CREATE TABLE #C2T_SIMRA_RiskFactorType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_RiskFactorType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskFactorTypeKey, MAX([T].RiskFactorTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_RiskFactorType] [C] JOIN [TARGET].RiskFactorType [T]
				ON [C].[RiskFactorTypeName] = [T].[RiskFactorTypeName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskFactorTypeKey

		CREATE TABLE #C2T_SIMRA_RiskMeasureType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
		INSERT #C2T_SIMRA_RiskMeasureType (CoreDimKey, TargetDimKey)
			SELECT [C].CoreRiskMeasureTypeKey, MAX([T].RiskMeasureTypeKey)								-- Be defensive on possible Corruption
			FROM [CORE].[SimraFORiskMeasures_RiskMeasureType] [C] JOIN [TARGET].RiskMeasureType [T]
				ON [C].[RiskMeasureTypeName] = [T].[RiskMeasureTypeName]
					AND T.Start <= @NowDate AND T.Finish > @NowDate
			GROUP BY [C].CoreRiskMeasureTypeKey


		PRINT 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
		--INSERT INTO @CoreIndexColumns VALUES('ProformaShift'),('LegalEntity'),('Cad2'),('InstrumentMatDays'),('ValueCurrency'),('BusDate'),('CoreRiskFactorKey'),('CoreRiskFactorTypeKey'),('CoreRiskMeasureTypeKey'),('CoreInstrumentTypeKey')
		INSERT INTO @CoreIndexColumns VALUES ('BusDate'),('CoreHierarchyKey'),('CoreRiskMeasureTypeKey'),('CoreRiskFactorTypeKey'),('CoreRiskFactorKey'),('CoreInstrumentTypeKey'),('CoreInstrumentTenorKey'),('CoreUnderlyingTenorKey'),('CoreFixingTenorKey'),('ProformaShift'),('LegalEntity'),('Cad2'),('ValueCurrency')
		EXEC core.p_CreateIndex
				@IndexName		= 'IX_SimraFORiskMeasures_Fact_BusinessKeys',
				@SchemaName		= 'core',
				@TableName		= 'SimraFORiskMeasures_Fact',
				@TableOfColumns	= @CoreIndexColumns

		SELECT DISTINCT
			@LoadInterface = S.InterfaceName
		FROM
			[core].[SimraFORiskMeasures_Fact] F
			join
			[core].[SimraFORiskMeasures_Source] S
			on
				F.CoreSourceKey = S.CoreSourceKey

		-- Clear out any temp tables
		-------------------------------------------------------------------------------------------------
		--IF OBJECT_ID ('tempdb..#C2T_Trade') IS NOT NULL DROP TABLE #C2T_Trade;


		--print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
		-- Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision
		-------------------------------------------------------------------------------------------------

		------------------
		-- ARE THESE ATTRIBUTES, BUISNESS KEYS OR DIMENSIONS?

							----,[C].[CoreTenorITKey]
							----,[C].[CoreTenorUTKey]
							----,[C].[CoreTenorFTKey]

		-- ABOVE ARE CODED AS BUISNES KEYS BELOW WHICH MAY NOT BE CORRECT, BUT AS NULL WHEN LAST LOOKED, MAY NOT MATTER.
		----------------------

		--print 'Perform the actual merge'
		-- Perform the actual merge
		-------------------------------------------------------------------------------------------------

		print 'Perform the actual merge'

		INSERT #C2T_RiskMeasureFact_Updates ( CoreKey ,  FactKey, IsAttributeMatch )
	    SELECT [C].CoreRiskMeasureKey, [TARGET].FactKey,
            CASE WHEN COALESCE([C].[Value],0)=COALESCE([TARGET].[Value],0)
            AND COALESCE([C].[ValueGBP],0)=COALESCE([TARGET].[ValueGBP],0)
            AND COALESCE([C].[ProformaShiftValue],0)=COALESCE([TARGET].[ProformaShiftValue],0)
            AND COALESCE([C].[UnderlyingMatDays],0)=COALESCE([TARGET].[UnderlyingMatDays],0)
            AND COALESCE([C].[FixingMatDays],0)=COALESCE([TARGET].[FixingMatDays],0)
            THEN 1 ELSE 0 END AS IsAttributeMatch
            --,TARGET.*
                  FROM [CORE].[SimraFORiskMeasures_Fact] [C]
					--LEFT JOIN [CORE].[SimraFORiskMeasures_Source] CS ON C.[CoreSourceKey] = CS.[CoreSourceKey]
					JOIN #C2T_SIMRA_TenorIT ON #C2T_SIMRA_TenorIT.[CoreDimKey] = [C].[CoreInstrumentTenorKey]
					JOIN #C2T_SIMRA_TenorUT ON #C2T_SIMRA_TenorUT.[CoreDimKey] = [C].[CoreUnderlyingTenorKey]
					JOIN #C2T_SIMRA_TenorFT ON #C2T_SIMRA_TenorFT.[CoreDimKey] = [C].[CoreFixingTenorKey]
					JOIN #C2T_SIMRA_Source ON #C2T_SIMRA_Source.[CoreDimKey] = [C].[CoreSourceKey]
					JOIN #C2T_SIMRA_Hierarchy ON #C2T_SIMRA_Hierarchy.[CoreDimKey] = [C].[CoreHierarchyKey]
					JOIN #C2T_SIMRA_RiskFactor ON #C2T_SIMRA_RiskFactor.[CoreDimKey] = [C].[CoreRiskFactorKey]
					JOIN #C2T_SIMRA_RiskFactorType ON #C2T_SIMRA_RiskFactorType.[CoreDimKey] = [C].[CoreRiskFactorTypeKey]
					JOIN #C2T_SIMRA_InstrumentType ON #C2T_SIMRA_InstrumentType.[CoreDimKey] = [C].[CoreInstrumentTypeKey]
					JOIN #C2T_SIMRA_RiskMeasureType ON #C2T_SIMRA_RiskMeasureType.[CoreDimKey] = [C].[CoreRiskMeasureTypeKey]
                  FULL OUTER JOIN (SELECT * FROM [TARGET].[RiskMeasure_Fact] F INNER JOIN #C2T_SIMRA_Source S ON F.SourceKey = S.TargetDimKey where BusDate = @BusDate AND Finish > @NowDate) [TARGET] ON
                        [C].[ValueCurrency] = [TARGET].[ValueCurrency]
						AND [C].[BusDate] = [TARGET].[BusDate]											-- Will not be empty
						AND [C].ProformaShift = [TARGET].ProformaShift
						AND [C].LegalEntity = [TARGET].LegalEntity
						AND [C].Cad2 = [TARGET].Cad2
						AND #C2T_SIMRA_Hierarchy.[TargetDimKey] = [TARGET].[HierarchyKey]					-- And Dimension Keys - Should not be null, but just in case
						AND #C2T_SIMRA_TenorIT.[TargetDimKey] = [TARGET].[InstrumentTenorKey]
						AND #C2T_SIMRA_TenorUT.[TargetDimKey] = [TARGET].[UnderlyingTenorKey]
						AND #C2T_SIMRA_TenorFT.[TargetDimKey] = [TARGET].[FixingTenorKey]
						AND #C2T_SIMRA_Source.[TargetDimKey]  = [TARGET].[SourceKey]
						AND #C2T_SIMRA_InstrumentType.[TargetDimKey] = [TARGET].[InstrumentTypeKey]
						AND #C2T_SIMRA_RiskFactor.[TargetDimKey] = [TARGET].[RiskFactorKey]
						AND #C2T_SIMRA_RiskFactorType.[TargetDimKey] = [TARGET].[RiskFactorTypeKey]
						AND #C2T_SIMRA_RiskMeasureType.[TargetDimKey] = [TARGET].[RiskMeasureTypeKey]

		CREATE CLUSTERED INDEX IX_C2T_RiskMeasureFact_Updates_FactKey ON #C2T_RiskMeasureFact_Updates(FactKey,CoreKey)

        BEGIN TRANSACTION
    --Print 'Expire previous and replaced records'
		UPDATE
			[TARGET].[RiskMeasure_Fact]
		SET
			[Finish] = @NowDate
		FROM
			[TARGET].[RiskMeasure_Fact] AS FACT
			INNER JOIN
			#C2T_RiskMeasureFact_Updates C2T
			on
				FACT.FactKey = C2T.FactKey
			INNER JOIN
			[TARGET].[Source] S
			on
				S.SourceKey = FACT.SourceKey
		WHERE
			(
				(C2T.CoreKey IS NULL AND C2T.FactKey IS NOT NULL)
				OR
				(C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
			)
			AND
			S.InterfaceName = @LoadInterface
			AND
			FACT.BusDate = @BusDate

		SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
		EXEC [core].p_LogInfo @ProcedureName, @Message


		INSERT [TARGET].[RiskMeasure_Fact] ( /*[FactKey], */ --[AppliedRules] -- CoreFactKey & TargetFactKey
						Busdate, Start, Finish
						, SourceKey
						, InstrumentTenorKey
						, UnderlyingTenorKey
						, FixingTenorKey
						, HierarchyKey
						, InstrumentTypeKey
						, RiskFactorKey
						, RiskFactorTypeKey
						, RiskMeasureTypeKey
						, ProformaShift
						, ProformaShiftValue
						, LegalEntity
						, Cad2
						, ValueCurrency
						, [Value]
						, [ValueGBP] )
				SELECT
					[CORE].[BUSDATE]
					, @NowDate, @finish
						,#C2T_SIMRA_Source.[TargetDimKey] [SourceKey]
						,#C2T_SIMRA_TenorIT.[TargetDimKey] [InstrumentTenorKey]
						,#C2T_SIMRA_TenorUT.TargetDimKey UnderlyingTenorKey
						,#C2T_SIMRA_TenorFT.TargetDimKey FixingTenorKey
						,#C2T_SIMRA_Hierarchy.[TargetDimKey] [HierarchyKey]
						,#C2T_SIMRA_InstrumentType.[TargetDimKey] [InstrumentTypeKey]
						,#C2T_SIMRA_RiskFactor.[TargetDimKey] [RiskFactorKey]
						,#C2T_SIMRA_RiskFactorType.[TargetDimKey] [RiskFactorTypeKey]
						,#C2T_SIMRA_RiskMeasureType.[TargetDimKey] [RiskMeasureTypeKey]
						,[Core].ProformaShift
						,[Core].ProformaShiftValue
						,[Core].LegalEntity
						,[Core].Cad2
						,[Core].ValueCurrency
						,[Core].Value
						,[Core].ValueGBP
				FROM [CORE].[SimraFORiskMeasures_Fact] [Core]
				--JOIN [CORE].[SimraFORiskMeasures_Source] CS ON [CORE].[CoreSourceKey] = CS.[CoreSourceKey]
				JOIN #C2T_SIMRA_TenorIT ON #C2T_SIMRA_TenorIT.CoreDimKey = [Core].[CoreInstrumentTenorKey]
				JOIN #C2T_SIMRA_TenorUT ON #C2T_SIMRA_TenorUT.CoreDimKey = [Core].CoreUnderlyingTenorKey
				JOIN #C2T_SIMRA_TenorFT ON #C2T_SIMRA_TenorFT.CoreDimKey = [Core].CoreFixingTenorKey
				JOIN #C2T_SIMRA_Source ON #C2T_SIMRA_Source.[CoreDimKey] = [Core].[CoreSourceKey]
				JOIN #C2T_SIMRA_Hierarchy ON #C2T_SIMRA_Hierarchy.[CoreDimKey] = [Core].[CoreHierarchyKey]
				JOIN #C2T_SIMRA_RiskFactor ON #C2T_SIMRA_RiskFactor.[CoreDimKey] = [Core].[CoreRiskFactorKey]
				JOIN #C2T_SIMRA_RiskFactorType ON #C2T_SIMRA_RiskFactorType.[CoreDimKey] = [Core].[CoreRiskFactorTypeKey]
				JOIN #C2T_SIMRA_InstrumentType ON #C2T_SIMRA_InstrumentType.[CoreDimKey] = [Core].[CoreInstrumentTypeKey]
				JOIN #C2T_SIMRA_RiskMeasureType ON #C2T_SIMRA_RiskMeasureType.[CoreDimKey] = [Core].[CoreRiskMeasureTypeKey]
				JOIN #C2T_RiskMeasureFact_Updates C2T ON [Core].CoreRiskMeasureKey = C2T.CoreKey
				WHERE (C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NULL)
				OR
				(C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)


		SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
		EXEC [core].p_LogInfo @ProcedureName, @Message

		COMMIT

	end

	-- Change the Superceeded data to mark it as just expired in this run
	-------------------------------------------------------------------------------------------------
	--UPDATE [TARGET].[RiskMeasure_Fact] SET CoreFactKey = Null

END TRY


--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO