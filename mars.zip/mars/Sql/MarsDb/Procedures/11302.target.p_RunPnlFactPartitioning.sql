IF OBJECT_ID ('target.p_RunPnlFactPartitioning') IS NOT NULL
	DROP PROCEDURE target.p_RunPnlFactPartitioning
GO
-- _PnlFact_Part_
-- _RiskMeasurePnlFact_Part_
-- PnlFact_RangePartScheme
-- PnlFact_RangePartFunction

--[target].[p_RunPnlFactPartitioning] '2017-03-01', 'PnlFact_RangePartFunction', 'PnlFact_RangePartScheme', '_PnlFact_Part_'
--[target].[p_RunPnlFactPartitioning] '2017-03-01', 'RiskMeasurePnlFact_RangePartFunction', 'RiskMeasurePnlFact_RangePartScheme', '_RiskMeasurePnlFact_Part_'
--[target].[p_RunPnlFactPartitioning] '2017-03-01', 'MarketDataFact_RangePartFunction', 'MarketDataFact_RangePartScheme', '_MarketDataFact_Part_'
--[target].[p_RunPnlFactPartitioning] '2017-03-01', 'VaRFact_RangePartFunction', 'VaRFact_RangePartScheme', '_VaRFact_Part_'
--[target].[p_RunPnlFactPartitioning] '2017-12-01', 'TradeLevelFact_RangePartFunction', 'TradeLevelFact_RangePartScheme', '_TradeLevelFact_Part_'
--[target].[p_RunPnlFactPartitioning] '2017-12-01', 'AggregatedFact_RangePartFunction', 'AggregatedFact_RangePartScheme', '_AggregatedFact_Part_'

-- exec [target].[p_RunPnlFactPartitioning] '2017-03-01' business date is optional and only provided if partitioning is not already set up, in this case set the date that was used in p_RunPnlFactArchiving
CREATE PROC [target].[p_RunPnlFactPartitioning] 
(
	@BusinessDate datetime2 = null,
	@RangePartFunction varchar(250) = null,
	@RangePartScheme varchar(250) = null,
	@PartFunction varchar(250) = null,
	@Months int = 12
)
AS 
BEGIN

	SET NOCOUNT ON
	
	DECLARE		
        @ProcedureName  			NVARCHAR(128),
        @Message 	    			NVARCHAR(MAX),   
        @SQL 	    			    NVARCHAR(4000),        
		@return_value				BIGINT		
		

BEGIN TRY


 
Declare @db varchar(50) = DB_NAME()
Declare @currentDate datetime2 = DATEADD(m, DATEDIFF(m, -2, ISNULL(@BusinessDate,GETDATE())), 0)
Declare @endDate datetime2 = DateAdd(month,@Months, @currentDate) -- new end date
Declare @dateAdd int = 1 -- Add 3 month = 1 Quarter

-- Get Current boundaries 
Select @currentDate = isnull(DATEADD(MONTH, @dateAdd,Cast(MAX(value) as datetime2)), @currentDate) From sys.partition_range_values as r
    Inner Join sys.partition_functions as f on r.function_id = f.function_id
Where f.name = @RangePartFunction
--'PnlFact_RangePartFunction'

Print 'Start date is set to ' + cast(@currentDate as varchar(50))
Print 'End date is set to ' + cast(@endDate as varchar(50))

-- Get all quarters between max and end date
; with d(id, date, name) as (
    Select 0, @currentDate, Convert(char(6), @currentDate, 112)
    Union All
    Select id+1, DATEADD(MONTH, @dateAdd, date), Convert(char(6), DATEADD(MONTH, @dateAdd, date), 112)
    From d Where d.date <= @endDate
)

Select * From (
    Select id = id*10, query = 'If Not Exists(Select 1 From sys.filegroups Where name = '''+@db+@PartFunction+name+''')
        Begin 
            Print ''Create Filegroup ['+@db+@PartFunction+name+']''
            Alter Database ['+DB_NAME()+'] Add Filegroup ['+@db+@PartFunction+name+']
        End
        '
    From d
    Union All
    Select id*10+1, 'If Not Exists(Select 1 From sys.sysfiles Where name = '''+@db+@PartFunction+name+''')
        Begin 
            Print ''Create File ['+@db+@PartFunction+name+'.ndf]''
            Alter Database '+DB_NAME()+' Add FILE ( NAME = N''FG_'+@db+@PartFunction+name+''', FILENAME = N''H:\Data\MSSQL10_50.'+@@servicename+'\MSSQL\DATA\FG_'+@db+@PartFunction+name+'.ndf'' , SIZE = 1000KB , FILEGROWTH = 1000KB ) TO Filegroup ['+@db+@PartFunction+name+']
        End
        '
    From d
    Union All
    Select id*10+2, 'Print ''Add Range ['+@db+@PartFunction+name+']''
        Alter Partition Scheme '+@RangePartScheme+' Next Used ['+@db+@PartFunction+name+']
        '
    From d
    Union All
    Select id*10+3, 'Print ''Split Function ['+Convert(char(8), date, 112)+']''
        Alter Partition Function '+@RangePartFunction+'() Split Range ('''+Convert(char(8), date, 112)+''');
        '
    From d
) as q order by id

	
END TRY


--#---------------------------------------------------- END OF IUSP ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
