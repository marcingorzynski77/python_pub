IF OBJECT_ID ('core.p_UpdateFact_Limit') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_Limit
GO

CREATE PROC [core].[p_UpdateFact_Limit]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT = 0,
	@HierarchyTag	INT
)
AS

BEGIN
    SET NOCOUNT ON;

	DECLARE
        @ProcedureName  			NVARCHAR(128),
        @Message 	    			NVARCHAR(MAX),
		@return_value				BIGINT;

	-- Legacy Core2Target
    DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
    DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT			= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
    DECLARE
		@BusinessKeyColumns			core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns				core.Core2TargetParameter

    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

    --Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'

	PRINT 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter
	--INSERT INTO @CoreIndexColumns VALUES ('LimitID'), ('Name'), ('CategoryName'), ('LimitStartDate'), ('LimitEndDate'), ('IsOverride')
	INSERT INTO @CoreIndexColumns VALUES ('LimitID'), ('LimitStartDate'), ('LimitEndDate'), ('IsOverride')
	EXEC core.p_CreateIndex
		@IndexName = 'IX_Limit_Fact_BusinessKeys',
		@SchemaName = 'core',
		@TableName = 'Limit_Fact',
		@TableOfColumns = @CoreIndexColumns

	SELECT DISTINCT
		@LoadInterface = S.InterfaceName
	FROM
		[core].[Limit_Fact] F
		join
		[core].[Limit_Source] S
		on
			F.CoreSourceKey = S.CoreSourceKey

	print 'Clear out any temp tables'
	-- Clear out any temp tables
	-------------------------------------------------------------------------------------------------
	IF OBJECT_ID ('tempdb..#C2T_Source') IS NOT NULL DROP TABLE #C2T_Source;
	IF OBJECT_ID ('tempdb..#C2T_Hierarchy') IS NOT NULL DROP TABLE #C2T_Hierarchy;
	IF OBJECT_ID ('tempdb..#C2T_RiskMeasureType') IS NOT NULL DROP TABLE #C2T_RiskMeasureType;
	IF OBJECT_ID ('tempdb..#C2T_Fact_Updates') IS NOT NULL DROP TABLE #C2T_Fact_Updates;

	-- Do the Data Mapping in the core table
	exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = '[core].[Limit_Fact]', @FactOrDimTable = 'Limit', @SessionID = @SessionID

	print 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
	-- Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision
	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_Source (CoreDimKey, TargetDimKey)
		SELECT DISTINCT C.CoreSourceKey, T.SourceKey
		FROM [CORE].[Limit_Source] C JOIN [TARGET].[Source] T ON
			C.InterfaceName = T.InterfaceName AND C.Environment = T.Environment AND C.Source = T.Source AND C.Origin = T.Origin
			AND T.Start <= @NowDate AND T.Finish > @NowDate

	CREATE TABLE #C2T_Hierarchy (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_Hierarchy (CoreDimKey, TargetDimKey)
		SELECT [C].CoreHierarchyKey, MAX([T].HierarchyKey)											-- Be defensive on possible Corruption
		FROM [CORE].[Limit_Hierarchy] [C] JOIN (select * from target.Hierarchy where HierarchyTag = @HierarchyTag) [T]
			ON COALESCE([C].[HierarchyString],'') = COALESCE([T].[HierarchyString],'')
				AND COALESCE([C].[BookSystem],'') = COALESCE([T].[BookSystem],'')
				AND T.Start <= @NowDate AND T.Finish > @NowDate
		GROUP BY [C].CoreHierarchyKey

	CREATE TABLE #C2T_RiskMeasureType (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_RiskMeasureType (CoreDimKey, TargetDimKey)
		SELECT [C].CoreRiskMeasureTypeKey, MAX([T].RiskMeasureTypeKey)								-- Be defensive on possible Corruption
		FROM [CORE].[Limit_RiskMeasureType] [C] JOIN [TARGET].RiskMeasureType [T]
			ON [C].[RiskMeasureTypeName] = [T].[RiskMeasureTypeName]
				AND T.Start <= @NowDate AND T.Finish > @NowDate
		GROUP BY [C].CoreRiskMeasureTypeKey

	CREATE TABLE #C2T_Fact_Updates (CoreKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);

	SET @Message = 'Perform the actual Merge.'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	-- Perform the actual merge
	-------------------------------------------------------------------------------------------------

	INSERT #C2T_Fact_Updates ( CoreKey ,  FactKey, IsAttributeMatch )
	SELECT [C].CoreLimitKey, [TARGET].FactKey,
            CASE WHEN COALESCE([C].[CategoryPriority],0)=COALESCE([TARGET].[CategoryPriority],0)
            AND COALESCE([C].[Value],0)=COALESCE([TARGET].[Value],0)
            AND COALESCE([C].[LimitOwner],'')=COALESCE([TARGET].[LimitOwner],'')
            AND COALESCE([C].[RiskApprover],'')=COALESCE([TARGET].[RiskApprover],'')
            AND COALESCE([C].[LimitApprover],'')=COALESCE([TARGET].[LimitApprover],'')
            AND COALESCE([C].[ApprovedFlag],0)=COALESCE([TARGET].[ApprovedFlag],0)
            THEN 1 ELSE 0 END AS IsAttributeMatch
            --,TARGET.*
                  FROM [CORE].[Limit_Fact] [C]
                  JOIN #C2T_Hierarchy ON #C2T_Hierarchy.[CoreDimKey] = [C].[CoreHierarchyKey]
                  JOIN #C2T_RiskMeasureType ON #C2T_RiskMeasureType.[CoreDimKey] = [C].[CoreRiskMeasureTypeKey]
                  FULL OUTER JOIN (SELECT * FROM [TARGET].[Limit_Fact] WHERE Finish > @NowDate) [TARGET] ON
                        [C].LimitId = [TARGET].LimitId
                        AND [C].LimitStartDate = [TARGET].LimitStartDate
                        AND COALESCE([C].LimitEndDate,'') = COALESCE([TARGET].LimitEndDate,'')
                        AND [C].IsOverride = [TARGET].IsOverride
                        AND [TARGET].[HierarchyKey] = #C2T_Hierarchy.[TargetDimKey]
                        AND [TARGET].[RiskMeasureTypeKey] = #C2T_RiskMeasureType.[TargetDimKey]


	 --Print 'Adding the index'
    CREATE CLUSTERED INDEX IX_C2T_Fact_Updates_Limits ON #C2T_Fact_Updates(FactKey,CoreKey)

	BEGIN TRANSACTION


    --Print 'Expire previous and replaced records'
    UPDATE
    	[TARGET].[Limit_Fact]
    SET
		[Finish] = @NowDate
    FROM
    	[TARGET].[Limit_Fact] AS FACT
		INNER JOIN
		#C2T_Fact_Updates C2T
		on
			FACT.FactKey = C2T.FactKey
		INNER JOIN
		[TARGET].[Source] S
		on
			S.SourceKey = FACT.SourceKey
	WHERE
		(
			(C2T.CoreKey IS NULL AND C2T.FactKey IS NOT NULL)
			OR
			(C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
		)
		AND
		S.InterfaceName = @LoadInterface

	SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	-- Insert New Records for CORE data which is superceeding freshly Superceeded data
	-------------------------------------------------------------------------------------------------
	INSERT [TARGET].[Limit_Fact](-- NOT IN LIMIT -[BUSDATE],
		[START], [FINISH],
		-- The Business Keys
		[LimitId],
		[Name],
		[CategoryName],
		[LimitStartDate],
		[LimitEndDate],
		[IsOverride],
		-- The Attributes are Next
		[CategoryPriority],
		[Value],
		[LimitOwner],
		[RiskApprover],
		[LimitApprover],
		[ApprovedFlag],
		-- Ignore ApliedRules
		--[AppliedRules]
		-- Set up the Target Dimension key references
		[SourceKey],
		[HierarchyKey],
		[RiskMeasureTypeKey])
				SELECT
				    @NowDate,
				    @finish,
				    [LimitId],
					[Core].[Name],
					[Core].[CategoryName],
					[Core].[LimitStartDate],
					[Core].[LimitEndDate],
					[Core].[IsOverride],
					-- The Attributes are Next
					[Core].[CategoryPriority],
					[Core].[Value],
					[Core].[LimitOwner],
					[Core].[RiskApprover],
					[Core].[LimitApprover],
					[Core].[ApprovedFlag]
					,#C2T_Source.[TargetDimKey] [SourceKey]
					,#C2T_Hierarchy.[TargetDimKey] [HierarchyKey]
					,#C2T_RiskMeasureType.[TargetDimKey] [RiskMeasureTypeKey]
				FROM [CORE].Limit_Fact [Core]
				--JOIN [CORE].Limit_Source CS ON Core.[CoreSourceKey] = CS.[CoreSourceKey]
				JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [Core].[CoreSourceKey]
				JOIN #C2T_Hierarchy ON #C2T_Hierarchy.[CoreDimKey] = [Core].[CoreHierarchyKey]
				JOIN #C2T_RiskMeasureType ON #C2T_RiskMeasureType.[CoreDimKey] = [Core].[CoreRiskMeasureTypeKey]
				JOIN #C2T_Fact_Updates C2T ON [Core].CoreLimitKey = C2T.CoreKey
				WHERE (C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NULL)
				OR
				(C2T.CoreKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)

	-- Change the Superceeded data to mark it as just expired in this run
	-------------------------------------------------------------------------------------------------
	     SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
	     EXEC [core].p_LogInfo @ProcedureName, @Message

		 COMMIT

END TRY

--COMMIT


--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();
		
		
	IF @@TRANCOUNT > 0
	BEGIN
		-- The transaction uncommittable transaction.
		ROLLBACK TRANSACTION  --@MyTranID;

		SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName
		EXEC [core].p_LogInfo @ProcedureName, @Message
		
	END		

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;
END

GO