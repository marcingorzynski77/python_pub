IF OBJECT_ID ('target.p_Get_DenormalisedSQLForFlexFacts') IS NOT NULL
	DROP PROCEDURE target.p_Get_DenormalisedSQLForFlexFacts
GO

CREATE PROC [target].[p_Get_DenormalisedSQLForFlexFacts]
(
	 @FlexFact		 VARCHAR(255)
	,@OffsetDates    VARCHAR(MAX)
	,@Query			 VARCHAR(MAX)	
	,@FlexExtractSQL VARCHAR(MAX) = null out
)
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE
        @ProcedureName	NVARCHAR(128),
        @Message		VARCHAR(1000);

	SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

  	--Start logging session		
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--
	
BEGIN TRY
	
	DECLARE  @Sql		NVARCHAR(MAX)
			,@RunSql	NVARCHAR(MAX)
			,@Filter    VARCHAR(MAX) = ''	
			,@Dim		VARCHAR(max) = ''
			,@CleanDim	VARCHAR(max) = ''
			,@Select    VARCHAR(255);	


	SET @Message = 'Args: @FlexFact = ''' + @FlexFact + ''', @OffsetDates = ''' + @OffsetDates + ''', @Query =  ''' + @Query + ''''
	EXEC [core].p_LogInfo @ProcedureName, @Message

	IF (@OffsetDates IS NULL OR @OffsetDates = '') AND @FlexFact NOT IN ('FeedLoadCheck.Threshold', 'Report.Values', 'FinanceDenominators')
    BEGIN
		EXEC [core].p_LogDebug @ProcedureName, 'Defaulting offset dates to current business date'
		SELECT @OffsetDates = BusDate FROM [target].f_BusDate()
	END
	ELSE IF @FlexFact IN ('FeedLoadCheck.Threshold', 'Report.Values', 'FinanceDenominators')
	BEGIN
		EXEC [core].p_LogDebug @ProcedureName, 'Defaulting offset dates to empty string'
		SET @OffsetDates = ''
	END
    ELSE
	BEGIN
        EXEC [core].p_LogDebug @ProcedureName, 'Offset dates cleanup'	
		SET @OffsetDates = REPLACE(@OffsetDates,',',''',''')
	END
	
    SET @Message = 'Offset dates after pre-process:' + @offsetdates
    EXEC [core].p_LogInfo @ProcedureName, @Message

	-- Drop the global temporary tables we will use (IF they already exist)
	-- N.B. we have to use global temp tables, as local temp tables are dropped at the end of a batch (so are not accessible outside of the sp_executesql context)
    IF EXISTS (SELECT 1 FROM tempdb.dbo.sysobjects WHERE name = '##Dimensions' AND xtype = 'U') 
    DROP TABLE ##Dimensions

    --Populate from data dictionary
	CREATE TABLE #Dictionary
	(
		 [DataSetType]      VARCHAR(255)
		,[Data Set]         VARCHAR(255)
		,[Fact/Dimension]   VARCHAR(9)
		,[OriginalTable]    VARCHAR(255)
		,[Table]            VARCHAR(255)
		,[Field]            VARCHAR(255)
		,[OriginalDataType] VARCHAR(255)
		,[DataType]         VARCHAR(255)
		,[Description]      VARCHAR(MAX)
	)	
	
	INSERT INTO #Dictionary
	EXEC [target].[p_Get_DataDictionary] '','ALL'
	
	
	DECLARE @Fields           VARCHAR(MAX) = ''	
		   ,@CleanFields      VARCHAR(MAX) = ''	
		   ,@CleanFieldsTemp  VARCHAR(MAX)	
		
	--Deduce the fields
	SET @CleanFieldsTemp = REPLACE(@query,'SELECT ','')
	SET @CleanFieldsTemp = LTRIM(RTRIM(LEFT(@CleanFieldsTemp,CHARINDEX(' FROM ',@CleanFieldsTemp))))
	
	--Clean the fields
	WHILE LEN(@CleanFieldsTemp) > 0
	BEGIN
        DECLARE @i INT
        SET @i = CHARINDEX(',',@CleanFieldsTemp,1)

		IF @i > 0
		BEGIN
			SET @CleanFields = @CleanFields + LTRIM(RTRIM(LEFT(@CleanFieldsTemp,@i-1)))+ ','
			SET @CleanFieldsTemp = RIGHT(@CleanFieldsTemp,LEN(@CleanFieldsTemp)-@i)				
		END
		ELSE
		BEGIN
			SET @CleanFields = @CleanFields + LTRIM(RTRIM(@CleanFieldsTemp))+ ','
			SET @CleanFieldsTemp = ''
		END
	END
	
	SET @CleanFields = REPLACE(@CleanFields,'[','')
	SET @CleanFields = REPLACE(@CleanFields,']','')
	IF RIGHT(@cleanfields,1)=','
	BEGIN 
		set @CleanFields = LEFT(@CleanFields,len(@CleanFields)-1)
	END	
		
	--Remove all leading and trailing whitespace
    SET @Message = 'CleanFields= ''' + @CleanFields + ''''
    EXEC [core].p_LogDebug @ProcedureName, @Message

	SELECT @Fields = @Fields + ',' + RTRIM(LTRIM(A.Item)) FROM (SELECT Item FROM TARGET.f_Split(@CleanFields,',')) A
	SET @Fields = @Fields + ','
	
    SET @Message = 'Fields= ''' + @Fields + ''''
    EXEC [core].p_LogDebug @ProcedureName, @Message

	SET @Select = 'SELECT '
    
	IF CHARINDEX(',BusDate,',@Fields,1) >0
	BEGIN
		SET @Dim = ',F.Busdate'
	END
    	
	--Deduce the filter
	IF CHARINDEX(' WHERE ', @Query, 10) > 1
	BEGIN
		SET @Filter = RIGHT(@query,len(@query)-CHARINDEX(' WHERE ',@query,10)+1)
		--Replace the WHERE with an AND
		SET @Filter = ' AND ' + RIGHT(LTRIM(@Filter), LEN(LTRIM(@Filter)) -6)
        
        SET @Message = '@Filter= ''' + @Fields + ''''
        EXEC [core].p_LogDebug @ProcedureName, @Message
	END
	
	SELECT DISTINCT [OriginalTable], [Table], '' AS [status]
	  INTO #Dimensions
	  FROM #Dictionary
	 WHERE [Data Set] = 'v'+ @FlexFact
	   AND OriginalTable != 'Measure'
	
	EXEC [core].p_LogDebug @ProcedureName, 'Adding Fact table and time travel offsets'  
	
	IF  @OffsetDates IS NULL or @OffsetDates = ''
	BEGIN
		SET @Sql = '[target].[FlexFactInstance] I' +
				' INNER JOIN [target].[FlexFact] F on I.FlexFactKey = F.FlexFactKey' +
				' INNER JOIN [target].[FlexFactHierarchy] H on F.FlexFactHierarchyKey = H.FlexFactHierarchyKey' +
				' INNER JOIN (SELECT  TOP 1 TargetDate as VersionDateTime from [target].f_TargetDate() ORDER BY TargetDate ) AS TT2' +
				' ON F.Start <= TT2.VersionDateTime and F.Finish > TT2.VersionDateTime' 
	END
	ELSE
	BEGIN	
		SET @Sql = 'target.FlexFactInstance I' +
				' INNER JOIN [target].FlexFact F on I.FlexFactKey = F.FlexFactKey' +
				' INNER JOIN [target].FlexFactHierarchy H on F.FlexFactHierarchyKey = H.FlexFactHierarchyKey' +
				' INNER JOIN (SELECT [DATE] AS offsetDate from [target].Calendar WHERE [date] in (''' + @OffsetDates +  ''')) AS TT on F.BusDate = TT.offsetDate' +
				' INNER JOIN (SELECT  TOP 1 TargetDate as VersionDateTime from [target].f_TargetDate() ORDER BY TargetDate ) AS TT2' +
				' ON F.Start <= TT2.VersionDateTime and F.Finish > TT2.VersionDateTime' 
	END 		
	
	--Identify dimensions required
	SET @RunSQL = 'SELECT F.* into ##Dimensions FROM ' + @Sql + ' WHERE H.[Description] = ''' + @FlexFact + '.Data'''

    EXEC [core].p_LogDebug @ProcedureName, 'Getting dimensions into ##Dimensions. RunSql:'
    EXEC [core].p_LogDebug @ProcedureName, @RunSql
	EXEC sp_executesql @RunSql
	
	--Check IF fact has associated dimensions
	IF (SELECT COUNT(1) FROM ##Dimensions) = 0
    BEGiN
        --No Data Returned
		SET @RunSql = REPLACE(REPLACE(@select ,'F.',''),',','= ''No Data Returned'',') + ' [' + REPLACE(RIGHT(@fields,LEN(@fields)-1),',',']=''No Data Returned'',[') 
		SET @RunSql = LEFT(@RunSql, LEN(@RunSql)-2)
    END
    ELSE
    BEGIN
	
        DECLARE @OpenBracket   INT = 1
			   ,@CloseBracket  INT = 1
               ,@SquareBracket INT = 1
               ,@FilterField   VARCHAR(255)
               ,@FilterValue   VARCHAR(255)
               ,@ResolvedFilter VARCHAR(MAX)	

        --replace facts in filter with Key Value combo. i.e. (ValueGBP = 10) becomes (I.Key = 'ValueGBP' AND I.Value = '10')

		SET @ResolvedFilter = REPLACE(@Filter,'((','(')
		SET @ResolvedFilter = REPLACE(@ResolvedFilter,'))',')')

        EXEC [core].p_LogDebug @ProcedureName, 'Looping through filter'
		WHILE (CHARINDEX('(', @Filter, @CloseBracket) > 0)
		BEGIN

			SET @OpenBracket = CHARINDEX('(', @ResolvedFilter, @CloseBracket) + 1
			SET @CloseBracket = CHARINDEX(')', @ResolvedFilter, @OpenBracket)
			
			SET @Message = 'Open bracket index:' + cast(@OpenBracket as varchar(3))
            EXEC [core].p_LogDebug @ProcedureName, @Message
            SET @Message = 'Close bracket index:' + cast(@CloseBracket as varchar(3))
            EXEC [core].p_LogDebug @ProcedureName, @Message
			
			--Deduce field 
			
			DECLARE @SingleFilter  VARCHAR(255) = ''	
			SET @SingleFilter = SUBSTRING(@Filter, CHARINDEX('[', @Filter, @OpenBracket), @CloseBracket - CHARINDEX('[', @Filter, @OpenBracket) + 2)			
			SET @FilterField = SUBSTRING(@SingleFilter, 1, CHARINDEX(']',@SingleFilter,1))
			
			DECLARE @Operator VARCHAR(2)	
			
			--Deduce operator
			SELECT @Operator = (SELECT '<>' WHERE CHARINDEX('<>',@SingleFilter,1) > 0)
			IF @Operator IS NULL SELECT @Operator = (SELECT '<=' WHERE CHARINDEX('<=',@SingleFilter,1) > 0)
			IF @Operator IS NULL SELECT @Operator = (SELECT '>=' WHERE CHARINDEX('>=',@SingleFilter,1) > 0)
			IF @Operator IS NULL SELECT @Operator = (SELECT '=' WHERE CHARINDEX('=',@SingleFilter,1) > 0)
			IF @Operator IS NULL SELECT @Operator = (SELECT '>' WHERE CHARINDEX('>',@SingleFilter,1) > 0)
			IF @Operator IS NULL SELECT @Operator = (SELECT '<' WHERE CHARINDEX('<',@SingleFilter,1) > 0)
			IF @Operator IS NULL SELECT @Operator = (SELECT 'IN' WHERE CHARINDEX('IN',@SingleFilter,1) > 0)
			
			--Deduce value
			SELECT @FilterValue = RTRIM(LTRIM(REPLACE(SUBSTRING(@SingleFilter, charindex(']', @SingleFilter, 1)+1, LEN(@SingleFilter) - LEN(@FilterField)), @Operator, '')))
			
			--Is the field a fact? 
            --??? #Facts is empty?!
            /*
			IF (SELECT COUNT(1) from #Facts WHERE Field = @FilterField) > 0 
			begin
				set @Filter = REPLACE(@Filter,@SingleFilter, '(I.[Key] = ''' + REPLACE(REPLACE(@FilterField,'[',''),']','') + ''' AND I.[Value] ' + @Operator + ' ''' + @FilterValue + ''')')			
                SET @Message = 'Filter after field check as fact= ''' + @Filter + ''''
                EXEC [core].p_LogDebug @ProcedureName, @Message
			end
            */
			
			--Add filter field If not included in select statement
			IF CHARINDEX(REPLACE(REPLACE(RTRIM(LTRIM(@FilterField)),'[',''),']',''),@fields, 1) = 0 
			BEGIN
				SET @Message = 'Adding ''' + @FilterField + ''' to list of fields'
                EXEC [core].p_LogDebug @ProcedureName, @Message
				SET @Fields = @Fields + REPLACE(REPLACE(@FilterField,'[',''),']','') + ','
			END
			
			SET @Message = 'Single filter: ' + @SingleFilter + ';' + @FilterField + ';' + @FilterValue			
            EXEC [core].p_LogDebug @ProcedureName, @Message

            SET @Message = 'Filter:' + @Filter						
            EXEC [core].p_LogDebug @ProcedureName, @Message
			
            SET @Message = 'Fields:' + @Fields
			EXEC [core].p_LogDebug @ProcedureName, @Message

		END
		
        EXEC [core].p_LogInfo @ProcedureName, 'Looping through the temp table adding each Dimension to the query'
		--Loop through the temp table adding each Dimension to the query
		
        CREATE TABLE #Fields
	    (
		    [Field] VARCHAR(255)		
	    )

        WHILE (SELECT COUNT(1) from #Dimensions WHERE [Status] = '') > 0
		BEGIN

			DECLARE @Table          VARCHAR(255)	
			       ,@OriginalTable  VARCHAR(255)	
		
			--get the table/originaltable combo for the dimension in question
			SELECT TOP 1 @Table = [Table]
				 	    ,@OriginalTable = [OriginalTable]
			FROM #Dimensions 
			WHERE [Status] = ''	
			
			SET @Message = 'Table = ' + @OriginalTable
			EXEC [core].p_LogDebug @ProcedureName, @Message


			IF (SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS C WHERE C.TABLE_SCHEMA  = 'target' and TABLE_NAME = 'v' + @OriginalTable)>0
			BEGIN  
				--concatenate the dynamic sql					
				SET @Sql = @Sql + ' LEFT OUTER JOIN [target].[' + @OriginalTable + '] AS D_' + @Table + ' ON F.' + @Table + 'Key = D_' + @Table + '.' + @OriginalTable + 'Key'
					   
				--deduce the dimensions fields and then only add to temp table the ones we want
				INSERT INTO #Fields 
                SELECT DISTINCT Field 
                  FROM #Dictionary 
                 WHERE [Fact/Dimension] = 'Dimension' 
                   AND OriginalTable = @OriginalTable 
                   AND Field NOT IN ('Start','Finish') 
                   AND RIGHT(field,3) <> 'Key' 
                   AND CHARINDEX(',' + Field + ',', @Fields, 1) > 0
					
				--Add keys so that rows don't get summarised
				SET @Dim = @Dim + ',D_' + @Table + '.[' + @Table + 'key]'
					
				--build strings for pivot
                IF @@ROWCOUNT > 0
				BEGIN
					SELECT @Dim = @Dim + ', D_' + @Table + '.[' + field + ']' FROM #Fields
					SELECT @CleanDim = @CleanDim + ', ISNULL([' + field + '],'''') AS [' + field + ']' FROM #Fields								
				END

                
			END
			
			--reset for next dimension
            DELETE FROM #Fields	

			--update temp table
			UPDATE #Dimensions SET [status] = '1' WHERE [Table] = @Table
			
		END	

        DROP TABLE #Fields	
        DROP TABLE #Dimensions	
		
        EXEC [core].p_LogDebug @ProcedureName, 'Finished getting dimensions'

		IF @Dim <> '' 
		BEGIN
			-- Remove comma
			SET @Dim = RIGHT(@dim, LEN(@Dim) - 1)
		END 
		
		IF @CleanDim <> '' 
		BEGIN
			SET @CleanDim = RIGHT(@CleanDim, LEN(@CleanDim)-1) +  ','		
		END 

        SET @Message = 'Dim = ''' + @Dim + ''''
        EXEC [core].p_LogInfo @ProcedureName, @Message

        SET @Message = 'CleanDim = ''' + @CleanDim + ''''
        EXEC [core].p_LogDebug @ProcedureName, @Message

        CREATE TABLE #Facts
	    (
		    [Field] varchar(255)		
	    )

        EXEC [core].p_LogInfo @ProcedureName, 'Identifing facts'

		INSERT INTO #Facts SELECT '[' + Field + ']' 
               FROM #Dictionary 
              WHERE [Fact/Dimension] = 'Fact' 
                AND [Data Set] = 'v'+@FlexFact 
                AND CHARINDEX(Field, REPLACE(@Fields,',','],[')) > 0

        SET @Message = '#Facts count = ' + CAST(@@ROWCOUNT as varchar(255))  
        EXEC [core].p_LogInfo @ProcedureName, @Message
		
        DECLARE @Facts     VARCHAR(MAX) = ''
		DECLARE @CleanFact VARCHAR(MAX) = ''
        
        SELECT @Facts = @Facts + Field + ',' FROM #Facts
		SELECT @CleanFact = @CleanFact + ', ISNULL(' + field + ','''') AS ' + field from #Facts
        
        DROP TABLE #Facts

		SET @Facts = SUBSTRING(@Facts, 1, LEN(@Facts) - 1)
		
		IF @CleanFact <> '' 
		BEGIN
			-- Remove comma
			SET @CleanFact = RIGHT(@CleanFact, LEN(@CleanFact) - 1)
		END 

		SET @Message = '@CleanFact = ''' + @CleanFact + ''''
        EXEC [core].p_LogInfo @ProcedureName, @Message

		-- Build the pivot code to transpose the fact columns
		
        EXEC [core].p_LogDebug @ProcedureName, 'Sql with dimensions: '
		SET @Sql = @Select + @Dim + ', I.[Key], I.Value, F.FlexFactKey FROM ' + @Sql + ' WHERE H.[Description] = ''' + @FlexFact +'.Data''' -- + @Filter 
		EXEC [core].p_LogDebug @ProcedureName, @Sql

        EXEC [core].p_LogDebug @ProcedureName, 'Pivot Sql: '
		set @RunSQL = REPLACE(@Select ,'F.','') + @CleanDim + @CleanFact + '  
						FROM (' + @Sql + ') x
						PIVOT (MAX([Value]) FOR [Key] in (' +  REPLACE(REPLACE(@Facts,'[BusDate],', ''),',[BusDate]', '') + ')) P' 
        EXEC [core].p_LogDebug @ProcedureName, @RunSQL


	END
	
    DROP TABLE #Dictionary

	--Retain desired column order
	SET @CleanFields = REPLACE(ltrim(@CleanFields),'[','')
	SET @CleanFields = REPLACE(rtrim(@CleanFields),']','')
	SET @CleanFields = '[' + REPLACE(@CleanFields,',','],[') + ']'
	
	SET @RunSQL = 'SELECT ' + @CleanFields + ' FROM (' + @RunSql + ') X' 
	EXEC [core].p_LogInfo @ProcedureName, 'Final Sql: '
    EXEC [core].p_LogInfo @ProcedureName, @RunSql

	--Tidy, drop the global temporary tables
	IF EXISTS (SELECT 1 FROM tempdb.dbo.sysobjects WHERE name = '##Dimensions' AND xtype = 'U') DROP TABLE ##Dimensions

	--Return the denormalised SQL
	IF @FlexExtractSQL IS NULL 
	begin		
		select @RunSql;
	end
	else
	begin
		--Return as output parameter
		select @FlexExtractSQL = REPLACE(@Query,'dbo.' + @FlexFact,'(' + @RunSql + ') Z')
	end

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END 

