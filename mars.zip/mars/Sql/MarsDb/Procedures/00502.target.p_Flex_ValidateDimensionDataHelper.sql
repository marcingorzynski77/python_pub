IF OBJECT_ID ('target.p_Flex_ValidateDimensionDataHelper') IS NOT NULL
	DROP PROCEDURE target.p_Flex_ValidateDimensionDataHelper
GO


-- exec [target].[p_Flex_ValidateDimensionDataHelper] 'Hierarchy', 'test'
CREATE PROC [target].[p_Flex_ValidateDimensionDataHelper]
(
	@Prefix		VARCHAR(250) = '',
	@SQLVALUES	NVARCHAR(4000) = '',
	@SQL		NVARCHAR(4000) = ''
)
AS

BEGIN

    SET NOCOUNT ON;
    
	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@SessionID		BIGINT,
		@NowDate	DATETIME2;

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName,
		@NowDate	= GETUTCDATE();
		
	EXEC [core].[p_LogInfo] @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
    
	EXEC [core].[p_LogInfo] @ProcedureName, 'Start of processing'
    SET @Message = 'Params: @Prefix = ' + @Prefix
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'Params: @SQLVALUES = ' + @SQLVALUES
    EXEC [core].[p_LogDebug] @ProcedureName, @Message
    SET @Message = 'Params: @SQL = ' + @SQL
    EXEC [core].[p_LogDebug] @ProcedureName, @Message

	DECLARE @BusinessKeyColumn varchar(100) = ''

	DECLARE @SQLRESOLVER nvarchar(4000) = ''
	DECLARE @SQLPACHER nvarchar(4000) = ''
	DECLARE @SQLPACHERVALUES nvarchar(4000) = ''
	DECLARE @SQLSTART nvarchar(4000) = ''
	DECLARE @SQLFINISH nvarchar(4000) = ''
	DECLARE @SQLPARAM nvarchar(4000) = ''
	--DECLARE @SQL NVARCHAR(4000)  = ''
	--DECLARE @SQLVALUES NVARCHAR(4000) = '' 

	SET @SQLRESOLVER = 'INSERT INTO #TempDimensionResolver (DimensionName,DimensionValues,StartSql,FinishSql,ParamSql,InsertSql) SELECT '''+@Prefix+'Key'', '
	SET @SQLSTART = 'SELECT ISNULL(T.Start,@StartTime) From (select Max(Finish) as Start from target.'+@Prefix+' where <WHERE_CLAUSE> and Finish <= @StartTime) T '
		
	SET @SQLFINISH = 'SELECT ISNULL(T.Finish,@EndTime) From (select min(Start) as Finish from target.'+@Prefix+' where <WHERE_CLAUSE> and Start >= @Endtime) T'

	DECLARE businessKeys_cursor CURSOR FOR   
	SELECT id FROM core.f_TableOfBusKey('target',@Prefix)

	OPEN businessKeys_cursor
	FETCH NEXT FROM businessKeys_cursor   
	INTO @BusinessKeyColumn
	SET @SQLPACHER = ',''INSERT INTO target.'+@Prefix+' (Start,Finish,'
	SET @SQLPACHERVALUES = ' VALUES (@Start,@Finish,'

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
		SET @SQLPARAM = @SQLPARAM + '@'+@BusinessKeyColumn + ','
		SET @SQLSTART = @SQLSTART + @BusinessKeyColumn + '=@'+@BusinessKeyColumn + ' and '
		SET @SQLFINISH = @SQLFINISH + @BusinessKeyColumn + '=@'+@BusinessKeyColumn + ' and '
		SET @SQLRESOLVER = @SQLRESOLVER + @BusinessKeyColumn + '+'',''+'
		SET @SQLPACHER = @SQLPACHER + @BusinessKeyColumn + ','
		SET @SQLPACHERVALUES = @SQLPACHERVALUES + + '@' +@BusinessKeyColumn  + ','
		FETCH NEXT FROM businessKeys_cursor INTO @BusinessKeyColumn
	END
	
	-- remove last and
	SET @SQLPARAM = substring(@SQLPARAM, 1, (len(@SQLPARAM) - 1))
	SET @SQLSTART = substring(@SQLSTART, 1, (len(@SQLSTART) - 3))
	SET @SQLFINISH = substring(@SQLFINISH, 1, (len(@SQLFINISH) - 3))
	SET @SQLPACHER = substring(@SQLPACHER, 1, (len(@SQLPACHER) - 1))
	SET @SQLPACHERVALUES = substring(@SQLPACHERVALUES, 1, (len(@SQLPACHERVALUES) - 1))
	SET @SQLSTART = @SQLSTART + ') as T'
	SET @SQLFINISH = @SQLFINISH + ') as T'
	SET @SQLPACHER = @SQLPACHER + ')'
	SET @SQLPACHERVALUES = @SQLPACHERVALUES + ')'
	SET @SQLRESOLVER = substring(@SQLRESOLVER, 1, (len(@SQLRESOLVER) - 5))

	SET @Message = '@SQLSTART ' + @SQLSTART
	EXEC [core].[p_LogDebug] @ProcedureName, @Message
	SET @Message = '@SQLPACHER ' + @SQLPACHER
	EXEC [core].[p_LogDebug] @ProcedureName, @Message
	SET @Message = '@SQLPACHERVALUES ' + @SQLPACHERVALUES
	EXEC [core].[p_LogDebug] @ProcedureName, @Message
	SET @Message = '@SQLPARAM ' + @SQLPARAM
	EXEC [core].[p_LogDebug] @ProcedureName, @Message

	SET @SQLRESOLVER = @SQLRESOLVER+ ',''' +@SQLSTART + ''''
	SET @SQLRESOLVER = @SQLRESOLVER+ ',''' +@SQLFINISH + ''''
	SET @SQLRESOLVER = @SQLRESOLVER+ ',''' +@SQLPARAM + ''''

	SET @SQLRESOLVER = @SQLRESOLVER + @SQLPACHER + @SQLPACHERVALUES + '''' + ' from ('+ @SQLVALUES + @SQL+') AS RES Where RES.'+@Prefix+'Key is null'
	CLOSE businessKeys_cursor  
	DEALLOCATE businessKeys_cursor 

	SET @Message = '@SQLRESOLVER_HELPER ' + @SQLRESOLVER
	EXEC [core].[p_LogDebug] @ProcedureName, @Message

	EXEC sp_executesql @SQLRESOLVER
	
	EXEC [core].[p_LogInfo] @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

RETURN 0;

END

GO