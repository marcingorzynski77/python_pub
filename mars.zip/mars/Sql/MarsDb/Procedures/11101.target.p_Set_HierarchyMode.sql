IF OBJECT_ID ('target.p_Set_HierarchyMode') IS NOT NULL
	DROP PROCEDURE target.p_Set_HierarchyMode
GO

CREATE PROC [target].[p_Set_HierarchyMode] 
(
	@Hierarchy int = 0
)
WITH EXECUTE AS OWNER
AS 	
BEGIN

	DECLARE @SessionContextBinary   VARBINARY(128)	
	DECLARE @SessionDateTime		VARCHAR(19)
	DECLARE @BusDate				VARCHAR(11)	
	DECLARE @TargetDate				VARCHAR(19)	
	DECLARE @LimitDate				VARCHAR(19)	
	DECLARE @XML					varchar(max)	

	--Get other dates		
	SET @BusDate = (select BusDate from target.vTimeTravel)
	SET @LimitDate = (select LimitDate from target.vTimeTravel)
	SET @TargetDate = (select VersionDateTime from target.vTimeTravel)
	SET @SessionDateTime = convert(VARCHAR(19), GETUTCDATE(), 120)
	
	SET @xml = '<C><S>' + convert(varchar(19),@SessionDateTime,120) + '</S><T>' 
					 	 + ISNULL(convert(varchar(19),@TargetDate,120),'') + '</T><B>'
					  	 + ISNULL(convert(varchar(10),@BusDate,120),'') + '</B><L>' 
						 + ISNULL(convert(varchar(10),@LimitDate,120),' ') + '</L><H>'
						  + ISNULL(convert(varchar(10),@Hierarchy),' ') + '</H></C>'

	--print @xml

	SET @SessionContextBinary = convert(varbinary(128), @XML)
	--print @SessionContextBinary

	--Set
	SET CONTEXT_INFO @SessionContextBinary

END



GO
