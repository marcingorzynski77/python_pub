IF OBJECT_ID ('core.p_MonitorEvent') IS NOT NULL
	DROP PROCEDURE core.p_MonitorEvent
GO


