IF OBJECT_ID ('core.p_UpdateFact_FXSpot') IS NOT NULL
	DROP PROCEDURE [core].[p_UpdateFact_FXSpot]
GO

CREATE PROC [core].[p_UpdateFact_FXSpot]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName  			NVARCHAR(128),
		@Message 	    			NVARCHAR(MAX),
		@return_value				BIGINT,
		@rowcount					INT;

	-- Legacy Core2Target
	DECLARE
		@SourceTable				VARCHAR(50) ,
		@SourceKeyColumn			VARCHAR(50),
		@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
		@SourceIgnoreColumns		CORE.Core2TargetParameter,
		@SourceRefDateTime			DATETIME2(7)

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@GoldenOrigins				core.Core2TargetParameter,
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= 0,
		@DimensionReference			varchar(MAX),
		@LoadInterface				VARCHAR(50)

	-- Relevant column parameters
	DECLARE
		@BusinessKeyColumns		core.Core2TargetParameter,
		@DimensionKeyColumns		core.Core2TargetParameter,
		@IgnoreColumns			core.Core2TargetParameter

	DECLARE @MyTran			BIT			= CASE WHEN @@trancount = 0 THEN 0 ELSE 1 END
    DECLARE @MyTranID		VARCHAR(32)	= REPLACE(CONVERT(CHAR(36), NEWID()), '-','')		

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;
	
	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Finish datetime2(7) = '99991231'

	EXEC [core].p_LogInfo @ProcedureName, 'Create Index on BusinessKey. Note the CreateStar routines, take off prior to loading with values'
	DECLARE	@CoreIndexColumns core.Core2TargetParameter

	INSERT INTO @CoreIndexColumns VALUES ('BusDate'), ('BaseCurrency'), ('VariableCurrency')
	EXEC core.p_CreateIndex
		@IndexName 		= 'IX_FXSpot_Fact_BusinessKeys',
		@SchemaName		= 'core',
		@TableName		= 'FXSpot_Fact',
		@TableOfColumns	= @CoreIndexColumns

	SELECT DISTINCT
		@LoadInterface = S.InterfaceName
	FROM
		[core].[FXSpot_Fact] F
		join
		[core].[FXSpot_Source] S
		on
			F.CoreSourceKey = S.CoreSourceKey

	--If outside a transaction, begin one otherwise create a savepoint
	IF @MyTran = 0
	BEGIN
		BEGIN TRANSACTION @MyTranID
		SET @Message = 'New Transaction Started - ' + @MyTranID
		EXEC [core].[p_LogInfo] @ProcedureName, @Message
	END
	ELSE
	BEGIN
		SAVE TRANSACTION @MyTranID
		EXEC [core].[p_LogInfo] @ProcedureName, 'Transaction Already in Progress. Save Point Established.'
	END

	EXEC [core].p_LogDebug @ProcedureName, 'Clear out any temp tables'
	---------------------------------------------------------------------------------------------------
	--IF OBJECT_ID ('tempdb..#C2T_Delta') IS NOT NULL DROP TABLE #C2T_Delta;
	IF OBJECT_ID ('tempdb..#C2T_Source') IS NOT NULL DROP TABLE #C2T_Source;


	-- Do the Data Mapping in the core table
	exec [core].[p_DataMapping] @Datafeed = @Datafeed, @UpdateTable = '[core].[FXSpot_Fact]', @FactOrDimTable = 'FXSpot', @SessionID = @SessionID

	SET @Message = 'Map the Core Dimensions to the final Target Dimemsions ready for Lookup and comparision'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	-------------------------------------------------------------------------------------------------
	CREATE TABLE #C2T_Source (CoreDimKey BIGINT NULL,TargetDimKey BIGINT NULL);
	INSERT #C2T_Source (CoreDimKey, TargetDimKey)
		SELECT DISTINCT C.CoreSourceKey, T.SourceKey
		FROM [CORE].[FXSpot_Source] C JOIN [TARGET].[Source] T ON
			C.InterfaceName = T.InterfaceName
			AND C.Environment = T.Environment
			AND C.[Source] = T.[Source]
			AND C.Origin = T.Origin
			AND T.Start <= @NowDate
			AND T.Finish > @NowDate

	CREATE TABLE #C2T_Fact_Updates (CoreFXSpotKey BIGINT NULL,FactKey BIGINT NULL, IsAttributeMatch bit);


	SET @Message = 'Perform the actual Merge.'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	-------------------------------------------------------------------------------------------------
	-- Perform the actual merge
	INSERT #C2T_Fact_Updates ( CoreFXSpotKey , FactKey, IsAttributeMatch)
	SELECT [C].CoreFxSpotKey,
			[TARGET].FactKey,
            CASE WHEN COALESCE([C].[Rate],0)= COALESCE([TARGET].[Rate],0)
			     THEN 1 ELSE 0 END AS IsAttributeMatch
	FROM [CORE].[FxSpot_Fact] [C]
	FULL OUTER JOIN
	(
		SELECT * FROM [TARGET].[FxSpot_Fact]
		where BusDate = @BusDate
		AND Finish > @NowDate
	) [TARGET]
	ON [C].[BaseCurrency] = [TARGET].[BaseCurrency]
		AND [C].[VariableCurrency] = [TARGET].[VariableCurrency]
	    AND [C].[BusDate] = [TARGET].[BusDate]


    SET @Message = 'Adding the index'
	EXEC [core].p_LogDebug @ProcedureName, 'Adding new and updated records'
    -------------------------------------------------------------------------------------------------
    CREATE CLUSTERED INDEX IX_C2T_Fact_Updates_FactKey ON #C2T_Fact_Updates(FactKey,CoreFXSpotKey)

    SET @Message =  'Expire previous and replaced records'
	EXEC [core].p_LogDebug @ProcedureName, 'Adding new and updated records' 
    -------------------------------------------------------------------------------------------------
    UPDATE
    	[TARGET].[FxSpot_Fact]
   	SET
		[Finish] = @NowDate
    FROM
    	[TARGET].[FxSpot_Fact] AS FACT
		INNER JOIN
		#C2T_Fact_Updates C2T
		on
			FACT.FactKey = C2T.FactKey
		INNER JOIN
		[TARGET].[Source] S
		on
			S.SourceKey = FACT.SourceKey
	WHERE
		(
			(C2T.CoreFXSpotKey IS NULL AND C2T.FactKey IS NOT NULL)
			OR
			(C2T.CoreFXSpotKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)
		)
		AND
		S.InterfaceName = @LoadInterface
		AND
		FACT.BusDate = @BusDate


	SET @Message = 'Expire previous and replaced records ' + CAST(@@ROWCOUNT as varchar(30)) + ' expired and replaced rows .'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	EXEC [core].p_LogDebug @ProcedureName, 'Adding new and updated records'
	-------------------------------------------------------------------------------------------------
	INSERT [TARGET].[FxSpot_Fact]
	(
		Busdate
		,Start
		,Finish
		,SourceKey
		,BaseCurrency
		,VariableCurrency
		,Rate
	)
	SELECT
		[CORE].[BUSDATE]
		, @NowDate
		, @finish
		, #C2T_Source.[TargetDimKey] [SourceKey]
		, [Core].[BaseCurrency]
		, [Core].[VariableCurrency]
		, [Core].[Rate]
	FROM [CORE].[FxSpot_Fact] [Core]
	JOIN [CORE].[FxSpot_Source] CS ON Core.[CoreSourceKey] = CS.[CoreSourceKey]
	JOIN #C2T_Source ON #C2T_Source.[CoreDimKey] = [Core].[CoreSourceKey]
	JOIN #C2T_Fact_Updates C2T ON [Core].CoreFXSpotKey = C2T.CoreFXSpotKey
	WHERE (C2T.CoreFXSpotKey IS NOT NULL AND C2T.FactKey IS NULL)
	OR
	(C2T.CoreFXSpotKey IS NOT NULL AND C2T.FactKey IS NOT NULL AND C2T.IsAttributeMatch = 0)

	SET @Message = 'Adding new and updated records: ' + CAST(@@ROWCOUNT as varchar(30)) + ' new data rows added.'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	SET @Message = 'Success. End of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	COMMIT TRAN

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();
		
		
	IF @@TRANCOUNT > 0
	BEGIN
		-- The transaction uncommittable transaction.
		ROLLBACK TRANSACTION @MyTranID;

		SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName
		EXEC [core].p_LogInfo @ProcedureName, @Message
		
	END		

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
