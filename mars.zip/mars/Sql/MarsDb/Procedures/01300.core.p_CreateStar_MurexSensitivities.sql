IF OBJECT_ID ('core.p_CreateStar_MurexSensitivities') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_MurexSensitivities
GO

CREATE PROC [core].[p_CreateStar_MurexSensitivities]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT		= 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT,
		@MaxRow			BIGINT,
		@UTCDate		DATETIME2	= getutcdate(),
		@Rate			FLOAT

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	-- First check that the relevant FX Rate has been loaded
	--
	SELECT
		@Rate = FX.Rate
	FROM
		[target].FxSpot_Fact FX
	WHERE
		CONVERT(DATE, FX.BusDate) = CONVERT(DATE, @BusDate)
		AND
		FX.Start <= @UTCDate AND FX.Finish > @UTCDate
		AND
		FX.BaseCurrency = 'GBP'
		AND
		FX.VariableCurrency = 'USD'

	IF @Rate IS NULL
	BEGIN
		SET @Message = 'USDGBP FX Rate for ' + convert(varchar(10), @BusDate, 103) + ' is not available.  Load FX rates before loading Murex Data'
		RAISERROR(@Message, 11, -1) WITH NOWAIT
	END

	--First empty the star ready for new data
	TRUNCATE TABLE [core].MurexSensitivities_Source
	TRUNCATE TABLE [core].MurexSensitivities_Hierarchy
	TRUNCATE TABLE [core].MurexSensitivities_HierarchyBook
	TRUNCATE TABLE [core].MurexSensitivities_Trade
	TRUNCATE TABLE [core].MurexSensitivities_InstrumentType
	TRUNCATE TABLE [core].MurexSensitivities_RiskFactor
	TRUNCATE TABLE [core].MurexSensitivities_RiskFactorType
	TRUNCATE TABLE [core].MurexSensitivities_RiskMeasureType
	TRUNCATE TABLE [core].MurexSensitivities_Tenor
	TRUNCATE TABLE [core].MurexSensitivities_RiskMeasure_Fact

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_Source'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_Hierarchy'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_Trade'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_InstrumentType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_RiskFactor'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_RiskFactorType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_RiskMeasureType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_Tenor'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MurexSensitivities_RiskMeasure_Fact'

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	DECLARE @MurexSourceId as int

	-- Source Dimension
	--
	INSERT INTO [core].MurexSensitivities_Source  (
			 [InterfaceName]
			,[Environment]
			,[Origin]
			,[Source]
		) Values (
			 'MurexSensitivities'
			,@Env
			,'Murex'
			,'Murex'
		)

	select @MurexSourceId = CoreSourceKey from [core].MurexSensitivities_Source

	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--
	DECLARE @hierarchytag as INT;
	-- build cursor 
	DECLARE @hierarchyCursor as CURSOR;
	
	SET @hierarchyCursor = CURSOR FOR
	SELECT distinct HierarchyTag FROM target.hierarchy where finish = '9999-12-31';
	OPEN @hierarchyCursor;
    FETCH NEXT FROM @hierarchyCursor INTO @hierarchytag
	--Hierarchy Dimension
	
	WHILE @@FETCH_STATUS = 0
	BEGIN

	INSERT INTO [core].MurexSensitivities_Hierarchy (
		  CoreSourceKey
		, NodeType
		, NodeName
		, BookSystem
		,HierarchyTag
	)
	SELECT
		 @MurexSourceId
		,'BO' AS [NodeType]
		,LTRIM(RTRIM(R.Portfolio))
		,'GDIMUREX'
		,@hierarchytag
	FROM
		[raw].MurexSensitivities_Merged R
	GROUP BY
		LTRIM(RTRIM(R.Portfolio))

	set @InsertedCount = @@ROWCOUNT

	update
		M
	set
		M.HierarchyString = HT.HierarchyString
	from
		[core].MurexSensitivities_Hierarchy M
		join
		(
			SELECT
				 RANK() OVER (PARTITION BY H.NodeName, H.NodeType ORDER BY ISNULL(G.Precedence, 999999)) AS RANK
				,H.*
			FROM
				[target].vHierarchyConsolidated H
				LEFT JOIN
				core.GoldenSource G
				ON
					G.Dimension = 'Hierarchy'
					AND
					H.BookSystem = G.Origin
			WHERE
					H.Start <= @UTCDate
					AND
					H.Finish > @UTCDate
		) HT
		on
			HT.NodeName = M.NodeName
			and
			HT.NodeType = M.NodeType
	WHERE
		HT.RANK = 1 and hierarchytag=@hierarchytag

	update
		M
	set
		M.HierarchyString = '/LBG/UNKNOWN/' + M.NodeName + '/'
	from
		[core].MurexSensitivities_Hierarchy M
	where
		M.HierarchyString is NULL and hierarchytag = @hierarchytag

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_Hierarchy dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	FETCH NEXT FROM @hierarchyCursor INTO @hierarchytag

	END
	
	CLOSE @hierarchyCursor;
	DEALLOCATE @hierarchyCursor;
	
	
	INSERT INTO core.MurexSensitivities_HierarchyBook (
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookSystem]
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,NodeName
		,NodeType
		,BookSystem
	FROM
	core.MurexSensitivities_Hierarchy H where NodeType = 'BO' and H.HierarchyTag = 0  -- we will have data for all hierarchies created and previous step but for books we can only need one , hence using default one
	
	select @InsertedCount = @@ROWCOUNT
	
    SET @Message = 'Split out ' + CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into [core].[MurexSensitivities_HierarchyBook] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex Trade Dimension
	--
	INSERT into [core].MurexSensitivities_Trade (
		 [CoreSourceKey]
		,[Financial_Contract]
		,[Portfolio]
		,[TradeDateTime]
		,[TradeType]
		,[Nominal_CCY]
		,[Call_Put]
		,[Strike]
		,[Status]
		,[Booking Units]
	)
	SELECT
		 @MurexSourceId
		,[Financial_Contract]
		,[Portfolio]
		,[TradeDateTime]
		,[TradeType]
		,[Nominal_CCY]
		,[Call_Put]
		,[Strike]
		,[Status]
		,[Booking Units]
	FROM
		[raw].MurexSensitivities_Merged R


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_Trade dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex Risk Measure Type Dimension
	--
	INSERT into [core].MurexSensitivities_RiskMeasureType  (
		 [CoreSourceKey]
		,[RiskMeasureTypeName]
		,[RiskMeasureFamily]
	)
	VALUES
		(@MurexSourceId, 'Interest Rate Delta', 'Interest Rate'),
		(@MurexSourceId, 'Interest Rate Spread Delta', 'Interest Rate'),
		(@MurexSourceId, 'Commodity Nominal', 'Commodity'),
		(@MurexSourceId, 'Commodity Delta', 'Commodity'),
		(@MurexSourceId, 'Commodity Gamma', 'Commodity'),
		(@MurexSourceId, 'Commodity Vega', 'Commodity'),
		(@MurexSourceId, 'Commodity Theta', 'Commodity'),
		(@MurexSourceId, 'Commodity Rho', 'Commodity'),
		(@MurexSourceId, 'Commodity Rho(f)', 'Commodity')


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_RiskMeasureType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex Risk Factor Type Dimension
	--
	INSERT into [core].MurexSensitivities_RiskFactorType  (
		 [CoreSourceKey]
		,[RiskFactorTypeName]
	)
	VALUES
		(@MurexSourceId, 'Commodity Curve'),
		(@MurexSourceId, 'Interest Rate Curve'),
		(@MurexSourceId, 'Interest Rate LIBOR Spread Curve');

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_RiskFactorType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex Risk Factor Dimension
	--
	INSERT into [core].MurexSensitivities_RiskFactor  (
		 [CoreSourceKey]
		,[RiskFactorName]
	)
	SELECT
		@MurexSourceId,
		'Commodity Curve UNKNOWN'

	UNION ALL

	SELECT
		@MurexSourceId,
		'Commodity Curve ' + [Index]
	FROM
		[raw].MurexSensitivities_Merged
	WHERE
		[INDEX] IS NOT NULL
	GROUP BY
		[Index]

	UNION ALL

	SELECT
		@MurexSourceId,
		CASE WHEN RIGHT(C.[Curve], 3) = ' FX' THEN 'Interest Rate LIBOR Spread Curve ' ELSE 'Interest Rate Curve ' END + C.[Curve]
	FROM
		[raw].MurexSensitivities_Com_pvbp C
	GROUP BY
		CASE WHEN RIGHT(C.[Curve], 3) = ' FX' THEN 'Interest Rate LIBOR Spread Curve ' ELSE 'Interest Rate Curve ' END + C.[Curve]

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_RiskFactor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex Instrument Type Dimension
	--
	INSERT into [core].MurexSensitivities_InstrumentType (
		 [CoreSourceKey]
		,[InstrumentType]
		,[InstrumentSubType]
	)
	SELECT
		 @MurexSourceId
		,'UNKNOWN'
		,'UNKNOWN'

	UNION ALL

	SELECT DISTINCT
		 @MurexSourceId
		,[TradeType]
		,[Product] + ' ' + [Units]
	FROM
		[raw].MurexSensitivities_Merged R


	--Log affected rows

	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_InstrumentType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex Tenor Dimension
	--
	INSERT into [core].MurexSensitivities_Tenor (
		 [CoreSourceKey]
		,[TenorName]
		,[TenorDate]
	)
	SELECT
		 @MurexSourceId
		,'Not Set'
		,NULL

	UNION

	SELECT
		 @MurexSourceId
		,ISNULL([Tenor], 'Not Set')
		,S.[Date]
	FROM
		[raw].MurexSensitivities_Com_pvbp T
		LEFT JOIN
		(
			SELECT
				CASE MONTH([Date])
					WHEN 1 THEN 'JAN'
					WHEN 2 THEN 'FEB'
					WHEN 3 THEN 'MAR'
					WHEN 4 THEN 'APR'
					WHEN 5 THEN 'MAY'
					WHEN 6 THEN 'JUN'
					WHEN 7 THEN 'JUL'
					WHEN 8 THEN 'AUG'
					WHEN 9 THEN 'SEP'
					WHEN 10 THEN 'OCT'
					WHEN 11 THEN 'NOV'
					WHEN 12 THEN 'DEC'
				END + ' ' +CONVERT(VARCHAR(3), YEAR([Date])%100) AS FutureDate,
				[Date]
			FROM
				(
					SELECT
						RANK() OVER (PARTITION BY Month,Year ORDER BY date) AS [Rank],
						*
					FROM
						target.Calendar
					WHERE
						Month IN (3,6,9,12)
						AND
						WeekDay = 'Fr'
				) R
			WHERE
				R.[Rank] = 3
				AND
				[Date] > getdate()
		) S
		ON
		T.Tenor = S.FutureDate
	GROUP BY
		 T.[Tenor]
		,S.[Date]


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_Tenor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message;

	--#--------------------------------------------- ------- ------- ------- ------------------------------------------#--

	-- Murex RiskMeasure Fact
	--
	INSERT into [core].MurexSensitivities_RiskMeasure_Fact (
		  CoreSourceKey
		, CoreHierarchyKey
		, CoreRiskMeasureTypeKey
		, CoreRiskFactorTypeKey
		, CoreRiskFactorKey
		, CoreInstrumentTypeKey
		, CoreInstrumentTenorKey
		, BusDate
		, Product
		, ValueCurrency
		, [Value]
		, [ValueGBP]
	)
	SELECT
		 @MurexSourceId
		,H.CoreHierarchyBookKey as CoreHierarchyKey
		,M.CoreRiskMeasureTypeKey
		,FT.CoreRiskFactorTypeKey
		,F.CoreRiskFactorKey
		,I.CoreInstrumentTypeKey
		,TN.CoreTenorKey
		,R.BusDate
		,R.Product
		,R.ValueCurrency
		,SUM(R.Value) as Value
		,SUM(R.Value / R.FXRate) as ValueGBP
	FROM
		(
			SELECT
				U.BusDate,
				U.Portfolio as Book,
				'Commodity ' + CASE WHEN RIGHT(U.RiskMeasure, 4) = '_GBP' THEN LEFT(U.RiskMeasure, len(U.RiskMeasure) - 4) ELSE U.RiskMeasure END as RiskMeasureTypeName,
				'Commodity Curve' AS RiskFactorTypeName,
				'Commodity Curve ' + U.[Index] as RiskFactorName,
				U.[TradeType] as [InstrumentType],
				U.[Product] + ' ' + U.[Units] as [InstrumentSubType],
				U.Product,
				LTRIM(U.Nominal_CCY) AS ValueCurrency,
				FX.Rate as FXRate,
				SUM(U.Value) * CASE WHEN RIGHT(U.RiskMeasure, 4) = '_GBP' THEN FX.RATE ELSE 1 END AS Value		-- Value in Position CCY
			FROM
				[raw].MurexSensitivities_Merged UNPIVOT
				(
					Value
					for RiskMeasure in (Nominal, Delta_GBP, Gamma_GBP, Vega, Theta, Rho, [Rho(f)])
				) U
				JOIN
				[target].FxSpot_Fact FX
				ON
					FX.BusDate = U.BusDate
					and
					FX.Start <= @UTCDate AND FX.Finish > @UTCDate
					AND
					FX.BaseCurrency = 'GBP'
					AND
					FX.VariableCurrency = LTRIM(U.Nominal_CCY)
			GROUP BY
				U.BusDate,
				U.Portfolio,
				U.RiskMeasure,
				U.[Index],
				U.[TradeType],
				U.[Product],
				U.[Units],
				U.Instrument,
				U.Nominal_CCY,
				FX.Rate
			HAVING
				SUM(U.Value) <> 0
		) R
		LEFT JOIN
		[core].MurexSensitivities_HierarchyBook H
		ON
			H.NodeName = R.Book
		LEFT JOIN
		[core].MurexSensitivities_RiskMeasureType M
		ON
			M.RiskMeasureTypeName = R.RiskMeasureTypeName
		LEFT JOIN
		[core].MurexSensitivities_RiskFactorType FT
		ON
			FT.RiskFactorTypename = R.RiskFactorTypeName
		LEFT JOIN
		[core].MurexSensitivities_RiskFactor F
		ON
			F.RiskFactorName = R.RiskFactorName
		LEFT JOIN
		[core].MurexSensitivities_InstrumentType I
		ON
			I.InstrumentType = R.InstrumentType
			AND
			I.InstrumentSubType = R.InstrumentSubType
		LEFT JOIN
		[core].MurexSensitivities_Tenor TN
		ON
			TN.TenorName = 'Not Set'
	GROUP BY
		 H.CoreHierarchyBookKey
		,M.CoreRiskMeasureTypeKey
		,FT.CoreRiskFactorTypeKey
		,F.CoreRiskFactorKey
		,I.CoreInstrumentTypeKey
		,TN.CoreTenorKey
		,R.BusDate
		,R.Product
		,R.ValueCurrency

	UNION ALL

	SELECT
		 @MurexSourceId
		,H.CoreHierarchyBookKey as CoreHierarchyKey
		,M.CoreRiskMeasureTypeKey
		,FT.CoreRiskFactorTypeKey
		,F.CoreRiskFactorKey
		,I.CoreInstrumentTypeKey
		,TN.CoreTenorKey
		,C.PvbpDate AS BusDate
		,R.Instrument
		,'GBP'
		,SUM(convert(FLOAT, R.[Total IR Sensistivity]))
		,SUM(convert(FLOAT, R.[Total IR Sensistivity])) / FX.Rate
	FROM
		[raw].MurexSensitivities_Control C
		join
		[raw].MurexSensitivities_Com_pvbp R
		ON
			1=1		-- ONLY 1 ROW SO CARTESIAN JOIN IS OK.  This contrivance is needed so I can refer to the Control table as C. later.
		JOIN
		[target].FxSpot_Fact FX
		ON
			FX.BusDate = C.PvbpDate
			and
			FX.Start <= @UTCDate AND FX.Finish > @UTCDate
			AND
			FX.BaseCurrency = 'GBP'
			AND
			FX.VariableCurrency = LEFT(R.Curve,3)
		LEFT JOIN
		[core].MurexSensitivities_HierarchyBook H
		ON
			H.NodeName = R.Portfolio
		LEFT JOIN
		[core].MurexSensitivities_RiskMeasureType M
		ON
			M.RiskMeasureTypeName = CASE WHEN RIGHT(R.[Curve], 3) = ' FX' THEN 'Interest Rate Spread Delta' ELSE 'Interest Rate Delta' END
		LEFT JOIN
		[core].MurexSensitivities_RiskFactorType FT
		ON
			FT.RiskFactorTypename = CASE WHEN RIGHT(R.[Curve], 3) = ' FX' THEN 'Interest Rate LIBOR Spread Curve' ELSE 'Interest Rate Curve' END
		LEFT JOIN
		[core].MurexSensitivities_RiskFactor F
		ON
			F.RiskFactorName = CASE WHEN RIGHT(R.[Curve], 3) = ' FX' THEN 'Interest Rate LIBOR Spread Curve ' ELSE 'Interest Rate Curve ' END + R.Curve
		LEFT JOIN
		[core].MurexSensitivities_InstrumentType I
		ON
			I.InstrumentType = 'UNKNOWN'
			AND
			I.InstrumentSubType = 'UNKNOWN'
		LEFT JOIN
		[core].MurexSensitivities_Tenor TN
		ON
			TN.TenorName = R.Tenor
	GROUP BY
		 H.CoreHierarchyBookKey 
		,M.CoreRiskMeasureTypeKey
		,FT.CoreRiskFactorTypeKey
		,F.CoreRiskFactorKey
		,I.CoreInstrumentTypeKey
		,TN.CoreTenorKey
		,C.PvbpDate
		,R.Instrument
		,FX.Rate
	HAVING
		SUM(convert(FLOAT, R.[Total IR Sensistivity])) <> 0


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].MurexSensitivities_RiskMeasure_Fact Fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	
END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO