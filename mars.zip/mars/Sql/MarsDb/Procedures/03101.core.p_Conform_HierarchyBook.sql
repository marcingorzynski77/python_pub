/****** Object:  StoredProcedure [core].[p_Conform_HierarchyBook]    Script Date: 11/17/2017 15:29:52 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Conform_HierarchyBook]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_Conform_HierarchyBook]
GO


CREATE PROC [core].[p_Conform_HierarchyBook]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT		= 0
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName				NVARCHAR(128),
		@InitialTranCount			BIGINT,
		@Message					NVARCHAR(MAX),
		@Origin						VARCHAR(30),
		@EndDate					DATETIME2,
		@InsertedCount				BIGINT,
		@return_value				BIGINT,
		@ReStatement				BINARY		= 0,
		@RowCount					BIGINT,
		@SQL						nvarchar(MAX);

	-- Legacy Core2Target
	DECLARE
		@TargetMaxRow				BIGINT,
		@AffectedRowsCount			BIGINT

	-- Core, Staging & Target Synchronisation Parameters
	DECLARE
		@TableToSync				VARCHAR(50),
		@CoreStarPrefix				VARCHAR(50),
		@CoreTable					VARCHAR(50) ,
		@CoreKeyColumn				VARCHAR(50),
		@CoreBusinessKeyColumns		CORE.Core2TargetParameter,
		@CoreIgnoreColumns			CORE.Core2TargetParameter,
		@CoreSourceTable			VARCHAR(50),
		@CoreSourceKeyColumn		VARCHAR(50),
		@StagingTable				VARCHAR(50),
		@TargetTable				VARCHAR(50),
		@TargetKeyColumn			VARCHAR(50),
		@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
		@TargetDimensionKeyColumns	CORE.Core2TargetParameter,
		@TargetIgnoreColumns		CORE.Core2TargetParameter,
--		@FactTableSync				INT		= 0,
		@TargetRefDateTime			DATETIME2(7),
		@ExcludeDeprecatedFlag		INT		= CASE WHEN @DataFeed = 'Hierarchy' OR @DataFeed = 'HierarchyT' THEN 1 ELSE 0 END,		--  Hierarchy feed is master,
		@MinNodeID as integer

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@EndDate			= CAST('9999-12-31' AS DATETIME2),
		@Message			= 'Invoking ' + @ProcedureName

	--Start logging
	EXEC [core].[p_LogInfo] @ProcedureName, @Message	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	-- Core Synchronisation Parameters
	SELECT @CoreStarPrefix = target.f_CoreStarPrefix (@DataFeed)

	-- Check Golden Source Mappings
	exec [target].[p_CheckGoldenSourceMappings] @CoreStarPrefix,'HierarchyBook'


    --IF(@DATAFEED <> '1')
    --BEGIN
	-- Common Staging & Target Syncronisation Parameters
	SET @TableToSync = 'HierarchyBook'															-- Ommit schemas
	INSERT INTO @TargetBusinessKeyColumns VALUES ('NodeName'),('NodeType'),('BookSystem')	-- Must be logically Unique from a business perspective
	INSERT INTO @TargetDimensionKeyColumns VALUES ('NOTHING_FOR DIMENSIONS')				-- How This table references other Dimensions. NULL for Dimensions
	SET @CoreSourceKeyColumn	= 'CoreSourceKey'
	-- Remainder are computed
	SET @StagingTable		= @TableToSync
	SET @TargetTable		= 'HierarchyBook' --@StagingTable --
	SET @TargetKeyColumn	= @TableToSync + 'Key'
	SET @CoreTable			= @CoreStarPrefix + @TableToSync
	SET @CoreSourceTable	= @CoreStarPrefix + 'Source'
	SET @CoreKeyColumn		= 'Core' + @TableToSync + 'Key'
--	breaks CORE2STAGING INSERT INTO @CoreIgnoreColumns VALUES (@CoreSourceKeyColumn)
	INSERT INTO @CoreBusinessKeyColumns SELECT id from @TargetBusinessKeyColumns
	INSERT INTO @TargetIgnoreColumns VALUES (@CoreSourceKeyColumn);

	-- CORE TO STAGING - Merge new data with existing in TARGET from other sources

	EXEC	@return_value				= [core].[p_Core2Staging]
			@Datafeed					= @Datafeed,
			@Environment				= @Env,
			@CoreTable					= @CoreTable,
			@CoreSourceTable			= @CoreSourceTable,
			@CoreKeyColumn				= @CoreKeyColumn,
			@CoreSourceKeyColumn		= @CoreSourceKeyColumn,
			@CoreBusinessKeyColumns 	= @CoreBusinessKeyColumns,
			@CoreIgnoreColumns			= @CoreIgnoreColumns,
			@StagingTable				= @StagingTable,
			@TargetTable				= @TargetTable,
			@TargetKeyColumn			= @TargetKeyColumn,
			@TargetBusinessKeyColumns	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumns		= @TargetIgnoreColumns,
			@TargetRefDateTime			= @NowDate,
			@ExcludeDeprecatedFlag		= @ExcludeDeprecatedFlag,
			@SessionID					= @SessionID

	SET @Message = CAST(@return_value AS VARCHAR(10)) + ' rows inserted into ' + @StagingTable + ' from ' + @TargetTable + ' and ' + @CoreTable
	EXEC [core].[p_LogInfo] @ProcedureName, @Message	
	
	--SET @MinNodeID = (SELECT MIN(ISNULL(NodeID,0)) FROM Staging.HierarchyBook)
	-- -- assign negative numbers to book that came from non golden source
	--update staging.HierarchyBook set NodeId = @MinNodeID - 1 where NodeId is null
	
	
	set @MinNodeID = (SELECT MIN(ISNULL(NodeID,0)) FROM target.HierarchyBook)
	If @MinNodeID > 0 set @MinNodeID = 0
	
	IF @CoreStarPrefix not like ('Hierarchy%')
	BEGIN
	
		--Try and resolve null nodeids from target
		UPDATE H SET
			 H.NodeId = T.NodeId				
		FROM staging.HierarchyBook H
		join target.HierarchyBook T
		on	H.NodeName = T.NodeName
			and
			H.NodeType = T.NodeType
			and
			H.BookSystem = T.BookSystem
			and
			T.Start <= @NowDate
			and 
			T.Finish > @NowDate
		where H.nodeid IS NULL
		
		-- Resolve remaining null nodeids by assigning negative numbers as they came from non golden source
		update H
			set nodeid = @MinNodeID - I.nodeid
		from staging.HierarchyBook H
		join
		(
			select 
				corehierarchybookkey
				,ROW_NUMBER() over (order by nodename) as nodeid			
			from staging.HierarchyBook
			where NodeId is null
		)I
		on H.CoreHierarchyBookKey = I.coreHierarchybookKey
		where H.NodeId is null
     
    END
     
     -- STAGING TO TARGET - Update the bitemporal TARGET with the new consolidated view provided in STAGING
    EXEC [core].p_LogInfo @ProcedureName, 'Processing staging to target for hierarchy books' 
    
	EXEC	@return_value					= [core].[p_Staging2Target]
			@StagingTable					= 'HierarchyBook',
			@StagingKeyColumn				= @CoreKeyColumn,
			@StagingBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@StagingIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@StagingRefDateTime				= @NowDate,
			@TargetTable					= 'HierarchyBook',
			@TargetKeyColumn				= @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM	= @TargetBusinessKeyColumns,
			@TargetIgnoreColumnsPARAM		= @TargetIgnoreColumns,
			@TargetRefDateTime				= @NowDate,
			@ExpireDimensionData			= @ExcludeDeprecatedFlag,
			@ReStatement					= 0,
			@SessionID						= @SessionID
	
	--------------------------------------------------------------------------------------------------------------

	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'
	
	--END
	
	/*
	ELSE
	
	BEGIN
	
		EXEC [core].p_LogInfo @ProcedureName, 'Processing books for HierarchyT is disabeled'
		
		SET @SQL = 'SELECT * from target.vHierarchyAttribution where NodeType = ''BO'' and HierarchyBookKey IS NULL AND Start >= '''+cast(@NowDate as varchar(30))+''' AND Finish = ''9999-12-31'''
		SET @Message = ' Executing book check: ' + @SQL
		EXEC [core].[p_LogInfo] @ProcedureName, @Message
		EXEC sp_executesql @SQL
		Set @RowCount =@@ROWCOUNT
		IF(@RowCount > 0)
		begin
		SET @Message = ' There are books detected in HierarchyT that are diffrent from golden source. Number of differences: ' + @RowCount
		EXEC [core].[p_LogWarning] @ProcedureName, @Message
		end
		
		
	END
	*/

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
    
    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END



GO


