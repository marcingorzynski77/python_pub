IF OBJECT_ID (N'[core].[p_Control_Position]') IS NOT NULL
	DROP PROCEDURE [core].[p_Control_Position]
GO

CREATE PROC [core].[p_Control_Position]
(
	@DataFeed			VARCHAR(64),
	@AsOfBusDate		DATETIME2,
	@Env				VARCHAR(6),
	@ExecutionTime		DATETIME2(7) = NULL
)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@SessionID			BIGINT,
		@SourceKey			BIGINT,
		@NowDate			DATETIME2,				
		@AllLoaded			TINYINT;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END,
		@SourceKey		= (
				Select
					SourceKey
				from
					target.Source
				where
					InterfaceName = @DataFeed
					and
					[Source] is null
					and
					Environment = @env
					and
					@NowDate >= Start
					and
					@NowDate < Finish
			);

	--Start logging session
	EXEC [core].p_LogInfo @ProcedureName, @Message
	--SET @SessionID = @@IDENTITY

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	EXEC [core].p_LogInfo @ProcedureName, 'Start of processing'

	IF @DataFeed='TridentBondPosition' update raw.Position_Control set TriDate = @AsOfBusDate
	ELSE IF @DataFeed='SummitBondPosition' update raw.Position_Control set SumDate = @AsOfBusDate	
	ELSE
	BEGIN
		SET @Message = CONVERT(VARCHAR(4000), 'Unrecognised Feed: ' + @DataFeed)
		RAISERROR(@Message, 11, -11)
	END

	SELECT
		@AllLoaded = COUNT(1)
	FROM
		raw.Position_Control
	WHERE
		TriDate = @AsOfBusDate
		AND
		SumDate = @AsOfBusDate


	IF  @AllLoaded = 1
	BEGIN
		set @DataFeed = 'Position'
	
		--Merge Trident and Summit data
		EXEC [core].[p_Merge_Positions] @BusDate = @AsOfBusDate, @DataFeed = @DataFeed, @Env = @Env, @SessionID = 1

		--Split raw data into a star
		EXEC [core].p_CreateStar_Position @AsOfBusDate, @DataFeed, @Env

		--Conform the raw star dimensions with Target dimensions
		EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_HierarchyBook @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_Hierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_Instrument @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_InstrumentType @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_Country @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_Rating @AsOfBusDate, @NowDate, @DataFeed, @Env

		--Update the Target facts with the star dimensions
		EXEC [core].p_UpdateFact_Position @AsOfBusDate, @NowDate, @DataFeed, @Env
		
		--Take note of load date
		EXEC [core].[p_Insert_TimeTravellingInstance] @AsOfBusDate, @NowDate, @DataFeed, @Env, 'Position'

		DECLARE @Stats Flex_LoadStatsParameters

		INSERT INTO @Stats (
			  Start
			, Finish
			, SourceKey
			, RiskMeasureTypeKey
			, RiskFactorTypeKey
			, InstrumentTypeKey
			, Status
			, Count
		)
		SELECT * FROM [core].f_PositionFactMonitor (
			 'Position'		 	--		 @FactType	VARCHAR(64)
			,@DataFeed 			--		,@Interface	VARCHAR(64)
			,@Env
			,@AsOfBusDate 		--		,@BusDate	DATETIME2
			,@NowDate			--		,@Now		DATETIME2
		)

		EXEC [core].p_Flex_UpdateLoadStats @AsOfBusDate, @NowDate, 'Position', @Stats, @SessionID
	END
	ELSE
		EXEC [core].p_LogInfo @ProcedureName, 'Other Position feed Loads not complete - no data processed'

	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

RETURN 0;

END

GO

