IF OBJECT_ID ('core.p_Conform_Calendar') IS NOT NULL
	DROP PROCEDURE core.p_Conform_Calendar
GO

CREATE PROC [core].[p_Conform_Calendar]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	BIGINT		= 0
)
AS

BEGIN

    SET NOCOUNT ON;

    DECLARE
		@return_status		int,
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@BusinessLogicSev	INT,
		@MaxRow			BIGINT;

    SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message	= 'Invoking ' + @ProcedureName;

	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @Historical_Date as datetime2, @Future_Date as datetime2, @Forward_And_Back_Years as integer, @Archive_After_Days as integer
	DECLARE @Products as bigint
	SET @Forward_And_Back_Years = 50
	SET @Archive_After_Days = 40
	SET @Historical_Date = cast(str(year(DATEADD(yyyy,(@Forward_And_Back_Years * -1), getutcdate()))) + '-12-31' as datetime2)
	SET @Future_Date = cast(str(year(DATEADD(yyyy,@Forward_And_Back_Years, getutcdate()))) + '-12-31' as datetime2)

	-- Extend the Calendar dimension out as needed (note, historical dates will be left and managed by the data purging in other
	-- Facts and Dimensions)

	INSERT into [target].Calendar([Date],[DateString],[Year],[Quarter],[Month],[Day],[WeekNo],[WeekDay],[WeekEnd],PeriodEnd, Archived)
	SELECT CalcDate as [Date], CONVERT(varchar(10),CalcDate,111) as DateString,
		DATEPART(yyyy,CalcDate) as [Year],
		DATEPART(q,CalcDate) as [Quarter],
		RIGHT('0' + DATEPART(mm,CalcDate),2) as [Month],
		RIGHT('0' + DATEPART(dd,CalcDate),2) as [Day],
		RIGHT('0' + DATEPART(isowk,CalcDate),2) as [WeekNo],
		substring('SuMoTuWeThFrSa',1+((DATEPART(dw,CalcDate)-1)*2),2) as [WeekDay],
		CASE WHEN DATEPART(dw,CalcDate) >=2 and DATEPART(dw,CalcDate) <=6 THEN 'N' ELSE 'Y' END as WeekEnd,
		CASE WHEN CONVERT(varchar(10),DATEADD(ms,-3,DATEADD(mm,0,DATEADD(mm,DATEDIFF(mm,0,CalcDate)+1,0))),111) = CONVERT(varchar(10),CalcDate,111)
			THEN (
			CASE WHEN DATEPART(mm,CalcDate) IN (1,2,4,5,7,8,10,11) THEN 'M'
				ELSE(CASE WHEN DATEPART(mm,CalcDate) IN (3,6,9) THEN 'Q' ELSE 'Y' END)
			END	)
			ELSE 'N' END as PeriodEnd,
		CASE WHEN CONVERT(varchar(10),DATEADD(ms,-3,DATEADD(mm,0,DATEADD(mm,DATEDIFF(mm,0,CalcDate)+1,0))),111) = CONVERT(varchar(10),CalcDate,111)
			THEN (CASE WHEN CalcDate < getutcdate() then 'N' END) -- Note Null for future dates
			ELSE (CASE WHEN CalcDate > DATEADD(DAY, -1 * @Archive_After_Days, getutcdate()) THEN
				(CASE WHEN CalcDate < getutcdate() then 'N' END) ELSE (CASE WHEN CalcDate < getutcdate() then 'Y' END) END)
			END as Archived
		FROM (
			SELECT Calc.Location, Calc.CalcDate
			FROM (
					SELECT Locs.Location, DATEADD(DAY,Counter.number+1,@Historical_Date) as CalcDate
					FROM
						(select distinct Location Location from raw.holiday where Location is not null) Locs
					CROSS JOIN (
						SELECT ROW_NUMBER() OVER(ORDER BY TenD.number, D.number) as number
						FROM master..spt_values D
						CROSS JOIN (SELECT TZFED.number FROM master..spt_values TZFED WHERE TZFED.type = 'P' AND TZFED.number <= (@Forward_And_Back_Years / 5)) TenD
						WHERE D.type = 'P'
					) Counter
				) Calc
			LEFT JOIN target.Calendar Cal ON Cal.Date = Calc.CalcDate
			WHERE Cal.Date is null ) A
	SELECT @Products = @@ROWCOUNT

	-- Ensure Holidays are Non-Working
	UPDATE target.Calendar
	SET WorkingDay = 'N'
	WHERE CONVERT(varchar(10),Date,111) IN (
		select CONVERT(varchar(10),C.Date,111)
		from target.Calendar C
		join raw.holiday H on C.[Date] = H.[Date]
		WHERE isnull(WorkingDay,'Y') = 'Y'
		)
	SELECT @Products = @Products + @@ROWCOUNT

	-- WeekEnds are Non-Working
	UPDATE target.Calendar
	SET WorkingDay = 'N'
	WHERE CONVERT(varchar(10),Date,111) IN (
		select CONVERT(varchar(10),C.Date,111)
		from target.Calendar C
		WHERE isnull(WorkingDay,'Y') = 'Y'
		 AND DATEPART(dw,C.[Date]) IN (1,7)
		)
	SELECT @Products = @Products + @@ROWCOUNT

	-- Ensure Working Days for all dates but Holidays
	UPDATE target.Calendar
	SET WorkingDay = 'Y'
	WHERE CONVERT(varchar(10),Date,111) IN (
		select CONVERT(varchar(10),C.Date,111)
		from target.Calendar C
		LEFT join raw.holiday H on C.[Date] = H.[Date]
		WHERE H.Date is null AND isnull(WorkingDay,'N') = 'N'
			AND DATEPART(dw,C.[Date]) NOT IN (1,7)
		)
	SELECT @Products = @Products + @@ROWCOUNT

	-- Set Previous & Next working Days for all working days
	UPDATE CAL
		SET CAL.PreviousWorkingDate = (SELECT MAX([Date])
			FROM target.Calendar
			WHERE [Date] < CAL.[Date] AND WorkingDay = 'Y'),
		CAL.NextWorkingDate = (SELECT MIN([Date])
			FROM target.Calendar
			WHERE [Date] > CAL.[Date] AND WorkingDay = 'Y')
	FROM target.Calendar CAL
	WHERE
		--CAL.WorkingDay = 'Y' AND (
		CAL.PreviousWorkingDate <> (SELECT MAX([Date])
			FROM target.Calendar
			WHERE [Date] < CAL.[Date] AND WorkingDay = 'Y')
		OR CAL.NextWorkingDate <> (SELECT MIN([Date])
			FROM target.Calendar
			WHERE [Date] > CAL.[Date] AND WorkingDay = 'Y')
		OR (CAL.NextWorkingDate is null AND CAL.PreviousWorkingDate is null)
		--)
	SELECT @Products = @Products + @@ROWCOUNT

	-- Ensure that Non-working Days dont use the Prev' & Next columns
	--UPDATE CAL
	--	SET CAL.PreviousWorkingDate = NULL,
	--	CAL.NextWorkingDate = NULL
	--FROM target.Calendar CAL
	--WHERE CAL.WorkingDay <> 'Y' AND NOT
	--	(CAL.NextWorkingDate is null OR CAL.PreviousWorkingDate is null)
	--SELECT @Products = @Products + @@ROWCOUNT

	-- Set the Accounting Peiod End codes, M=Month, Q=Quarter, Y-Year, otherwise lave at N
	UPDATE CAL
		SET CAL.PeriodEnd = Periods.PeriodEnd
	FROM target.Calendar CAL
	JOIN
		(SELECT Months.LastWorkingDay,
			CASE WHEN DATEPART(mm,LastWorkingDay) IN (1,2,4,5,7,8,10,11) THEN 'M'
				ELSE
					(CASE WHEN
							DATEPART(mm,LastWorkingDay) IN (3,6,9) THEN 'Q'
					ELSE 'Y'
					END)
				END as PeriodEnd
		 FROM
			(SELECT
				(SELECT MAX([Date]) FROM target.Calendar WHERE [Date] <= CAL.[LastDayInMonth] AND WorkingDay = 'Y') LastWorkingDay
			FROM (SELECT [Date] LastDayInMonth
				FROM target.CALENDAR
				WHERE CONVERT(varchar(10),DATEADD(ms,-3,DATEADD(mm,0,DATEADD(mm,DATEDIFF(mm,0,[Date])+1,0))),111)= CONVERT(varchar(10),DATE,111)
				) CAL) Months
		) Periods ON CAL.[Date] = Periods.[LastWorkingDay]
	WHERE CAL.PeriodEnd = 'N'
	SELECT @Products = @Products + @@ROWCOUNT

	-- Ensure that non accountin period end dates are set as N (could happen when Bank holidays are added)
	UPDATE CAL
		SET CAL.PeriodEnd = 'N'
	FROM target.Calendar CAL
	LEFT JOIN
		(SELECT Months.LastWorkingDay
		 FROM
			(SELECT
				(SELECT MAX([Date]) FROM target.Calendar WHERE [Date] <= CAL.[LastDayInMonth] AND WorkingDay = 'Y') LastWorkingDay
			FROM (SELECT [Date] LastDayInMonth
				FROM target.CALENDAR
				WHERE CONVERT(varchar(10),DATEADD(ms,-3,DATEADD(mm,0,DATEADD(mm,DATEDIFF(mm,0,[Date])+1,0))),111)= CONVERT(varchar(10),DATE,111)
				) CAL) Months
		) Periods ON CAL.[Date] = Periods.[LastWorkingDay]
	WHERE Periods.[LastWorkingDay] is null AND CAL.PeriodEnd <> 'N'
	SELECT @Products = @Products + @@ROWCOUNT

END TRY

--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;
	
END CATCH;

RETURN 0;
END
GO