IF OBJECT_ID ('target.p_Get_ViewDetails') IS NOT NULL
	DROP PROCEDURE target.p_Get_ViewDetails
GO

CREATE PROC [target].[p_Get_ViewDetails] 

AS 

BEGIN

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--

	SET NOCOUNT ON

	select	
		a.name as Star,
		b.name as Field ,
		u.TABLE_NAME as Origin,
		----c.name as DataType,	
		h.COLUMN_DESCRIPTION
		--CASE WHEN h.value is null THEN '-' ELSE cast(h.value as varchar(max)) END  as [Description]
		----u.*
		--,h.*
		
	from sysobjects as a
	join sys.schemas s on a.uid = s.schema_id
	join syscolumns as b on a.id = b.id
	join systypes as c on b.xtype = c.xtype 
	left join (
			 
	SELECT VIEW_COLUMN_NAME=c.name,VIEW_CATALOG,VIEW_SCHEMA,VIEW_NAME,TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME, ep.value as 'COLUMN_DESCRIPTION'
	FROM sys.columns c
	INNER JOIN sys.views vw on c.OBJECT_ID = vw.OBJECT_ID
	INNER JOIN sys.schemas s ON s.schema_id = vw.schema_id
	LEFT JOIN INFORMATION_SCHEMA.VIEW_COLUMN_USAGE vcu on vw.name = vcu.VIEW_NAME and s.name = vcu.VIEW_SCHEMA and c.name = vcu.COLUMN_NAME
	LEFT JOIN (
		SELECT distinct SCM_Name=SCM.Name,TBL_Name=TBL.name,COLName=COL.name,COL_Object_id= COL.object_id,COL_column_id=COL.column_id
		FROM
		SYS.COLUMNS COL
		INNER JOIN SYS.TABLES TBL on COL.object_id = TBL.object_id
		INNER JOIN SYS.SCHEMAS SCM ON TBL.schema_id = SCM.schema_id) tempTBL on tempTBL.TBL_Name=vcu.TABLE_NAME and tempTBL.SCM_Name=TABLE_SCHEMA and tempTBL.COLName = vcu.COLUMN_NAME
	Left join sys.extended_properties ep on tempTBL.COL_Object_id = ep.major_id and tempTBL.COL_column_id = ep.minor_id
	--where vw.NAME = 'vTest'
	) as h on a.name = h.VIEW_NAME and b.name = h.COLUMN_NAME
	--left join sys.extended_properties as h on a.id = h.major_id and b.colid = h.minor_id
	--left join INFORMATION_SCHEMA.COLUMNS as u on u.TABLE_NAME = a.name and u.COLUMN_NAME = b.name and u.ORDINAL_POSITION = b.colid 
	left join INFORMATION_SCHEMA.VIEW_COLUMN_USAGE as u on a.name = u.VIEW_NAME and b.name = u.COLUMN_NAME 
	
		
	where s.name='target' 
		--and u.TABLE_SCHEMA = 'target'
		and a.type = 'V'
		and b.name not like '%Key'
		and b.name not in ('Start','Finish')
		--and a.name = 'vTest'
		and u.TABLE_NAME not in ('vTimeTravel','f_BUSDATEsInFact')
		and a.name not in ('v_FXRate_OLD','v_Position_OLD')
		and b.name not in ('busdate')
		order by Star,field asc
			 
			 
	--SELECT VIEW_COLUMN_NAME=c.name,VIEW_CATALOG,VIEW_SCHEMA,VIEW_NAME,TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME, ep.value as 'COLUMN_DESCRIPTION'
	--FROM sys.columns c
	--INNER JOIN sys.views vw on c.OBJECT_ID = vw.OBJECT_ID
	--INNER JOIN sys.schemas s ON s.schema_id = vw.schema_id
	--LEFT JOIN INFORMATION_SCHEMA.VIEW_COLUMN_USAGE vcu on vw.name = vcu.VIEW_NAME and s.name = vcu.VIEW_SCHEMA and c.name = vcu.COLUMN_NAME
	--LEFT JOIN (
	--	SELECT distinct SCM_Name=SCM.Name,TBL_Name=TBL.name,COLName=COL.name,COL_Object_id= COL.object_id,COL_column_id=COL.column_id
	--	FROM
	--	SYS.COLUMNS COL
	--	INNER JOIN SYS.TABLES TBL on COL.object_id = TBL.object_id
	--	INNER JOIN SYS.SCHEMAS SCM ON TBL.schema_id = SCM.schema_id) tempTBL on tempTBL.TBL_Name=vcu.TABLE_NAME and tempTBL.SCM_Name=TABLE_SCHEMA and tempTBL.COLName = vcu.COLUMN_NAME
	--Left join sys.extended_properties ep on tempTBL.COL_Object_id = ep.major_id and tempTBL.COL_column_id = ep.minor_id
	--where vw.NAME = 'vTest'
			 
			 
	RETURN

--#-------------------------------------------------- END OF HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

END
GO
