IF OBJECT_ID ('core.p_Control_Calendar') IS NOT NULL
	DROP PROCEDURE core.p_Control_Calendar
GO

CREATE PROC [core].[p_Control_Calendar] 
(	
	@Datafeed		VARCHAR(64),
	@AsOfBusDate	DATETIME2,
	@Env			VARCHAR(6)
)
AS 

BEGIN

    SET NOCOUNT ON;

    DECLARE
        @ProcedureName 		NVARCHAR(128),
		@Message 	   		NVARCHAR(MAX),
		@NowDate			DATETIME2,
		@SourceKey			BIGINT;
 
    SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),                  
		@Message			= 'Invoking ' + @ProcedureName,
		@NowDate			= GETUTCDATE();
	
  	--Start logging session		
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

  	--Start logging event
	SET @Message = 'Start of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--Update the Target facts
	EXEC [core].p_Conform_Calendar @AsOfBusDate, @DataFeed, @Env

	--Finish logging
	
	SET @Message = 'Finish'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

     DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO