IF OBJECT_ID ('core.[p_Core2Staging4Facts]') IS NOT NULL
	DROP PROCEDURE core.[p_Core2Staging4Facts]
GO

CREATE PROC [Core].[p_Core2Staging4Facts]
(
	@Datafeed				nVARCHAR(100),
	@Environment			nvarchar(30),
	@CoreStarPrefix			varchar(50),
	@CoreTable				nVARCHAR(50),
	@CoreKeyColumn			nVARCHAR(50),
	@FactTable				nVARCHAR(50),
	@BusinessKeyColumns		core.Core2TargetParameter READONLY,
	@DimensionKeyColumns	core.Core2TargetParameter READONLY,
	@IgnoreColumns			core.Core2TargetParameter READONLY,
	@TargetRefDateTime		DATETIME2(7),
	@GoldenOrigins			core.Core2TargetParameter READONLY,
	@ExcludeDeprecatedFlag	INT		= 1,
	@SessionID				INT		= 0
)
AS

BEGIN
	SET NOCOUNT ON

	DECLARE
		@return_status		INT,
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@BusinessLogicSev	INT,
		@ID					int;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@SessionID = @@IDENTITY,
		@Message = 'Invoking ' + @ProcedureName
	
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @DEBUG BINARY=1 -- default debug is off

	DECLARE @nSQL nvarchar(MAX)='';
	DECLARE @nAnalysisSQL nvarchar(MAX)='';
	DECLARE @nSQLCandidate nvarchar(MAX)='';

	DECLARE @TargetBusinessKeys VARCHAR(MAX)
	DECLARE @BusinessKeyCompare VARCHAR(MAX)
	DECLARE @StagingBusinessKeys VARCHAR(MAX)
	DECLARE @StagingPayloadColumns VARCHAR(MAX)
	DECLARE @StagingImportJoinCols VARCHAR(MAX)
	DECLARE	@ALLBusinessKeyColumns core.Core2TargetParameter
	DECLARE	@CoreIndexColumns core.Core2TargetParameter
--	DECLARE @CoreBusinessKeyColumnList as varchar(MAX)
	DECLARE @StagingBusinessKeyColumnList as VARCHAR(MAX)
	DECLARE @StagingColumnList VARCHAR(MAX)
	DECLARE @TargetBusinessKeyColumnList as varchar(MAX)
	DECLARE @TargetImportJoinCols VARCHAR(MAX)
	DECLARE @TargetPayloadColumns VARCHAR(MAX)
	DECLARE @TargetColumnList VARCHAR(MAX)
	DECLARE @TargetRefDateStr nvarchar(30)
	DECLARE @TargetSourceTable nVARCHAR(50)
	DECLARE @TargetSourceKeyColumn nvarchar(50)
	DECLARE @GoldenSource nVARCHAR(100)
	DECLARE @COUNTER int
	DECLARE @CoreSourceTable nVARCHAR(50)
	DECLARE @StagingTable nVARCHAR(50)
	DECLARE @TargetTable nVARCHAR(50)
	DECLARE @KeyColumn nVARCHAR(50)
	DECLARE @AllFactColumns VARCHAR(MAX)
	DECLARE @TotalRows INT
	DECLARE @Currentrow INT = 0
	DECLARE @DimensionReference VARCHAR(50)
	DECLARE @OrigCoreTable nVARCHAR(50)

	-- Extract the golden source
	SET @GoldenSource = (SELECT TOP 1 ID FROM @GoldenOrigins)

	-- Add system suffixs to table names

	SET @KeyColumn				= 'FactKey'
	SET @OrigCoreTable			= @CoreTable
	SET @CoreTable				= '[CORE].[' + @CoreStarPrefix + @CoreTable + ']'
	SET @StagingTable			= '[STAGING].[' + @FactTable + ']'
	SET @TargetTable			= '[TARGET].[' + @FactTable + ']'
	SET @TargetSourceTable		= '[TARGET].[SOURCE]'
	SET @TargetSourceKeyColumn	= '[SourceKey]'

	--=================================================================================================================
	-- SPECIAL PATCH FOR NON-STANDARD COLUMN NAMES

	IF @CoreTable = '[CORE].[SimraFORiskMeasures_RiskMeasureValue]' SET @KeyColumn = 'CoreRiskMeasureValueKey'
	IF @CoreTable = '[CORE].[SimraPnLs_PnlValue]' SET @KeyColumn = 'CorePnLValueKey'

	--=================================================================================================================

	IF @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, 'Tables names are : @CoreTable = ' + isnull(@CoreTable,' Null or no value ') + ',  @StagingTable = ' + isnull(@StagingTable,' Null or no value ') + ', @TargetTable = ' + isnull(@TargetTable, ' Null or no value ')

	-- Transfer Parameters into working variables
	SET @TargetRefDateTime = ISNULL(@TargetRefDateTime,GETUTCDATE())
	SET @TargetRefDateStr = CONVERT(nvarchar(19),@TargetRefDateTime,121)

	-- Prepare Staging to receive new data and copy accross from Core
	SET @nSQLCandidate = 'TRUNCATE TABLE ' + @StagingTable +';'
	EXEC sp_executesql @nSQLCandidate

	-- Move All of the Candidate data from Core to Staging
	SET @AllFactColumns = NULL
	SELECT
		@AllFactColumns = COALESCE(@AllFactColumns + ', ', '')  + '[' + Name + ']'
	FROM
		sys.columns
	WHERE
		object_id = OBJECT_ID(@CoreTable)
		AND 
		Name <> @KeyColumn

	SET @nSQL = '';
	SET @nSQL = @nSQL + ' INSERT INTO ' + @StagingTable + ' ( ' + @KeyColumn + ', ' + @AllFactColumns + ' ) '
	SET @nSQL = @nSQL + ' SELECT (' + @CoreKeyColumn + ' * -1 ), ' + @AllFactColumns
	SET @nSQL = @nSQL + ' FROM ' + @CoreTable
	PRINT @nSQL
	EXEC sp_executesql @nSQL

	-- Insert the Target Source References into Staging (for the data that just came from Core),
	-- ready to be merged into Target
	
	SET @nSQL = ''
	SET @nSQL = @nSQL + 'UPDATE ' + @StagingTable
	SET @nSQL = @nSQL + '	SET SourceKey = StagingSourceKeys.SourceKey '
	SET @nSQL = @nSQL + 'FROM '
	SET @nSQL = @nSQL + '	( '
	SET @nSQL = @nSQL + '		SELECT DISTINCT '
	SET @nSQL = @nSQL + '			CS.CoreSourceKey, '
	SET @nSQL = @nSQL + '			TS.SourceKey '
	SET @nSQL = @nSQL + '		FROM CORE.' + @CoreStarPrefix + 'Source CS '
	SET @nSQL = @nSQL + '			JOIN TARGET.Source TS '
	SET @nSQL = @nSQL + '			ON '
	SET @nSQL = @nSQL + '				CS.InterfaceName = TS.InterfaceName '
	SET @nSQL = @nSQL + '				AND '
	SET @nSQL = @nSQL + '				CS.Environment = TS. Environment '
	SET @nSQL = @nSQL + '				AND '
	SET @nSQL = @nSQL + '				CS.Source = TS.Source '
	SET @nSQL = @nSQL + '				AND '
	SET @nSQL = @nSQL + '				CS.Origin = TS.Origin '
	SET @nSQL = @nSQL + '	) StagingSourceKeys '
	SET @nSQL = @nSQL + 'WHERE ' + @StagingTable + '.CoreSourceKey = StagingSourceKeys.CoreSourceKey'
	PRINT @nSQL
	EXEC sp_executesql @nSQL

	-- Associate Core Fact data in Staging with Their Dimensions in Target

	IF (OBJECT_ID('tempdb..#DimTab') is not null) -- create a temporary table only available for this connection
		TRUNCATE TABLE #DimTab
	ELSE
		CREATE TABLE #DimTab (row_n INT, id VARCHAR(50));
	INSERT INTO #DimTab SELECT DISTINCT ROW_NUMBER() OVER (ORDER BY id) AS row_n,id FROM @DimensionKeyColumns
	SET @Currentrow = 1
	SET @TotalRows = (select COUNT(*) FROM #DimTab)
	IF @TotalRows > 0

	BEGIN
		WHILE @Currentrow <= @TotalRows
		BEGIN
			SET @DimensionReference = (SELECT id FROM #DimTab WHERE row_n = @Currentrow)
			IF ISNULL(@DimensionReference,'blank') = 'blank' or LEN(@DimensionReference) = 0
				PRINT '@DimensionReference is zero length varchar'
			ELSE
			BEGIN
				--
				SET @nSQL = ''
				SET @nSQL = @nSQL + 'UPDATE ' + @StagingTable
				SET @nSQL = @nSQL + '     SET ' + @DimensionReference + ' = StagingKeys.' + @DimensionReference
				SET @nSQL = @nSQL + ' FROM '
				SET @nSQL = @nSQL + '     (SELECT CREF.Core' + @DimensionReference + ', SREF.' + @DimensionReference
				SET @nSQL = @nSQL + '     FROM ' + @CoreTable + ' CF '
				SET @nSQL = @nSQL + '     JOIN core.' + @CoreStarPrefix + SUBSTRING(@DimensionReference,1,LEN(@DimensionReference)-3) + ' CREF '
				SET @nSQL = @nSQL + ' ON CF.Core' + @DimensionReference + ' = CREF.Core' + @DimensionReference
				SET @nSQL = @nSQL + '     JOIN staging.' + SUBSTRING(@DimensionReference,1,LEN(@DimensionReference)-3) + ' SREF ON '
				SET @nSQL = @nSQL + '     CF.core' + @DimensionReference + ' = SREF.Core' + @DimensionReference
				SET @nSQL = @nSQL + '     ) StagingKeys '
				SET @nSQL = @nSQL + ' WHERE ' + @StagingTable + '.core'+ @DimensionReference
				SET @nSQL = @nSQL + '           = StagingKeys.core' + @DimensionReference

				PRINT @nSQL

				EXEC sp_executesql @nSQL
			END

			SET @Currentrow = @Currentrow + 1
		END
	END
	ELSE
	BEGIN
		EXEC [core].p_LogInfo @ProcedureName, 'No dimensions  to generate @SQL (or @TargetDimensionKeyColumns is null)'
	END

	IF (OBJECT_ID('tempdb..#DimTab') is not null) DROP TABLE #DimTab; -- drop the temporary table - only available for this connection

	DECLARE @IXName VARCHAR(100) = 'IX_' + @OrigCoreTable + '_BusinessKeys'
	DECLARE @TBLName VARCHAR(100) = @CoreStarPrefix + @OrigCoreTable
	EXEC [core].p_LogInfo @ProcedureName, 'Create Index on BusinessKey'
	
	INSERT INTO @CoreIndexColumns SELECT ID FROM @BusinessKeyColumns
	INSERT INTO @CoreIndexColumns SELECT 'Core'+ID FROM @DimensionKeyColumns

	EXEC core.p_CreateIndex
		@IndexName = @IXName,
		@SchemaName = 'core',
		@TableName = @TBLName,
		@TableOfColumns = @CoreIndexColumns
		
	-- Extend Busines Key column to add in the Dimension References
	INSERT INTO @ALLBusinessKeyColumns SELECT ID FROM @BusinessKeyColumns
	INSERT INTO @ALLBusinessKeyColumns SELECT ID FROM @DimensionKeyColumns
			
	-- Business Key Columns with appropriate prefixes
	SET @StagingBusinessKeyColumnList = Null
	SELECT @StagingBusinessKeyColumnList = COALESCE( @StagingBusinessKeyColumnList + ', ', '') + '[S].[' + ID + ']' FROM @ALLBusinessKeyColumns;
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, '    Staging Business Key Columns = ' + @StagingBusinessKeyColumnList

--	SET @StagingBusinessKeyColumnList = REPLACE (@CoreBusinessKeyColumnList,'[SS].','[S].')

	SET @TargetBusinessKeyColumnList = REPLACE (@StagingBusinessKeyColumnList,'[S].','[T].')

	SET @TargetBusinessKeys = replace (@StagingBusinessKeyColumnList,'[S].[','[A].[STAGING_')

	SELECT @StagingBusinessKeys = COALESCE(@StagingBusinessKeys + ', ', '') + '[STAGING].[' + Id + '] [STAGING_' + Id + ']' FROM @ALLBusinessKeyColumns order by id

	SET @TargetBusinessKeys = replace (@StagingBusinessKeys,'[STAGING','[TARGET')

	-- CORE Payload columns with [C.] Prefix
	SET @StagingPayloadColumns = Null
	SELECT @StagingPayloadColumns = COALESCE(@StagingPayloadColumns + ', ', '')  + '[S].[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@StagingTable)
			  and not name = @KeyColumn
			  and name not in (select ID name from @IgnoreColumns)
			 order by name

	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, '    Core Columns remaining = ' + isnull(@StagingPayloadColumns, 'No Source Columns to read from')
	SET @StagingPayloadColumns = ISNULL(@StagingPayloadColumns,'') -- avoid null + varchar giving null later

	SET @StagingColumnList = REPLACE (@StagingPayloadColumns,'[S].','[S].')

	-- CORE to TARGET Business Key Compare
	SET @BusinessKeyCompare = Null
	SELECT @BusinessKeyCompare = COALESCE(@BusinessKeyCompare + ' AND ', '') + '[STAGING].[' + Id + '] = [TARGET].[' + Id + ']'
		FROM @ALLBusinessKeyColumns order by id

	IF @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, ' *** @BusinessKeyCompare = ' + isnull(@BusinessKeyCompare, 'No Core Business Key Columns')
	SET @BusinessKeyCompare = isnull(@BusinessKeyCompare, '')

	SET @TargetImportJoinCols  = REPLACE (@BusinessKeyCompare,'[STAGING].[','[T].[')
		SET @TargetImportJoinCols  = REPLACE (@TargetImportJoinCols,'[TARGET].[','[A].[TARGET_')

	SET @StagingImportJoinCols  = REPLACE (@BusinessKeyCompare,'[STAGING].[','[S].[')
		SET @StagingImportJoinCols  = REPLACE (@StagingImportJoinCols,'[TARGET].[','[A].[STAGING_')

	-- Target PayLoad Columns
	SET @TargetPayloadColumns = Null
	SELECT @TargetPayloadColumns = COALESCE(@TargetPayloadColumns + ', ', '')  + '[' + Name + ']'
		FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable)
			  and name not in (select * from @IgnoreColumns)
			  and name not in ('Start','Finish')
			 order by name
	If @DEBUG=1 EXEC [core].p_LogDebug @ProcedureName, '    Target Columns remaining = ' + isnull(@TargetPayloadColumns, 'No Target Columns to read from')
	SET @TargetPayloadColumns = ISNULL(@TargetPayloadColumns,'') -- avoid null + varchar giving null later

	SET @TargetColumnList  = REPLACE (@TargetPayloadColumns,'[','[T].[')

	-- For All Business keys, replace NULLs with Emty strings, to allow Matches to OCCUR in schema to schema reconcilliations	SELECT

	SET @nSQL = NULL;
	SELECT @nSQL = COALESCE( @nSQL + ', ', '') +
		' [' + ID + '] = CASE WHEN ISNUMERIC([' + ID + '])=1 THEN ISNULL([' + ID + '],0) ELSE ISNULL(['  + ID + '],"") END'
		FROM @ALLBusinessKeyColumns WHERE ID NOT LIKE '%DATE%';
	SET @nSQL = ' Update ' + @StagingTable + ' SET ' + @nSQL
	SET @nSQL = replace (@nSQL,'"',char(39))
	PRINT @nSQL
	EXEC sp_executesql @nSQL

	-- Contstruct the Analysis Clause
	SET @nSQL = '';
	SET @nSQL = @nSQL + ' WITH ANALYSIS AS ( '
	SET @nSQL = @nSQL + ' SELECT CASE WHEN '
	SET @nSQL = @nSQL + '   ((GOLDEN_CORE IS NOT NULL) AND (ISNULL(GOLDEN_CORE,0)=1 OR ISNULL(GOLDEN_TARGET,-1)=0 OR ISNULL(GOLDEN_TARGET,-1)=-1)) '
	SET @nSQL = @nSQL + '   THEN "CORE" '
	SET @nSQL = @nSQL + '   ELSE (CASE WHEN (GOLDEN_CORE IS NULL) AND ' + CONVERT(nVARCHAR(1),@ExcludeDeprecatedFlag) + ' =1 AND TARGET.SOURCE IN'
	SET @nSQL = @nSQL + '         (SELECT DISTINCT [SOURCE] FROM STAGING.SOURCE ' -- + @CoreSourceTable
	SET @nSQL = @nSQL + '         WHERE [InterfaceName] = "' + @Datafeed + '" AND Environment = "' + @Environment + '") THEN '
	SET @nSQL = @nSQL + '         "DEPRICATE" ELSE "TARGET" END) END [USE], '
	SET @nSQL = @nSQL + '         ' + @StagingBusinessKeys + ', '
	SET @nSQL = @nSQL + '         ' + @TargetBusinessKeys + ' '
	SET @nSQL = @nSQL + ' FROM ('
	SET @nSQL = @nSQL + ' SELECT ' + @StagingBusinessKeyColumnList + ', '
	SET @nSQL = @nSQL + '       [CS].[SOURCE] ,' -- IF RIGHT(@StagingTable,8) <> '_SOURCE]' SET @nSQL = @nSQL + ' [CS].[SOURCE] ,'
	SET @nSQL = @nSQL + '   CASE WHEN [CS].[SOURCE] = "' + @GoldenSource + '" THEN 1 ELSE 0 END GOLDEN_CORE '
	SET @nSQL = @nSQL + '   FROM  ' + @StagingTable + ' [S] '
	SET @nSQL = @nSQL + '   JOIN [STAGING].[Source] CS ON S.SourceKey = CS.SourceKey'
	SET @nSQL = @nSQL + ') [STAGING] FULL OUTER JOIN ('
	SET @nSQL = @nSQL + ' SELECT ' + @TargetBusinessKeyColumnList + ', '
	SET @nSQL = @nSQL + '       [TS].[SOURCE] ,' -- IF RIGHT(@StagingTable,8) <> '_SOURCE]' SET @nSQL = @nSQL + ' [TS].[SOURCE] ,'
	SET @nSQL = @nSQL + '   CASE WHEN [TS].[SOURCE] = "' + @GoldenSource + '" THEN 1 ELSE 0 END GOLDEN_TARGET '
	SET @nSQL = @nSQL + '   FROM  ' + @TargetTable + ' [T] '
	SET @nSQL = @nSQL + '   JOIN [TARGET].[Source] TS ON T.' + @TargetSourceKeyColumn + ' = TS.' + @TargetSourceKeyColumn
	SET @nSQL = @nSQL + '   WHERE T.Start <= "' + @TargetRefDateStr + '" AND T.Finish > "' + @TargetRefDateStr + '" '
	SET @nSQL = @nSQL + '         AND TS.Start <= "' + @TargetRefDateStr + '" AND TS.Finish > "' + @TargetRefDateStr + '" '
	SET @nSQL = @nSQL + ') [TARGET] ON ' + @BusinessKeyCompare + ')'
	SET @nAnalysisSQL = @nAnalysisSQL + @nSQL

	-- Remove data from Staging (came from Core) where Target data will be used (e.g. It is the higher priority Golden Source)
	SET @nSQL = '';
	SET @nSQL = @nSQL + @nAnalysisSQL
	SET @nSQL = @nSQL +  ' DELETE ' + @StagingTable + ' FROM ' + @StagingTable + ' S '
	SET @nSQL = @nSQL +  ' INNER JOIN ANALYSIS A on ' + @StagingImportJoinCols
	SET @nSQL = @nSQL +  ' WHERE A.[USE] = "TARGET" '

	SET @nSQLCandidate = '';
	SET @nSQLCandidate = replace (@nSQL,'"',char(39))
	EXEC [core].p_LogDebug @ProcedureName, @nSQLCandidate
	EXEC sp_executesql @nSQLCandidate

	-- Insert data to Staging from Target
	SET @nSQL = '';
	SET @nSQL = @nSQL + @nAnalysisSQL
	SET @nSQL = @nSQL +  ' INSERT INTO ' + @StagingTable + ' ( ' + @TargetPayloadColumns + ' ) '
	SET @nSQL = @nSQL +  ' SELECT ' + @TargetColumnList + ' '
	SET @nSQL = @nSQL +  ' FROM ' + @TargetTable + ' T '
	SET @nSQL = @nSQL +  ' INNER JOIN ANALYSIS A on ' + @TargetImportJoinCols
	SET @nSQL = @nSQL +  ' WHERE A.[USE] = "TARGET" '
	SET @nSQL = @nSQL +  '   AND T.Start <= "'+ @TargetRefDateStr + '"'
	SET @nSQL = @nSQL +  '   AND T.Finish > "'+ @TargetRefDateStr + '"'

	SET @nSQLCandidate = '';
	SET @nSQLCandidate = replace (@nSQL,'"',char(39))
	EXEC [core].p_LogDebug @ProcedureName, @nSQLCandidate
	EXEC sp_executesql @nSQLCandidate

	-- Lastly, all the new data in Staging (from core) has negative numbers. Renumber them now ready for Target

	SET @nSQL = '';
	SET @nSQL = @nSQL + ' DECLARE @MaxTargetKey as bigint; '
	SET @nSQL = @nSQL + ' SET @MaxTargetKey = (SELECT ISNULL(MAX(FactKey),0) FROM ' + @TargetTable + '); '
	SET @nSQL = @nSQL + ' 	MERGE ' + @StagingTable + ' S USING '
	SET @nSQL = @nSQL + ' 		(SELECT ' + @KeyColumn + ', RANK() OVER(ORDER BY ' + @KeyColumn + ' DESC) INCREMENT '
	SET @nSQL = @nSQL + ' 		FROM ' + @StagingTable + ' WHERE ' + @KeyColumn + ' < 0 ) F '
	SET @nSQL = @nSQL + ' 	ON S.FactKey = F.' + @KeyColumn
	SET @nSQL = @nSQL + ' 	WHEN MATCHED THEN UPDATE SET S.' + @KeyColumn + ' = @MaxTargetKey + INCREMENT; '
	PRINT @nSQL
	EXEC sp_executesql @nSQL

--	RETURN isnull(@COUNTER,0)

END TRY

--#------------------------------------------------- END OF PROCEDURE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	DECLARE @ErrorNumber		INT,
			@ErrorSeverity		INT,
			@ErrorState			INT,
			@ErrorLine			INT,
			@ErrorMessage		VARCHAR(MAX),
			@ErrorProcedure		VARCHAR(128);

	SELECT
		@ErrorNumber    = ERROR_NUMBER()    ,
		@ErrorSeverity  = ERROR_SEVERITY()  ,
		@ErrorState     = ERROR_STATE()     ,
		@ErrorMessage   = ERROR_MESSAGE()   ,
		@ErrorProcedure = ISNULL(ERROR_PROCEDURE(),'err') ,
		@ErrorMessage   = ERROR_MESSAGE()   ,
		@ErrorLine		= ERROR_LINE();

	EXEC [CORE].p_LogError
		 @SessionID			= @SessionID
		,@ErrorNumber		= @ErrorNumber
		,@ProcedureName		= @ProcedureName
		,@ProcID			= @@ProcID
		,@ErrorProcedure	= @ProcedureName
		,@ErrorSeverity		= @ErrorSeverity
		,@ErrorState		= @ErrorState
		,@ErrorMessage		= @ErrorMessage
		,@NESTLEVEL			= @@NESTLEVEL
		,@ErrorLine			= @ErrorLine
		,@Message			= @Comment
		,@messageTypeId		= 3
		,@UpdateType		= 'Error'

		RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN @ErrorNumber

END
GO

/*

	-- SAMPLE CALL

	DECLARE				@return_value int
	DECLARE
	@Datafeed			nVARCHAR(100),
	@Environment			nvarchar(30),
	@CoreTable			nVARCHAR(50),
	@CoreStarPrefix			varchar(50),
	@CoreKeyColumn			varchar(50),
	@FactTable			nVARCHAR(50),
	@BusinessKeyColumns		core.Core2TargetParameter,
	@DimensionKeyColumns	core.Core2TargetParameter,
	@IgnoreColumns			core.Core2TargetParameter,
	@TargetRefDateTime		DATETIME2(7),
	@GoldenOrigins			core.Core2TargetParameter,
	@ExcludeDeprecatedFlag	INT,
	@SessionID				INT

	--Parameters

	SET @Datafeed				= 'RiskMeasure_Fact'
	SET @Environment			= 'SIT'
	SET @CoreStarPrefix			= 'SimraFORiskMeasures_'
	SET @CoreTable				= 'RiskMeasureValue'
	SET @CoreKeyColumn          = 'CoreRiskMeasureValueKey'
	SET @FactTable				= 'RiskMeasure_Fact'
	SET @TargetRefDateTime		= '2016-12-21'
	SET @ExcludeDeprecatedFlag	= 1
	SET @SessionID				= 0
	INSERT INTO @BusinessKeyColumns VALUES
		  ('BusDate')
		, ('HierarchyKey'),('RiskMeasureTypeKey'),('RiskFactorTypeKey'),('RiskFactorKey'),('InstrumentTypeKey')
		, ('TenorKey_IT')
		, ('TenorKey_UT')
		, ('TenorKey_FT')
		, ('ProformaShift')
		, ('LegalEntity')
		, ('Cad2') -- Must be logically Unique from a business perspective when DimensionKeyColumns are included
	INSERT INTO @DimensionKeyColumns VALUES
		('HierarchyKey'),('RiskMeasureTypeKey'),('RiskFactorTypeKey'),('RiskFactorKey'),('InstrumentTypeKey')
	-- None SET @IgnoreColumns core.Core2TargetParameter
	INSERT INTO @GoldenOrigins VALUES ('SIMRA')

EXEC	@return_value = [CORE].[p_Core2Staging4Facts]
		@Datafeed = @Datafeed,
		@Environment = @Environment,
		@CoreStarPrefix	= @CoreStarPrefix,
		@CoreTable = @CoreTable,
		@CoreKeyColumn = @CoreKeyColumn,
		@FactTable = @FactTable,
		@BusinessKeyColumns = @BusinessKeyColumns,
		@DimensionKeyColumns = @DimensionKeyColumns,
		@IgnoreColumns = @IgnoreColumns,
		@GoldenOrigins = @GoldenOrigins,
		@TargetRefDateTime = @TargetRefDateTime,
		@ExcludeDeprecatedFlag = 1,
		@SessionID = 1

SELECT	'Return Value' = @return_value

GO
*/