IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_Control_ScenarioHierarchy]') AND type in (N'P', N'PC'))
DROP PROCEDURE [core].[p_Control_ScenarioHierarchy]
GO

CREATE PROC [core].[p_Control_ScenarioHierarchy]
(
	@Datafeed		VARCHAR(64),
	@AsOfBusDate	DATETIME2,
	@Env			VARCHAR(6),
	@ExecutionTime	DATETIME2(7) = NULL
)
AS

BEGIN

	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@SessionID		BIGINT,
		@SourceKey		BIGINT,
		@NowDate		DATETIME2,
		@LogInfo		varchar(1),
		@LogWarn		varchar(1);

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END,
		@SourceKey		= (SELECT SourceKey
							 FROM target.Source
				            WHERE InterfaceName = @DataFeed
							  AND [Source] IS NULL
					          AND Environment = @env
							  AND @NowDate >= Start
							  AND @NowDate < Finish);

	--Start logging session
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	SET @Message = 'Start of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--Split raw data into a star
	EXEC [core].p_CreateStar_ScenarioHierarchy @AsOfBusDate, @DataFeed, @Env

	--Conform the raw star dimensions with Target dimensions
	EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_ScenarioHierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env

	--Take note of load date
	EXEC [core].[p_Insert_TimeTravellingInstance] @AsOfBusDate, @NowDate, @DataFeed, @Env, 'ScenarioHierarchy'

	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	
    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO