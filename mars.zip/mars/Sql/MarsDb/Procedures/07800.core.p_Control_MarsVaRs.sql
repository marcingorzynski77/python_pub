IF OBJECT_ID ('core.p_Control_MarsVaRs') IS NOT NULL
	DROP PROCEDURE core.p_Control_MarsVaRs
GO

/*
  DECLARE @ExecutionTime AS DATETIME2; 
  SET @ExecutionTime = GETUTCDATE()
  EXEC [core].[p_Control_MarsVaRs] 'MarsVaRs', '2017-07-07', 'PROD', @ExecutionTime, 0  
  -- SELECT * FROM [target].[VaR_Fact] WHERE BusDate = '2017-07-07'
*/ 

CREATE  PROC [core].[p_Control_MarsVaRs]
(
	@DataFeed		VARCHAR(64),
	@AsOfBusDate	DATETIME2,
	@Env			VARCHAR(6),
	@ExecutionTime	DATETIME2(7),
    @HierarchyTag   INT,
	@ExternalRef    VARCHAR(255) = null,
	@ExternalRef2   VARCHAR(255) = null
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@NowDate			DATETIME2;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;

	--Start logging session
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	EXEC [core].p_LogInfo @ProcedureName, 'Start of processing'

	--Split raw data into a star
	EXEC [core].p_CreateStar_MarsVaRs @AsOfBusDate, @NowDate, @DataFeed, @Env, @HierarchyTag

	--Conform the raw star dimensions with Target dimensions
	EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env
	
    --at the moment we don't calculate VaR for books (and anyway we should not have any new books any way)
    --EXEC [core].p_Conform_HierarchyBook @AsOfBusDate, @NowDate, @DataFeed, @Env

    EXEC [target].p_Set_HierarchyMode @HierarchyTag
	--EXEC [core].p_Conform_Hierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env
	
	EXEC [core].p_Conform_ScenarioHierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env
	EXEC [core].p_Conform_RiskMeasureType @AsOfBusDate, @NowDate, @DataFeed, @Env

	--Update the Target facts with the star dimensions
	EXEC [core].p_UpdateFact_VaRs @AsOfBusDate, @NowDate, @DataFeed, @Env

	--Take note of load date
	EXEC [core].[p_Insert_TimeTravellingInstance] @AsOfBusDate, @NowDate, @DataFeed, @Env, 'VaR', @ExternalRef, @ExternalRef2
    
	DECLARE @Stats Flex_LoadStatsParameters
	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT * FROM [core].f_VarFactMonitor(
		 'VaR'		 		--		 @FactType	VARCHAR(64)
		,@DataFeed 			--		,@Interface	VARCHAR(64)
		,@Env
		,@AsOfBusDate 		--		,@BusDate	DATETIME2
		,@NowDate			--		,@Now		DATETIME2
	)

	EXEC [core].p_Flex_UpdateLoadStats @AsOfBusDate, @NowDate, 'VaR', @Stats 
    
	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing.'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO