IF OBJECT_ID ('core.p_Control_MurexSensitivities') IS NOT NULL
	DROP PROCEDURE core.p_Control_MurexSensitivities
GO

CREATE PROC [core].[p_Control_MurexSensitivities]
(
	@DataFeed			VARCHAR(64),
	@AsOfBusDate		DATETIME2,
	@Env				VARCHAR(6),
	@ExecutionTime		DATETIME2(7) = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@SourceKey			BIGINT,
		@NowDate			DATETIME2,
		@AllLoaded			TINYINT;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;

	--Start logging session
	EXEC [core].p_LogInfo @ProcedureName, @Message 

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	SET @Message = 'Start of processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	--#----------------------------------- First Merge the tables if they are all Loaded -------------------------------#--

	IF @DataFeed='Murex-ComData31' update raw.MurexSensitivities_Control set ComDataDate = @AsOfBusDate
	ELSE IF @DataFeed='Murex-ComGrk' update raw.MurexSensitivities_Control set GrkDate = @AsOfBusDate
	ELSE IF @DataFeed='Murex-ComiCommod' update raw.MurexSensitivities_Control set OmiCommodDate = @AsOfBusDate
	ELSE IF @DataFeed='Murex-ComPvbp' update raw.MurexSensitivities_Control set PvbpDate = @AsOfBusDate
	ELSE
	BEGIN
		SET @Message  = CONVERT(VARCHAR(4000), 'Unrecognised Feed: ' + @DataFeed)
		RAISERROR(@Message, 11, -11)
	END

	SELECT
		@AllLoaded = COUNT(1)
	FROM
		raw.MurexSensitivities_Control
	WHERE
		OmiCommodDate = @AsOfBusDate
		AND
		GrkDate = @AsOfBusDate
		AND
		PvbpDate = @AsOfBusDate
		AND
		ComDataDate = @AsOfBusDate


	IF  @AllLoaded = 1
	BEGIN
		EXEC [core].[p_Merge_MurexSensitivities] @AsOfBusDate, @DataFeed, @Env 


		--Split raw data into a star
		EXEC [core].p_CreateStar_MurexSensitivities @AsOfBusDate, @DataFeed, @Env 

		--Conform the raw star dimensions with Target dimensions
		EXEC [core].p_Conform_Source @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_HierarchyBook @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_Hierarchy @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_RiskMeasureType @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_RiskFactorType @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_RiskFactor @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_InstrumentType @AsOfBusDate, @NowDate, @DataFeed, @Env
		EXEC [core].p_Conform_Tenor @AsOfBusDate, @NowDate, @DataFeed, @Env

		--Update the Target facts with the star dimensions
		EXEC [core].p_UpdateFact_RiskMeasure @AsOfBusDate, @NowDate, @DataFeed, @Env

		--Take note of load date
		EXEC [core].[p_Insert_TimeTravellingInstance] @AsOfBusDate, @NowDate, 'MurexSensitivities', @Env, 'RiskMeasure' 

		DECLARE @Stats Flex_LoadStatsParameters
		
		INSERT INTO @Stats (
			  Start
			, Finish
			, SourceKey
			, RiskMeasureTypeKey
			, RiskFactorTypeKey
			, InstrumentTypeKey
			, Status
			, Count
		)
		SELECT * FROM [core].f_RiskMeasureFactMonitor (
			 'RiskMeasure'		--		 @FactType	VARCHAR(64)
			,'MurexSensitivities' 			--		,@Interface	VARCHAR(64)
			,@Env
			,@AsOfBusDate 		--		,@BusDate	DATETIME2
			,@NowDate			--		,@Now		DATETIME2
		)

		EXEC [core].p_Flex_UpdateLoadStats @AsOfBusDate, @NowDate, 'RiskMeasure', @Stats
	END
	ELSE
		EXEC [core].p_LogInfo @ProcedureName, 'Other Murex feed Loads not complete - no data processed'


	--Finish logging
	EXEC [core].p_LogInfo @ProcedureName, 'Finish'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END
GO