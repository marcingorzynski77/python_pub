IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_RRRHierarchyBookList]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [target].[p_Get_RRRHierarchyBookList]
GO


CREATE PROCEDURE [target].[p_Get_RRRHierarchyBookList]
(
    @BusinessDate DATETIME2,
    @HierarchyTag INT
)
AS
BEGIN

    EXEC TARGET.p_Set_HierarchyMode @HierarchyTag 
    EXEC TARGET.p_Set_TargetDate null, @BusinessDate 
    
    SELECT H.[NodeId] AS [RiskNodeId],
           H.[NodeParentID] AS [RiskNodeParentId],
           H.[NodeName] AS [RiskNodeName],
           H.[NodeType] AS [RiskNodeType],
           H.[BookLegalEntity],
           H.[BookCad2],
           H.[Ordinality],
           H.[Reporting],
           H.[Trading],
           H.[Group],
           H.[SubGroup],
           H.[Business],
           H.[BusinessArea],
           H.[Division],
           H.[Desk],
           H.[SubDesk],
           H.[Book],
           H.[BookSystem] 
      FROM [dbo].[Hierarchy] H
     INNER JOIN [dbo].[Hierarchy] P
        ON H.NodeParentID = P.NodeId
     WHERE H.[NodeType] = 'BO'
       AND P.[NodeType] != 'BO'
     ORDER BY H.[NodeName]

     RETURN

END
