IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_CreateStar_RRR]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [core].[p_CreateStar_RRR]
GO


CREATE PROC [core].[p_CreateStar_RRR]
(
	@BusDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@Debug		INT = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@CommentID		INT,
		@InsertedCount	BIGINT,
		@MaxRow			BIGINT,
		@UTCDate		DATETIME2 = getutcdate(),
		@BusinessKeyColumnsTable	[core].Core2TargetParameter

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 

--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--First empty the star ready for new data
	TRUNCATE TABLE [core].RRR_Source
	TRUNCATE TABLE [core].RRR_Counterparty
	TRUNCATE TABLE [core].RRR_InstrumentType
	TRUNCATE TABLE [core].RRR_RiskFactor
	TRUNCATE TABLE [core].RRR_RiskFactorType
	TRUNCATE TABLE [core].RRR_RiskMeasureType
	TRUNCATE TABLE [core].RRR_Trade	
	TRUNCATE TABLE [core].RRR_Hierarchy
	TRUNCATE TABLE [core].RRR_HierarchyBook
	TRUNCATE TABLE [core].RRR_FinancialDefinition
	TRUNCATE TABLE [core].RRR_TradeRule
	TRUNCATE TABLE [core].RRR_TradeLevel_Fact	
	TRUNCATE TABLE [core].RRR_Aggregated_Fact	

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'RRR_TradeLevel_Fact'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'RRR_Aggregated_Fact'
	
	--#-------------------------------------------- Populate the Source Dimension ------------------------------------------#--
	
	--Source Dimension
	
	;WITH sources AS (
		Select 'RRR' InterfaceName, @ENV Environment, 'RRR' Source, 'RRR'			Origin UNION 
		Select 'RRR' InterfaceName, @ENV Environment, 'RRR' Source, 'SIMRA'			Origin UNION 
		Select 'RRR' InterfaceName, @ENV Environment, 'RRR' Source, 'PARIS'			Origin UNION 
		Select 'RRR' InterfaceName, @ENV Environment, 'RRR' Source, 'SIMRAPARIS'	Origin 
		
	)
	INSERT INTO  [core].RRR_Source (		
		[InterfaceName]
		,[Environment]		
		,[Source]
		,[Origin]
	)
	SELECT * FROM sources
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_Source] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--Counterparty Dimension
	INSERT INTO  [core].RRR_Counterparty (
		[CoreCounterpartyKey]
		,[CoreSourceKey]
		,[CounterpartyCode]
		,[CounterpartyCodeType]
		,[LegalName]
		,[TradingStatus]
		,[TradingName]
		,[BusinessType]
		,[InternalClassification]
		,[InternalDescription]
		,[RfbSegment]
		,[DiamondSegment]
		,[HocustCode]
		,[InternalClient]
	)
	SELECT
		[CounterpartyID]
		,1 -- There is only one source: RRR
		,[CounterpartyCode]
		,[CounterpartyCodeType]
		,[LegalName]
		,[TradingStatus]
		,[TradingName]
		,[BusinessType]
		,[InternalClassification]
		,[InternalDescription]
		,[RfbSegment]
		,[DiamondSegment]
		,[HocustCode]
		,[InternalClient]
	FROM
		[raw].RRR_Counterparty C
			

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_Counterparty] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Hierarchy Dimension -----------------------------------------#--

	--Hierarchy Dimension
	INSERT INTO  [core].RRR_Hierarchy (
		[CoreHierarchyKey]
		,[CoreSourceKey]
		,[NodeId]
		,[NodeParentID]
		,[NodeName]
		,[NodeType]
		,[BookLegalEntity]		
		,[BookSystem]
		,[Book]
		,[SubDesk]
		,[Desk]
		,[Division]
		,[BusinessArea]
		,[Business]
		,[SubGroup]
		,[HierarchyTag]
	)
	SELECT		
	  [HierarchyKey]	
	  ,1 -- There is only one source: RRR
      ,[NodeId]
      ,[NodeParentID]
      ,[NodeName]
      ,[NodeType]
      ,[BookLegalEntity]     
      ,[BookSystem]
      ,(case when NodeType = 'BO' then NodeName else '' end) book
      ,[SubDesk]
      ,[Desk]
      ,[Division]
      ,[BusinessArea]
      ,[Business]
      ,[SubGroup]
      ,1
	FROM
		[raw].RRR_Hierarchy C


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_Hierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	

	--Populate Hierarchy Book
	INSERT INTO [core].RRR_HierarchyBook (
		 [CoreHierarchyBookKey]
		,[CoreSourceKey]
		,[NodeName]
		,[NodeType]
		,[BookCAD2]
		,[Trading]
		,[BookSystem]		
	)
	SELECT
		 CoreHierarchyKey
		,CoreSourceKey
		,H.NodeName
		,H.NodeType
		,(case when r.NodeId < 0 and r.NodeParentID = 0 and r.BookLegalEntity = 'UNKNOWN' then 1 else null end) as 'BookCAD2' --For Paris nodes
		,(case when r.NodeId < 0 and r.NodeParentID = 0 and r.BookLegalEntity = 'UNKNOWN' then 0 else 1 end) as 'Trading' --For Paris nodes
		,H.BookSystem		
	FROM [CORE].RRR_Hierarchy H 
	LEFT JOIN RAW.RRR_Hierarchy R
		ON R.NodeName = H.NodeName AND R.BookSystem = H.BookSystem
	where H.NodeType = 'BO' 
	
	--Update unknowns
	Update core.RRR_Hierarchy
		set SubDesk = (case when SubDesk = 'UNKNOWN' THEN 'UNKNOWN_SD' ELSE SubDesk END),
			Desk = (case when Desk = 'UNKNOWN' THEN 'UNKNOWN_DE' ELSE Desk END),
			Division = (case when Division = 'UNKNOWN' THEN 'UNKNOWN_DV' ELSE Division END),
			BusinessArea = (case when BusinessArea = 'UNKNOWN' THEN 'UNKNOWN_BA' ELSE BusinessArea END),
			Business = (case when Business = 'UNKNOWN' THEN 'UNKNOWN_BU' ELSE Business END),
			SubGroup = (case when SubGroup = 'UNKNOWN' THEN 'UNKNOWN_SG' ELSE SubGroup END)


	--Update unknowns
	Update core.RRR_Hierarchy
		set SubDesk = (case when SubDesk = 'UNKNOWN_SD' THEN null ELSE SubDesk END)

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--RiskFactor Dimension
	INSERT INTO  [core].RRR_RiskFactor (
		[CoreRiskFactorKey]
		,[CoreSourceKey]
		,[RiskFactorName]
	)
	SELECT
		[RiskFactorKey]
		,1 -- There is only one source: RRR
		,[RiskFactor]
	FROM
		[raw].RRR_RiskFactor C
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_RiskFactor] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--RiskFactorType Dimension
	INSERT INTO  [core].RRR_RiskFactorType (
		[CoreRiskFactorTypeKey]
		,[CoreSourceKey]
		,[RiskFactorTypeName]
	)
	SELECT
		[RiskFactorTypeKey]
		,1 -- only one source: RRR
		,[RiskFactorType]
	FROM
		[raw].RRR_RiskFactorType C
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_RiskFactorType] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--RiskMeasureType Dimension
	INSERT INTO  [core].RRR_RiskMeasureType (
		[CoreRiskMeasureTypeKey]
		,[CoreSourceKey]
		,[RiskMeasureTypeName]
		,[RiskMeasureFamily]		
	)
	SELECT
		[RiskMeasureTypeKey]
		,1 -- only one source: RRR
		,[RiskMeasureType]
		,[RiskMeasureFamily]
	FROM
		[raw].RRR_RiskMeasureType C


	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_RiskMeasureType] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--InstrumentType Dimension
	INSERT INTO  [core].RRR_InstrumentType (
		[CoreInstrumentTypeKey]
		,[CoreSourceKey]
		,[InstrumentSubType]
		,[InstrumentType]
		,[AssetClass]
		,[DerivativeFlag]
		,[OptionFlag]
		,[Permitted]
		,[LegsExpected]
	)
	SELECT
		[InstrumentTypeKey]
		,1 -- only one source: RRR
		,[InstrumentSubType]
		,[InstrumentType]
		,[AssetClass]
		,[DerivativeFlag]
		,[OptionFlag]
		,[Permitted]
		,[LegsExpected]
	FROM
		[raw].RRR_InstrumentType C
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_InstrumentType] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--Trade Dimension
	--Trade Dimension
	INSERT INTO  [core].RRR_Trade (
		[CoreSourceKey]		
		,[TradeReference]
		,[Maturity]
		,[InScopeForRRR]
		,[Notional]
		,[NotionalCurrency]
		,[StructureId]
		,[PackageMemberType]
		,[GrandFatheredFlag]
		,[ProxyTradeFlag]
		,[InternalTradeFlag]
		,[HedgeTradeFlag]
		,[TradePurpose]
		,[AppliedRules]
	)
	SELECT		
		S.CoreSourceKey		
		,[TradeReference]
		,[MATURITY]
		,[InScopeForRRR]
		,[Notional]
		,[NotionalCurrency]
		,[StructureId]
		,[PackageMemberType]
		,[grandFatheredFlag]
		,[ProxyTradeFlag]
		,[InternalTradeFlag]
		,[HedgeTradeFlag]
		,[TradePurpose]
		,[AppliedRules]
	FROM
		[raw].RRR_Trade C
	JOIN [core].RRR_Source S ON S.ORIGIN = C.[ORIGIN]
	GROUP BY S.CoreSourceKey
		,[TradeReference]
		,[Maturity]
		,[InScopeForRRR]
		,[Notional]
		,[NotionalCurrency]
		,[StructureId]
		,[PackageMemberType]
		,[GrandFatheredFlag]		
		,[ProxyTradeFlag]
		,[InternalTradeFlag]
		,[HedgeTradeFlag]
		,[TradePurpose]
		,[AppliedRules]

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_Trade] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--FinancialDefinition Dimension
	INSERT INTO  [core].RRR_FinancialDefinition (	
		[CoreSourceKey]			
		,[EffectiveDate]
		,[FDLegalEntity]
		,[Denominator]
		,[DenominatorType]
		,[FDValueGBP]
		,[Notes]
	)
	SELECT 		
		1
		,'20000101'
		,'UNKNOWN'
		,'UNKNOWN'
		,'UNKNOWN'
		,''
		,'UNKNOWN'
	UNION ALL
	SELECT
		1 -- only one source: RRR		
		,[BusinessDate]
		,[LegalEntity]
		,[Denominator]
		,[DenominatorType]		
		,isnull([FDValueGBP],0)
		,[Notes]	
	FROM 
		raw.RRR_FinancialDefinition
	where FDValueGBP is not null
	and FDValueGBP <> 0
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_FinancialDefinition] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#--------------------------------------------- Populate the Dimensions ------------------------------------------#--

	--# This is a special dimension in that it will in no way be linked to any fact tables. It will instead be used in the 
	--# specific functions RRRAggregatedDrillDown and RRRTradeDrillUp.

	--TradeRule Dimension
	INSERT INTO  [core].RRR_TradeRule (	
		  [CoreSourceKey]			
		  ,[BusDate]
		  ,[TradeReference]
		  ,[RuleName]
		  ,[FiredAt]
		  --,[RuleType]
		  --,[RuleValue]		
	)
	SELECT
		1 -- only one source: RRR		
		,[BusDate]
		  ,[TradeReference]
		  ,[RuleName]
		  ,[FiredAt]
		  --,[RuleType]
		  --,[RuleValue]		
	FROM 
		raw.RRR_TradeRule
	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[RRR_TradeRule] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#----------------------------------------------- Populate the TradeLevel Fact ---------------------------------------------#--

	--TradeLevel Fact
	insert into core.RRR_TradeLevel_Fact
	(
		[BusDate]
		,[CoreTradeKey]
		,[CoreRiskMeasureTypeKey]
		,[CoreInstrumentTypeKey]
		,[CoreCounterpartyKey]
		,[CoreRiskFactorKey]
		,[CoreRiskFactorTypeKey]
		,[CoreHierarchyKey]		
		,[CoreSourceKey]		
		,[ValueCurrency]
		,[Value]
		,[ValueGBP]
		,[MaturityBucket]
	)
	SELECT		
		@BusDate
		,isnull(T.[CORETradeKey],0)			AS [TradeKey]
		,isnull([RiskMeasureTypeKey],0)		AS [RiskMeasureTypeKey] 
		,isnull([InstrumentTypeKey],0)		AS [InstrumentTypeKey]
		,isnull([CounterpartyKey],0)		AS [CounterpartyKey]
		,isnull([RiskFactorKey],0)			AS [RiskFactorKey]
		,isnull([RiskFactorTypeKey],0)		AS [RiskFactorTypeKey]
		,isnull([HierarchyID],0)			AS [HierarchyKey]
		,T.[CoreSourceKey]		
		,[ValueCurrency]
		,[Value]
		,[ValueGBP]
		,[MaturityBucket] 
	FROM 
	(
		select * from raw.RRR_TradeResults R
		left join raw.RRR_Hierarchy H
		on H.HierarchyKey = R.HierarchyId
	)R
	JOIN CORE.RRR_TRADE T
		ON T.TradeReference = R.TradeReference
	JOIN RAW.RRR_TRADE RT 
		ON RT.TradeReference = T.TradeReference
	LEFT JOIN core.RRR_Hierarchy H
		ON H.NodeName = R.NodeName
		AND H.BookSystem = r.BookSystem
		
	
	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(10)) + ' rows into [core].[RRR_TradeLevel_Fact] fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--#----------------------------------------------- Populate the Aggregated Fact ---------------------------------------------#--
	
	--Aggregated Fact
	insert into core.RRR_Aggregated_Fact
	(
	   [CoreHierarchyKey]
      ,[CoreRiskMeasureTypeKey]
      ,[CoreFinancialDefinitionKey]     
      ,[CoreSourceKey]
      ,[BusDate]
      ,[AggregationID]
      ,[AggregationType]
      ,[AggregationRule]
      ,[ValueGBP]
      ,[ValueCurrency]
      ,[LegalEntity]
      ,[InstrumentType]
      ,[CounterpartyLegalName]
      ,[MaturityBucket]
      ,[AssetClass]
      ,[Internal]
      ,[DerivativeFlag]
      ,[OptionFlag]
      ,[IncludedTrades]
      ,[ExcludedTrades]
	)
	SELECT
	   [CoreHierarchyKey] [HierarchyKey]	   
      ,isnull([RiskMeasureTypekey],0) as [RiskMeasureTypeKey]
      ,isnull([CoreFinancialDefinitionKey],0) as [CoreFinancialDefinitionKey]
      ,1
      ,@BusDate
      ,[AggregationID]
      ,[AggregationType]
      ,[AggregationRule]
      ,[ValueGBP]
      ,[ValueCurrency]
      ,A.[LegalEntity]
      ,[InstrumentType]
      ,[CounterpartyLegalName]
      ,[MaturityBucket]
      ,A.[AssetClass]
      ,[Internal]
      ,A.[DerivativeFlag]
      ,A.[OptionFlag]      
      ,[IncludedTrades]
      ,[ExcludedTrades]
	FROM RAW.RRR_AggregatedResults A
	LEFT JOIN 
	(
		----Each node can have multiple booksystems and so ignore duplicates based on their precedence in golden source table
		select * from core.RRR_Hierarchy
		where CoreHierarchyKey not in
		(
			select CoreHierarchyKey from
			(
				select
					CoreHierarchyKey, 
					NodeName,BookSystem,
					RANK() over(partition by nodename order by precedence asc) as 'ordinality',
					g.*	
				from core.RRR_Hierarchy h
				left join core.GoldenSource G
				on G.InterfaceName = 'RRR'
				and G.Origin = h.BookSystem 
				and Dimension = 'Hierarchy'
				where NodeName in
				(
					select nodename from core.RRR_Hierarchy 
					group by NodeName
					having COUNT(1) > 1
				)
			)a
			where ordinality <> 1
		)	
	)
	 H
		on h.nodename = (case when a.Book <> '' then a.Book
						 when a.subdesk <> '' then a.subdesk
						 when a.desk <> '' then a.desk
						 when a.Division <> '' then a.Division
						 when a.BusinesArea <> '' then a.BusinesArea
						 when a.Business <> '' then a.Business
						 when a.SubGroup <> '' then a.SubGroup end)
		and h.nodetype = (case when a.Book <> '' then 'BO'
						 when a.subdesk <> '' then 'SD'
						 when a.desk <> '' then 'DE'
						 when a.Division <> '' then 'DV'
						 when a.BusinesArea <> '' then 'BA'
						 when a.Business <> '' then 'BU'
						 when a.SubGroup <> '' then 'SG' end)			
	left join 
	(
		select * from
		(
			select 
				RANK() over(partition by EffectiveDate,FDlegalentity,denominator order by denominatortype desc) as 'ordinality'
				,dense_RANK() over(partition by coresourcekey order by EffectiveDate desc) as 'DateOrdinality'
				,*
			from
			(select * from
			core.RRR_FinancialDefinition 
			where FDValueGBP is not null and EffectiveDate <= @busdate)a
		)G 
		where ordinality = 1
			and DateOrdinality = 1
	)F
	on A.AggregationType = (case when F.Denominator = 'Own Funds' then 'Net' else 'Gross' end)
	and f.FDLegalEntity = a.LegalEntity
	
		
		
		
	--Attributes
	update A
		set A.GrandFatheredFlag = B.GrandFatheredFlag,
			A.HedgeTradeFlag = B.HedgeTradeFlag,
			A.ProxyTradeFlag = B.ProxyTradeFlag,
			A.InternalTradeFlag = B.InternalTradeFlag,
			A.TradePurpose = B.TradePurpose		
	from core.RRR_Aggregated_Fact A
	left outer join
	(	
		select AggregationID
			,max([IsHedge]) HedgeTradeFlag
			,max([IsGrandFather])GrandFatheredFlag
			,max([IsProxy])ProxyTradeFlag
			,max([IsInternal])InternalTradeFlag 
			,max([TradePurpose])TradePurpose
		from
		(
		  select 
				 AggregationID,           				 
				 left(s.Item,CHARINDEX('=',s.item,1)-1) attribute,
				 right(s.Item,len(s.item) -CHARINDEX('=',s.item,1)) value
		  from
				(
				select AggregationID
					  , attributes 
				from raw.RRR_AggregatedResults 
				where Attributes is not null
				and Attributes <> ''
		  )  R       
		  CROSS APPLY target.f_split(R.Attributes,';') S      
		)a
		PIVOT
		(
			MAX(value) FOR attribute IN ([IsHedge],[IsGrandFather],[IsProxy],[IsInternal],[TradePurpose])

		) as P 
		group by AggregationID
    )B
    on A.AggregationID = B.AggregationID

		
	--Log affected rows
	SET @Message = 'Split out '+ CAST((@@ROWCOUNT)AS VARCHAR(10)) + ' rows into [core].[RRR_Aggregated_Fact] fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END