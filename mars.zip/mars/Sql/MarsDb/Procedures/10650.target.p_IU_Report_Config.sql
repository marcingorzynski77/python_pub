/****** Object:  StoredProcedure [target].[p_IU_Report_Config]    Script Date: 07/04/2017 16:11:10 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_IU_Report_Config]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_IU_Report_Config]
GO


CREATE PROC [target].[p_IU_Report_Config] 
(
	@Event varchar(10),
	@Report varchar(100),		
	@Description varchar(100),		
	@Filepath varchar(MAX),
	@User varchar(50)
)
AS 

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE
		@return_status		int,
        @ProcedureName      NVARCHAR(128),
        @Message 	        NVARCHAR(MAX),
        @BusinessLogicSev	INT,
        @SessionID  		BIGINT ,
        @VersionPath		varchar(100);
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
        @Message            = 'Invoking ' + @ProcedureName;

	exec [core].p_LogInfo @ProcedureName, @Message
	set @SessionID = @@IDENTITY	
  
--#---------------------------------------- END OF STANDARD TRANSACTION HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY	

		
	if @Event = 'UPDATE'
	begin
				
		if (select COUNT(1) 
			from core.Report_Config
			where Name = @Report
			and [Description] = @Description
			and [TemplateFilepath] = @Filepath
			AND Finish = '99991231') = 0
		begin
			--Expire previous entry
			update core.Report_Config
			set finish = GETUTCDATE()			
			where Name = @Report
			AND Finish = '99991231'
			
			--Insert new entry
			insert into core.Report_config			
			values(GETUTCDATE(),'99991231',@Report,@Description,@Filepath,@user)
			
		end
	end
	

END TRY

--#---------------------------------------------------- END OF IUSP ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END



GO


