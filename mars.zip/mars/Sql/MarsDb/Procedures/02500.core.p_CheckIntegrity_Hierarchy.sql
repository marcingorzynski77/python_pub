IF OBJECT_ID ('core.p_CheckIntegrity_Hierarchy') IS NOT NULL
	DROP PROCEDURE core.p_CheckIntegrity_Hierarchy
GO

CREATE PROC [core].[p_CheckIntegrity_Hierarchy]
(
	@SessionID	int		= 0,
	@NowDate	DATETIME2,
	@return_status	int OUTPUT
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@InitialTranCount	INT,
		@BusinessLogicSev	INT;


    SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT;

	SET @Message = 'Invoking ' + @ProcedureName
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#------------------------------------------ END OF STANDARD INEGRITY HEADER -----------------------------------------#--
--#====================================================================================================================#--

DECLARE @ERR_Misconformed int; SET @ERR_Misconformed = 50001
EXEC sp_addmessage @ERR_Misconformed, 16, N'Integrity Checks: Misconformed hierarchy NodeTypes were found in [target].HierarchyConsolidated.',@replace='replace';
DECLARE @ERR_MisAligned int; SET @ERR_MisAligned = 50002
EXEC sp_addmessage @ERR_MisAligned, 16, N'Integrity Checks: Misaligned hierarchy entities were found in [target].HierarchyConsolidated.',@replace='replace';
DECLARE @ERR_Duplicates int; SET @ERR_Duplicates = 50003
EXEC sp_addmessage @ERR_Duplicates, 16, N'Integrity Checks: Duplicate Nodes were found in [target].HierarchyConsolidated.',@replace='replace';

BEGIN TRY

	declare @rowCount bigint

	--Check Dimensions are conformed in [target].vHierarchyConsolidated
	set @rowCount = (select COUNT(*) from [target].vHierarchyConsolidated)
	IF @rowCount > 0
	BEGIN
		set @rowCount = (
			select
				COUNT(1)
			from
				[target].vHierarchyConsolidated
			where
				(
					(NodeType = 'GR' AND [GROUP] IS NULL)
					or 
					(NodeType = 'BU' AND [Business] IS NULL)
					or 
					(NodeType = 'BA' AND [BusinessArea] IS NULL)
					or 
					(NodeType = 'DV' AND [Division] IS NULL)
					or 
					(NodeType = 'DE' AND [Desk] IS NULL)
					or 
					(NodeType = 'SD' AND [SubDesk] IS NULL)
					or 
					(NodeType = 'BO' AND [Book] IS NULL)
				)
				AND 
				START <=  @NowDate
				AND 
				Finish > @NowDate
		)
	END

	IF @rowCount > 0
	BEGIN
		SET @Message = (SELECT TEXT FROM sys.messages WHERE message_id = @ERR_Misconformed)
		EXEC [core].p_LogInfo @ProcedureName, @Message
		RAISERROR( @ERR_Misconformed,11,-1, @ProcedureName)
	END

--	select * from sys.messages where  message_id = 50001
	set @rowCount = (select COUNT(*) from [target].vHierarchyConsolidated)
	--Check Dimension alignment in [target].vHierarchyConsolidated
	IF @rowCount > 0
	BEGIN
		set @rowCount = (
			select
				COUNT(1)
			from
				[target].vHierarchyConsolidated
			where
				(
					(NodeType = 'GR' AND [Business] is not null AND [BusinessArea] is not null AND [Division] is not null AND [Desk] is not null AND [SubDesk] is not null AND [Book] is not null)
					or
					(NodeType = 'BU' AND [BusinessArea] is not null AND [Division] is not null AND [Desk] is not null AND [SubDesk] is not null AND [Book] is not null)
					or 
					(NodeType = 'BA' AND [Division] is not null AND [Desk] is not null AND [SubDesk] is not null AND [Book] is not null)
					or 
					(NodeType = 'DV' AND [Desk] is not null AND [SubDesk] is not null AND [Book] is not null)
					or 
					(NodeType = 'DE' AND [SubDesk] is not null AND [Book] is not null)
					or 
					(NodeType = 'SD' AND [Book] is not null)
				)
				AND 
				START <=  @NowDate
				AND 
				Finish > @NowDate
		)
	END
	IF @rowCount > 0
	BEGIN
		SET @Message = (SELECT TEXT FROM sys.messages WHERE message_id = @ERR_MisAligned)
		EXEC [core].p_LogInfo @ProcedureName, @Message
		RAISERROR( @ERR_MisAligned,11,-1, @ProcedureName)
	END

	--Check duplicate Nodes in [target].vHierarchyConsolidated
	set @rowCount = (
		select 
			count(1)
		from
		(
			select
				NodeId
			from 
				[target].vHierarchyConsolidated
			where
				START <=  @NowDate
				AND 
				Finish > @NowDate
			group by 
				NodeId,
				SourceKey
			having 
				COUNT(1) > 1
		) A
	)

	IF @rowCount > 0
	BEGIN
		--USE FOR TESTING TO SEE WHICH NODES HAVE DUPLICATES
		select 
			* 
		from 
			target.vHierarchyConsolidated 
		where 
			NodeId in
			(
				select 
					NodeId
				from
					[target].vHierarchyConsolidated
				where
					START <=  @NowDate
					AND 
					Finish > @NowDate
				group by 
					NodeId,
					SourceKey
				having 
					COUNT(1) > 1
			)
			AND 
			Start <=  @NowDate
			AND 
			Finish > @NowDate
		order by
			NodeID

		--Log Conformed count

		SET @Message = (SELECT TEXT FROM sys.messages WHERE message_id = @ERR_Duplicates)
		EXEC [core].p_LogInfo @ProcedureName, @Message
		RAISERROR( @ERR_Duplicates,11,-1, @ProcedureName)

	END

	--Check hierarchy string matches conformed hierarchy string in [target].vHierarchyConsolidated
--	set @rowCount = (
--		select
--			count(1)
--		from
--			(
--				select
--					Nodeid
--				from 
--					[target].vHierarchyConsolidated
--				where 
--					HierarchyString <> ConformedHierarchyString
--					AND 
--					CHARINDEX(':',ConformedHierarchyString,1) < 1
--					AND 
--					START <=  @NowDate 
--					AND 
--					Finish > @NowDate
--			) A
--	)
--
--	IF @rowCount > 0
--	BEGIN
--		--Log Conformed count
--		SET @Message = 'Integrity Checks: ' +  cast(@rowCount as varchar(10)) + ' hierarchy string mismatches were found in [target].Fact_Hierarchy.'
--		EXEC [core].p_LogInfo @ProcedureName, @Message
--	END

	IF @rowCount = 0
		SET @return_status	= 1
	ELSE
		SET @return_status	= 0

	RETURN @return_status

END TRY


--#--------------------------------------------------- END OF Checks --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

   DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END



/*

select
	*
from
	[core].staging_Hierarchy
where
	NodeId in
	(
		select
			NodeId
		from
			[core].staging_Hierarchy
		--where
		--	START <=  @NowDate
		--	AND 
		--	Finish > @NowDate
		--	AND 
		--	BookLegalEntity <> 'UNKNOWN'
		group by
			NodeId
		having
			COUNT(1) > 1
	)
order by
	Nodename
*/

GO

