IF OBJECT_ID ('target.p_IU_QueryTracker') IS NOT NULL
	DROP PROCEDURE target.p_IU_QueryTracker
GO

CREATE PROC [target].[p_IU_QueryTracker] 
(
	--@CRCID varchar(6),
	@ReportPath varchar(300),
	@ReportName varchar(100),
	@UserName varchar(50),
	@QueryID int,
	@Event varchar(10)
)
AS 

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE
		@ProcedureName      NVARCHAR(128),
        @ErrorNumber        INT,
        @ErrorSeverity      INT,
        @ErrorState         INT,
        @ErrorLine          INT,
        @ErrorMessage       VARCHAR(MAX),
        @ErrorProcedure     NVARCHAR(128),
        @ReportKey			INT,
        @QueryKey			INT,
        @UserKey			INT,
        @ReportID			INT;        
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
        @ErrorNumber        = 50000  -- ok we are in an error for transaction purposes (ie post roll back)        

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY					
	
	--Update the dimensions first
	--#---------------------------------------- 'Insert/Update Report Dimension' --------------------------------------#--
	
	----Does it alerady exist?
	--Set @ReportKey = (Select ReportKey
	--					from [target].[Report]
	--					where ReportPath = @ReportPath
	--						and ReportName = @ReportName
	--						and Finish = '99991231')
					
	
	--IF @Event = 'INSERT' 
	--begin
	--	if @ReportKey is null
	--	begin
	--		--Create a new entry
	--		insert into target.Report(
	--			Start,
	--			Finish,
	--			ReportID,				
	--			ReportPath,
	--			ReportName)			
	--		select
	--			GETUTCDATE(),
	--			'99991231',
	--			1,
	--			@ReportPath,
	--			@ReportName
	--			--@ReportID			
	--	end
		
	--		--Grab the new key
	--		Set @ReportKey = (Select ReportKey
	--							from [target].[Report]
	--							where ReportPath = @ReportPath
	--								and ReportName = @ReportName
	--								and Finish = '99991231')
	--end
	
	----#---------------------------------------- 'Insert/Update Query Dimension' ---------------------------------------#--						
	
	----Does it alerady exist?
	--Set @QueryKey = (Select QueryVersionKey
	--					from [target].[QueryVersion] Q
	--					join [core].[QueryCatalogue] C
	--						on Q.QueryName = C.Alias							
	--						and Q.VersionID = C.VersionID
	--						and Q.VersionPath = C.VersionPath						
	--					where Q.Finish = '99991231'
	--						and c.ID = @QueryID)
	
	print @querykey
	
	--IF @Event = 'INSERT' 
	--begin
	--	if @QueryKey is null
	--	begin
	--		--Create a new entry
	--		insert into target.QueryVersion(
	--			Start,
	--			Finish,			
	--			QueryName,
	--			VersionID,
	--			VersionPath,
	--			[Description])
	--		select
	--			GETUTCDATE(),
	--			'99991231',			
	--			Alias,
	--			VersionID,
	--			VersionPath,
	--			Comment		
	--		from [core].[QueryCatalogue] C
	--		where C.ID = @QueryID
			
	--		--Grab the new key
	--		Set @QueryKey = (Select QueryVersionKey
	--							from [target].[QueryVersion] Q
	--							join [core].[QueryCatalogue] C
	--								on Q.QueryName = C.Alias							
	--								and Q.VersionID = C.VersionID
	--								and Q.VersionPath = C.VersionPath						
	--							where Q.Finish = '99991231'
	--								and c.ID = @QueryID)
	--	end				
	--end

	----#----------------------------------------- 'Insert/Update User Dimension' ---------------------------------------#--		
	
	----Does it alerady exist?							
	--Set @UserKey = (Select UserKey
	--					from [target].[User]
	--					where systemname = SUSER_NAME()
	--						and Finish = '99991231')		


	--IF @Event = 'INSERT' 
	--begin
	--	if @UserKey is null
	--	begin
	--		--Create a new entry
	--		insert into [target].[User](
	--			Start,
	--			Finish,			
	--			FullName,
	--			SystemName,
	--			Roles)
	--		select
	--			GETUTCDATE(),
	--			'99991231',			
	--			@UserName,
	--			SUSER_NAME(),
	--			''				
				
	--		--Grab the new key
	--		Set @UserKey = (Select UserKey
	--						from [target].[User]
	--						where systemname = SUSER_NAME()
	--						and Finish = '99991231')		
	--	end	
	--end
	

	----#------------------------------------------ 'Insert/Update Fact Table' -----------------------------------------#--

	--IF @Event = 'INSERT' 
	--begin
	--	INSERT INTO [target].QueryExecution_Fact(
	--		Start,
	--		Finish,
	--		BusDate,
	--		ReportKey,
	--		QueryVersionKey,
	--		UserKey)
	--	select
	--		GETUTCDATE(),
	--		'99991231',
	--		(select busdate from target.f_BusDate()),
	--		@ReportKey,
	--		@QueryKey,
	--		@UserKey
	--end
	--else if @Event = 'FINISH'
	--begin
	--	Update [target].QueryExecution_Fact
	--	Set Finish = GETUTCDATE()
	--	where ReportKey = @ReportKey
	--		and QueryVersionKey = @ReportKey
	--		and UserKey = @UserKey
	--		and Finish = '99991231'
	--end

END TRY


--#--------------------------------------------------- END OF UPDATE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    SELECT 
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,        
		@ErrorProcedure = isnull(ERROR_PROCEDURE(),'err') ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
        @ErrorLine		= ERROR_LINE();
		        
        --LOG        
        EXEC [core].p_LogError @SessionID = 0
					  ,@ErrorNumber = @ErrorNumber
					  ,@ProcedureName=@ProcedureName
					  ,@ProcID = @@ProcID
					  ,@ErrorProcedure = @ErrorProcedure
					  ,@ErrorSeverity = @ErrorSeverity
					  ,@ErrorState = @ErrorState
					  ,@ErrorMessage = @ErrorMessage
					  ,@NESTLEVEL = @@NESTLEVEL
					  ,@ErrorLine = @ErrorLine


	
			               
		RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN @ErrorNumber
END

GO
