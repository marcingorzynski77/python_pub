IF OBJECTPROPERTY(OBJECT_ID('core.p_LogDebug'), N'IsProcedure') = 1
	DROP PROCEDURE [core].[p_LogDebug]
GO

CREATE PROCEDURE [core].[p_LogDebug]
(	
	@ProcedureName NVARCHAR(128),	
	@Message NVARCHAR(MAX)
)
AS
BEGIN
	
	EXEC [core].[p_LogEvent] @ProcedureName, @Message, 'DEBUG'
	
END
GO 
