/****** Object:  StoredProcedure [target].[p_Get_DataDictionary]    Script Date: 01/29/2018 13:54:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_DataDictionary]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Get_DataDictionary]
GO

/*
    EXEC [target].[p_Get_DataDictionary] 
*/

CREATE PROC [target].[p_Get_DataDictionary] 
(
	@WhereFilter as varchar(200) = ''
	,@Category as varchar(10) = ''
)
AS
BEGIN

	SET NOCOUNT ON;
	SET ANSI_WARNINGS OFF
	DECLARE
        @ProcedureName	NVARCHAR(128),
        @Message		VARCHAR(1000);

	SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName;

  	--Start logging session		
	EXEC [core].p_LogInfo @ProcedureName, @Message

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

    EXEC [core].p_LogInfo @ProcedureName, 'Populating facts'

    CREATE TABLE #DataDictionary
    (
        [DataSetType]      VARCHAR(255),
        [Data Set]         NVARCHAR(128),
        [Fact/Dimension]   VARCHAR(255),
        [OriginalTable]    NVARCHAR(128),
        [Table]	           NVARCHAR(128),
        [Field]	           NVARCHAR(128),
        [OriginalDataType] NVARCHAR(128),
        [DataType]         NVARCHAR(128),
        [Description]      VARCHAR(MAX)
    )

    INSERT INTO #DataDictionary
	SELECT 'Facts' AS [DataSetType],
            C.TABLE_NAME AS [Data Set]
		   ,CASE UPPER(RIGHT(V.TABLE_NAME,4)) 
                   WHEN 'FACT' THEN 'Fact' 
                   ELSE 'Dimension ' 
            END AS [Fact/Dimension]
		   ,ISNULL(V.TABLE_NAME, 'UNKNOWN') AS [OriginalTable] 
		   ,ISNULL(V.TABLE_NAME, 'UNKNOWN') AS [Table]			
		   ,C.COLUMN_NAME AS [Field]		
		   ,DATA_TYPE AS [OriginalDataType]
		   ,CASE WHEN LOWER(DATA_TYPE) LIKE 'date%' THEN 'Date'
                 WHEN LOWER(DATA_TYPE) like '%char%' then 'Char'
                 WHEN LOWER(DATA_TYPE) IN ('bit') then 'Boolean'
                 WHEN LOWER(DATA_TYPE) IN ('float', 'decimal') then 'Numeric'
                 WHEN LOWER(DATA_TYPE) LIKE ('%int%') then 'Numeric'
                 ELSE LOWER(DATA_TYPE)
            END AS [DataType] 
		   ,ISNULL(E.[Description],'') as [Description] 
	FROM INFORMATION_SCHEMA.COLUMNS C
	LEFT JOIN INFORMATION_SCHEMA.VIEW_COLUMN_USAGE V
		 ON C.TABLE_NAME = v.VIEW_NAME		
		 AND C.TABLE_SCHEMA = v.VIEW_SCHEMA
		 AND C.COLUMN_NAME = v.COLUMN_NAME
	LEFT JOIN
		(
			SELECT A.[Name] AS [TableName],
                    B.[Name] AS [Field],
                    CAST(P.[Value] AS VARCHAR(MAX)) AS [Description]
			    FROM SYSOBJECTS A
			    INNER JOIN SYSCOLUMNS B
			       ON A.ID = B.ID
                 LEFT OUTER JOIN SYS.EXTENDED_PROPERTIES P 
                   ON A.ID = P.MAJOR_ID 
                  AND B.COLID = P.MINOR_ID
			    WHERE A.XTYPE = 'U'
		 	      AND P.[VALUE] IS NOT NULL
		) E
		ON E.TABLENAME = V.TABLE_NAME
		AND E.FIELD = C.COLUMN_NAME 
	WHERE ISNULL(V.TABLE_NAME, '') NOT IN ('vTimeTravel','f_busdate','f_Dim_Hierarchy')
	  AND LOWER (C.TABLE_SCHEMA) = 'dataset'

    SET @Message = 'Inserted ' + CONVERT(VARCHAR(255), @@ROWCOUNT) + ' facts'
    EXEC [core].p_LogInfo @ProcedureName, @Message
	
	--Fill in unknowns caused by virtual tenor dimensions
	UPDATE #DataDictionary
       SET [Table] = SUBSTRING([Field],1,LEN([Field])-4)
		  ,[OriginalTable] = 'Tenor'
	 WHERE [Field] in ('InstrumentTenorName','UnderlyingTenorName','FixingTenorName','InstrumentTenorDays','UnderlyingTenorDays','FixingTenorDays')
	
	--Fix instances where views reference views
	UPDATE #DataDictionary
	   SET [Table] = SUBSTRING([Table],2,LEN([Table])-1)
		  ,[OriginalTable] = SUBSTRING([Table],2,LEN([Table])-1)
	 WHERE [Table] in ('vPnL_Fact','vRiskMeasure_Fact','vVAR_Fact','vRRRAggregated_Fact','vRRRTradeLevel_Fact','vRiskMeasureTrade_Fact')
	
	UPDATE #DataDictionary
       SET [Table] = 'Hierarchy' 
     WHERE [table] = 'vHierarchy'

	UPDATE #DataDictionary 
       SET [OriginalTable] = 'Hierarchy'
     WHERE [OriginalTable] = 'vHierarchy'
	
    EXEC [core].p_LogInfo @ProcedureName, 'Adding dimensions'

    --Add Dimesions
	INSERT INTO #DataDictionary
	SELECT DISTINCT 'Dimensions' AS [DataSetType]
          ,'v'+ [Table] as [Data Set]
          ,[Fact/Dimension]
          ,[OriginalTable]
          ,[Table]
          ,[Field]
          ,[OriginalDataType]
          ,[DataType]
          ,[Description]
      FROM #DataDictionary
     WHERE [Fact/Dimension] = 'Dimension'
	   AND [Table] NOT IN ('InstrumentTenor', 'UnderlyingTenor','FixingTenor','vHierarchyConsolidated')


    --Add Dimensions that don't appear in any datasets. (Required for flexfacts)
	INSERT INTO #DataDictionary
    SELECT 'Dimensions' AS [DataSetType],
            C.TABLE_NAME AS [Data Set]
		   ,CASE UPPER(RIGHT(V.TABLE_NAME,4)) 
                   WHEN 'FACT' THEN 'Fact' 
                   ELSE 'Dimension ' 
            END AS [Fact/Dimension]
		   ,ISNULL(V.TABLE_NAME, 'UNKNOWN') AS [OriginalTable] 
		   ,ISNULL(V.TABLE_NAME, 'UNKNOWN') AS [Table]			
		   ,C.COLUMN_NAME AS [Field]		
		   ,DATA_TYPE AS [OriginalDataType]
		   ,CASE WHEN LOWER(DATA_TYPE) LIKE 'date%' THEN 'Date'
                 WHEN LOWER(DATA_TYPE) like '%char%' then 'Char'
                 WHEN LOWER(DATA_TYPE) IN ('bit') then 'Boolean'
                 WHEN LOWER(DATA_TYPE) IN ('float', 'decimal') then 'Numeric'
                 WHEN LOWER(DATA_TYPE) LIKE ('%int%') then 'Numeric'
                 ELSE LOWER(DATA_TYPE)
            END AS [DataType] 
		   ,ISNULL(E.[Description],'') as [Description] 
	FROM INFORMATION_SCHEMA.COLUMNS C
	LEFT JOIN INFORMATION_SCHEMA.VIEW_COLUMN_USAGE V
		 ON C.TABLE_NAME = v.VIEW_NAME		
		 AND C.TABLE_SCHEMA = v.VIEW_SCHEMA
		 AND C.COLUMN_NAME = v.COLUMN_NAME
	LEFT JOIN
		(
			SELECT A.[Name] AS [TableName],
                    B.[Name] AS [Field],
                    CAST(P.[Value] AS VARCHAR(MAX)) AS [Description]
			    FROM SYSOBJECTS A
			    INNER JOIN SYSCOLUMNS B
			       ON A.ID = B.ID
                 LEFT OUTER JOIN SYS.EXTENDED_PROPERTIES P 
                   ON A.ID = P.MAJOR_ID 
                  AND B.COLID = P.MINOR_ID
			    WHERE A.XTYPE = 'U'
		 	      AND P.[VALUE] IS NOT NULL
		) E
		ON E.TABLENAME = V.TABLE_NAME
		AND E.FIELD = C.COLUMN_NAME 
	WHERE ISNULL(V.VIEW_NAME, '') IN ('vSource')
	  AND LOWER (C.TABLE_SCHEMA) = 'target'

    --Remove special dimensions that are listed as facts
	DELETE FROM #DataDictionary 
     WHERE [DataSetType] = 'Facts' 
       AND [Data Set] IN ('vCalendar','vHierarchy') 

    SET @Message = 'DataDictionary has ' + CONVERT(VARCHAR(255), (SELECT COUNT(*) FROM  #DataDictionary)) + ' non-flex items'
    EXEC [core].p_LogInfo @ProcedureName, @Message

    --Handle ringfencing hierarchy view
	UPDATE #DataDictionary 
       SET [Table] = 'HierarchyConsolidated'
     WHERE [table] = 'vHierarchyConsolidated'
	
    UPDATE #DataDictionary
       SET [OriginalTable] = 'HierarchyConsolidated' 
     WHERE [OriginalTable] = 'vHierarchyConsolidated'

    EXEC [core].p_LogInfo @ProcedureName, 'Adding flex datasets'

    INSERT INTO #DataDictionary
    SELECT 'FlexFacts' AS [DataSetType]
           ,REPLACE('v'+F1.[Description],'.MetaData.Fact.Name','') AS [Data Set]
           ,'Fact' AS [Fact/Dimension]
           ,'Measure' AS [OriginalTable]
           ,'Measure' AS [Table]
           ,F1.[Name] AS [Field]
           ,F2.[Name] AS [OriginalDataType]
           ,LOWER(F2.[Name]) AS [DataType]
           ,ISNULL(F3.[Name],'') AS [Description] 
      FROM [target].FlexFactHierarchy P
	 INNER JOIN [target].FlexFactHierarchy F1
		ON P.[FlexFactHierarchyKey] = F1.[ParentFlexFactHierarchyKey]
       AND F1.[Description] like '%Fact.Name' 
     INNER JOIN [target].FlexFactHierarchy F2
		ON P.[FlexFactHierarchyKey] = F2.[ParentFlexFactHierarchyKey]
       AND F2.[Description] like '%Fact.Type'  
      LEFT OUTER JOIN [target].FlexFactHierarchy F3
		ON P.[FlexFactHierarchyKey] = F3.[ParentFlexFactHierarchyKey]
       AND F3.[Description] like '%Fact.Description'
	 WHERE P.[Name] = 'Fact'

    INSERT INTO #DataDictionary
    SELECT 'FlexFacts' AS [DataSetType]
           ,REPLACE('v'+H.[Description],'.MetaData.Dimension.Name','') AS [Data Set]
           ,'Dimension' AS [Fact/Dimension]
           ,D.[OriginalTable]
           ,D.[Table]
           ,D.[Field]
           ,D.[OriginalDataType]
           ,D.[DataType]
           ,D.[Description] 
      FROM [target].FlexFactHierarchy H
	  LEFT OUTER JOIN #DataDictionary D
		ON SUBSTRING(H.[Name], 1, LEN(H.[Name])-3) = D.OriginalTable
     WHERE D.DataSetType = 'Dimensions' 
	   AND H.[Description] LIKE '%Dimension.Name'
	   AND D.Field NOT LIKE '%Key'
	   AND D.Field NOT IN ('Start','Finish')

    SET @Message = 'DataDictionary has total of ' + CONVERT(VARCHAR(255), (SELECT COUNT(*) FROM  #DataDictionary)) + ' items'
    EXEC [core].p_LogInfo @ProcedureName, @Message


    DECLARE @Sql NVARCHAR (MAX)

	--Get the results with any extra filters
	if @Category = 'ALL'
        SET @Sql = 'select * '
    else if @Category = 'PREDEFINED'
		SET @Sql = 'select [Fact/Dimension],[Table],[Field],[DataType],[Description] '
	ELSE 
        SET @Sql = 'select [DataSetType],[Data Set],[Fact/Dimension],[Table],[Field],[DataType],[Description] '

    SET @Sql = @Sql + ' FROM  #DataDictionary ' + @WhereFilter + ' ORDER BY [Data Set], [Fact/Dimension] DESC'


    EXEC [core].p_LogInfo @ProcedureName, 'Final Sql:'
    EXEC [core].p_LogInfo @ProcedureName, @Sql

    EXEC sp_executesql @Sql

	DROP TABLE #DataDictionary


    EXEC [core].[p_LogInfo] @ProcedureName, 'Finished process. Success'

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END 


GO


