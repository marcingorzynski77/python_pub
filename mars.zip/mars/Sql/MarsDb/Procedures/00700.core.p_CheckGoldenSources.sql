IF OBJECT_ID ('core.p_CheckGoldenSources') IS NOT NULL
	DROP PROCEDURE core.p_CheckGoldenSources
GO

CREATE PROC [core].[p_CheckGoldenSources]

AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName	NVARCHAR(128),
		@Message		NVARCHAR(MAX),
		@SessionID		BIGINT,
		@SourceKey		BIGINT,
		@NowDate		DATETIME2;

	SELECT
		@ProcedureName	= OBJECT_NAME(@@PROCID),
		@Message		= 'Invoking ' + @ProcedureName,
		@NowDate		= GETUTCDATE();
		
	EXEC [core].p_LogInfo @ProcedureName, @Message
		
--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	SET @Message = 'Processing'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	SET ANSI_WARNINGS ON

	DECLARE @T NVARCHAR(128)
	DECLARE @SQL NVARCHAR(4000) = N''

	DECLARE T CURSOR FOR
		SELECT
			C.TABLE_NAME
		FROM
			INFORMATION_SCHEMA.TABLES T
			JOIN
			INFORMATION_SCHEMA.COLUMNS C
			ON
				T.TABLE_CATALOG = C.TABLE_CATALOG
				AND
				T.TABLE_SCHEMA = C.TABLE_SCHEMA
				AND
				T.TABLE_NAME = C.TABLE_NAME
				AND
				T.TABLE_TYPE = 'BASE TABLE'
		WHERE
			C.TABLE_SCHEMA = 'Target'
			AND
			C.COLUMN_NAME = 'SourceKey'
			AND
			NOT C.TABLE_NAME LIKE '%_Fact'
			AND
			NOT C.TABLE_NAME = 'Source'

	OPEN T
	FETCH NEXT FROM T INTO @T

	CREATE TABLE #G
	(
		 [Dimension]			[NVARCHAR] (128) NOT NULL
		,[Origin]				[NVARCHAR] (128) NOT NULL
		,[InterfaceName]		[NVARCHAR] (128) NOT NULL
	)


	WHILE @@FETCH_STATUS = 0
	BEGIN
	--	SELECT @SQL = @SQL + CASE WHEN @SQL = '' THEN '' ELSE '
	-- UNION
	--' END

		SELECT @SQL = 'INSERT INTO #G SELECT DISTINCT
			 ''' + @T + '''
			,S.Origin
			,S.InterfaceName
		FROM
			[target].[' + @T + '] D
			JOIN
			target.Source S
			ON
				S.SourceKey = D.SourceKey
	'

		EXEC sp_executesql @SQL

	--	SELECT @SQL = @SQL + 'SELECT DISTINCT ''''''' + @T + ''''','' Dimension, '''''''' + S.Origin + '''''''' Origin, ''--'''''' + S.InterfaceName + '''''''' Interface FROM [target].[' + @T + '] D JOIN target.Source S ON S.SourceKey = D.SourceKey'

		FETCH NEXT FROM T INTO @T
	END

	CLOSE T;
	DEALLOCATE T;

	--PRINT @SQL
	--EXEC sp_executesql @SQL

	SELECT DISTINCT
		 '''' + G1.Dimension + ''',' 	AS Dimension
		,'''' + G1.Origin + ''','		AS Origin
		,'''' + G1.InterfaceName + ''','	AS InterfaceName
		,ISNULL(G2.Precedence, 9999) 	AS Precedence
	FROM
		#G G1
		LEFT JOIN
		[core].[GoldenSource] G2
		on
			G2.Dimension = G1.Dimension
			and
			G2.Origin = G1.Origin
			and
			G2.InterfaceName = G1.InterfaceName
	WHERE
		G2.[CoreGoldenSourceKey] IS NULL
	ORDER BY
		 Dimension
		,Precedence
		,Origin
		,InterfaceName

	DROP TABLE #G

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN 0;

END

GO

