IF OBJECT_ID ('core.p_Control_Log') IS NOT NULL
	DROP PROCEDURE core.p_Control_Log
GO

CREATE PROC [core].[p_Control_Log]

AS

BEGIN
    SET NOCOUNT ON;

    DECLARE
	@ProcedureName		NVARCHAR(128),
	@ErrorNumber		INT,
	@ErrorSeverity		INT,
	@ErrorState		INT,
	@ErrorLine		INT,
	@ErrorMessage		VARCHAR(MAX),
	@ErrorProcedure		NVARCHAR(128),
	@Comment		VARCHAR(1000),
	@SessionID		BIGINT,
	@SourceKey		BIGINT,
	@NowDate		DATETIME2;

    SELECT
	@ProcedureName		= OBJECT_NAME(@@PROCID),
		@Comment	= 'Invoking ' + @ProcedureName,
  		@NowDate	= GETUTCDATE(),
  		@ErrorNumber	= 0

--#---------------------------------------- END OF STANDARD CONTROLLER HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--Start logging event
	EXEC [core].p_LogEvent @Comment = 'Processing', @SessionID = @SessionID, @procedureName = @procedureName

END TRY

--#------------------------------------------------ END OF CONTROLLER -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
    SELECT
	@ErrorNumber	= ERROR_NUMBER()    ,
	@ErrorSeverity	= ERROR_SEVERITY()  ,
	@ErrorState	= ERROR_STATE()     ,
	@ErrorMessage	= ERROR_MESSAGE()   ,
	@ErrorLine	= ERROR_LINE()	    ;

    --Log error
    EXEC [core].p_LogEvent @SessionID = @SessionID
				  ,@ErrorNumber = @ErrorNumber
				  ,@ProcedureName=@ProcedureName
				  ,@ProcID = @@ProcID
				  ,@ErrorProcedure = @ProcedureName
				  ,@ErrorSeverity = @ErrorSeverity
				  ,@ErrorState = @ErrorState
				  ,@ErrorMessage = @ErrorMessage
				  ,@NESTLEVEL = @@NESTLEVEL
				  ,@ErrorLine = @ErrorLine
				  ,@Comment = 'There has been an Error'
				  ,@messageTypeId = 3
				  ,@UpdateType = 'Error'

    RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT
END CATCH;

RETURN @ErrorNumber

END
GO

