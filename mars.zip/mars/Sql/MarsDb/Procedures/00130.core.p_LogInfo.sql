IF OBJECTPROPERTY(OBJECT_ID('core.p_LogInfo'), N'IsProcedure') = 1
	DROP PROCEDURE [core].[p_LogInfo]
GO

CREATE PROCEDURE [core].[p_LogInfo]
(	
	@ProcedureName NVARCHAR(128),	
	@Message NVARCHAR(MAX)
)
AS
BEGIN
	
	EXEC [core].[p_LogEvent] @ProcedureName, @Message, 'INFO'
	
END
GO 
