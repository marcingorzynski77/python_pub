IF OBJECT_ID ('target.p_UpdateVersionPath') IS NOT NULL
	DROP PROCEDURE target.p_UpdateVersionPath
GO

CREATE PROC [target].[p_UpdateVersionPath] 
(
	@HierarchyNode INT
)
AS 
BEGIN

	DECLARE @Start 				INT,
			@Space 				INT,
			@Mnemonic 			VARCHAR(20),
			@return_status		INT,
			@ProcedureName  	NVARCHAR(128),
			@Message   		    NVARCHAR(MAX),
			@InitialTranCount	BIGINT,
			@VersionPath		VARCHAR(1000);

	SET NOCOUNT ON

	--EXEC [core].p_LogEvent @SessionID = 0, @procedureName = 'p_Run_QueryFromCatalogue', @Comment = 'Invoking p_Run_QueryFromCatalogue', @NestLevel = 2

BEGIN TRY

	EXEC [core].p_LogInfo @ProcedureName, 'Start of processing'
--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--
;
	--Recursive loop to determine all parent nodes
	WITH NodesCTE AS
	( 
		--anchor select
		select  NodeName, NodeID, ParentNodeID 
		from core.QueryCatalogue_Hierarchy
		where NodeID = @HierarchyNode		
		UNION ALL
		--recursive select, recursive until you reach a leaf (a node which is not a parent of any other node)
		select  a.NodeName, a.NodeID, a.ParentNodeID 
		from core.QueryCatalogue_Hierarchy a
		INNER JOIN NodesCTE s ON a.NodeID = s.ParentNodeID 
	) 
	
	--Add row number and order in reverse 
	select ROW_NUMBER() OVER (ORDER BY (SELECT 100)) AS SNO ,* into #Data from NodesCTE order by SNO desc;
	
	--Concatenate
	select @VersionPath = (Select N.nodename + '/'  
							From #Data N			
							For XML PATH (''))	

	drop table #Data
	
	update core.QueryCatalogue set versionpath  = @versionpath where HierarchyNode = @HierarchyNode
	
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'
	

END TRY


BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
