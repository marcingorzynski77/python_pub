IF OBJECT_ID ('target.p_FactVersion') IS NOT NULL
	DROP PROCEDURE target.p_FactVersion
GO

CREATE PROCEDURE [target].[p_FactVersion]
	( 
	@BUSDATE AS DATE,	-- The business date for which the lates version number is required. Note Time Traveling applies
	@VERSION AS INT OUTPUT)
AS 
BEGIN
	DECLARE @Facts table(ID varchar(50))
	DECLARE @i bigint
	DECLARE @FactTableName nvarchar(50)
	DECLARE @nSQL nvarchar(MAX)
	
	INSERT @Facts EXECUTE [target].[p_FactNames]
	SET @I = 1
	SET @nSQL = 'SELECT MAX(Y.Versions) FROM ( '
	SET @nSQL = @nSQL + 'SELECT RANK() OVER (ORDER BY X.START ASC) Versions FROM ( '
	IF @BUSDATE IS NULL SET @BUSDATE = (SELECT BUSDATE FROM TimeTravel)
	WHILE @I<= (SELECT COUNT(*) FROM @Facts)
	BEGIN
		SET @FactTableName = (SELECT X.ID + '_Fact' FROM (SELECT ID, RANK() OVER (ORDER BY ID) POS FROM @Facts) X WHERE X.POS = @I)
		SET @nSQL = @nSQL + 'SELECT DISTINCT F.START FROM [target].[' + @FactTableName + '] F '
		SET @nSQL = @nSQL + 'JOIN TimeTravel T 
									ON F.START <= T.VersionDateTime 
									WHERE F.BUSDATE = ' + QUOTENAME(@BUSDATE,'''')
		IF @I<> (SELECT COUNT(*) FROM @Facts) SET @nSQL = @nSQL + ' UNION '
		SET @I=@I+1
	END	
	SET @nSQL = @nSQL + ') X ) Y'
	--PRINT @nSQL
	EXECUTE(@nSQL)

   RETURN @VERSION

END
GO
