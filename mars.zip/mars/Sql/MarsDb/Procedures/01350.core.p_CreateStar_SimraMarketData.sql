IF OBJECT_ID ('core.p_CreateStar_SimraMarketData') IS NOT NULL
	DROP PROCEDURE core.p_CreateStar_SimraMarketData
GO

CREATE PROC [core].[p_CreateStar_SimraMarketData]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
	@SessionID	INT			= 0
)
AS

BEGIN
    SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@InitialTranCount	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@RejectedCount		BIGINT,
		@UTCDate			DATETIME2;

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message 
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	--First empty the star ready for new data
	TRUNCATE TABLE [core].SimraMarketData_Source
	TRUNCATE TABLE [core].SimraMarketData_RiskFactorType
	TRUNCATE TABLE [core].SimraMarketData_RiskFactor
	TRUNCATE TABLE [core].SimraMarketData_Tenor
	TRUNCATE TABLE [core].SimraMarketData_Fact

--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraMarketData_Source'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraMarketData_RiskFactorType'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraMarketData_RiskFactor'
--	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraMarketData_Tenor'
	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'SimraMarketData_Fact'

	--#--------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT into [core].SimraMarketData_Source (
		 [InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	)
	SELECT DISTINCT
		 @Datafeed
		,@Env
		,'SIMRA'
		,[Data Source]
	FROM
		[raw].SimraMarketData

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraMarketData_Source dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the RiskFactorType Dimension ----------------------------------------#--

	--RiskFactorType Dimension

	INSERT INTO [core].SimraMarketData_RiskFactorType (
		 [CoreSourceKey]
		,[RiskFactorTypeName]
	)
	SELECT DISTINCT
		 S.[CoreSourceKey]
		,R.[Market Data Type]
	FROM
		[raw].SimraMarketData R
		JOIN
		[core].SimraMarketData_Source S
		ON
			R.[Data Source] = S.[Origin]
	WHERE
		 R.[Exception Type] = 'Valid'

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraMarketData_RiskFactorType dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the RiskFactor Dimension ----------------------------------------#--

	--RiskFactor Dimension

	INSERT INTO [core].SimraMarketData_RiskFactor (
		 [CoreSourceKey]
		,[RiskFactorName]
	)
	SELECT DISTINCT
		 S.[CoreSourceKey]
		,LEFT(R.[Market Data], len(R.[Market Data]) - charindex(' ', reverse(R.[Market Data]), charindex(' ', reverse(R.[Market Data]))+1)) AS [RiskFactorName]
	FROM
		[raw].SimraMarketData R
		JOIN
		[core].SimraMarketData_Source S
		ON
			R.[Data Source] = S.[Origin]
	WHERE
		 R.[Exception Type] = 'Valid'

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(10)) + ' rows into [core].SimraMarketData_RiskFactor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message


	--#------------------------------------------ Populate the Tenor Dimension ----------------------------------------#--

	--Tenor Dimension

	INSERT INTO [core].SimraMarketData_Tenor (
		 [CoreSourceKey]
		,[TenorName]
	)
	SELECT DISTINCT
		 S.[CoreSourceKey]
		,R.[TenorName]
	FROM
		(
			select distinct
				  M.[Instrument Tenor] as TenorName
				 ,M.[Data Source]
			from
				 [raw].SimraMarketData M
			where
				 M.[Instrument Tenor] is not null
				 and
		 		 M.[Exception Type] = 'Valid'


			union

			select distinct
				  M.[Underlying Tenor]
				 ,M.[Data Source]
			from
				 [raw].SimraMarketData M
			where
				 M.[Underlying Tenor] is not null
				 and
		 		 M.[Exception Type] = 'Valid'

			union

			select distinct
				  M.[Fixing Tenor]
				 ,M.[Data Source]
			from
				 [raw].SimraMarketData M
			where
				 M.[Fixing Tenor] is not null
				 and
		 		 M.[Exception Type] = 'Valid'
		) R
		JOIN
		[core].SimraMarketData_Source S
		ON
			R.[Data Source] = S.[Origin]

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].SimraMarketData_Tenor dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#----------------------------------------------- Populate the SimraRiskMeasureValue Fact ---------------------------------------------#--

	-- Risk Measure Values
	INSERT INTO [core].[SimraMarketData_Fact] (
		 [BusDate]
		,[CoreSourceKey]
		,[CoreRiskFactorTypeKey]
		,[CoreRiskFactorKey]
		,[CoreInstrumentTenorKey]
		,[CoreUnderlyingTenorKey]
		,[CoreFixingTenorKey]
		,[Index]
		,[Curve]
		,[Currency1]
		,[Currency2]
		,[Value]
	)
	SELECT
		 R.[Business Date]
		,S.[CoreSourceKey]
		,RFT.[CoreRiskFactorTypeKey]
		,RF.[CoreRiskFactorKey]
		,IT.[CoreTenorKey]
		,UT.[CoreTenorKey]
		,FT.[CoreTenorKey]
		,R.[Index]
		,R.[Curve Identifier]
		,R.[Currency 1]
		,R.[Currency 2]
		,R.[Market Data Value]
	FROM
		[raw].SimraMarketData R
		LEFT JOIN
		[core].SimraMarketData_Source S
		on
			R.[Data Source] = S.[Origin]
		LEFT JOIN
		[core].SimraMarketData_RiskFactorType RFT
		ON
			R.[Market Data Type] = RFT.[RiskFactorTypeName]
			AND
			S.[CoreSourceKey] = RFT.[CoreSourceKey]
		LEFT JOIN
		[core].SimraMarketData_RiskFactor RF
		ON
			LEFT(R.[Market Data], len(R.[Market Data]) - charindex(' ', reverse(R.[Market Data]), charindex(' ', reverse(R.[Market Data]))+1)) = RF.[RiskFactorName]
			AND
			S.[CoreSourceKey] = RF.[CoreSourceKey]
		LEFT JOIN
		[core].SimraMarketData_Tenor IT
		ON
			R.[Instrument Tenor] = IT.TenorName
			AND
			S.[CoreSourceKey] = IT.[CoreSourceKey]
		LEFT JOIN
		[core].SimraMarketData_Tenor UT
		ON
			R.[Underlying Tenor] = UT.TenorName
			AND
			S.[CoreSourceKey] = UT.[CoreSourceKey]
		LEFT JOIN
		[core].SimraMarketData_Tenor FT
		ON
			R.[Fixing Tenor] = FT.TenorName
			AND
			S.[CoreSourceKey] = FT.[CoreSourceKey]
	WHERE
		 R.[Exception Type] = 'Valid'

	SET @InsertedCount = @@ROWCOUNT

	--Log affected rows
	SET @Message = 'Split out '+ CAST((@InsertedCount)AS VARCHAR(30)) + ' rows into core.SimraMarketData_Fact fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message 

	
END TRY

--#---------------------------------------------- END OF STAR CODE -----------------------------------------------#--
--#===============================================================================================================#--

BEGIN CATCH

   DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO