IF OBJECT_ID ('core.p_Core2Target') IS NOT NULL
	DROP PROCEDURE core.p_Core2Target
GO

CREATE PROCEDURE [core].[p_Core2Target] 
(
	@SourceTable VARCHAR(50), 
	@SourceKeyColumn VARCHAR(50),
	@SourceBusinessKeyColumnsPARAM Core2TargetParameter READONLY,
	@SourceIgnoreColumnsPARAM Core2TargetParameter READONLY,
	@SourceRefDateTime DATETIME2(7),
	@TargetTable VARCHAR(50),
	@TargetKeyColumn VARCHAR(50),
	@TargetBusinessKeyColumnsPARAM Core2TargetParameter READONLY,
	@TargetIgnoreColumnsPARAM Core2TargetParameter READONLY,
	@TargetRefDateTime DATETIME2(7),
	@ExpireDimensionData BINARY = 0,
	@ReStatement BINARY = 0,
	@SessionID INT = 0
)
AS 

BEGIN

    SET NOCOUNT ON;

    DECLARE
	@return_status		int,
	@ProcedureName		NVARCHAR(128),
	@ErrorNumber		INT,
	@ErrorSeverity		INT,
	@ErrorState		INT,
	@ErrorLine		INT,
	@ErrorMessage		VARCHAR(MAX),
	@ErrorProcedure		NVARCHAR(128),
-- 	@InitialTranCount	INT, NOT required as we'll only need transactions within C2T
	@BusinessLogicSev	INT,
	@Comment		VARCHAR(1000),
	@SQL			varchar(1000),
	@ID			int;

  	DECLARE @MyTran bit = CASE WHEN @@trancount = 0 THEN 0 ELSE 1 END
	DECLARE @MyTranID varchar(32) = replace(convert(char(36), newid()), '-','')
 
    SELECT
	@ProcedureName      = OBJECT_NAME(@@PROCID),
	@ErrorNumber        = 50000;  -- ok we are in an error for transaction purposes (ie post roll back)        
--	@InitialTranCount   = @@TRANCOUNT;
                
  	SET @Message = 'Invoking ' + @ProcedureName  	
	exec [core].p_LogEvent @SessionID = @SessionID,  @Procid = @@ProcID, @ProcedureName =@ProcedureName, @Comment = @Comment, @NestLevel = @@NESTLEVEL
	set @SessionID = @@IDENTITY

--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @return_value				INT


	EXEC	@return_value = [core].[p_Staging2Target]
			@StagingTable = @SourceTable,
			@StagingKeyColumn = @SourceKeyColumn,
			@StagingBusinessKeyColumnsPARAM = @SourceBusinessKeyColumnsPARAM,
			@StagingIgnoreColumnsPARAM = @SourceIgnoreColumnsPARAM,
			@StagingRefDateTime = @SourceRefDateTime,
			@TargetTable = @TargetTable,
			@TargetKeyColumn = @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM = @TargetBusinessKeyColumnsPARAM,
			@TargetIgnoreColumnsPARAM = @TargetIgnoreColumnsPARAM,
			@TargetRefDateTime = @TargetRefDateTime,
			@ExpireDimensionData = @ExpireDimensionData,
			@ReStatement = 0,
			@SessionID = @SessionID	


	RETURN @return_value
	
END TRY

--#------------------------------------------------- END OF PROCEDURE -------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
	
   	SELECT 
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,        
	@ErrorProcedure = isnull(ERROR_PROCEDURE(),'err') ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
        @ErrorLine	= ERROR_LINE();
    
        IF @@TRANCOUNT > 0 
		BEGIN
			-- The transaction uncommittable transaction.

			-- print @ProcedureName + ' - Rollback Transaction .'
			ROLLBACK TRANSACTION @MyTranID;
			
			SET @Message = 'Rollback Transaction after encountering - ' + @ErrorMessage + ' ' + @ProcedureName  	
			EXEC [core].p_LogEvent @SessionID = @SessionID,  @Procid = @@ProcID, @ProcedureName =@ProcedureName, @Comment = @Comment, @NestLevel = @@NESTLEVEL
			PRINT @Comment

		END
		--ELSE
		--	print @ProcedureName + ' - There has been an Error. outside of the transaction.'
		
        EXEC [core].p_LogEvent @SessionID = @SessionID
					  ,@ErrorNumber = @ErrorNumber
					  ,@ProcedureName=@ProcedureName
					  ,@ProcID = @@ProcID
					  ,@ErrorProcedure = @ProcedureName
					  ,@ErrorSeverity = @ErrorSeverity
					  ,@ErrorState = @ErrorState
					  ,@ErrorMessage = @ErrorMessage
					  ,@NESTLEVEL = @@NESTLEVEL
					  ,@ErrorLine = @ErrorLine
					  ,@Comment = @Comment

	

		RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

-- RETURN @ErrorNumber
RETURN 0

END
GO

