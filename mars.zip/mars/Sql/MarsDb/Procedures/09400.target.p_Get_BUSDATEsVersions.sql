IF OBJECT_ID ('target.p_Get_BUSDATEsVersions') IS NOT NULL
	DROP PROCEDURE target.p_Get_BUSDATEsVersions
GO

CREATE PROC [target].[p_Get_BUSDATEsVersions] 
(
	@BusDate varchar(10)
)
AS 

BEGIN

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--

	SET NOCOUNT ON
	
	declare 		@Table varchar(50),
					@ID int;

	create table #Versions(
		FactTable varchar(30)
		,StartDateTime datetime2
	)
	
	--Get temp table of relevant active rules
	select REPLACE(t.[Name], '_Fact'	,'') as 'Table'
			, '' as 'status'
	into #Queries
	from sys.tables t
	join sys.schemas S on t.schema_id = S.schema_id
	where s.name = 'target'	
		and t.name like '%_Fact'
		and t.name <> 'Monitor_Fact'
		and t.name <> 'Limit_fact'
		and t.name <> 'FlexFact'

	--Loop through the temp table executing each query in turn
	WHILE (SELECT COUNT(1) from #Queries where [Status] = '') > 0
	BEGIN
		
		select  top 1 
				@Table = [Table]
		from #Queries 
		where [Status] = ''	

		exec ('insert into #Versions(FactTable,StartDateTime) select ''' + @table + ''', Start from (select distinct Start from target.' + @Table + '_Fact where BusDate = ''' + @BusDate + ''') A')
		
		update #Queries set [status] = '1' where [Table] = @Table
		
	END
	
	
	select * from #Versions order by StartDateTime asc
	drop table #Versions
		 
	RETURN

--#-------------------------------------------------- END OF HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

END

GO
