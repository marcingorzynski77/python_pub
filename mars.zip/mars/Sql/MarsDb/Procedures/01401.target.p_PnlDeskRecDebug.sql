IF OBJECT_ID ('target.p_PnlDeskRecDebug') IS NOT NULL
	DROP PROC target.p_PnlDeskRecDebug
GO

--exec [target].[p_PnlDeskRecDebug] 0.01, '2017-DEC-22','2017-DEC-28', 'SimraVaR1DPnLs', 'PROD', 'SSF00004831','2017-12-27 13:41:58.3400000', 7, 'FX Operational Losses', 1, 'LTSB'

CREATE PROC [target].[p_PnlDeskRecDebug]
(
	@ToleranceLevelInPercentage float = 1.00,
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(30),
	@Env		VARCHAR(6),
	@ExternalReference  VARCHAR(50),
	@Start datetime2,
	@SourceKey int,
	@Desk VARCHAR(250),
	@Cad2 bit,
	@LegalEntity VARCHAR(250)
)

AS 
BEGIN

DECLARE @Msg varchar(8000) 
DECLARE @ValueGBP float
DECLARE @Records int
DECLARE @HierarchyKey int

SELECT @ValueGBP = SUM(ValueGBP), @Records = COUNT(*), @HierarchyKey = HierarchyKey
FROM
(
SELECT				  ISNULL(target.PnL_Fact.BusDate, ' ') AS BusDate,
					  ISNULL(target.PnL_Fact.AnalysisTypeName, ' ') AS AnalysisTypeName, 
                      ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS LegalEntity,
                      ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS Cad2,
                      ISNULL(target.PnL_Fact.[Value], 0) AS [Value],
                      ISNULL(target.PnL_Fact.[ValueGBP], 0) AS [ValueGBP],
                      ISNULL(target.vHierarchyConsolidated.NodeId, ' ') AS NodeID, 
                      ISNULL(target.vHierarchyConsolidated.NodeName, ' ') AS NodeName,
                      ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS BookLegalEntity,
                      ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS BookCAD2,
                      ISNULL(target.vHierarchyConsolidated.BusinessArea, ' ') AS BusinessArea,
                      ISNULL(target.vHierarchyConsolidated.Business, ' ') AS Business,
                      ISNULL(target.vHierarchyConsolidated.Division, ' ') AS Division, 
                      ISNULL(target.vHierarchyConsolidated.Desk, ' ') AS Desk, 
                      ISNULL(target.vHierarchyConsolidated.SubDesk, ' ') AS SubDesk,
                      ISNULL(target.vHierarchyConsolidated.Book, ' ') AS Book,
                      ISNULL(target.vHierarchyConsolidated.BookSystem, ' ') AS BookSystem,
                      ISNULL(target.PnL_Fact.SourceKey, ' ') AS SourceKey,
                      ISNULL(target.PnL_Fact.HierarchyKey, ' ') AS HierarchyKey
FROM         target.PnL_Fact 
                      INNER JOIN
                      target.vHierarchyConsolidated ON target.PnL_Fact.HierarchyKey = target.vHierarchyConsolidated.HierarchyKey 
                      WHERE target.vHierarchyConsolidated.NodeType = 'BO'  --and [target].[f_IsBookInReportingDesk](target.vHierarchyConsolidated.HierarchyString) = 1
                      --AND target.PnL_Fact.Start <= @Start and target.PnL_Fact.Finish > @Start and target.PnL_Fact.BusDate = @BusDate
					  --AND target.vHierarchyConsolidated.Start <= @Start and target.vHierarchyConsolidated.Finish > @Start
					  AND target.vHierarchyConsolidated.Start <= target.PnL_Fact.Start and target.vHierarchyConsolidated.Finish > target.PnL_Fact.Start and target.PnL_Fact.BusDate = @BusDate
					  AND target.PnL_Fact.SourceKey = @SourceKey
					  AND (target.vHierarchyConsolidated.Desk = @Desk)
					  AND (target.vHierarchyConsolidated.BookCad2 = @Cad2 )
					  AND (target.vHierarchyConsolidated.BookLegalEntity = @LegalEntity)
                      )  AS REC 
GROUP BY LegalEntity, Desk, BookCAD2, BusinessArea, HierarchyKey


Set @Msg =  'Target Summary: HierarchyKey=' + cast(@HierarchyKey as varchar(50)) + ', Desk=' + @Desk + ', @BookCad2=' + cast(@Cad2 as varchar(50))  + ', BookLegalEntity='+@LegalEntity + ', ValueGBP='+cast(@ValueGBP as varchar(100)) + ' TargetCount=' + cast(@Records as varchar(50)) 
Print @Msg

select @ValueGBP =sum([sum Value GBP]),  @Records = COUNT(*) from raw.SimraPnLs where BusinessHierarchyPath like '%'+@Desk+'%' and Cad2 = @Cad2 and LegalEntity = @LegalEntity

Set @Msg =  'Raw Summary:' +' Desk=' + @Desk + ', @BookCad2=' + cast(@Cad2 as varchar(50))  + ', BookLegalEntity='+@LegalEntity + ', ValueGBP='+cast(@ValueGBP as varchar(100)) + ' TargetCount=' + cast(@Records as varchar(50)) 
Print @Msg


SELECT @ValueGBP = SUM(RiskValue) FROM
(
	SELECT
	 [ReportDate]    
	,[BusinessEntity]
	,[BusinessEntitySource]
	,[BusinessEntityType]
	,[DataType]
	,[RiskType]
	,Cast([RiskValue] as float) AS [RiskValue]
	,[1] [NodeName]
	,[3] [Cad2]
	,[4] [LegalEntity] 
	 FROM [raw].[SimraRiskPnL_Reconciliation] R CROSS APPLY target.f_split(R.BusinessEntity,'_')
	PIVOT
	(
	 MAX(Item) FOR Position IN ([1],[2],[3],[4])
	  
	) as P  WHERE DataType like @ExternalReference and cast(ReportDate as datetime2) = @BusDate
) AS REC
GROUP BY NodeName, Cad2, LegalEntity, BusinessEntityType
HAVING BusinessEntityType in ('Desk') and LegalEntity = @LegalEntity and Cad2 = @Cad2 and NodeName like @Desk

Set @Msg =  'Bridge Summary:' +' Desk=' + @Desk + ', @BookCad2=' + cast(@Cad2 as varchar(50))  + ', BookLegalEntity='+@LegalEntity + ', ValueGBP='+cast(@ValueGBP as varchar(100))
Print @Msg


SELECT				  
					  ISNULL(target.PnL_Fact.HierarchyKey, ' ') AS HierarchyKey,
                      ISNULL(target.PnL_Fact.Start, ' ') AS Start,
                      ISNULL(target.PnL_Fact.Finish, ' ') AS Finish,
					  ISNULL(target.PnL_Fact.BusDate, ' ') AS BusDate,
					  ISNULL(target.PnL_Fact.AnalysisTypeName, ' ') AS AnalysisTypeName, 
                      ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS LegalEntity,
                      ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS Cad2,
                      ISNULL(target.PnL_Fact.[Value], 0) AS [Value],
                      ISNULL(target.PnL_Fact.[ValueGBP], 0) AS [ValueGBP],
                      ISNULL(target.vHierarchyConsolidated.NodeId, ' ') AS NodeID, 
                      ISNULL(target.vHierarchyConsolidated.NodeName, ' ') AS NodeName,
                      ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS BookLegalEntity,
                      ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS BookCAD2,
                      ISNULL(target.vHierarchyConsolidated.BusinessArea, ' ') AS BusinessArea,
                      ISNULL(target.vHierarchyConsolidated.Business, ' ') AS Business,
                      ISNULL(target.vHierarchyConsolidated.Division, ' ') AS Division, 
                      ISNULL(target.vHierarchyConsolidated.Desk, ' ') AS Desk, 
                      ISNULL(target.vHierarchyConsolidated.SubDesk, ' ') AS SubDesk,
                      ISNULL(target.vHierarchyConsolidated.Book, ' ') AS Book,
                      ISNULL(target.vHierarchyConsolidated.BookSystem, ' ') AS BookSystem,
                      ISNULL(target.PnL_Fact.SourceKey, ' ') AS SourceKey
                     
FROM         target.PnL_Fact 
                      INNER JOIN
                      target.vHierarchyConsolidated ON target.PnL_Fact.HierarchyKey = target.vHierarchyConsolidated.HierarchyKey 
                      WHERE target.vHierarchyConsolidated.NodeType = 'BO'  --and [target].[f_IsBookInReportingDesk](target.vHierarchyConsolidated.HierarchyString) = 1
                      --AND target.PnL_Fact.Start <= @Start and target.PnL_Fact.Finish > @Start and target.PnL_Fact.BusDate = @BusDate
					  --AND target.vHierarchyConsolidated.Start <= @Start and target.vHierarchyConsolidated.Finish > @Start
					  AND target.vHierarchyConsolidated.Start <= target.PnL_Fact.Start and target.vHierarchyConsolidated.Finish > target.PnL_Fact.Start and target.PnL_Fact.BusDate = @BusDate
					  AND target.PnL_Fact.SourceKey = @SourceKey
					  AND target.vHierarchyConsolidated.Desk = @Desk
					  AND target.vHierarchyConsolidated.BookCad2 = @Cad2 
					  AND target.vHierarchyConsolidated.BookLegalEntity = @LegalEntity

END

GO
