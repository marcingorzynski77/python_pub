IF OBJECT_ID ('core.p_UpdateFact_QueryTracker') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_QueryTracker
GO

CREATE PROC [core].[p_UpdateFact_QueryTracker]
(
	@CRCID varchar(6),
	@FilePath varchar(200),
	@FileName varchar(100),
	@QueryID int
)
AS

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
    SET NOCOUNT ON;
    DECLARE
	    @ProcedureName      NVARCHAR(128),
	    @Message       NVARCHAR(MAX)
	

     SELECT
	    @ProcedureName      = OBJECT_NAME(@@PROCID)
	

--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--#------------------------------------------ 'Insert/Update Target Table' ----------------------------------------#--


	if (select COUNT(1) from core.QueryTracker where CRCID = @CRCID) > 0
	begin
		--Update any entries where the CRCID already exists
		update
			Q
		set
			 [counter] = [Counter] + 1
			,LastRan = GETUTCDATE()
			,UserName  = SUSER_NAME()
		from
			core.QueryTracker Q
		where
			CRCID = @CRCID
			and
			QueryID  = @QueryID

	end
	else
	begin
		--Insert any entries where the CRCID doesn't exist
		insert into core.QueryTracker (
			 CRCID
			,FilePath
			,[FileName]
			,QueryID
			,[Counter]
			,UserName
			,LastRan
		)
		select
			 @CRCID
			,@FilePath
			,@FileName
			,@QueryID
			,1
			,SUSER_NAME()
			,GETUTCDATE()
	end


END TRY


--#--------------------------------------------------- END OF UPDATE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH
 
    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
