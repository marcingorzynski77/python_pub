IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_TrendDates]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [target].[p_Get_TrendDates]
GO


CREATE PROC [target].[p_Get_TrendDates]
(
	@Busdate aS DATETIME2(7)
	,@TimePeriod as char(1) 
	,@LookBack as int
)
AS
BEGIN

SET NOCOUNT ON

	declare @multiplier as int
	
	if @LookBack > 0 set @multiplier = 1
	if @LookBack < 0 set @multiplier = -1
	

	if @TimePeriod = 'D'
	begin
	
		select 
			(Case when busdate IS null then 0 else 1 end) as Available
			,cast((@multiplier *  ROW_NUMBER()over(order by [date] desc)+1) as varchar(4)) + @TimePeriod as [rowcount]	
			,cast([date] as varchar(10)) as [Date]
			,cast(PreviousWorkingDate as varchar(10)) as PreviousWorkingDate
			,cast(NextWorkingDate as varchar(10)) as NextWorkingDate
		from
		(		
			select distinct busdate
				,C.[Date]
				,c.PreviousWorkingDate
				,c.NextWorkingDate
			FROM target.Calendar C
			left join target.TimeTravellingInstance F ON F.BusDate = C.[Date]
			WHERE c.[Date] <= @Busdate
				and c.[date]> target.f_CalendarOffset(cast(@LookBack as varchar(4)) + @TimePeriod,@Busdate)
				and WorkingDay = 'Y'
		)A
		group by busdate,[date],PreviousWorkingDate,NextWorkingDate
		order by [Date] desc
		
	end
	else if @TimePeriod = 'W'
	begin	
	
		declare @weekday as char(2)
		set @weekday = (select weekday from target.Calendar where DATE = @busdate)
							
		select 
			(Case when busdate IS null then 0 else 1 end) as Available
			,cast((@multiplier *  ROW_NUMBER()over(order by [date] desc)+1) as varchar(4)) + @TimePeriod as [rowcount]	
			,cast([date] as varchar(10)) as [Date]
			,cast(PreviousWorkingDate as varchar(10)) as PreviousWorkingDate
			,cast(NextWorkingDate as varchar(10)) as NextWorkingDate
		from
		(		
			select busdate
				,(case when c.WorkingDay = 'Y' then c.[Date] else c.NextWorkingDate end) as [date]
				,c.PreviousWorkingDate
				,c.NextWorkingDate
			FROM target.Calendar C
			left join target.TimeTravellingInstance F ON F.BusDate = C.[Date]
			WHERE c.[Date] <= @busdate				
				and c.[date]>= target.f_CalendarOffset(cast(@LookBack as varchar(3)) + 'W',@busdate)	
				and c.[WeekDay] = @weekday		
				--and c.[Day] = CAST(SUBSTRING(cast('20170202' as varchar(10)),9,2)AS INT)
		)A
		group by busdate,[date],PreviousWorkingDate,NextWorkingDate
		order by [Date] desc
	end
	else if @TimePeriod = 'M'
	begin
		
		select 
			(Case when busdate IS null then 0 else 1 end) as Available
			,cast((@multiplier *  ROW_NUMBER()over(order by [date] desc)+1) as varchar(4)) + @TimePeriod as [rowcount]	
			,cast([date] as varchar(10)) as [Date]
			,cast(PreviousWorkingDate as varchar(10)) as PreviousWorkingDate
			,cast(NextWorkingDate as varchar(10)) as NextWorkingDate
		from
		(			
			select busdate
				,(case when c.WorkingDay = 'Y' then c.[Date] else c.NextWorkingDate end) as [date]
				,c.PreviousWorkingDate
				,c.NextWorkingDate
			FROM target.Calendar C
			left join target.TimeTravellingInstance F ON F.BusDate = C.[Date]
			WHERE c.[Date] < @Busdate
				and c.[date]>= target.f_CalendarOffset(cast(@LookBack as varchar(3)) + 'M',@Busdate)			
				and c.[Day] = CAST(SUBSTRING(cast(@busdate as varchar(10)),9,2)AS INT)
		)A
		group by busdate,[date],PreviousWorkingDate,NextWorkingDate
		order by [Date] desc

	end
	else if @TimePeriod = 'Q'
	begin
		
		DECLARE @MONTH1 AS INT
		DECLARE @MONTH2 AS INT
		DECLARE @MONTH3 AS INT
		DECLARE @MONTH4 AS INT
		
		SET @MONTH1 = CAST(SUBSTRING(cast(@busdate as varchar(10)),6,2) AS INT)
		SET @MONTH2 = CAST(SUBSTRING(cast(target.f_CalendarOffset('-3M',@busdate)as varchar(10)),6,2) AS INT)
		SET @MONTH3 = CAST(SUBSTRING(cast(target.f_CalendarOffset('-6M',@busdate)as varchar(10)),6,2) AS INT)
		SET @MONTH4 = CAST(SUBSTRING(cast(target.f_CalendarOffset('-9M',@busdate)as varchar(10)),6,2) AS INT)
		
		select 
			(Case when busdate IS null then 0 else 1 end) as Available
			,cast((@multiplier *  ROW_NUMBER()over(order by [date] desc)+1) as varchar(4)) + @TimePeriod as [rowcount]	
			,cast([date] as varchar(10)) as [Date]
			,cast(PreviousWorkingDate as varchar(10)) as PreviousWorkingDate
			,cast(NextWorkingDate as varchar(10)) as NextWorkingDate
		from
		(			
			select busdate
				,(case when c.WorkingDay = 'Y' then c.[Date] else c.nextWorkingDate end) as [date]
				,c.PreviousWorkingDate
				,c.NextWorkingDate
			FROM target.Calendar C
			left join target.TimeTravellingInstance F ON F.BusDate = C.[Date]
			WHERE c.[Date] < @busdate
				and c.[date]>= target.f_CalendarOffset(cast(@LookBack as varchar(3)) + 'Q',@busdate)			
				and c.[Day] = 1 --CAST(SUBSTRING(cast(@busdate as varchar(10)),9,2)AS INT)
				and c.[Month] IN (1,3,6,9)--(@MONTH1, @MONTH2, @MONTH3, @MONTH4)
		)A
		group by busdate,[date],PreviousWorkingDate,NextWorkingDate
		order by [Date] desc
		
	end
	else if @TimePeriod = 'Y'
	begin
		
		select 
			(Case when busdate IS null then 0 else 1 end) as Available
			,cast(@multiplier * ROW_NUMBER()over(order by [date] desc) as varchar(4)) + 'Y'  as [rowcount]	
			,cast([date] as varchar(10)) as [Date]
			,cast(PreviousWorkingDate as varchar(10)) as PreviousWorkingDate
			,cast(NextWorkingDate as varchar(10)) as NextWorkingDate
		from
		(			
			select busdate
				,(case when c.WorkingDay = 'Y' then c.[Date] else c.PreviousWorkingDate end) as [date]
				,c.PreviousWorkingDate
				,c.NextWorkingDate
			FROM target.Calendar C
			left join target.TimeTravellingInstance F ON F.BusDate = C.[Date]
			WHERE c.[Date] < @busdate
				and c.[date]>= target.f_CalendarOffset(cast(@LookBack as varchar(3)) + 'Y',@busdate)			
				and c.[Day] = CAST(SUBSTRING(cast(@busdate as varchar(10)),9,2)AS INT)
				and c.[Month] = CAST(SUBSTRING(cast(@busdate as varchar(10)),6,2) AS INT)
		)A
		group by busdate,[date],PreviousWorkingDate,NextWorkingDate
		order by [Date] desc
	
	end
End
GO
