IF OBJECT_ID ('core.p_UpdateFact_PnLShift') IS NOT NULL
	DROP PROCEDURE core.p_UpdateFact_PnLShift
GO

CREATE PROC [core].[p_UpdateFact_PnLShift]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(30),
	@Env		VARCHAR(6),
	@SessionID	BIGINT		= 0
)
AS

BEGIN

    SET NOCOUNT ON;

    DECLARE
	@return_status			INT,
        @ProcedureName			NVARCHAR(128),
        @ErrorNumber			INT,
        @ErrorSeverity			INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage			VARCHAR(MAX),
        @ErrorProcedure			NVARCHAR(128),
        @BusinessLogicSev		INT,
        @Comment			VARCHAR(1000),
        @MaxRow				BIGINT,
        @EndDate			DATETIME2,
	@AffectedRowsCount		BIGINT,
	@return_value			BIGINT,
	@SourceTable			VARCHAR(50) ,
	@SourceKeyColumn		VARCHAR(50),
	@SourceBusinessKeyColumns	CORE.Core2TargetParameter,
	@SourceIgnoreColumns		CORE.Core2TargetParameter,
	@SourceRefDateTime		DATETIME2(7),
	@TargetTable			VARCHAR(50),
	@TargetKeyColumn		VARCHAR(50),
	@TargetBusinessKeyColumns	CORE.Core2TargetParameter,
	@TargetIgnoreColumns		CORE.Core2TargetParameter,
	@TargetRefDateTime		DATETIME2(7),
	@ReStatement			BINARY = 0,
	@ExpireDimensionData		BINARY;


    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),
        @ErrorNumber	= 0,
        @EndDate	= CAST('9999-12-31' as DATETIME2),
	@Comment	= 'Invoking ' + @ProcedureName;


	--Start logging
	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD CONFORMING HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	IF @DataFeed in ('SimraPnL_Stressed',
			 'SimraPnL_VaR1D',
			 'SimraPnL_Var10D',
			 'SimraPnL_StressedVar1D_LBG',
			 'SimraPnL_StressedVaR10D_HBOS',
			 'SimraPnL_StressedVaR10D_LBG',
			 'SimraPnL_StressedVaR10D_LTSB')

	BEGIN

	--#------------------------------------------------- 'Update Target Table' ----------------------------------------------#--

		-- With the key for the Scenario from Target or the Hierarchy Staging table if it does not exist in Target
		update C
			set C.ScenarioKey = isnull(T.ScenarioKey,I.ScenarioKey)
		from
			core.SimraRiskPnL_PnLShift C
			LEFT join
			staging.Scenario I
			on
				I.CoreScenarioKey = C.CoreScenarioKey
			join
			core.SimraRiskPnL_Scenario S
			on
				S.coreScenarioKey = C.coreScenarioKey
			LEFT JOIN
			[target].Scenario T
			ON
				I.sGroup = T.SGroup
				AND
				I.Name = T.Name
				AND
				I.RiskType = T.RiskType
				AND
				(T.Start <= @NowDate and T.Finish > @NowDate)


		update C
			set C.HierarchyKey = isnull(T.HierarchyKey,I.HierarchyKey)
		from
			core.SimraRiskPnL_PnLShift C
			LEFT join
			staging.Hierarchy I
			on
				I.CoreHierarchyKey = C.CoreHierarchyKey
			join
			core.SimraRiskPnL_RiskNode S
			on
				S.CoreRiskNodeKey = C.coreHierarchyKey
			LEFT join
			[target].Hierarchy T
			on
				s.RiskNodeName = T.RiskNodeName
				AND
				s.RiskNodeType = t.RiskNodeType
				AND
				s.RiskNodeOrigin = t.RiskNodeOrigin
				AND
				(T.Start <= @NowDate and T.Finish > @NowDate)


		update C
			set C.SourceKey = isnull(T.SourceKey,I.SourceKey)
		from
			core.SimraRiskPnL_PnLShift C
			LEFT join
			staging.Source I
			on
				I.CoreSourceKey = C.CoreSourceKey
			join
			core.SimraRiskPnL_Source S
			on
				S.CoreSourceKey = C.coreSourceKey
			LEFT JOIN
			[target].[Source] T
			ON
				@DataFeed = T.InterfaceName
				AND
				isnull(S.[source],'UNKNOWN') = T.[Source]
				AND
				isnull(S.[Origin],'UNKNOWN') = T.origin
				AND
				(T.Start <= @NowDate and T.Finish > @NowDate)


		--Log Conformed count
		SET @Message = 'Foreign keys added to [core].[SimraRiskPnL_PnLShift] fact.'
		exec [core].p_LogEvent @SessionID = @SessionID, @Comment = @Comment, @ProcedureName = @ProcedureName, @NestLevel = @@NESTLEVEL

	END
	ELSE
	BEGIN
		RAISERROR( 'DataFeed Not recognised',11,-1, @ProcedureName)
	END


	--#------------------------------------------------ 'Update Staging Table' ----------------------------------------------#--

	delete from staging.PnlShift_Fact

	--Create a tempory table to include all the new/revised sceanarios and all the existing (except the scenarios about to be loaded/reloaded).
	insert into staging.PnlShift_Fact(
		corePnLShiftKey
		, busdate
		, ScenarioKey
		, SourceKey
		, HierarchyKey
		, ValuationPeriodStart
		, ValuationPeriodEnd
		, ValuationShift
		, Currency
		, AppliedRules
		, CoreScenarioKey
		, CoreSourceKey
		, CoreHierarchyKey)
	SELECT CurrentPicture.*
	FROM (
		SELECT C.corePnLShiftKey, C.busdate, C.ScenarioKey, C.SourceKey, C.HierarchyKey, C.ValuationPeriodStart,
				C.ValuationPeriodEnd, C.ValuationShift, C.Currency, C.AppliedRules,
				C.CoreScenarioKey, C.CoreSourceKey, C.CoreHierarchyKey
		FROM core.SimraRiskPnL_PnLShift C
	UNION
		SELECT T.FactKey, T.busdate, T.ScenarioKey, T.SourceKey, T.HierarchyKey, T.ValuationPeriodStart,
				T.ValuationPeriodEnd, T.ValuationShift, T.Currency, T.AppliedRules,
				Null ScenarioKey, Null SourceKey, Null HierarchyKey
		FROM target.pnlshift_fact T
		LEFT JOIN
			(SELECT DISTINCT Busdate, SourceKey, ScenarioKey FROM core.SimraRiskPnL_PnLShift) OTHER_PAYLOADS
		ON T.BUSDATE = OTHER_PAYLOADS.BUSDATE AND T.SourceKey= OTHER_PAYLOADS.SourceKey AND T.ScenarioKey= OTHER_PAYLOADS.ScenarioKey
		WHERE T.Start <= getutcdate() and T.Finish > getutcdate()
			AND T.BUSDATE = (SELECT distinct Busdate FROM core.SimraRiskPnL_PnLShift)
			AND OTHER_PAYLOADS.BusDate is null
			) CurrentPicture


	--Log Conformed count
	SET @Message = cast(@@ROWCOUNT as varchar(30)) + ' rows added to [staging].[PnlShift_Fact] fact.'
	exec [core].p_LogEvent @SessionID = @SessionID, @Comment = @Comment, @ProcedureName = @ProcedureName, @NestLevel = @@NESTLEVEL


	--#------------------------------------------------- 'Update Target Table' ----------------------------------------------#--

	--Source Parameters
	SET @SourceTable = 'staging.PnlShift_Fact'
	SET @SourceKeyColumn = 'CorePnLShiftKey'
	INSERT INTO @SourceBusinessKeyColumns VALUES ('ScenarioKey'),('HierarchyKey'),('SourceKey'),('ValuationPeriodStart'),('ValuationPeriodEnd')
	INSERT INTO @SourceIgnoreColumns VALUES (@SourceKeyColumn), ('CoreScenarioKey'),('CoreRiskNodeKey'),('CoreSourceKey')
	SET @SourceRefDateTime = GETUTCDATE()

	-- Target Parameters
	SET @TargetTable = '[target].[PnLShift_Fact]'
	SET @TargetKeyColumn = 'FactKey'
	INSERT INTO @TargetBusinessKeyColumns VALUES ('ScenarioKey'),('HierarchyKey'),('SourceKey'),('ValuationPeriodStart'),('ValuationPeriodEnd')
	INSERT INTO @TargetIgnoreColumns VALUES (@TargetKeyColumn),('SourceKey')
	SET @TargetRefDateTime = GETUTCDATE()
	SET @ExpireDimensionData = 1

	EXEC	@return_value = [core].[p_Core2Target]
			@SourceTable = @SourceTable,
			@SourceKeyColumn = @SourceKeyColumn,
			@SourceBusinessKeyColumnsPARAM = @SourceBusinessKeyColumns,
			@SourceIgnoreColumnsPARAM = @SourceIgnoreColumns,
			@SourceRefDateTime = @SourceRefDateTime,
			@TargetTable = @TargetTable,
			@TargetKeyColumn = @TargetKeyColumn,
			@TargetBusinessKeyColumnsPARAM = @TargetBusinessKeyColumns,
			@TargetIgnoreColumnsPARAM = @TargetIgnoreColumns,
			@TargetRefDateTime = @TargetRefDateTime,
			@ExpireDimensionData = @ExpireDimensionData,
			@ReStatement = 0,
			@SessionID = @SessionID

	--Log Conformed count
	SET @Message = cast(@return_value as varchar(30)) + ' PnLShift_Fact facts were inserted.'
	exec [core].p_LogEvent @SessionID = @SessionID, @Comment = @Comment, @ProcedureName = @ProcedureName, @NestLevel = @@NESTLEVEL

	--Log Completion
	exec [core].[p_MonitorEvent]  @sessionID, @ENV, @DataFeed, @BusDate, 'PnLShift_Fact facts conformed.', 'G', @return_value

END TRY


--#------------------------------------------------ END OF CONFORMATION -----------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

	SELECT
        @ErrorNumber    = ERROR_NUMBER()    ,
        @ErrorSeverity  = ERROR_SEVERITY()  ,
        @ErrorState     = ERROR_STATE()     ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
		@ErrorProcedure = isnull(ERROR_PROCEDURE(),'err') ,
        @ErrorMessage   = ERROR_MESSAGE()   ,
        @ErrorLine		= ERROR_LINE()		;

	--LOG
	EXEC [core].p_LogEvent @SessionID = @SessionID
				  ,@ErrorNumber = @ErrorNumber
				  ,@ProcedureName=@ProcedureName
				  ,@ProcID = @@ProcID
				  ,@ErrorProcedure = @ErrorProcedure
				  ,@ErrorSeverity = @ErrorSeverity
				  ,@ErrorState = @ErrorState
				  ,@ErrorMessage = @ErrorMessage
				  ,@NESTLEVEL = @@NESTLEVEL
				  ,@ErrorLine = @ErrorLine
				  ,@Comment = 'There has been an Error'
				  ,@messageTypeId = 3
				  ,@UpdateType = 'Error'

	RAISERROR( @ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT

END CATCH;

RETURN @ErrorNumber
END
GO

