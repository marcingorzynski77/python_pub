IF OBJECT_ID ('comment.p_IU_Comment') IS NOT NULL
	DROP PROCEDURE comment.p_IU_Comment
GO

CREATE PROC [comment].[p_IU_Comment] 
(
	@BusDate datetime2(7), --(yyyy-MM-dd)
	@TemplateID varchar(50),
	@CommentID varchar(50),
	@Comment varchar(3000),
	@Version INT,
	@UserName varchar(50),
	@UserID varchar(50),
	@Event varchar(10)
)
AS 


BEGIN

    --SET NOCOUNT ON added to prevent extra result sets FROM interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE		
	@UserKey		INT,
	@CommentKey		INT,
	@CommentCatalogueKey	INT,
        @ProcedureName		VARCHAR(126),
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState		INT,
        @ErrorLine		INT,
        @ErrorMessage		VARCHAR(MAX),
        @ErrorProcedure		VARCHAR(126);
		 
    SELECT
        @ProcedureName	= OBJECT_NAME(@@PROCID),       
        @ErrorNumber	= 0,
        @UserKey	= 0;
		
	--EXEC [core].p_LogInfo @ProcedureName, @Message

--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	--handles whether comment is already published within the addin


	--Identify Comment form the catalogue
	set @CommentCatalogueKey = (select CommentCatalogueKey from comment.CommentCatalogue where commentID = @CommentID)
	
	
	--Identify user and insert if neccessary
	set @UserKey = isnull((select UserID from comment.[User] where SystemName = @UserName),0)		
	if @UserKey =0
	begin
		insert into comment.[User]
			(FullName
			,SystemName)
		select
			@UserName
			,@UserID
	end


	if @Event = 'Save'
	begin			
		set @commentkey = (select commentkey from comment.Comment 
							where [Version] = @Version
								and CommentCatalogueKey = @CommentCatalogueKey
								and Published = 0
								and busdate	= @BusDate)
								
		print @commentkey
		if @Commentkey > 0
		begin
			PRINT 'UPDATE'
		
			--update
			update comment.Comment 
			set Comment = @Comment
				,Start = GETUTCDATE()
			where CommentKey = @CommentKey
		
		end
		else
		begin
		PRINT 'INSERT'
			--insert
			insert into comment.Comment
				(Start
				,Finish
				,BusDate
				,CommentCatalogueKey
				,UserKey
				,[Version]
				,Comment
				,Published)
			select
				GETUTCDATE()
				,'9999-12-13'	
				,@BusDate
				,@CommentCatalogueKey
				,@UserKey
				,@Version
				,@Comment
				,0
		end
		
	
	end
	else if @Event = 'Publish'
	begin
			
		--Set the comment as published 
		Update C
			set Published = 1,
			Start = GETUTCDATE()
		From comment.comment C
		where CommentCatalogueKey = @CommentCatalogueKey
			and [Version] = @Version
			and BusDate = @BusDate
	
	end
	
	
		
	
END TRY

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO

