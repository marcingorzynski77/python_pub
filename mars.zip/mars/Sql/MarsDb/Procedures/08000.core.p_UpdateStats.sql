IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[p_UpdateStats]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [core].[p_UpdateStats]
GO


create PROC [core].[p_UpdateStats] with execute as 'dbo'
AS
BEGIN
exec sp_updatestats
End
GO