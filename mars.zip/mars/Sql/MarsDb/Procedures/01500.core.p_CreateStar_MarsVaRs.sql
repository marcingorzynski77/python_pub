IF OBJECT_ID ('[core].[p_CreateStar_MarsVaRs]') IS NOT NULL
	DROP PROCEDURE [core].[p_CreateStar_MarsVaRs]
GO

/*
  DECLARE @TargetDate AS DATETIME2; 
  SET @TargetDate = GETUTCDATE()
  EXEC [core].[p_CreateStar_MarsVaRs] '2017-07-05', @TargetDate, 'MarsVaRs', 'PROD' 

*/

CREATE PROC [core].[p_CreateStar_MarsVaRs]
(
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(64),
	@Env		VARCHAR(6),
    @HierarchyTag INT = 0
)
AS

BEGIN
	SET NOCOUNT ON;

	DECLARE
		@ProcedureName		NVARCHAR(128),
		@Message			NVARCHAR(MAX),
		@InitialTranCount	INT,
		@CommentID			INT,
		@InsertedCount		BIGINT,
		@RejectedCount		BIGINT,
		@UTCDate			DATETIME2;

	SELECT
		@ProcedureName		= OBJECT_NAME(@@PROCID),
		@InitialTranCount	= @@TRANCOUNT,
		@Message			= 'Invoking ' + @ProcedureName;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY
	--First empty the star ready for new data
    TRUNCATE TABLE [core].MarsVaRs_Source
	TRUNCATE TABLE [core].MarsVaRs_Hierarchy
	TRUNCATE TABLE [core].MarsVaRs_RiskMeasureType
	TRUNCATE TABLE [core].MarsVaRs_ScenarioHierarchy
	TRUNCATE TABLE [core].MarsVaRs_Fact

	EXEC core.p_DropIndexes @IndexSchemaName = 'core', @IndexTableName = 'MarsVaRs_Fact'

 	--#--------------------------------------------- Populate the Source Dimension ------------------------------------------#--

	--Source Dimension
	INSERT INTO [core].[MarsVaRs_Source] (
		 [InterfaceName]
		,[Environment]
		,[Source]
		,[Origin]
	)
	SELECT
		 @DataFeed as [InterfaceName]
		,@Env as [Environment]
		,'MaRS' as [Source]
		,'SIMRA' as [Origin]	

	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[MarsVaRs_Source] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the Hierarchy Dimension ----------------------------------------#--
	
	INSERT INTO [core].[MarsVaRs_Hierarchy](
           [CoreSourceKey]
          ,[NodeName]
          ,[NodeType]
          ,[BookSystem]
          ,[HierarchyString]
		  ,[Group]
          ,[SubGroup]
          ,[Business]
          ,[BusinessArea]
          ,[Division]
          ,[Desk]
          ,[SubDesk]
          ,[HierarchyTag])
	SELECT DISTINCT
           S.CoreSourceKey
          ,COALESCE(R.[SubDesk],R.[Desk],R.[Division],R.[BusinessArea],R.[Business],R.[SubGroup],R.[Group]) AS NodeName
          ,CASE WHEN R.[SubDesk] IS NOT NULL THEN 'SD'
                WHEN R.[Desk] IS NOT NULL THEN 'DE'
                WHEN R.[Division] IS NOT NULL THEN 'DV'
                WHEN R.[BusinessArea] IS NOT NULL THEN 'BA'
                WHEN R.[Business] IS NOT NULL THEN 'BU'
                WHEN R.[SubGroup] IS NOT NULL THEN 'SG'
                WHEN R.[Group] IS NOT NULL THEN 'GR' END AS [NodeType]
          ,'Risk Management'
          ,'/' + CASE WHEN R.[Group] IS NOT NULL THEN R.[Group] + '/' ELSE '' END
               + CASE WHEN R.[SubGroup] IS NOT NULL THEN R.[SubGroup] + '/' ELSE '' END
               + CASE WHEN R.[Business] IS NOT NULL THEN R.[Business] + '/' ELSE '' END
               + CASE WHEN R.[BusinessArea] IS NOT NULL THEN R.[BusinessArea] + '/' ELSE '' END
               + CASE WHEN R.[Division] IS NOT NULL THEN R.[Division] + '/' ELSE '' END
               + CASE WHEN R.[Desk] IS NOT NULL THEN R.[Desk] + '/' ELSE '' END
               + CASE WHEN R.[SubDesk] IS NOT NULL THEN R.[SubDesk] + '/' ELSE '' END AS [HierarchyString]
          ,R.[Group]
          ,R.[SubGroup]
          ,R.[Business]
          ,R.[BusinessArea]
          ,R.[Division]
          ,R.[Desk]
          ,R.[SubDesk]
          ,@HierarchyTag 
	  FROM [raw].[MarsVaRs] R
     INNER JOIN [core].[MarsVaRs_Source] S
	    ON S.[Source] = 'MaRS' AND S.[Origin] = 'SIMRA'

       	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[MarsVaRs_Hierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the ScenarioHierarchy Dimension ----------------------------------------#--

	CREATE TABLE #ScenarioHierarchy (
		  [CoreSourceKey]				BIGINT
		, [NodeID]	 					BIGINT
		, [ScenarioNodeName]			VARCHAR (50)
		, [Level]						INT
		, [AggregationType]				VARCHAR (255)
		, [ScenarioHierarchyString]		VARCHAR (900)
	)

	INSERT INTO #ScenarioHierarchy (
		   CoreSourceKey
		  ,ScenarioNodeName)
	SELECT S.CoreSourceKey
		  ,R.ScenarioNodeName
	  FROM (SELECT DISTINCT ScenarioNodeName FROM [raw].[MarsVaRs]) R
	 INNER JOIN core.MarsVaRs_Source S
		ON S.[Source] = 'MaRS' AND S.[Origin] = 'SIMRA' 

	SELECT @InsertedCount = @@ROWCOUNT

	UPDATE H
	   SET [ScenarioHierarchyString] = ISNULL(T.ScenarioHierarchyString, '`LBG`' + H.ScenarioNodeName)
		  ,[NodeID] = ISNULL(T.NodeID, -1)
		  ,[Level] = ISNULL(T.[Level], 2)
		  ,[AggregationType] = ISNULL(T.[AggregationType], 'None')
	  FROM #ScenarioHierarchy H
	  LEFT JOIN [target].ScenarioHierarchy T
	    ON H.ScenarioNodeName = T.ScenarioNodeName

	INSERT INTO [core].MarsVaRs_ScenarioHierarchy (
		   [CoreSourceKey]
		  ,[NodeID]
		  ,[ScenarioNodeName]
		  ,[Level]
		  ,[AggregationType]
		  ,[ScenarioHierarchyString])
	SELECT [CoreSourceKey]
		  ,[NodeID]
		  ,[ScenarioNodeName]
		  ,[Level]
		  ,[AggregationType]
		  ,[ScenarioHierarchyString]
	  FROM #ScenarioHierarchy H

	DROP TABLE #ScenarioHierarchy 
    
	--Log affected rows
	SET @Message = 'Split out ' + CAST((@InsertedCount) AS VARCHAR(30)) + ' rows into [core].[MarsVaRs_ScenarioHierarchy] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#------------------------------------------ Populate the RiskMeasureType Dimension ------------------------------------------#--
	
    INSERT INTO [core].[MarsVaRs_RiskMeasureType] (
         [CoreSourceKey]
		,[RiskMeasureTypeName]
		,[RiskMeasureFamily]
	)
	SELECT DISTINCT
           S.CoreSourceKey
          ,R.RiskMeasureTypeName
		  ,R.RiskMeasureFamily		
	 FROM [raw].[MarsVaRs] R
    INNER JOIN [core].[MarsVaRs_Source] S
	   ON S.[Source] = 'MaRS' AND S.[Origin] = 'SIMRA' 
	
	--Log affected rows
	SET @Message = 'Split out ' + CAST((@@ROWCOUNT)AS VARCHAR(30)) + ' rows into [core].[MarsVaRs_RiskMeasureType] dimension'
	EXEC [core].p_LogInfo @ProcedureName, @Message

	--#----------------------------------------------- Populate the SimraPnLValue Fact ---------------------------------------------#--

	-- Risk Measure Values
	INSERT INTO [core].[MarsVaRs_Fact] (
           [BusDate]
		  ,[CoreSourceKey]
		  ,[CoreHierarchyKey]
		  ,[CoreScenarioHierarchyKey]
		  ,[CoreRiskMeasureTypeKey]
		  ,[AnalysisTypeName]
          ,[VarMeasureType]
          ,[ConfidenceLevel]
		  ,[LegalEntity]
		  ,[Cad2]
          ,[Label]
		  ,[ValueGBP])
	SELECT @BusDate
          ,S.[CoreSourceKey]
		  ,H.[CoreHierarchyKey]
		  ,SH.[CoreScenarioHierarchyKey]
		  ,RM.[CoreRiskMeasureTypeKey]
		  ,R.[AnalysisTypeName]
          ,R.[CalculationType]
          ,R.[ConfidenceLevel]
		  ,R.[LegalEntity]
		  ,R.[Cad2]
          ,CASE R.[LegalEntity] 
           WHEN 'LTBS' THEN 'Lloyds_'
           WHEN 'HBOS' THEN 'BOS_'
           ELSE '' END + 
           CASE WHEN R.[AnalysisTypeName] LIKE '%Stressed%' THEN 'S' ELSE '' END +
           R.[CalculationType] + '_' +
           CASE WHEN R.[AnalysisTypeName] LIKE '%VaR 1 day%' THEN '1D'
                WHEN R.[AnalysisTypeName] LIKE '%VaR 10 day%' THEN '10D' 
           ELSE '' END +
           CONVERT(VARCHAR(10),R.[ConfidenceLevel]) AS Label
		  ,R.[ValueGBP]
	 FROM [raw].[MarsVaRs] R
     LEFT JOIN [core].MarsVaRs_Source S
       ON  S.[Source] = 'MaRS' AND S.[Origin] = 'SIMRA' 
     LEFT JOIN [core].MarsVaRs_Hierarchy H
       ON ISNULL(R.[Group], '') = ISNULL(H.[Group], '')
      AND ISNULL(R.[SubGroup], '') = ISNULL(H.[SubGroup], '')
      AND ISNULL(R.Business, '') = ISNULL(H.Business, '')
      AND ISNULL(R.BusinessArea, '') = ISNULL(H.BusinessArea, '')
      AND ISNULL(R.Division, '') = ISNULL(H.Division, '')
      AND ISNULL(R.Desk, '') = ISNULL(H.Desk, '')
      AND ISNULL(R.SubDesk, '') = ISNULL(H.SubDesk, '')
     LEFT JOIN [core].[MarsVaRs_ScenarioHierarchy] SH
       ON R.ScenarioNodeName = SH.ScenarioNodeName
     LEFT JOIN [core].[MarsVaRs_RiskMeasureType] RM
       ON R.RiskMeasureTypeName = RM.[RiskMeasureTypeName]
	  AND R.RiskMeasureFamily = RM.[RiskMeasureFamily]

	SET @InsertedCount = @@ROWCOUNT

	--Log affected rows
	SET @Message = 'Inserted ' + CAST(@InsertedCount as VARCHAR(30)) + ' rows into [core].[MarsVaRs_Fact] fact table'
	EXEC [core].p_LogInfo @ProcedureName, @Message

    EXEC [core].p_LogInfo @ProcedureName, 'Finished processing. Success'

END TRY

--#---------------------------------------------- END OF STAR CODE -----------------------------------------------#--
--#===============================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END
