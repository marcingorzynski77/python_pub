/****** Object:  StoredProcedure [target].[p_IU_Report_Bookmark]    Script Date: 07/04/2017 16:11:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_IU_Report_Bookmark]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_IU_Report_Bookmark]
GO


CREATE PROC [target].[p_IU_Report_Bookmark] 
(
	@Event varchar(10),
	@Report varchar(50),		
	@Bookmark varchar(50),		
	@Formula varchar(MAX),
	@user varchar(50)
)
AS 

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE
		@return_status		int,
        @ProcedureName      NVARCHAR(128),
        @Message 	        NVARCHAR(MAX),
        @BusinessLogicSev	INT,
        @SessionID  		BIGINT ,
        @VersionPath		varchar(100),
        @ReportConfigKey	int;
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
        @Message            = 'Invoking ' + @ProcedureName;

	exec [core].p_LogInfo @ProcedureName, @Message
	set @SessionID = @@IDENTITY	
  
--#---------------------------------------- END OF STANDARD TRANSACTION HEADER ----------------------------------------#--
--#====================================================================================================================#--


BEGIN TRY	
	select @ReportConfigKey = (select ReportConfigKey
							   from core.Report_Config
							   where Name = @Report
							   AND Finish = '99991231')

	if @Event = 'UPDATE'
	begin
			
		if (select COUNT(1) 
			from core.Report_Bookmark
			where ReportConfigKey = @ReportConfigKey
				and [bookmark] = @Bookmark
				and [Formula] = @Formula
				AND Finish = '99991231') = 0
		begin
			--Expire previous entry
			Update core.Report_Bookmark
			set finish = GETUTCDATE()
			where ReportConfigKey = @ReportConfigKey
				and Bookmark = @Bookmark
				AND Finish = '99991231'
			
			--Insert new entry
			insert into core.Report_Bookmark			
			values(GETUTCDATE(),'99991231',@Bookmark,@Formula,@ReportConfigKey,@user)
		end
	
	end
	else
	if @Event = 'DELETE'
	begin
		--Expire previous entry
		Update core.Report_Bookmark
		set finish = GETUTCDATE()
		where ReportConfigKey = @ReportConfigKey
			and Bookmark = @Bookmark
	end

END TRY

--#---------------------------------------------------- END OF IUSP ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END



GO


