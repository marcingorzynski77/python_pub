IF OBJECT_ID ('core.p_Insert_TimeTravellingInstance') IS NOT NULL
	DROP PROCEDURE [core].[p_Insert_TimeTravellingInstance]
GO


CREATE PROC [core].[p_Insert_TimeTravellingInstance]
(
	@BusDate		DATETIME2,
	@ExecutionTime	DATETIME2,
	@DataFeed		VARCHAR(64),
	@Env		    VARCHAR(6),
	@FactTable      VARCHAR(50),
	@ExternalRef    VARCHAR(255) = null,
	@ExternalRef2   VARCHAR(255) = null
)
AS
BEGIN
  SET NOCOUNT ON;

    DECLARE
	@ProcedureName	NVARCHAR(128),
	@Message		NVARCHAR(MAX),
	@NowDate		DATETIME2;
	
    SELECT			@ProcedureName = OBJECT_NAME(@@PROCID),
					@Message	   = 'Invoking ' + @ProcedureName,
					@NowDate	   = CASE WHEN @ExecutionTime IS NULL THEN GETUTCDATE() ELSE @ExecutionTime END;

	EXEC [core].p_LogInfo @ProcedureName, @Message
	
--#----------------------------------------- END OF STANDARD SNOWFLAKE HEADER -----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY

	DECLARE @SQL nvarchar(4000), @SQLUpdate nvarchar(4000), @SQLInsert nvarchar(4000)
	
	SET @Message = 'External reference: '+ ISNULL(@ExternalRef, 'Not supplied')
	EXEC [core].p_LogInfo @ProcedureName, @Message

	SET @Message = 'External reference2: '+ ISNULL(@ExternalRef2, 'Not supplied')
	EXEC [core].p_LogInfo @ProcedureName, @Message

	DECLARE @PreviousStart DATETIME2  
	SELECT @PreviousStart = MAX([Start]) 
	  FROM target.TimeTravellingInstance 
	 WHERE [DataFeed] = @DataFeed

	INSERT 
	  INTO target.TimeTravellingInstance 
	      ([Start]
           ,[Finish]
           ,[Datafeed]
           ,[FactTable]
           ,[Env]
           ,[Busdate]
           ,[VersionDateTime]
           ,[Official]
           ,[ExternalReference]
           ,[ExternalReference2]
		   )
	VALUES (@NowDate
	        ,'9999-DEC-31'			
			,@DataFeed
		    ,@FactTable
			,@Env
            ,@BusDate
            ,@NowDate
			,0
			,@ExternalRef
			,@ExternalRef2
			)
		
	EXEC [core].p_LogInfo @ProcedureName, 'Added Time Travelling instance' 
	
	IF @PreviousStart IS NOT NULL
	BEGIN

		UPDATE target.TimeTravellingInstance
		   SET [Finish] = @NowDate
		 WHERE [Start] = @PreviousStart
		   AND [DataFeed] = @DataFeed 

		EXEC [core].p_LogInfo @ProcedureName, 'Expired Previous Time Travelling Instance'
	END
	
	EXEC [core].p_LogInfo @ProcedureName, 'Success. End of processing'
		
END TRY

--	exec [core].[p_Log_TimeTravellingInstance] '20171212','PnL','PROD','PnL',0

--#------------------------------------------------ END OF STAR CODE --------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
