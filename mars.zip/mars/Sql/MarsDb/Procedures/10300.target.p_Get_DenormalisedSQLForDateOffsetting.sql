/****** Object:  StoredProcedure [target].[p_Get_DenormalisedSQLForDateOffsetting]    Script Date: 02/21/2017 04:36:07 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[p_Get_DenormalisedSQLForDateOffsetting]') AND type in (N'P', N'PC'))
DROP PROCEDURE [target].[p_Get_DenormalisedSQLForDateOffsetting]
GO



CREATE PROC [target].[p_Get_DenormalisedSQLForDateOffsetting]
(
	@Dataset as varchar(30)
	,@OffsetDates aS varchar(2000)	
)
AS
BEGIN

SET NOCOUNT ON

	declare @Fact as varchar(30)
	declare @Sql as varchar(MAX)
	declare @Table as varchar(900)
	declare @OriginalTable as varchar(900)
	
	--set @OffsetDates = '''20150202'',''20150203'''
	
	set @OffsetDates = '''' + REPLACE(@OffsetDates,',',''',''')+''''	
	
	create table #dictionary
	(
		[DataSetType] varchar(30)
		,[Data Set] varchar(30)
		,[Fact/Dimension] varchar(9)
		,[OriginalTable] varchar(30)
		,[Table] varchar(30)
		,[Field] varchar(30)
		,[OriginalDataType] varchar(20)
		,[DataType] varchar(20)
		,[Description] varchar(900)
	)
	
	insert into #dictionary
	exec [target].[p_Get_DataDictionary] '','ALL'
	
	
	--Get Fact	
	set @Fact = (select distinct OriginalTable
				from #dictionary
				where [Data Set] = @Dataset 
				and [Fact/Dimension] = 'Fact')
	
	
	--Get Dimensions
	select distinct OriginalTable,[Table],'' as [status]
	into #Dimensions
	from #dictionary
	where [Data Set] = @Dataset
	and [Fact/Dimension] = 'Dimension'
	
	
	--Add Fact table and time travel offsets
	set @Sql = 'target.' + @Fact + 
				' INNER JOIN (SELECT [DATE] AS offsetDate from target.Calendar where [date] in (' + @OffsetDates + ')) AS TT on target.' + @Fact + '.BusDate = TT.offsetDate' +
				' INNER JOIN (SELECT  TOP 1 TargetDate as VersionDateTime from target.f_TargetDate() ORDER BY TargetDate ) AS TT2' +
				' ON target.' + @Fact + '.Start <= TT2.VersionDateTime and target.' + @Fact + '.Finish > TT2.VersionDateTime'
	
	
	--Loop through the temp table adding each Dimension to the query
	WHILE (SELECT COUNT(1) from #Dimensions where [Status] = '') > 0
	BEGIN

		--step through each table/originaltable combo
		select  top 1 
				@Table = [Table]
				,@OriginalTable = [OriginalTable]
		from #Dimensions 
		where [Status] = ''	
		
		if @OriginalTable = 'Hierarchy' 
		begin
			--concatenate the dynamic sql
			set @Sql = @Sql + ' LEFT OUTER JOIN target.vHierarchy AS D_' + @Table + ' ON target.' + @Fact + '.' + @Table + 'Key = D_' + @Table + '.' + @OriginalTable + 'Key'
		end
		else
		begin
			--concatenate the dynamic sql
			set @Sql = @Sql + ' LEFT OUTER JOIN target.' + @OriginalTable + ' AS D_' + @Table + ' ON target.' + @Fact + '.' + @Table + 'Key = D_' + @Table + '.' + @OriginalTable + 'Key'
		end
		
		--update temp table
		update #Dimensions set [status] = '1' where [Table] = @Table
		
	END	
		
	drop table #dictionary
	drop table #Dimensions
			
	--Handle HierarchyConsolidateds
	set @Sql = REPLACE(@sql,'HierarchyConsolidatedKey','HierarchyKey')
	set @Sql = REPLACE(@sql,'HierarchyConsolidated','vHierarchyConsolidated')
		
	--Retrun the denormalised SQL
	select @Sql
	
End

GO