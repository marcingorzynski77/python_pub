IF OBJECT_ID ('target.p_Get_LimitTIFs') IS NOT NULL
	DROP PROCEDURE target.p_Get_LimitTIFs
GO

CREATE PROC [target].[p_Get_LimitTIFs] 
(
	@BusDate datetime2(7)
	,@VersionDate  datetime2(7)=''
)
AS 

BEGIN

----#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
----#====================================================================================================================#--

	
	Set nocount on

	DECLARE @colsPivot as  NVARCHAR(MAX)	
	DECLARE @query as NVARCHAR(max)

	create table #results
	(
		Limitdate datetime2(7)
		,LimitId int
		,Name varchar(50)
		,dateType varchar(50)
		,BeforeValue int
		,AfterValue int
		,LimitChange varchar(100)	
	)
	
	create table #ActiveDates
	(
		LimitStartDate datetime2(7),
		LimitEndDate datetime2(7)
	)
	
	if @VersionDate = ''
	begin
		set @VersionDate = @BusDate
	end
		

	--Get active dates
	insert into #ActiveDates
	exec target.[p_Get_ActiveLimitDates]
	
	
	--Get distinct dates of limits set before or on the chose business date
	select distinct limitDate as limitDate, sum(cast(dateType as int)) as dateType,'' as [status]		
	into #distinctDates
	from
	(
		select 
			distinct LimitStartDate as limitDate,
			-1 as dateType
		from #ActiveDates
	union 
		select 
			distinct LimitEndDate as limitDate,
			1 as dateType
		from #ActiveDates
	)A
	group by limitDate 
		
 
	--Identify range of dates that we want to display on form.
	select top 4 limitDate, dateType,'' as [status]
	into #dates
	from #distinctDates
	where limitDate >= @VersionDate

	
	--Identify range of dates that we want to display on form.
	insert into #dates			
	select TOP 3 limitDate, dateType,''
	from #distinctDates
	where limitDate < @VersionDate
	order by limitDate desc
		
	
	--Get limits with a start date we're interested in
	insert into #results
	select 
		F.LimitStartDate as 'Limitdate'
		,F.LimitId
		,F.Name 
		,'Start'
		,0 as 'BeforeValue'
		,F.Value as 'AfterValue'
		,''	
	from target.Limit_Fact F
	join #dates D
	on D.limitDate = F.LimitStartDate
		and D.dateType in (-1,0)
					
	
	--Get limits with an end date we're interested in	
	insert into #results
	select 		
		F.LimitEndDate as 'Limitdate'
		,F.LimitId
		,F.Name 
		,'Finish'
		,F.Value as 'BeforeValue'
		,0 as 'AfterValue'
		,''
	from target.Limit_Fact F
	join #dates D
	on D.limitDate = F.LimitEndDate
		and D.dateType in (0,1)
		
		
	--Identify the next days values for expiring limits
	update R
		set BeforeValue = Value
	from #results R
	join target.Limit_Fact F
		on R.LimitId = F.LimitId
	join target.Calendar C
		on R.LimitDate = C.[Date]
	where R.dateType = 'Finish'
		and F.LimitStartDate <= C.NextWorkingDate
		and F.LimitEndDate >= C.NextWorkingDate
	
	
	--Shift End dates by one day as the limit change only takes affect on the following day
	update R
		set limitDate = C.NextWorkingDate
	from #results R
	join target.Calendar C
		on C.[Date] = R.limitDate
	where R.dateType = 'Finish' --End Date DateType
	
	
	--Concatenate values to produce message describing the change in the limit
	update R
		set LimitChange = '(' + Name + ') ' + cast(BeforeValue as varchar(20)) + ' -> ' + cast(AfterValue as varchar(20))
	from #results R
		
	
	--Add distinct dates to column header string
	SELECT @colsPivot = COALESCE(@colsPivot + N',[ ', N'[') + a.[limitdate] + ']'
	from
	(
		select distinct cast([Limitdate] as nvarchar(max)) as limitdate
		from #results
	)a
	
	
	--Build dynamic pivot query	
	set @query = 'set nocount on SELECT limitid,' + @colsPivot + ' from 
             (
                select limitdate,limitid, limitchange
                from #results
            ) x
            pivot 
            (
                max([limitchange])
                for [limitdate] in (' + @colsPivot + ')
            ) p '


	--Execute query to be consumed by Excel GUI
	execute(@query);
	
	--Tidy
	drop table #dates
	drop table #ActiveDates
	drop table #results
	drop table #distinctDates

END
GO
