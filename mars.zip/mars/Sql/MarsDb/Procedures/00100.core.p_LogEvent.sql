IF OBJECTPROPERTY(OBJECT_ID('core.p_LogEvent'), N'IsProcedure') = 1
	DROP PROCEDURE [core].[p_LogEvent]
GO

CREATE PROCEDURE [core].[p_LogEvent]
(	
	@ProcedureName 		NVARCHAR(128),	
	@Message 			NVARCHAR(MAX),
	@LogLevel 			VARCHAR(100) = 'INFO'
)
AS
BEGIN
	DECLARE @SubMessage NVARCHAR(3700)

	WHILE LEN(@Message) > 3700
	BEGIN
		SET @SubMessage = LEFT(@Message, 3700)
		PRINT cast(Sysutcdatetime() as varchar) + ' ' + @LogLevel + ' [' + @ProcedureName + '] ' + @SubMessage
		SET @Message = RIGHT(@Message, LEN(@Message) - 3700)
	END
	
	PRINT cast(Sysutcdatetime() as varchar) + ' ' + @LogLevel + ' [' + @ProcedureName + '] ' + @Message
END
GO 
