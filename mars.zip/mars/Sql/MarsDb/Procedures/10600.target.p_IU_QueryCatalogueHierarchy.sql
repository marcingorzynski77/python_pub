IF OBJECT_ID ('target.p_IU_QueryCatalogueHierarchy') IS NOT NULL
	DROP PROCEDURE target.p_IU_QueryCatalogueHierarchy
GO

CREATE PROC [target].[p_IU_QueryCatalogueHierarchy] 
(
	@NodeID as int
	,@NodeName as varchar(100)
	,@ParentNodeID as int			
	,@Owner	as varchar(100)	
	,@Event varchar(10)=''
)
AS 

BEGIN

    --SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.    
    SET NOCOUNT ON;
    DECLARE
		@BusDate			datetime2,
		@BusDay				char(2),
		@return_status		int,
        @ProcedureName      NVARCHAR(128),
		@Message 	        NVARCHAR(1000),
        @InitialTranCount   INT,
        @BusinessLogicSev	INT,
        @SessionID  		BIGINT;
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID),
		@BusDate			= (select target.f_GetBusinessDate(GETUTCDATE(),-1,'D'));
      
    SET @BusDay			= cast ((Select [WeekDay] from target.Calendar where [DATE] = @BusDate) AS char(2));

	SET @Message = 'Invoking ' + @ProcedureName
	EXEC [core].p_LogInfo @ProcedureName, @Message
	set @SessionID = @@IDENTITY	
  
--#---------------------------------------- END OF STANDARD TRANSACTION HEADER ----------------------------------------#--
--#====================================================================================================================#--

BEGIN TRY	


	if @Event= 'NEW ROOT'
	begin
		
		insert into [core].QueryCatalogue_Hierarchy(
			[NodeName]
			,[ParentNodeID] 
			,[Owner]
		)	
		SELECT
			@NodeName
			,@ParentNodeID			
			,@Owner
		
		SET @ParentNodeID = (Select nodeid from core.QueryCatalogue_Hierarchy 
							 where NodeName = @NodeName 
							 and ParentNodeID is null
							 and [Owner] = @Owner) 
		
		insert into [core].QueryCatalogue_Hierarchy(
			[NodeName]
			,[ParentNodeID] 
			,[Owner]
		)	
		SELECT
			'My Scripts'
			,@ParentNodeID			
			,@Owner		
			
		SET @Message = 'Created new Root for user "' + @Owner + '"'
		exec [core].p_LogInfo @ProcedureName, @Message
		
	end
	else if @Event= 'NEW'
	begin
		
		insert into [core].QueryCatalogue_Hierarchy(
			[NodeName]
			,[ParentNodeID] 
			,[Owner]
		)	
		SELECT
			@NodeName
			,@ParentNodeID			
			,@Owner
					
		SET @Message = 'Created new Node "' + @NodeName + '" to sit under node ' + cast(@ParentNodeID as varchar(4))
		exec [core].p_LogInfo @ProcedureName, @Message
		
	end
	else if @Event= 'RENAME'
	begin

		update [core].QueryCatalogue_Hierarchy
		set NodeName = @NodeName
		where NodeID = @NodeID
		
		SET @Message = 'Renamed Node ' + cast(@NodeID as varchar(4)) + ' to "' + @NodeName + '"'
		exec [core].p_LogInfo @ProcedureName, @Message
		
	end
	else if @Event = 'MOVE'
	begin	
	
		update [core].QueryCatalogue_Hierarchy
		set ParentNodeID = @ParentNodeID
		where NodeID = @NodeID
		
		SET @Message = 'Moved Node ' + cast(@NodeID as varchar(4)) + ' to be a child of Node ' + cast(@ParentNodeID  as varchar(4))
		exec [core].p_LogInfo @ProcedureName, @Message
		
	end		
	else if @Event = 'DELETE'
	begin	
		
		delete from [core].QueryCatalogue_Hierarchy
		where NodeID = @NodeID
			 		
		SET @Message = 'Deleted Node ' + cast(@NodeID as varchar(4))  
		exec [core].p_LogInfo @ProcedureName, @Message
		
	end	

	--Finish logging
	SET @Message = 'Success. End of processing'
	exec [core].p_LogInfo @ProcedureName, @Message

END TRY




--#---------------------------------------------------- END OF IUSP ---------------------------------------------------#--
--#====================================================================================================================#--

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
