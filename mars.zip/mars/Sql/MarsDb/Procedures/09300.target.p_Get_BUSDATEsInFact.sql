IF OBJECT_ID ('target.p_Get_BUSDATEsInFact') IS NOT NULL
	DROP PROCEDURE target.p_Get_BUSDATEsInFact
GO

CREATE PROC [target].[p_Get_BUSDATEsInFact] 
(
	@Bus varchar(30) = null
)
AS 

BEGIN

	SET NOCOUNT ON
	
    DECLARE
		@ProcedureName      NVARCHAR(128),
        @Message       		NVARCHAR(MAX),
		@Table				varchar(50),
		@ID					int,
		@SQL				varchar(MAX);
		 
     SELECT
        @ProcedureName      = OBJECT_NAME(@@PROCID);
					

BEGIN TRY

--#----------------------------------------------- END OF BASIC HEADER ------------------------------------------------#--
--#====================================================================================================================#--
					
					

	--Get the target date
	if @Bus is null
	begin
		set @Bus =  ISNULL((select BusDate from target.f_BusDate()),GETUTCDATE())
	end


	--Get the dates 	
	select
		FactTable,
		cast(BusDate as varchar(10)) as 'BusDate'
	into #dates
	from
	(
		select FactTable
			   ,cast(busdate as varchar(10)) as 'busdate' 
		from [target].TimeTravellingInstance 
		where Busdate <= @Bus
		and BusDate > DATEADD(DAY,-7,@Bus)	
		group by FactTable, Busdate
		UNION ALL
		select left([Description],LEN([description])-5) as 'FactTable'
			   ,f.BusDate			
		from target.FlexFact F 
		join target.FlexFactHierarchy H on H.FlexFactHierarchyKey = F.FlexFactHierarchyKey
		where H.[Name] like '%Data%'
		and Busdate <= @Bus
		and BusDate > DATEADD(DAY,-7,@Bus)		
		group by [Description], Busdate
	)a

	
	 	
	--Concat the dates 
	Select Main.FactTable,'''' + Left(Main.Dates,Len(Main.Dates)-1) As "COBDates"
	From
		(
			Select distinct ST2.FactTable, 
				(
					Select ST1.BusDate + ''',''' AS [text()]
					From #dates ST1
					Where ST1.facttable = ST2.facttable
					ORDER BY ST1.facttable
					For XML PATH ('')
				) [Dates]
			From #dates ST2
		) [Main]

	
	--select * from #Dates
	drop table #Dates
	
		 
--#-------------------------------------------------- END OF HEADER ---------------------------------------------------#--
--#====================================================================================================================#--

END TRY

BEGIN CATCH

    DECLARE
        @ErrorNumber		INT,
        @ErrorSeverity		INT,
        @ErrorState			INT,
        @ErrorLine			INT,
        @ErrorMessage		NVARCHAR(4000),
        @ErrorProcedure		NVARCHAR(128);

   	SELECT
        @ErrorNumber    = ERROR_NUMBER(),
        @ErrorSeverity  = ERROR_SEVERITY(),
        @ErrorState     = ERROR_STATE(),
        @ErrorMessage   = ERROR_MESSAGE(),
		@ErrorProcedure = ERROR_PROCEDURE(),
        @ErrorLine		= ERROR_LINE();

	EXEC [core].p_LogError 
		@ProcedureName 	= @ProcedureName,
		@Message 		= @ErrorMessage,
		@ErrorNumber 	= @ErrorNumber,
		@ErrorProcedure = @ProcedureName,
		@ErrorSeverity 	= @ErrorSeverity,
		@ErrorState 	= @ErrorState,
		@ErrorLine 		= @ErrorLine,
		@NESTLEVEL 		= @@NESTLEVEL;

	RAISERROR(@ErrorMessage,@ErrorSeverity,@ErrorState) WITH NOWAIT;

END CATCH;

RETURN 0;

END

GO
