UPDATE FI 
   SET FI.AppliedRules = 'x'
FROM [target].FlexFactInstance FI
INNER JOIN
(SELECT FlexFactKey, [Key], COUNT(*) AS COUNTER
  FROM [target].FlexFactInstance                        
 GROUP BY FlexFactKey, [Key]
 HAVING COUNT(*) > 1) A
  ON FI.FlexFactKey = A.FlexFactKey
 AND FI.[Key] = A.[Key]

 INSERT INTO [target].FlexFactInstance (FlexFactKey, [Key], Value, AppliedRules)
 SELECT FI.FlexFactKey, FI.[Key], SUM(CAST(FI.Value AS BIGINT)) AS Value, NULL AS AppliedRules
 FROM [target].FlexFactInstance FI
 WHERE FI.[Key] = 'Active.Count'
 AND  FI.AppliedRules = 'x'
 GROUP BY FI.FlexFactKey, FI.[Key]

 INSERT INTO [target].FlexFactInstance (FlexFactKey, [Key], Value, AppliedRules)
 SELECT FI.FlexFactKey, FI.[Key], MIN(CAST(FI.Value AS DATETIME2)) AS Value, NULL AS AppliedRules
 FROM [target].FlexFactInstance FI
 WHERE FI.[Key] = 'Active.Start'
 AND  FI.AppliedRules = 'x'
 GROUP BY FI.FlexFactKey, FI.[Key]

 INSERT INTO [target].FlexFactInstance (FlexFactKey, [Key], Value, AppliedRules)
 SELECT FI.FlexFactKey, FI.[Key], MAX(CAST(FI.Value AS DATETIME2)) AS Value, NULL AS AppliedRules
 FROM [target].FlexFactInstance FI
 WHERE FI.[Key] = 'Active.Finish'
 AND  FI.AppliedRules = 'x'
 GROUP BY FI.FlexFactKey, FI.[Key]

 DELETE FROM [target].FlexFactInstance 
 WHERE AppliedRules = 'x'
 AND [Key] IN ('Active.Count', 'Active.Start', 'Active.Finish')

 INSERT INTO [target].FlexFactInstance (FlexFactKey, [Key], Value, AppliedRules)
 SELECT FI.FlexFactKey, FI.[Key], SUM(CAST(FI.Value AS BIGINT)) AS Value, NULL AS AppliedRules
 FROM [target].FlexFactInstance FI
 WHERE FI.[Key] = 'Dead.Count'
 AND  FI.AppliedRules = 'x'
 GROUP BY FI.FlexFactKey, FI.[Key]

 INSERT INTO [target].FlexFactInstance (FlexFactKey, [Key], Value, AppliedRules)
 SELECT FI.FlexFactKey, FI.[Key], MIN(CAST(FI.Value AS DATETIME2)) AS Value, NULL AS AppliedRules
 FROM [target].FlexFactInstance FI
 WHERE FI.[Key] = 'Dead.Start'
 AND  FI.AppliedRules = 'x'
 GROUP BY FI.FlexFactKey, FI.[Key]

 INSERT INTO [target].FlexFactInstance (FlexFactKey, [Key], Value, AppliedRules)
 SELECT FI.FlexFactKey, FI.[Key], MAX(CAST(FI.Value AS DATETIME2)) AS Value, NULL AS AppliedRules
 FROM [target].FlexFactInstance FI
 WHERE FI.[Key] = 'Dead.Finish'
 AND  FI.AppliedRules = 'x'
 GROUP BY FI.FlexFactKey, FI.[Key]

 DELETE FROM [target].FlexFactInstance 
 WHERE AppliedRules = 'x'
 AND [Key] IN ('Dead.Count', 'Dead.Start', 'Dead.Finish')