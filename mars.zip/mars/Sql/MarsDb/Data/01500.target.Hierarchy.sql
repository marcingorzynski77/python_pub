--A bug has caused duplicates within PROD and so expire them.
Update H
	set h.Finish = GETUTCDATE() 
from target.Hierarchy H 
join
(
	select NodeId,Hierarchytag
	from target.Hierarchy 
	where Finish = '99991231'
	group by NodeId,HierarchyTag
	having COUNT(1) > 1
)D
on D.nodeid = h.nodeid
and d.hierarchytag = h.hierarchytag
AND Finish = '99991231'