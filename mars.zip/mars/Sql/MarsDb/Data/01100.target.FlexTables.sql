--Add the 2 values that are utilised by the hierarchy dropdown on the MaRS addin
--Add fact for official
insert into target.FlexFact
select 
	(select flexfacthierarchykey from target.FlexFactHierarchy where [Description] = 'RingFencing.Hierarchy.Data')	
	,GETUTCDATE(),'9999-12-31 00:00:00.0000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
	,(select sourcekey from target.Source where InterfaceName = 'FLEX' and Environment = 'PROD' and [Source] = 'FLEX' and Origin = 'FLEX')
	,NULL
	,NULL
	,'System'
	,NULL

--Add instance for official
INSERT INTO TARGET.FlexFactInstance
SELECT 
	(SELECT MAX(FLEXFACTKEY) FROM target.FlexFact where FlexFactHierarchyKey = (select flexfacthierarchykey from target.FlexFactHierarchy where [Description] = 'RingFencing.Hierarchy.Data'))	
	,'Official',0,NULL

--Add fact for adhoc
insert into target.FlexFact
select 
	(select flexfacthierarchykey from target.FlexFactHierarchy where [Description] = 'RingFencing.Hierarchy.Data')	
	,GETUTCDATE(),'9999-12-31 00:00:00.0000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
	,(select sourcekey from target.Source where InterfaceName = 'FLEX' and Environment = 'PROD' and [Source] = 'FLEX' and Origin = 'FLEX')
	,NULL
	,NULL
	,'System'
	,NULL

--Add instance for adhoc
INSERT INTO TARGET.FlexFactInstance
SELECT 
	(SELECT MAX(FLEXFACTKEY) FROM target.FlexFact where FlexFactHierarchyKey = (select flexfacthierarchykey from target.FlexFactHierarchy where [Description] = 'RingFencing.Hierarchy.Data'))	
	,'Adhoc',1,NULL
	
GO