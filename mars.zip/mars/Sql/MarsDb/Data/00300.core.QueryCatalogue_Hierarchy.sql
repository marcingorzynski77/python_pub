SET IDENTITY_INSERT [core].[QueryCatalogue_Hierarchy] ON
INSERT INTO [core].[QueryCatalogue_Hierarchy] ([NodeID], [NodeName], [ParentNodeID], [Owner]) VALUES (1, N'Public', NULL, N'Public')
INSERT INTO [core].[QueryCatalogue_Hierarchy] ([NodeID], [NodeName], [ParentNodeID], [Owner]) VALUES (46, N'Support', 1, N'Public')
INSERT INTO [core].[QueryCatalogue_Hierarchy] ([NodeID], [NodeName], [ParentNodeID], [Owner]) VALUES (47, N'Reconciliation', 46, N'Public')
INSERT INTO [core].[QueryCatalogue_Hierarchy] ([NodeID], [NodeName], [ParentNodeID], [Owner]) VALUES (11, N'Monitor', 1, N'Public')
SET IDENTITY_INSERT [core].[QueryCatalogue_Hierarchy] OFF
