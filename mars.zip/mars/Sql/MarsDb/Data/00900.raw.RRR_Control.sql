insert into raw.RRR_Control(HierarchyDate)
values(getutcdate())


