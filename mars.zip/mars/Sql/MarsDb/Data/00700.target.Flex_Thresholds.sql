
CREATE TABLE #Thresholds
(
    [InterfaceName] VARCHAR(64),
    [Environment] VARCHAR(50),
    [Source] VARCHAR(50),
    [Origin] VARCHAR(50),
    [Threshold] FLOAT
)

INSERT INTO #Thresholds 
VALUES 
    ('SimraFORiskMeasures','PROD','SIMRA','SIMRA', 1.0),
    ('MurexSensitivities','PROD','Murex','Murex', 1.0),
    ('SimraMD_BondSwapSpread','PROD','SIMRA','ADHOC', 1.0),
    ('SimraMD_BondSwapSpread','PROD','SIMRA','BLOOMBERG', 1.0),
    ('SimraMD_CashSwapRate','PROD','SIMRA','ADHOC', 1.0),
    ('SimraMD_CashSwapRate','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_CreditAssetSwap','PROD','SIMRA','IDC', 1.0),
    ('SimraMD_CreditAssetSwap','PROD','SIMRA','SIMRA', 1.0),
    ('SimraMD_CreditCDSIndex','PROD','SIMRA','MARKIT', 1.0),
    ('SimraMD_CreditCDSIndex','PROD','SIMRA','SIMRA', 1.0),
    ('SimraMD_CreditCDSCompositesSpread','PROD','SIMRA','MARKIT', 1.0),
    ('SimraMD_CreditCDSCompositesSpread','PROD','SIMRA','SIMRA', 1.0),
    ('SimraMD_ForeignExchangeVolatilitySwaps','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_FRASwap','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_FXSpotRates','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_FXVol','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InflationVol','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InflationRate','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateCrossCurrencyBasisSpreadSwaps','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateCrossCurrencyBasisSpreadSwapsOIS','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateFRASwapsOIS','PROD','SIMRA','ADHOC', 1.0),
    ('SimraMD_InterestRateFRASwapsOIS','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateTenorBasisSpreadSwaps','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateTenorBasisSpreadSwapsOIS','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateVolatilitySwaps','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_InterestRateVolatilitySwapsOIS','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_IRVol','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_LIBORSpread','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_TenorBasisSpread','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_X-CCYBasisSpread','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraMD_ZeroForward','PROD','SIMRA','ADHOC', 1.0),
    ('SimraMD_ZeroForward','PROD','SIMRA','GATEWAY', 1.0),
    ('SimraVaR1DPnLs','PROD','SIMRA','SIMRA', 1.0),
    ('SimraMD_CreditAssetSwap','PROD','SIMRA','ADHOC', 1.0),
    ('SimraMD_CreditAssetSwap','PROD','SIMRA','BLOOMBERG', 1.0),
    ('SimraMD_ForeignExchangeVolatilitySwaps','PROD','SIMRA','ADHOC', 1.0),
    ('Position','PROD','Summit','Summit', 1.0),
    ('SimraSVaR1DPnLs','PROD','SIMRA','SIMRA', 1.0),
    ('SimraVaR10DPnLs','PROD','SIMRA','SIMRA', 1.0),
    ('SimraSVaR10DPnLs','PROD','SIMRA','SIMRA', 1.0),
	('FxSpot','PROD','TRIDENT','SMDS', 1.0)

DECLARE @SourceKey BIGINT 
DECLARE @InterfaceName VARCHAR(64)
DECLARE @Environment VARCHAR(50)
DECLARE @Source VARCHAR(50)
DECLARE @Origin VARCHAR(50)
DECLARE @Threshold FLOAT
DECLARE @FlexFactHierarchyKey BIGINT
DECLARE @FactKey BIGINT

SELECT @FlexFactHierarchyKey = FlexFactHierarchyKey 
  FROM [target].[FlexFactHierarchy]
 WHERE Description = 'FeedLoadCheck.Threshold.Data'

DECLARE thresholds_cursor CURSOR
FOR SELECT [InterfaceName], [Environment], [Source], [Origin], [Threshold] 
FROM #Thresholds;

OPEN thresholds_cursor  

FETCH NEXT FROM thresholds_cursor   
INTO @InterfaceName, @Environment, @Source, @Origin, @Threshold  

WHILE @@FETCH_STATUS = 0  
BEGIN  

    SET @SourceKey = NULL
    SELECT @SourceKey = [SourceKey] 
      FROM [target].[Source] 
     WHERE [InterfaceName] = @InterfaceName
       AND [Environment] = @Environment
       AND [Source] = @Source
       AND [Origin] = @Origin

    IF @SourceKey IS NULL
    BEGIN
        INSERT INTO [target].[Source] ([Start],[Finish],[InterfaceName],[Environment],[Source],[Origin])
        VALUES (GETUTCDATE(), '9999-12-31', @InterfaceName, @Environment, @Source, @Origin) 

        SET @SourceKey = SCOPE_IDENTITY()
        PRINT 'INSERTING Source: ' + @InterfaceName + ',' + @Environment + ',' + @Source + ',' + @Origin
    END

    INSERT INTO [target].[FlexFact] ([FlexFactHierarchyKey],[Start],[Finish],[BusDate],[SourceKey],[UserName])
     VALUES(@FlexFactHierarchyKey, '2017-04-01', '9999-12-31', NULL, @SourceKey, 'Initial')

    SET @FactKey = SCOPE_IDENTITY()

    INSERT INTO [target].[FlexFactInstance] ([FlexFactKey],[Key],[Value])
     VALUES (@FactKey, 'ThresholdValue', @Threshold)

    FETCH NEXT FROM thresholds_cursor   
    INTO @InterfaceName, @Environment, @Source, @Origin, @Threshold 

END   

CLOSE thresholds_cursor;  
DEALLOCATE thresholds_cursor;  

DROP TABLE #Thresholds
