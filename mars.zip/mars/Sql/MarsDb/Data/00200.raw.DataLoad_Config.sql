TRUNCATE TABLE [raw].[DataLoad_Config]
GO

--SET IDENTITY_INSERT [raw].[DataLoad_Config] ON
--INSERT [raw].[DataLoad_Config] ([ID], [DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (1, N'FXSpot', N'UAT', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMU-D8-3076\TRIDENTU01;Trusted_Connection=Yes', N'MarketData', N'select COBDate, BaseCurrency, VariableCurrency, Rate,Domain from dbo.t_FXSpotRate where COBDate = ''{yyyy-MM-dd}''', NULL, NULL, NULL, NULL, N'FXSpot', N'p_Control_FXSpot', NULL, NULL, 1, CAST(0x07007D75F15C6B3B0B AS DateTime2), N'MARKETS\svcMRAPU', CAST(0x07007D75F15C6B3B0B AS DateTime2), N'MARKETS\svcMRAPU')
--SET IDENTITY_INSERT [raw].[DataLoad_Config] OFF
--GO


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Holiday-Calendar',
	'DEV',
	'SQL Database',
	'Provider=SQLNCLI10.1;Data Source=FMD-D8-3076\TRIDENTD01;Initial Catalog=quartz;Trusted_Connection=Yes',
	'Quartz',
	'exec [dbo].[QRTZ_CALENDAR]',
	NULL,	-- FilePath
	NULL,	-- FileName
	NULL,	-- Worksheet
	NULL,	-- Range
	'Holiday',	-- StagingTable
	'p_Control_Calendar',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C008631',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C008631'	-- CreatedBy
)
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'FXSpot', N'UAT', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMU-D8-3076\TRIDENTU01;Trusted_Connection=Yes', N'MarketData', N'select COBDate, BaseCurrency, VariableCurrency, Rate,Domain from dbo.t_FXSpotRate where COBDate = ''{yyyy-MM-dd}''', NULL, NULL, NULL, NULL, N'FXSpot', N'p_Control_FXSpot', NULL, NULL, 1, CAST(0x07007D75F15C6B3B0B AS DateTime2), N'MARKETS\svcMRAPU', CAST(0x07007D75F15C6B3B0B AS DateTime2), N'MARKETS\svcMRAPU')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'FXSpot', N'PROD', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes', N'MarketData', N'select COBDate, BaseCurrency, VariableCurrency, Rate,Domain from dbo.t_FXSpotRate where COBDate = ''{yyyy-MM-dd}''', NULL, NULL, NULL, NULL, N'FXSpot', N'p_Control_FXSpot', NULL, NULL, 1, CAST(0x07007D75F15C6B3B0B AS DateTime2), N'MARKETS\svcMRAPP', CAST(0x07007D75F15C6B3B0B AS DateTime2), N'MARKETS\svcMRAPP')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'Hierarchy', N'PROD', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes', N'Hierarchy', N'select * FROM core.Hierarchy WHERE (Start <= ''{yyyyMMdd} 23:59:59'') AND (Finish > ''{yyyyMMdd} 23:59:59'')', NULL, NULL, NULL, NULL, N'Hierarchy', N'p_Control_Hierarchy', NULL, NULL, 1, CAST(0x076069156264733B0B AS DateTime2), N'MARKETS\C008631', CAST(0x076069156264733B0B AS DateTime2), N'MARKETS\C008631')
INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'ScenarioHierarchy',
	'UAT',
	'SQL Database',
	'Provider=SQLNCLI10.1;Data Source=FMU-D8-3076\TRIDENTU01;Initial Catalog=ScenarioVault;Trusted_Connection=Yes',
	'ScenarioVault',
	'SELECT BusinessDate, NodeId, NodeParentId, [Level], NodeName, AggregatioType, HierarchyString FROM ScenarioVault.target.fMarsScenarioExtract (''{yyyyMMdd}'')',
	NULL,	-- FilePath
	NULL,	-- FileName
	NULL,	-- Worksheet
	NULL,	-- Range
	'ScenarioHierarchy',	-- StagingTable
	'p_Control_ScenarioHierarchy',			-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',		-- TriggerDay
	1,						-- Active
	getdate(),				-- DateUpdated
	'MARKETS\C002594',		-- UpdatedBy
	getdate(),				-- DateCreated
	'MARKETS\C002594'		-- CreatedBy
)
INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'ScenarioHierarchy',
	'PROD',
	'SQL Database',
	'Provider=SQLNCLI10.1;Data Source=FMP-D8-3076\TRIDENTP01;Initial Catalog=ScenarioVault;Trusted_Connection=Yes',
	'ScenarioVault',
	'SELECT BusinessDate, NodeId, NodeParentId, [Level], NodeName, AggregatioType, HierarchyString FROM ScenarioVault.target.fMarsScenarioExtract (''{yyyyMMdd}'')',
	NULL,	-- FilePath
	NULL,	-- FileName
	NULL,	-- Worksheet
	NULL,	-- Range
	'ScenarioHierarchy',	-- StagingTable
	'p_Control_ScenarioHierarchy',			-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',		-- TriggerDay
	1,						-- Active
	getdate(),				-- DateUpdated
	'MARKETS\C002594',		-- UpdatedBy
	getdate(),				-- DateCreated
	'MARKETS\C002594'		-- CreatedBy
)
INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Limit',
	'DEV',
	'SQL Database',
	'Provider=SQLNCLI10.1;Data Source=FMD-D8-3076\TRIDENTD01;Initial Catalog=LimitsDev;Trusted_Connection=Yes',
	'LimitsDev',
	'SELECT LimitId,LimitStartDate,LimitEndDate,HierarchyPath,[Source],[SourceOrigin] ,RiskMeasureTypeGroup,RiskMeasureTypeName,LimitName,LimitCategory,LimitCategoryPriority,LimitValue,IsOverride,LimitOwner,RiskApprover,LimitApprover,ApprovedFlag FROM [LimitsDev].[target].[fMarsLimitExtract] (''{yyyyMMdd}'')',
	NULL,	-- FilePath
	NULL,	-- FileName
	NULL,	-- Worksheet
	NULL,	-- Range
	'limit',	-- StagingTable
	'p_control_Limit',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C008631',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C008631'	-- CreatedBy
)
INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Limit',
	'PROD',
	'SQL Database',
	'Provider=SQLNCLI10.1;Data Source=FMP-D8-3076\TRIDENTP01;Initial Catalog=Limits;Trusted_Connection=Yes',
	'LimitsDev',
	'SELECT LimitId,LimitStartDate,LimitEndDate,HierarchyPath,[Source],[SourceOrigin] ,RiskMeasureTypeGroup,RiskMeasureTypeName,LimitName,LimitCategory,LimitCategoryPriority,LimitValue,IsOverride,LimitOwner,RiskApprover,LimitApprover,ApprovedFlag FROM [LimitsDev].[target].[fMarsLimitExtract] (''{yyyyMMdd}'')',
	NULL,	-- FilePath
	NULL,	-- FileName
	NULL,	-- Worksheet
	NULL,	-- Range
	'limit',	-- StagingTable
	'p_control_Limit',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C008631',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C008631'	-- CreatedBy
)
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'BondRisk', N'UAT', N'CSV File', NULL, NULL, NULL, N'C:\Users\c008631\Documents\Zion\Test Data Files', N'bond_risk_{yyyyMMdd}.csv', N'Sheet1', NULL, N'BondRisk', NULL, N'Mo,Tu,We,Th,Fr', NULL, 0, CAST(0x0720B7723891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x0720B7723891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'BondRiskTest', N'Dev', N'CSV File', NULL, NULL, NULL, N'C:\Users\c008631\Documents\Zion\Test Data Files', N'bond_risk_{yyyyMMdd}.csv', N'Sheet2', NULL, N'BondRisk', NULL, N'Mo,Tu,We,Th,Fr', NULL, 0, CAST(0x0790C8733891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x0790C8733891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'TridentBondPosition', N'DEV', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMU-D8-3076\TRIDENTU01;Trusted_Connection=Yes', N'Trident', N'EXEC Report.p_SimraFeed_BondRisk ''{yyyyMMdd}'',Null', NULL, NULL, NULL, NULL, N'TridentBondPosition', N'p_Control_Position', NULL, NULL, 0, CAST(0x0770B4E28D92283B0B AS DateTime2), N'MARKETS\C008631', CAST(0x0770B4E28D92283B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'TridentBondPosition', N'PROD', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes', N'Trident', N'SELECT C.*,ISNULL(M.Source, g.OriginalDataSource) AS ''Origin''
FROM Report.t_CR01 C
LEFT JOIN
(
 SELECT ISIN,PRODUCT,SOURCE FROM ETL.t_MoRisk WHERE ReportingDate = ''{yyyyMMdd}'' GROUP BY ISIN,PRODUCT,SOURCE
)M
ON M.ISIN = C.ISIN
 AND M.Product = C.Product
LEFT JOIN
(
 SELECT TradeIdentifier, OriginalDataSource
 FROM [Trident].[ETL].[t_GDI_Deal]
 WHERE ReportingDate = ''{yyyyMMdd}''
) G
ON C.TradeID = G.TradeIdentifier
WHERE c.Product IN (''BOND'',''BOND INDEX LINKED'',''CDS'')
 AND C.ReportDate = ''{yyyyMMdd}''
 AND C.Maturity >= ''{yyyyMMdd}''
 AND C.Notional <> 0', NULL, NULL, NULL, NULL, N'TridentBondPosition', N'p_Control_Position', NULL, NULL, 0, CAST(0x0770B4E28D92283B0B AS DateTime2), N'MARKETS\C002594', CAST(0x0770B4E28D92283B0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'TridentBondPosition', N'UAT', N'SQL Database', N'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes', N'Trident', N'SELECT C.*,ISNULL(M.Source, g.OriginalDataSource) AS ''Origin''
FROM Report.t_CR01 C
LEFT JOIN
(
 SELECT ISIN,PRODUCT,SOURCE FROM ETL.t_MoRisk WHERE ReportingDate = ''{yyyyMMdd}'' GROUP BY ISIN,PRODUCT,SOURCE
)M
ON M.ISIN = C.ISIN
 AND M.Product = C.Product
LEFT JOIN
(
 SELECT TradeIdentifier, OriginalDataSource
 FROM [Trident].[ETL].[t_GDI_Deal]
 WHERE ReportingDate = ''{yyyyMMdd}''
) G
ON C.TradeID = G.TradeIdentifier
WHERE c.Product IN (''BOND'',''BOND INDEX LINKED'',''CDS'')
 AND C.ReportDate = ''{yyyyMMdd}''
 AND C.Maturity >= ''{yyyyMMdd}''
 AND C.Notional <> 0', NULL, NULL, NULL, NULL, N'TridentBondPosition', N'p_Control_Position', NULL, NULL, 1, CAST(0x07D0C359F3506B3B0B AS DateTime2), N'MARKETS\C008631', CAST(0x07D0C359F3506B3B0B AS DateTime2), N'MARKETS\C008631')

INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_Stressed', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_StressTest_Pnl.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x07C03D743891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x07C03D743891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_StressedVar1D_LBG', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_stress_var_1_day_lbg_Pnl.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x07F0B2743891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x07F0B2743891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_Var1D', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_var_1_day_Pnl.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x07304F753891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x07304F753891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_Var10D', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_var_10_day_Pnl.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x0760C4753891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x0760C4753891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_StressTestRMT', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_StressTest_Pnl_RMT.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Mo,Tu,We,Th,Fr', NULL, 0, CAST(0x079039763891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x079039763891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_VarPnLRMT', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_VaR_Pnl_RMT.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Mo,Tu,We,Th,Fr', NULL, 0, CAST(0x07D0D5763891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x07D0D5763891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraVaR_Stressed', N'UAT', N'XL File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRA Reports\{yyyy-MM-dd}\FLASH\SSF*\Stress testing', N'FM_Trading_Book_Extreme_Stress_Report_LBG_SSF*_*-*-*-*-*-*.xls', N'Stress Data', NULL, N'SimraRiskVaR', N'p_Control_SimraRiskVaR', N'Mo,Tu,We,Th,Fri', NULL, 0, CAST(0x0750D5040F625D3B0B AS DateTime2), N'MARKETS\C008631', CAST(0x0750D5040F625D3B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_StressedVaR10D_HBOS', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_stress_var_10_day_hbos_Pnl.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Fr', NULL, 1, CAST(0x077081BEC089473B0B AS DateTime2), N'MARKETS\C008631', CAST(0x077081BEC089473B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraPnL_StressedVaR10D_LBG', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabodev.markets.global.lloydstsb.com\simrabo_Live$\SIMRAToBridgeExtract\PROD', N'{yyyyMMdd}_*_stress_var_10_day_lbg_Pnl.csv', N'Sheet1', NULL, N'SimraRiskPnL', N'p_Control_SimraRiskPnL', N'Fr', NULL, 1, CAST(0x07A0D1783891403B0B AS DateTime2), N'MARKETS\C008631', CAST(0x07A0D1783891403B0B AS DateTime2), N'MARKETS\C008631')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraFORiskMeasures', N'PROD', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRAToMarsExtract\PROD', N'{yyyymmdd}_*_front_office.csv', NULL, NULL, N'SimraFORiskMeasures', N'p_Control_SimraFORiskMeasures', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x07A0B639A367283C0B AS DateTime2), N'MARKETS\C002594', CAST(0x07A0B639A367283C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraVaR1DPnLs', N'PROD', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRAToMarsExtract\PROD', N'{yyyymmdd}_*_var_1_day_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraVaR10DPnLs', N'PROD', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRAToMarsExtract\PROD', N'{yyyymmdd}_*_var_10_day_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraSVaR1DPnLs', N'PROD', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRAToMarsExtract\PROD', N'{yyyymmdd}_*_stress_var_1_day_lbg_pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraSVaR10DPnLs', N'PROD', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRAToMarsExtract\PROD', N'{yyyymmdd}_*_stress_var_10_day_lbg_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraCore1StressTests', N'PROD', N'CSV File', NULL, NULL, NULL, N'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\SIMRAToMarsExtract\PROD', N'{yyyymmdd}_*_stress_tests_core1_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraFORiskMeasures', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\emea.tsrtdom.com\dfsroot\LDN\Data\Common\BusinessApplicationDelivery\Apps\MaRS\Feeds\SIMRA', N'{yyyymmdd}_*_front_office.csv', NULL, NULL, N'SimraFORiskMeasures', N'p_Control_SimraFORiskMeasures', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x07A0B639A367283C0B AS DateTime2), N'MARKETS\C002594', CAST(0x07A0B639A367283C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraVaR1DPnLs', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\emea.tsrtdom.com\dfsroot\LDN\Data\Common\BusinessApplicationDelivery\Apps\MaRS\Feeds\SIMRA', N'{yyyymmdd}_*_var_1_day_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraVaR10DPnLs', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\emea.tsrtdom.com\dfsroot\LDN\Data\Common\BusinessApplicationDelivery\Apps\MaRS\Feeds\SIMRA', N'{yyyymmdd}_*_var_10_day_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraSVaR1DPnLs', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\emea.tsrtdom.com\dfsroot\LDN\Data\Common\BusinessApplicationDelivery\Apps\MaRS\Feeds\SIMRA', N'{yyyymmdd}_*_stress_var_1_day_lbg_pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraSVaR10DPnLs', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\emea.tsrtdom.com\dfsroot\LDN\Data\Common\BusinessApplicationDelivery\Apps\MaRS\Feeds\SIMRA', N'{yyyymmdd}_*_stress_var_10_day_lbg_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')
INSERT [raw].[DataLoad_Config] ([DataFeed], [Environment], [SourceType], [Connection], [Database], [Query], [FilePath], [FileName], [WorkSheet], [Range], [StagingTable], [PostLoadProcessing], [TriggerDay], [TriggerTime], [Active], [DateUpdated], [UpdatedBY], [DateCreated], [CreatedBy]) VALUES (N'SimraCore1StressTests', N'UAT', N'CSV File', NULL, NULL, NULL, N'\\emea.tsrtdom.com\dfsroot\LDN\Data\Common\BusinessApplicationDelivery\Apps\MaRS\Feeds\SIMRA', N'{yyyymmdd}_*_stress_tests_core1_Pnl.csv', NULL, NULL, N'SimraPnLs', N'p_Control_SimraPnLs', N'Mo,Tu,We,Th,Fr', NULL, 1, CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594', CAST(0x075078C4F0632F3C0B AS DateTime2), N'MARKETS\C002594')


--INSERT INTO raw.DataLoad_Config (
--	[DataFeed],
--	[Environment],
--	[SourceType],
--	[Connection],
--	[DATABASE],
--	[Query],
--	[FilePath],
--	[FileName],

--	[WorkSheet],
--	[Range],
--	[StagingTable],
--	[PostLoadProcessing],
--	[TriggerDay],
--	[Active],
--	[DateUpdated],
--	[UpdatedBy],
--	[DateCreated],
--	[CreatedBy]
--) VALUES (
--	'OEP-BookLevel',
--	'PROD',
--	'SQL Database',
--	'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes',
--	'OEP',
--	'exec dbo.p_MaRSOEPBookLevelOEP @COB=''{yyyyMMdd}''',
--	NULL,			-- FilePath
--	NULL,			-- FileName
--	NULL,			-- Worksheet
--	NULL,			-- Range
--	'OEPBookLevelOEP',	-- StagingTable
--	NULL,		 	-- PostLoadProcessing
--	'Mo,Tu,We,Th,Fr',	-- TriggerDay
--	1,			-- Active
--	getdate(),		-- DateUpdated
--	'MARKETS\C002594',	-- UpdatedBy
--	getdate(),		-- DateCreated
--	'MARKETS\C002594'	-- CreatedBy
--)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-BookLevel',
	'PROD',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPBookLevelOEP @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPBookLevelOEP',	-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-Cash',
	'PROD',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPCash @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPParisCash',		-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-DeltaLadder',
	'PROD',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPDeltaLadder @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPParisDeltaLadder',	-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-VegaLadder',
	'PROD',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPVegaLadder @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPParisVegaLadder',	-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-Finance',
	'PROD',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMP-D8-3076\TRIDENTP01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPFinance @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPFinance',		-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-BookLevel',
	'DEV',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMD-D8-3076\TRIDENTD01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPBookLevelOEP @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range

	'OEPBookLevelOEP',	-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-Cash',
	'DEV',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMD-D8-3076\TRIDENTD01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPCash @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPParisCash',		-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-DeltaLadder',
	'DEV',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMD-D8-3076\TRIDENTD01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPDeltaLadder @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPParisDeltaLadder',	-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-VegaLadder',
	'DEV',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMD-D8-3076\TRIDENTD01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPVegaLadder @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPParisVegaLadder',	-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'OEP-Finance',
	'DEV',
	'SQL Database',
	'Provider=SQLOLEDB.1;Data Source=FMD-D8-3076\TRIDENTD01;Trusted_Connection=Yes',
	'OEP',
	'exec dbo.p_MaRSOEPFinance @COB=''{yyyyMMdd}''',
	NULL,			-- FilePath
	NULL,			-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'OEPFinance',		-- StagingTable
	NULL,		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Murex-ComData31',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfmurexreports\MurexReports$\{yyyyMMdd}',	-- FilePath
	'comdata31.csv',				-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'MurexSensitivities_Comdata31',	-- StagingTable
	'p_Control_MurexSensitivities',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Murex-ComGrk',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfmurexreports\MurexReports$\{yyyyMMdd}',	-- FilePath
	'com_grk.csv',					-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'MurexSensitivities_Com_grk',	-- StagingTable
	'p_Control_MurexSensitivities',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Murex-COmiCommod',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfmurexreports\MurexReports$\{yyyyMMdd}',	-- FilePath
	'c_omi_commod_new.csv',				-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'MurexSensitivities_C_omi_commod',	-- StagingTable
	'p_Control_MurexSensitivities',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)


INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'Murex-ComPvbp',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfmurexreports\MurexReports$\{yyyyMMdd}',	-- FilePath
	'Com_pvbp.csv',					-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'MurexSensitivities_Com_pvbp',	-- StagingTable
	'p_Control_MurexSensitivities',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SummitBondPosition',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\summitdata\summitreports\{yyyyMMdd}',		-- FilePath
	'BondPos_ALL.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SummitBondPosition',	-- StagingTable
	'p_Control_Position',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_BondSwapSpread',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_BondSwapSpread_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_CashSwapRate',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_CashSwapRate_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_CreditAssetSwap',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_CreditAssetSwap_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_CreditCDSCompositesSpread',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_CreditCDSCompositesSpread_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing

	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_CreditCDSIndex',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_CreditCDSIndex_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_ForeignExchangeVolatilitySwaps',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_ForeignExchangeVolatilitySwaps_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_FRASwap',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_FRASwap_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_FXSpotRates',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_FXSpotRates_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_FXVol',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_FXVol_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InflationVol',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InflationVol_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InflationRate',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InflationRate_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateCrossCurrencyBasisSpreadSwaps',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateCrossCurrencyBasisSpreadSwaps_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateCrossCurrencyBasisSpreadSwapsOIS',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateCrossCurrencyBasisSpreadSwapsOIS_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateFRASwapsOIS',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateFRASwapsOIS_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateTenorBasisSpreadSwaps',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateTenorBasisSpreadSwaps_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateTenorBasisSpreadSwapsOIS',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateTenorBasisSpreadSwapsOIS_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateVolatilitySwaps',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateVolatilitySwaps_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],

	[CreatedBy]
) VALUES (
	'SimraMD_InterestRateVolatilitySwapsOIS',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_InterestRateVolatilitySwapsOIS_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_IRVol',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_IRVol_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_LIBORSpread',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_LIBORSpread_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_TenorBasisSpread',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_TenorBasisSpread_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_X-CCYBasisSpread',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_X-CCYBasisSpread_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'SimraMD_ZeroForward',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfsimrabolive.markets.global.lloydstsb.com\SIMRABO_Live$\RiskPlatformExtract\MarketDataExtract\PROD',		-- FilePath
	'{yyyymmdd}_ZeroForward_*.csv',						-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'SimraMarketData',			-- StagingTable
	'p_Control_SimraMarketData',		 	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

--==========================================================--

INSERT INTO raw.DataLoad_Config (
	[DataFeed],
	[Environment],
	[SourceType],
	[Connection],
	[DATABASE],
	[Query],
	[FilePath],
	[FileName],
	[WorkSheet],
	[Range],
	[StagingTable],
	[PostLoadProcessing],
	[TriggerDay],
	[Active],
	[DateUpdated],
	[UpdatedBy],
	[DateCreated],
	[CreatedBy]
) VALUES (
	'MurexOptionTrade',
	'PROD',
	'CSV File',
	NULL,
	NULL,
	NULL,
	'\\cmfmurexreports\MurexReports$\{yyyyMMdd}',	-- FilePath
	'c_omi_opt_new.csv',				-- FileName
	NULL,			-- Worksheet
	NULL,			-- Range
	'MurexPositions_C_omi_opt',	-- StagingTable
	'p_Control_MurexOptionTrade',	-- PostLoadProcessing
	'Mo,Tu,We,Th,Fr',	-- TriggerDay
	1,			-- Active
	getdate(),		-- DateUpdated
	'MARKETS\C002594',	-- UpdatedBy
	getdate(),		-- DateCreated
	'MARKETS\C002594'	-- CreatedBy
)

GO

