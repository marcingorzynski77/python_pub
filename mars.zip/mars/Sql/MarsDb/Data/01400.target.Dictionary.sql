declare @Dictionary table ( [id] int identity(1,1), [table] nvarchar(100), [column] nvarchar(100), [value] nvarchar(1000))

insert @Dictionary ([table],[column],[value])
values
 (N'InstrumentType',NULL,N'The Type and SubType of Instruments')
,(N'InstrumentType',N'InstrumentType',N'The instrument Type (e.g. Risky Bonds  Government Bonds  Foreign Exchange Forwards  Money Markets)')
,(N'InstrumentType',N'InstrumentSubType',N'The Instrument SubType  where applicable (e.g. InstrumentType Foreign Exchange Forwards could have FX Swap or FX Forward)')
---------------------------------
,(N'Hierarchy',NULL,N'Holds a demormalised representation of the Hierarchy conformed to the levels levels supported by the standardised Hierarchy')
,(N'Hierarchy',N'HierarchyKey',N'Unique numeric Index to be referenced when associating with Facts')
,(N'Hierarchy',N'NodeName',N'PK - The Name of the Hierarchy node as specified by Risk Platforms - Normally the same as that used in PARIS.')
,(N'Hierarchy',N'NodeType',N'PK - The type of Node in the following domain of values; GR')
,(N'Hierarchy',N'NodeId',N'A mnemonic representing the node in the Risk defined hierarchy. Unique numeric Index to be referenced when associating with Facts')
,(N'Hierarchy',N'NodeParentID',N'A mnemonic representing the node of the Parent Risk Node in the Risk defined hierarchy')
,(N'Hierarchy',N'Ordinality',N'The sequence of Presentation on Risk Reports')
,(N'Hierarchy',N'Reporting',N'1 if the risk node is to be included in Risk reports or 0 for it to be ignored.')
,(N'Hierarchy',N'BookLegalEntity',N'The Legal Entity applicable for this book (if applicable - non-books do not have a value for this)')
,(N'Hierarchy',N'Group',N'The Business Group which owns the Businesses Units')
,(N'Hierarchy',N'Business',N'The Businesses Unit owned by the Group  which own the Business Areas')
,(N'Hierarchy',N'BusinessArea',N'The Business Areas owned by the Business Unit  which own the Divisions or Desks')
,(N'Hierarchy',N'Division',N'The Division owned by the Business Area  which own the Desks')
,(N'Hierarchy',N'Desk',N'The Desks owned by the Business Area or Division  which own the Sub-Desks and/or Books')
,(N'Hierarchy',N'SubDesk',N'The Sub-Desks owned by the Desks  which own Books')
,(N'Hierarchy',N'Book',N'The Books owned by the Desks & Sub-Desks which hold positions.')
,(N'Hierarchy',N'BookSystem',N'The Original System from which trades or positions is a book derive. There may be several instances of a book  each from different systems so this will allow each to be separately identified.')
,(N'Hierarchy',N'HierarchyString',N'The Original Hierarchy maintained by Risk Platforms  based on a feed from PARIS')
,(N'Hierarchy',N'AppliedRules',N'Traceability - List of the data conformance rules which have been automatically applied to this record')
---------------------------------
,(N'Calendar',N'Date',N'The Date that is the subject of the other columns')
,(N'Calendar',N'DateString',N'The Date represented as a string in the format YYYY/MM/DD')
,(N'Calendar',N'Year',N'Year Component of the Date column')
,(N'Calendar',N'Quarter',N'Quarter relevant to the Date column')
,(N'Calendar',N'Month',N'Month Component of the Date column  leading zero padded to two characters')
,(N'Calendar',N'Day',N'The day in the month  leading zero padded to two characters')
,(N'Calendar',N'WeekDay',N'Two character day of the week as follows... Mo(nday)  Tu(sday)  We(dnesday)  Th(ursday)  Fr(iday)  Sa(turday) or Su(nday)')
,(N'Calendar',N'WeekNo',N'The number of the week within the year leading zero padded to two characters')
,(N'Calendar',N'WeekEnd',N'Y for Saturday & Sunday  Otherwise N')
,(N'Calendar',N'PeriodEnd',N'M for Calandar Month end  Q for Calandar Quarter End  Y for Calandar year end  otherwise N')
,(N'Calendar',N'Archived',N'N for the data is available in the database  Y for the data has been archived and purged. A configurable number of the most recent days will be kept and all period ends')
,(N'Calendar',N'WorkingDay',N'Y is the date is/was a working day  observing the holiday calandar (and weekends) for the location  Otherwise N')
,(N'Calendar',N'NextWorkingDate',N'The next working day after the the date  observing the holiday calandar (and weekends) for the location')
,(N'Calendar',N'PreviousWorkingDate',N'Previous working day before the the date  observing the holiday calandar (and weekends) for the location')
---------------------------------
,(N'FxSpot_Fact',NULL,N'FX Rate Market Data for particular business dates')
,(N'FxSpot_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'FxSpot_Fact',N'BusDate',N'The BusinessDate on which the RiskMeasure is measured')
,(N'FxSpot_Fact',N'SourceKey',N'The Original Source system from which this FX Rate was obtained')
,(N'FxSpot_Fact',N'BaseCurrency',N'The Base Currency for the FX Rate.  We have one of these.')
,(N'FxSpot_Fact',N'VariableCurrency',N'The Variable Currency for the FX Rate.  We have a number of these determined by Rate')
,(N'FxSpot_Fact',N'Rate',N'The Rate of exchange for one Unit of the Base Currency into the Variable Currency')
,(N'FxSpot_Fact',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
---------------------------------
,(N'ScenarioHierarchy',NULL,N'A hierarchy for aggregation of Stress Scenarios.  This determines how to combine a set of Stress Results at a particular node in the organisation hierarchy to give a single overall result for Stress Tests at that node')
,(N'ScenarioHierarchy',N'NodeId',N'Node ID in the Scnario Hierarchy')
,(N'ScenarioHierarchy',N'NodeParentID',N'Parent Scenario Hierarchy node ID')
,(N'ScenarioHierarchy',N'Level',N'The level in the Scenario Hierarchy for this node')
,(N'ScenarioHierarchy',N'ScenarioNodeName',N'The name of this node in the Scenario Hierarchy')
,(N'ScenarioHierarchy',N'AggregationType',N'How the immediate children of this node are combined to give an aggregate Stress result at this node.  Might be "Sum" or "Worst of"')
,(N'ScenarioHierarchy',N'NameLevel1',N'The name of the node at level 1 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel2',N'The name of the node at level 2 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel3',N'The name of the node at level 3 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel4',N'The name of the node at level 4 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel5',N'The name of the node at level 5 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel6',N'The name of the node at level 6 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel7',N'The name of the node at level 7 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel8',N'The name of the node at level 8 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'NameLevel9',N'The name of the node at level 9 in the Scenario Hierarchy on the path to this node')
,(N'ScenarioHierarchy',N'ScenarioHierarchyString',N'The full path through the Scenario Hierarchy of this node')
---------------------------------
,(N'Instrument',N'InstrumentKey',N'Unique numeric Index to be referenced when associating with Facts')
,(N'Instrument',N'Product',N'An enumerated list  indicating the type of the productfor the position  e.g. BOND')
,(N'Instrument',N'InstrumentID',N'An industry identifier for the instrument in the position  unique when combined with the instrument type.could be ISIN  SEDOL  CUSIP  QUICK  or internal ID  etc')
,(N'Instrument',N'ISIN',N'International Securities Identification Number')
,(N'Instrument',N'ProductName',N'A descriptive display namefor the instrument')
,(N'Instrument',N'IssueCountry',N'The country where the Issuer  issued the product')
,(N'Instrument',N'Ticker',N'The market data vendor short code (normally Bloomberg) for the instrument')
,(N'Instrument',N'Maturity',N'Maturity date or <NULL> for instruments that are open ended')
,(N'Instrument',N'Sector',N'The textual description of the industry sector applicable to the instrument')
,(N'Instrument',N'Currency',N'The quotation/trading currency of the instrument')
,(N'Instrument',N'SeniorityLevel',N'The text SENIOR or SUBORDINATE as appropriate.')
,(N'Instrument',N'IssuerName',N'The name of the Issuer of the Instrument')
---------------------------------
,(N'Country',NULL,N'The country of issue a security')
,(N'Country',N'IssuerPhysicalCountry',N'The Physical country of the issuer')
,(N'Country',N'IssuerLogCountry',N'The logical country of the issuer')
,(N'Country',N'SecCountry',N'The country of the security')
---------------------------------
,(N'Rating',NULL,N'A collection of Credit Ratings from various sources')
,(N'Rating',N'SecSandP_RISKRATE',N'Rating from Standard & Poors')
,(N'Rating',N'SECMoodys_RISKRATE',N'Rating from Moodys')
,(N'Rating',N'INTERNAL_RISKRATE',N'LBG Internal rating')
,(N'Rating',N'SecECAI_RiskRate',N'External Credit Assessment Institutions rating')
,(N'Rating',N'SecHBOS_RiskRate',N'Rating from HBOS')
,(N'Rating',N'Fitch_RiskRate',N'Rating from Fitch')
---------------------------------
,(N'Limit_Fact',NULL,N'Limits: A Limit can exist at any node in the hierarchy and can apply to any quantity that can be measured or aggreagated at that node')
,(N'Limit_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'Limit_Fact',N'HierarchyKey',N'Unique key for the node in the hierarchy at which this Limit is applied')
,(N'Limit_Fact',N'SourceKey',N'The Original Source system from which this Limit was obtained')
,(N'Limit_Fact',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
,(N'Limit_Fact',N'RiskMeasureTypeKey',N'The type of this RiskMeasure to which the Limit is applied')
,(N'Limit_Fact',N'Name',N'The Name of this Limit')
,(N'Limit_Fact',N'LimitId',N'The Unique ID of this Limit.  This ID is constant over time for a particular Limit regarless of approval or override status and so can be relied upon to reference the valid instance of the Limit on the date requested')
,(N'Limit_Fact',N'CategoryName',N'The Limit Category (e.g. Management Action Trigger  Review Trigger)')
,(N'Limit_Fact',N'CategoryPriority',N'A textual description of the Limit as entered by the user who set it up')
,(N'Limit_Fact',N'Value',N'The value of the Limit.  The intention is that when a measure exceeds this value  the actions associated with the Limit are triggered')
,(N'Limit_Fact',N'IsOverride',N'Whether or not this Limit is an override.  An Override co-exists with a Limit and takes precedence in retrieval and reporting')
,(N'Limit_Fact',N'LimitStartDate',N'The Date on which this Limit becomes valid (there may be other isntances of this Limit that cover different periods)')
,(N'Limit_Fact',N'LimitEndDate',N'(The Date on which this Limit ceases to be valid (there may be other isntances of this Limit that cover different periods)')
,(N'Limit_Fact',N'LimitOwner',N'Usually the head of desk or business unit to which teh Limit is applied')
,(N'Limit_Fact',N'RiskApprover',N'The Risk Manager responsible for monitoring this Limit')
,(N'Limit_Fact',N'LimitApprover',N'Usually a more senior member of the business who approves the Limits for that business area')
,(N'Limit_Fact',N'ApprovedFlag',N'The Approval Status for this Limit.  Currently this field is for information only and does not prevent a Limit from being used in reports')
---------------------------------
,(N'MarketData_Fact',NULL,N'Various Market Data for particular business dates')
,(N'MarketData_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'MarketData_Fact',N'BusDate',N'The BusinessDate on which the RiskMeasure is measured')
,(N'MarketData_Fact',N'SourceKey',N'The Original Source system from which this FX Rate was obtained')
,(N'MarketData_Fact',N'RiskFactorTypeKey',N'The Risk Factor Type for this market data item')
,(N'MarketData_Fact',N'RiskFactorKey',N'The Risk Factor for this market data item')
,(N'MarketData_Fact',N'Value',N'The Market value for this Risk Factor on this BusDate')
,(N'MarketData_Fact',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
---------------------------------
,(N'MarketData_Fact_History',NULL,N'Various Market Data for particular business dates')
,(N'MarketData_Fact_History',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'MarketData_Fact_History',N'BusDate',N'The BusinessDate on which the RiskMeasure is measured')
,(N'MarketData_Fact_History',N'SourceKey',N'The Original Source system from which this FX Rate was obtained')
,(N'MarketData_Fact_History',N'RiskFactorTypeKey',N'The Risk Factor Type for this market data item')
,(N'MarketData_Fact_History',N'RiskFactorKey',N'The Risk Factor for this market data item')
,(N'MarketData_Fact_History',N'Value',N'The Market value for this Risk Factor on this BusDate')
,(N'MarketData_Fact_History',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
---------------------------------
,(N'PnL_Fact',NULL,N'PnL: The P&L data from SIMRA that relates to VaR  Stress Tests and other Calculations.')
,(N'PnL_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'PnL_Fact',N'InstrumentTypeBlipSize',N'')
,(N'PnL_Fact',N'PnLFunctionID',N'The SIMRA P&L Function used to calculate this value')
,(N'PnL_Fact',N'LegalEntity',N'The Legal Entity applicable to the aggregation containing this P&L value (if applicable)')
,(N'PnL_Fact',N'Cad2',N'The CAD2 status of this aggregation (if applicable)')
,(N'PnL_Fact',N'ScenarioDate',N'The ScenarioDate of this P&L in a set of results from an historical simulation')
,(N'PnL_Fact',N'ValueCurrency',N'The currency of the P&L Value')
,(N'PnL_Fact',N'Value',N'The P&L Value (in ValuerCurrency units)')
,(N'PnL_Fact',N'ValueGBP',N'The P&L Value in GBP')
---------------------------------
,(N'PnL_Fact_History',NULL,N'PnL: The P&L data from SIMRA that relates to VaR  Stress Tests and other Calculations.')
,(N'PnL_Fact_History',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'PnL_Fact_History',N'InstrumentTypeBlipSize',N'')
,(N'PnL_Fact_History',N'PnLFunctionID',N'The SIMRA P&L Function used to calculate this value')
,(N'PnL_Fact_History',N'LegalEntity',N'The Legal Entity applicable to the aggregation containing this P&L value (if applicable)')
,(N'PnL_Fact_History',N'Cad2',N'The CAD2 status of this aggregation (if applicable)')
,(N'PnL_Fact_History',N'ScenarioDate',N'The ScenarioDate of this P&L in a set of results from an historical simulation')
,(N'PnL_Fact_History',N'ValueCurrency',N'The currency of the P&L Value')
,(N'PnL_Fact_History',N'Value',N'The P&L Value (in ValuerCurrency units)')
,(N'PnL_Fact_History',N'ValueGBP',N'The P&L Value in GBP')
---------------------------------
,(N'VaR_Fact',NULL,N'VaR: The VaR calculated from SIMRA P&Ls.')
,(N'VaR_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'VaR_Fact',N'LegalEntity',N'The Legal Entity applicable to the aggregation containing this P&L value (if applicable)')
,(N'VaR_Fact',N'Cad2',N'The CAD2 status of this aggregation (if applicable)')
,(N'VaR_Fact',N'ConfidenceLevel',N'VaR Confidence Level')
,(N'VaR_Fact',N'ValueGBP',N'The VaR Value (in GBP)')
---------------------------------
,(N'VaR_Fact_History',NULL,N'VaR: The VaR calculated from SIMRA P&Ls.')
,(N'VaR_Fact_History',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'VaR_Fact_History',N'LegalEntity',N'The Legal Entity applicable to the aggregation containing this P&L value (if applicable)')
,(N'VaR_Fact_History',N'Cad2',N'The CAD2 status of this aggregation (if applicable)')
,(N'VaR_Fact_History',N'ConfidenceLevel',N'VaR Confidence Level')
,(N'VaR_Fact_History',N'ValueGBP',N'The VaR Value (in GBP)')
---------------------------------
,(N'Position_Fact',NULL,N'Positions being held in various portfolios')
,(N'Position_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'Position_Fact',N'BusDate',N'The BusinessDate on which the Position is measured')
,(N'Position_Fact',N'HierarchyKey',N'Unique key for the node in the hierarchy in which the Position is held')
,(N'Position_Fact',N'SourceKey',N'The Original Source system in which this Position was booked or aggregated (if known)')
,(N'Position_Fact',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
,(N'Position_Fact',N'InstrumentKey',N'The Instrument of the Position')
,(N'Position_Fact',N'MarketValue',N'The Market Value of the Position on the Business Date in the Currency of the Position')
,(N'Position_Fact',N'MarketValueGBP',N'The Market Value of the Position on the Business Date in GBP')
,(N'Position_Fact',N'ZSpread',N'The Z-Spread of the Position')
,(N'Position_Fact',N'CS01',N'The Credit Sensitivitiy of the Position (in GBP per basis point)')
,(N'Position_Fact',N'StandardisedCS01',N'The Standardised Credit Sensitivitiy of the Position (in GBP per basis point)')
---------------------------------
,(N'RiskFactor',NULL,N'RiskFactor from SIMRA')
,(N'RiskFactor',N'RiskFactorName',N'RiskFactor from SIMRA (includes Curve  CCY  etc. as appropriate)')
---------------------------------
,(N'RiskFactorType',NULL,N'Risk Factor Type from SIMRA')
,(N'RiskFactorType',N'RiskFactorTypeName',N'Risk Factor Type from SIMRA')
---------------------------------
,(N'RiskMeasure_Fact',NULL,N'Measures taken from current positions or portfolios which include amongst other things  sensitivitiy to changes in market rates  current P&L  scenario P&L and VaR')
,(N'RiskMeasure_Fact',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'RiskMeasure_Fact',N'BusDate',N'The BusinessDate on which the RiskMeasure is measured')
,(N'RiskMeasure_Fact',N'HierarchyKey',N'Unique key for the node in the hierarchy to which this RiskMeasure applies')
,(N'RiskMeasure_Fact',N'SourceKey',N'The Original Source system in which this RiskMeasure was computed (if known)')
,(N'RiskMeasure_Fact',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
,(N'RiskMeasure_Fact',N'RiskMeasureTypeKey',N'The type of this RiskMeasure')
,(N'RiskMeasure_Fact',N'RiskFactorTypeKey',N'The Risk Factor Type to which this Risk Measure is mapped')
,(N'RiskMeasure_Fact',N'RiskFactorKey',N'The RiskFactor to which this Risk Measure is mapped')
,(N'RiskMeasure_Fact',N'InstrumentTenorKey',N'The Instrument Tenor (if applicable)')
,(N'RiskMeasure_Fact',N'UnderlyingTenorKey',N'The Tenor of the Underlying Instrument (if applicable)')
,(N'RiskMeasure_Fact',N'FixingTenorKey',N'The Fixing Tenor for the Instrument (if applicable)')
,(N'RiskMeasure_Fact',N'ProformaShift',N'The name of the ProForma Shift used to calculate the Risk Measure (if relevant)')
,(N'RiskMeasure_Fact',N'ProformaShiftValue',N'The shift size or blip value used to calculate the Risk Measure (if relevant)')
,(N'RiskMeasure_Fact',N'LegalEntity',N'The legal entity to which the position or portfolio being measured belongs')
,(N'RiskMeasure_Fact',N'Cad2',N'Whether or not this position or portfolio is in scope for CAD2')
,(N'RiskMeasure_Fact',N'InstrumentMatDays',N'The number of days between the Business Date and the Instrument Tenor')
,(N'RiskMeasure_Fact',N'UnderlyingMatDays',N'The number of days between the Business Date and the Underlying Tenor')
,(N'RiskMeasure_Fact',N'FixingMatDays',N'The number of days between the Business Date and the Fixing Tenor')
,(N'RiskMeasure_Fact',N'ValueCurrency',N'The currency in which the Risk Measure Value is being reported')
,(N'RiskMeasure_Fact',N'Value',N'The Value of the Risk Measure in the Value Currency')
,(N'RiskMeasure_Fact',N'ValueGBP',N'The Value of the Risk Measure in GBP')
---------------------------------
,(N'RiskMeasure_Fact_History',NULL,N'Measures taken from current positions or portfolios which include amongst other things  sensitivitiy to changes in market rates  current P&L  scenario P&L and VaR')
,(N'RiskMeasure_Fact_History',N'FactKey',N'Unique numeric Index for the fact. Note this is not unique in time  i.e. Several versions of the same fact can exist at different periods in time.')
,(N'RiskMeasure_Fact_History',N'BusDate',N'The BusinessDate on which the RiskMeasure is measured')
,(N'RiskMeasure_Fact_History',N'HierarchyKey',N'Unique key for the node in the hierarchy to which this RiskMeasure applies')
,(N'RiskMeasure_Fact_History',N'SourceKey',N'The Original Source system in which this RiskMeasure was computed (if known)')
,(N'RiskMeasure_Fact_History',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
,(N'RiskMeasure_Fact_History',N'RiskMeasureTypeKey',N'The type of this RiskMeasure')
,(N'RiskMeasure_Fact_History',N'RiskFactorTypeKey',N'The Risk Factor Type to which this Risk Measure is mapped')
,(N'RiskMeasure_Fact_History',N'RiskFactorKey',N'The RiskFactor to which this Risk Measure is mapped')
,(N'RiskMeasure_Fact_History',N'InstrumentTenorKey',N'The Instrument Tenor (if applicable)')
,(N'RiskMeasure_Fact_History',N'UnderlyingTenorKey',N'The Tenor of the Underlying Instrument (if applicable)')
,(N'RiskMeasure_Fact_History',N'FixingTenorKey',N'The Fixing Tenor for the Instrument (if applicable)')
,(N'RiskMeasure_Fact_History',N'ProformaShift',N'The name of the ProForma Shift used to calculate the Risk Measure (if relevant)')
,(N'RiskMeasure_Fact_History',N'ProformaShiftValue',N'The shift size or blip value used to calculate the Risk Measure (if relevant)')
,(N'RiskMeasure_Fact_History',N'LegalEntity',N'The legal entity to which the position or portfolio being measured belongs')
,(N'RiskMeasure_Fact_History',N'Cad2',N'Whether or not this position or portfolio is in scope for CAD2')
,(N'RiskMeasure_Fact_History',N'InstrumentMatDays',N'The number of days between the Business Date and the Instrument Tenor')
,(N'RiskMeasure_Fact_History',N'UnderlyingMatDays',N'The number of days between the Business Date and the Underlying Tenor')
,(N'RiskMeasure_Fact_History',N'FixingMatDays',N'The number of days between the Business Date and the Fixing Tenor')
,(N'RiskMeasure_Fact_History',N'ValueCurrency',N'The currency in which the Risk Measure Value is being reported')
,(N'RiskMeasure_Fact_History',N'Value',N'The Value of the Risk Measure in the Value Currency')
,(N'RiskMeasure_Fact_History',N'ValueGBP',N'The Value of the Risk Measure in GBP')
---------------------------------
,(N'RiskMeasureType',N'SourceKey',N'Unique numeric Index to be referenced when associating with Facts')
,(N'RiskMeasureType',N'RiskMeasureTypeName',N'Risk Measure Type Name')
,(N'RiskMeasureType',N'RiskMeasureFamily',N'Risk Measure Family')
,(N'RiskMeasureType',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
---------------------------------
,(N'Source',N'SourceKey',N'Unique numeric Index to be referenced when associating with Facts')
,(N'Source',N'InterfaceName',N'Traceability - Where several sources porport to contain the same date  this one was used')
,(N'Source',N'AppliedRules',N'Traceability - List of the data conformance rules which have been applied to this record')
---------------------------------
,(N'Tenor',NULL,N'The set of tenors that occur in the data')
,(N'Tenor',N'TenorName',N'The name of a tenor')
,(N'Tenor',N'TenorDate',N'When a tenor refers to a fixed date rather than a period relative to the present day (e.g. a fututes expiration date) then this is the date')
---------------------------------
,(N'Trade',N'TradeReference',N'The latest trade id')
,(N'Trade',N'TradeDateTime',N'The Date and Time that the trade occurred')
,(N'Trade',N'CaptureDateTime',N'The date & time that the record of the transation was first received')
,(N'Trade',N'AmendDateTime',N'The date & time that the trade was last amended')
,(N'Trade',N'AmendArea',N'The system that amended the trade')
,(N'Trade',N'AmendReason',N'A description for the the amendment')
,(N'Trade',N'BorS',N'Buy or Sell the product (for FX Options )')
,(N'Trade',N'ExpiryDate',N'The expiry date on the trade')
,(N'Trade',N'ExerciseType',N'Option Type European/American')
,(N'Trade',N'PutOrCall',N'Option Type Put/Call')
,(N'Trade',N'MaturityDate',N'The maturity of the trade')
,(N'Trade',N'ExerciseDate',N'The date on which an option is exercised')
,(N'Trade',N'Strike',N'The strike of an option')
,(N'Trade',N'ValueDate',N'The first contractual settlement date')
,(N'Trade',N'Price',N'For FX products  the FX rate agreed')
,(N'Trade',N'ReceiveCurrency',N'The Currency to be received')
,(N'Trade',N'ReceiveAmount',N'The amount to be received in the receive currency')
,(N'Trade',N'PayCurrency',N'The currency to be paid')
,(N'Trade',N'PayAmount',N'The amount of the payment currency to be made')
,(N'Trade',N'ForwardRate',N'For FX  the rate used at maturity')
,(N'Trade',N'PremiumCurrency',N'The currency of the premium paid/received')
,(N'Trade',N'PremiumAmount',N'The amount of the premium')
,(N'Trade',N'Maturity',N'The maturity as sourced from Simra')
,(N'Trade',N'Notional',N'The notional as sourced from Simra')
,(N'Trade',N'NotionalCurrency',N'The notional Currency as sourced from Simra')
,(N'Trade',N'AppliedRules',N'Soft transformation rules applied during load')
,(N'Trade',N'TradeTypeSubtype',N'Temporary filter for fxOption strike report')
---------------------------------

/*
SELECT * 
FROM sys.fn_listextendedproperty (NULL, 'schema', 'target', 'table', default, default, default)
*/
declare @id int, @sql nvarchar(max)
, @columnDrop nvarchar(max) = 'EXEC sys.sp_dropextendedproperty @level0type=N''SCHEMA'', @level0name=N''target'',@level1type=N''TABLE'', @level1name=N''<TABLE>'',@level2type=N''COLUMN'',@level2name=N''<COLUMN>'', @name=N''<NAME>''; '
, @tableDrop nvarchar(max) = 'EXEC sys.sp_dropextendedproperty @level0type=N''SCHEMA'', @level0name=N''target'',@level1type=N''TABLE'',	@level1name=N''<TABLE>'', @name=N''Description''; '
, @columnInsert nvarchar(max) = 'EXEC sys.sp_addextendedproperty @level0type=N''SCHEMA'', @level0name=N''target'',@level1type=N''TABLE'', @level1name=N''<TABLE>'',@level2type=N''COLUMN'',@level2name=N''<COLUMN>'', @name=N''Description'',@value=N''<VALUE>''; '
, @tableInsert nvarchar(max) = 'EXEC sys.sp_addextendedproperty @level0type=N''SCHEMA'', @level0name=N''target'',@level1type=N''TABLE'', @level1name=N''<TABLE>'', @name=N''Description'',@value=N''<VALUE>''; '
, @tbl varchar(100) = ''
, @col varchar(100) = ''
, @propname varchar(100) = ''

SELECT @tbl = min(t.[name])
FROM sys.tables t
JOIN sys.schemas s on s.schema_id = t.schema_id
WHERE 1 = 1
AND   s.[name] = 'target'

	
while( @tbl is not null )
begin
	
	print 'drop property for table : ' + @tbl
	select @sql  =  REPLACE(REPLACE(@tableDrop,'<TABLE>',objname),'<SCHEMA>','target')
	FROM sys.fn_listextendedproperty (NULL, 'schema', 'target', 'table', @tbl, default, default)
	where objname = @tbl

	if(@@ROWCOUNT > 0)
	begin 
		print @sql
		exec sp_executesql @sql
	end
	
	SELECT @col = min(objname)
	FROM sys.fn_listextendedproperty (NULL, 'schema', 'target', 'table', @tbl, 'column', default)
	where objname > ''
	


	while (@col is not null)
	begin

		SELECT @propname = min([name])
		FROM sys.fn_listextendedproperty (NULL, 'schema', 'target', 'table', @tbl, 'column', default)
		WHERE objname = @col
		AND   [name] > ''
		
		while ( @propname is not null)
		begin

			print 'drop property for column : ' + @tbl + ',' + @col	+ ',' + @propname
		
			select @sql  =  REPLACE(REPLACE(REPLACE(REPLACE(@columnDrop,'<TABLE>',@tbl),'<SCHEMA>','target'),'<COLUMN>',@col),'<NAME>',@propname)

			print @sql
			exec sp_executesql @sql			

			SELECT @propname = min(name)
			FROM sys.fn_listextendedproperty (NULL, 'schema', 'target', 'table', @tbl, 'column', default)
			WHERE objname = @col
			AND   [name] > @propname
			
		end
		
		SELECT @col = min(objname)
		FROM sys.fn_listextendedproperty (NULL, 'schema', 'target', 'table', @tbl, 'column', default)
		where objname > @col

	end 
	
	SELECT @tbl = min(t.[name])
	FROM sys.tables t
	JOIN sys.schemas s on s.schema_id = t.schema_id
	WHERE 1 = 1
	AND   s.[name] = 'target'
	AND	  t.[name] > @tbl

end


select @id = 0

while (@id is not null)
begin
	
	SELECT @sql = REPLACE(REPLACE(@tableInsert,'<TABLE>',[TABLE]),'<VALUE>',[VALUE])
	FROM @Dictionary WHERE ID = @id

	if(@@ROWCOUNT>0)
	begin 
		print @sql
		exec sp_executesql @sql
	end
	select @id = min(id) from @Dictionary where id > @id and [column] is null
	
end 


select @id = 0
while (@id is not null)
begin
	
	SELECT @sql = REPLACE(REPLACE(REPLACE(@columnInsert,'<COLUMN>',[column]),'<TABLE>',[TABLE]),'<VALUE>',[VALUE])
	FROM @Dictionary WHERE ID = @id

	if(@@ROWCOUNT>0)
	begin 
		print @sql
		exec sp_executesql @sql
	end
	
	select @id = min(id) from @Dictionary where id > @id and [column] is not null
	

end

