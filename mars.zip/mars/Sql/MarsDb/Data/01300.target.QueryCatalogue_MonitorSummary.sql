Update core.querycatalogue set Query =

'SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
    and WorkingDay = ''Y'' 
    and [DATE] < @offsetdate
order by [DATE] desc)

--set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
    busdate varchar(10)
    ,InterfaceName varchar(100)
    ,[Count] float
    ,Start varchar(50)
    ,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS Float)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                        Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                        [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                    and [KEY] like ''Active.%''
        ) x 
        PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
            SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [active.Start] AS ''Start'', 
                      [fact] 
            FROM   
            (
                    SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
                            Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                            [Fact] 
                    FROM   target.flexfactinstance I 
                    INNER JOIN target.flexfact F 
                            ON I.FlexFactKey = F.FlexFactKey 
                    INNER JOIN target.flexfacthierarchy H 
                            ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                    INNER JOIN (SELECT [date] AS offsetDate 
                                FROM   target.calendar 
                                WHERE left([date],10) = @Previousdate
                               ) AS TT 
                            ON F.busdate = TT.offsetdate 
                    INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                                FROM   target.F_targetdate() 
                                ORDER  BY targetdate) AS TT2 
                            ON F.start <= TT2.versiondatetime 
                               AND F.finish > TT2.versiondatetime 
                    LEFT OUTER JOIN target.source AS D_Source 
                                 ON F.sourcekey = D_Source.sourcekey 
                    WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                        and [KEY] like ''Active.%''
            ) x 
            PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([Difference] AS Float)) AS ''Count'' , 
                  [Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                      (case when H.[description] LIKE ( ''Reconciliation.PnL.%'' ) then ''Reconciliation''
                        when H.[description] LIKE ( ''Reconciliation.PnL_Adhoc.%'' ) then ''Reconciliation_Adhoc''
                        end) AS [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
                        ) x 
        PIVOT (Max([value]) FOR [key] IN ([Difference], [Start], [Finish])) p
    GROUP  BY [busdate], 
          [Start], 
          [Finish], 
          [fact], 
          [interfacename] 
                      
    

select busdate + '' ('' +   left(DATENAME(dw,busdate),2) + '')'' as busdate
    ,InterfaceName 
    ,(case when Fact like ''Reconciliation%'' and [Count] = 0 then 1 
           when Fact like ''Reconciliation%'' and [Count] <> 0 then -1 
           when Fact = ''FXSpot'' and [Count] = 1 then -1 
           else cast(round([Count],0) as Int) end) as ''Count''
    ,Start 
    ,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(20)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates'

where Name = 'Monitor Summary' 
and versionID = 1
and Alias = 'MonSum'