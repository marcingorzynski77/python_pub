﻿
SET IDENTITY_INSERT [core].[QueryCatalogue] ON
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (3, N'2017-04-19 11:20:57', N'1999-12-31 00:00:00', 11, N'FxSpot_Fact Monitor', N'Mon_FxSpot', 1, N'--
-- Summarise FX Fact feed loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.FXSpot_Fact F
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish
', N'Monitor FxSpot Feed loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (4, N'2017-04-19 11:21:46', N'1999-12-31 00:00:00', 11, N'MarketData_Fact Monitor', N'Mon_MarketData', 1, N'--
-- Summarise Market Data feed loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	R.RiskFactorTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.MarketData_Fact F
	JOIN
	target.RiskFactorType R
	ON
		F.RiskFactorTypeKey = R.RiskFactorTypeKey
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskFactorTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskFactorTypeName
', N'Summarise Market Data feed loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (5, N'2017-04-19 11:22:37', N'1999-12-31 00:00:00', 11, N'RiskMeasure_Fact Monitor', N'Mon_RiskMeasure', 1, N'--
-- Summarise RiskMeasure Fact loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.RiskMeasure_Fact F
	JOIN
	target.RiskMeasureType R
	ON
		F.RiskMeasureTypeKey = R.RiskMeasureTypeKey
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish
', N'Summarise RiskMeasure Fact loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (6, N'2017-04-19 11:23:11', N'2017-04-24 14:00:31', 11, N'PnL_Fact Monitor', N'Mon_PnL', 1, N'--
-- Summarise SIMRA PnL feed loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.PnL_Fact F
	JOIN
	target.RiskMeasureType R
	ON
		F.RiskMeasureTypeKey = R.RiskMeasureTypeKey
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName
', N'Summarise SIMRA PnL feed loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (7, N'2017-04-19 11:24:08', N'1999-12-31 00:00:00', 11, N'Position_Fact Monitor', N'Mon_Position', 1, N'--
-- Summarise Position Fact loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	R.InstrumentType,
	R.InstrumentSubType,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.Position_Fact F
	JOIN
	target.InstrumentType R
	ON
		F.InstrumentTypeKey = R.InstrumentTypeKey
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.InstrumentType,
	R.InstrumentSubType,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish
', N'Summarise Position Fact loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (8, N'2017-04-19 11:25:01', N'1999-12-31 00:00:00', 11, N'RiskFactor_dim Monitor', N'Mon_RiskFactor', 1, N'--
-- Summarise RiskFactor dimension loads
--

SELECT
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.RiskFactor F
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish
', N'Summarise RiskFactor dimension loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (9, N'2017-04-19 11:25:59', N'1999-12-31 00:00:00', 11, N'Hierarchy_dim Monitor', N'Mon_Hierarchy', 1, N'--
-- Summarise Hierarchy dimension loads
--

SELECT
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.Hierarchy F
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
GROUP BY
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish
', N'Summarise Hierarchy dimension loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (10, N'2017-04-24 14:00:31', N'2017-04-24 14:11:51', 11, N'PnL_Fact Monitor', N'Mon_PnL', 2, N'--
-- Summarise SIMRA PnL feed loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.PnL_Fact F
	JOIN
	target.RiskMeasureType R
	ON
		F.RiskMeasureTypeKey = R.RiskMeasureTypeKey
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
WHERE
	F.BusDate in (select top 5 BusDate from target.PnL_Fact order by BusDate desc)
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName
', N'Summarise SIMRA PnL feed loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (11, N'2017-04-24 14:11:51', N'1999-12-31 00:00:00', 11, N'PnL_Fact Monitor', N'Mon_PnL', 3, N'--
-- Summarise SIMRA PnL feed loads
--

SELECT
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish AS S_Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END AS [Status],
	count(*) AS [Count]
FROM
	target.PnL_Fact F
	JOIN
	target.RiskMeasureType R
	ON
		F.RiskMeasureTypeKey = R.RiskMeasureTypeKey
	JOIN
	target.Source S
	ON
		F.SourceKey = S.SourceKey
WHERE
	F.BusDate in (select top 5 BusDate from target.PnL_Fact group by BusDate order by BusDate desc)
GROUP BY
	F.BusDate,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName,
	CASE WHEN F.finish > getdate() THEN ''Active'' ELSE ''Dead'' END
ORDER BY
	F.BusDate DESC,
	F.Start,
	F.Finish,
	S.InterfaceName,
	S.Source,
	S.Origin,
	S.Finish,
	R.RiskMeasureTypeName
', N'Summarise SIMRA PnL feed loads', N'SQL', N'', N'', N'Skea, Alan (C002594)', 1, N'MARKETS\C002594 as MARKETS\C002594', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (52, N'2017-05-10 17:14:55', N'1999-12-31 00:00:00', 11, N'Support_Poison_Queue', N'SPQ', 1, N'USE QUARTZ

SET NOCOUNT ON

select '''' as ''Business Date'', JOB_NAME, 1 as ''Status'' from dbo.QRTZ_JOB_DETAILS where job_Group = ''Poison-Queue''', N'Returns any jobs currently in the poison queue', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (90, N'2017-08-29 16:00:07', N'1999-12-31 00:00:00', 11, N'OEP Query', N'OEP Query', 1, N'SELECT CAST(convert(VARCHAR, BusDate, 111) AS SMALLDATETIME), Desk, RIGHT(RiskFactorName,3), sum(ValueGBP) 
FROM RiskMeasure 
WHERE ProformaShift =''Base'' AND RiskMeasureTypeName =''OEP'' AND Desk in (''CCY Swaps Business'',''CSA Trading'',''EUR and USD Trading'',''GBP Flow'',''Inflation'',''IR Options'',''STIR Trading'') 
Group by CAST(convert(VARCHAR, BusDate, 111) AS SMALLDATETIME), Desk, RIGHT(RiskFactorName,3) 
Order by Desk, RIGHT(RiskFactorName,3) Asc ', N'OEP Query', N'SQL', N'', N'', N'Herblot, Alex (9325145)', 1, N'MARKETS\9325145 as MARKETS\9325145', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (53, N'2017-05-10 17:17:13', N'1999-12-31 00:00:00', 11, N'Support Target_Table_Count', N'STTC', 1, N'DECLARE @BUSDATE AS DATETIME
SET @BUSDATE = (Select busdate from target.f_busdate())

-- FX Spot
SELECT ''FX Spot'', COUNT(*) as ''RowCount'' FROM target.FXSpot_Fact F
 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
WHERE F.finish > GETUTCDATE() AND S.InterfaceName=''FxSpot'' AND F.BusDate = @BUSDATE
union all
-- Hierarchy
SELECT ''Hierarchy'', COUNT(*) as ''RowCount'' FROM target.Hierarchy F
 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
 WHERE F.finish > GETUTCDATE() AND S.InterfaceName = ''Hierarchy''
union all
-- Market Data
SELECT ''Market Data'', COUNT(*) as ''RowCount'' FROM target.MarketData_Fact F
 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%SimraMD%'' AND F.BusDate = @BUSDATE
union all
-- PnL
SELECT ''PnL'', COUNT(*) as ''RowCount'' FROM target.PnL_Fact F
 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%PnLs%'' AND F.BusDate = @BUSDATE
union all
-- Position
SELECT ''Position'' as ''Fact Table'', COUNT(*) as ''RowCount'' FROM target.Position_Fact F
 INNER JOIN target.InstrumentType R ON F.InstrumentTypeKey = R.InstrumentTypeKey
 INNER JOIN target.[Source] S ON F.SourceKey = S.SourceKey
WHERE F.BusDate = @BUSDATE AND F.Finish > GETUTCDATE() AND S.InterfaceName = ''Position''
union all
-- RiskMeasure
SELECT ''Risk Measure'', COUNT(*) as ''RowCount'' FROM target.RiskMeasure_Fact F
 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
 WHERE F.finish > GETUTCDATE() AND S.InterfaceName in (''SimraFORiskMeasures'',''MurexSensitivities'') AND F.BusDate = @BUSDATE
', N'Returns a count of rows inserted into target fact tables', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (54, N'2017-05-10 17:20:26', N'1999-12-31 00:00:00', 11, N'Support Time_Travel_Instance', N'STTI', 1, N'DECLARE @BUSDATE AS DATETIME
DECLARE @BUSDATE_T2 AS varchar(10)
DECLARE @BUSDATE_T3 AS varchar(10)

SET @BUSDATE = (Select busdate from target.f_busdate())
SET @BUSDATE_T2 = (Select target.f_CalendarOffset(''-1D'',@busdate))
SET @BUSDATE_T3 = (Select target.f_calendaroffset(''-2D'',@busdate))

select [Start]
      ,T.[Datafeed]
      ,isnull([FactTable],'''')as ''FactTable''
      ,isnull([Official],'''') as ''Official''
      ,isnull(ExternalReference,'''') as ''ExternalReference''
      ,(case when Start is null then 0 else 1 end) as ''Load Status''
      ,''... '' as '' ''
      ,isnull(a.[RowCount],0) as ''T-1''
      ,isnull(b.[RowCount],0) as ''T-2''
      ,isnull(c.[RowCount],0) as''T-3''
from
(
	Select [Start]
		  ,T2.[Datafeed]
		  ,[FactTable]      
		  ,[Official]
		  ,[ExternalReference]
	FROM
	(
		SELECT [Start]
		  ,[Datafeed]
		  ,[FactTable]      
		  ,[Official]
		  ,isnull([ExternalReference],'''') as ''ExternalReference''
		FROM [MaRS].[target].[TimeTravellingInstance]
		where Busdate = @BusDate
	)  T1
	full join  
	(
		select distinct datafeed from [MaRS].[target].[TimeTravellingInstance]
		where Busdate > DATEadd(day,-7,@Busdate)
	) T2
	on T1.Datafeed = T2.Datafeed
               union all
Select '''',
''Hierarchy'',
''Hierarchy'',
'''',
''''
)T
full join
(
	-- Position
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.Position_Fact F
	 INNER JOIN target.InstrumentType R ON F.InstrumentTypeKey = R.InstrumentTypeKey
	 INNER JOIN target.[Source] S ON F.SourceKey = S.SourceKey
	WHERE F.BusDate = @BUSDATE AND F.Finish > GETUTCDATE() AND S.InterfaceName = ''Position''
	group by S.InterfaceName
	union all
	-- FX Spot
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.FXSpot_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	WHERE F.finish > GETUTCDATE() AND S.InterfaceName=''FxSpot'' AND F.BusDate = @BUSDATE
	group by S.InterfaceName
	union all
	-- Hierarchy
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.Hierarchy F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName = ''Hierarchy''
	group by S.InterfaceName
	union all
	-- RiskMeasure
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.RiskMeasure_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName in (''SimraFORiskMeasures'',''MurexSensitivities'') AND F.BusDate = @BUSDATE
	 group by S.InterfaceName
	union all
	-- PnL
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.PnL_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%PnLs%'' AND F.BusDate = @BUSDATE
	 group by InterfaceName
	union all
	-- MarketData
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.MarketData_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%SimraMD_%'' AND F.BusDate = @BUSDATE
	 group by InterfaceName
)a
ON a.InterfaceName = T.Datafeed
full join
(
	-- Position
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.Position_Fact F
	 INNER JOIN target.InstrumentType R ON F.InstrumentTypeKey = R.InstrumentTypeKey
	 INNER JOIN target.[Source] S ON F.SourceKey = S.SourceKey
	WHERE F.BusDate = @BUSDATE_T2 AND F.Finish > GETUTCDATE() AND S.InterfaceName = ''Position''
	group by S.InterfaceName
	union all
	--FX Spot
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.FXSpot_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	WHERE F.finish > GETUTCDATE() AND S.InterfaceName=''FxSpot'' AND F.BusDate = @BUSDATE_T2
	group by S.InterfaceName
	union all
	--Hierarchy
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.Hierarchy F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName = ''Hierarchy''
	 group by S.InterfaceName
	union all
	--RiskMeasure
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.RiskMeasure_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName in (''SimraFORiskMeasures'',''MurexSensitivities'') AND F.BusDate = @BUSDATE_T2
	 group by S.InterfaceName
	union all
	--PnL
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.PnL_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%PnLs%'' AND F.BusDate = @BUSDATE_T2
	 group by InterfaceName
	union all
	--MarketData
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.MarketData_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%SimraMD_%'' AND F.BusDate = @BUSDATE_T2
	 group by InterfaceName
)b
ON b.InterfaceName = T.Datafeed
full join
(
	--Position
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.Position_Fact F
	 INNER JOIN target.InstrumentType R ON F.InstrumentTypeKey = R.InstrumentTypeKey
	 INNER JOIN target.[Source] S ON F.SourceKey = S.SourceKey
	WHERE F.BusDate = @BUSDATE_T3 AND F.Finish > GETUTCDATE() AND S.InterfaceName = ''Position''
	group by S.InterfaceName
	union all
	-- FX Spot
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.FXSpot_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	WHERE F.finish > GETUTCDATE() AND S.InterfaceName=''FxSpot'' AND F.BusDate = @BUSDATE_T3
	group by S.InterfaceName
	union all
	-- Hierarchy
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.Hierarchy F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName = ''Hierarchy''
	 group by S.InterfaceName
	union all
	-- RiskMeasure
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.RiskMeasure_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName in (''SimraFORiskMeasures'',''MurexSensitivities'') AND F.BusDate = @BUSDATE_T3
	 group by S.InterfaceName
	union all
	-- PnL
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.PnL_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%PnLs%'' AND F.BusDate = @BUSDATE_T3
	 group by InterfaceName
	union all
	-- MarketData
	SELECT InterfaceName, COUNT(*) as ''RowCount'' FROM target.MarketData_Fact F
	 INNER JOIN target.Source S ON F.SourceKey = S.SourceKey
	 WHERE F.finish > GETUTCDATE() AND S.InterfaceName like ''%SimraMD_%'' AND F.BusDate = @BUSDATE_T3
	 group by InterfaceName
)c
ON c.InterfaceName = T.Datafeed
Order by Datafeed ASC,Start DESC


', N'Joins data with the TimeTravelInstance table to show which loads have completed for T-1, T-2 and T-3', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (55, N'2017-05-10 17:24:12', N'2017-05-18 12:00:38', 11, N'Support Flex_Rex', N'SFR', 1, N'DECLARE @BUSDATE AS DATETIME
SELECT @BUSDATE = (select busdate from target.f_BusDate())
	
-- PnL 1 Day
select ''PnL 1 Day'' as ''Reconciliation'', (case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR1DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR1DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end) as ''Status''
union all
select ''PnL 10 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR10DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR10DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end 
union all
select ''Stress PnL 1 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR1DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR1DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end 
union all
select ''Stress PnL 10 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR10DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FactKey = FF.FactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR10DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end ', N'Returns the results of the data reconciliation', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (56, N'2017-05-11 10:38:15', N'2017-05-11 10:38:35', 11, N'Monitor Summary', N'MonSum', 1, N'	 
				
SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
	and WorkingDay = ''Y'' 
	and [DATE] < @offsetdate
order by [DATE] desc)

--set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
	busdate varchar(10)
	,InterfaceName varchar(100)
	,[Count] int
	,Start varchar(50)
	,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([count] AS INT)) AS ''Count'' , 
                  [start], 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
						Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
						[Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.factkey = F.factkey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
		) x 
		PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
			SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [start], 
                      [fact] 
            FROM   
            (
					SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
							Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
							[Fact] 
					FROM   target.flexfactinstance I 
					INNER JOIN target.flexfact F 
							ON I.factkey = F.factkey 
					INNER JOIN target.flexfacthierarchy H 
							ON F.flexfacthierarchykey = H.flexfacthierarchykey 
					INNER JOIN (SELECT [date] AS offsetDate 
								FROM   target.calendar 
								WHERE left([date],10) = @Previousdate
							   ) AS TT 
							ON F.busdate = TT.offsetdate 
					INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
								FROM   target.F_targetdate() 
								ORDER  BY targetdate) AS TT2 
							ON F.start <= TT2.versiondatetime 
							   AND F.finish > TT2.versiondatetime 
					LEFT OUTER JOIN target.source AS D_Source 
								 ON F.sourcekey = D_Source.sourcekey 
					WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
			) x 
			PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([count] AS INT)) AS ''Count'' , 
                  [start], 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
					  ''Reconciliation'' AS [Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.factkey = F.factkey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
						) x 
		PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename] 
				      
    

select busdate + '' ('' +	left(DATENAME(dw,busdate),2) + '')'' as busdate
	,InterfaceName 
	,[Count] 
	,Start 
	,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(7)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates
', N'Data to power the pivot on the the monitor sheet', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (57, N'2017-05-11 10:38:35', N'2017-05-11 10:38:45', 11, N'Monitor Summary', N'MonSum', 2, N'	 
SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
	and WorkingDay = ''Y'' 
	and [DATE] < @offsetdate
order by [DATE] desc)

--set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
	busdate varchar(10)
	,InterfaceName varchar(100)
	,[Count] int
	,Start varchar(50)
	,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([count] AS INT)) AS ''Count'' , 
                  [start], 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
						Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
						[Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.factkey = F.factkey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
		) x 
		PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
			SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [start], 
                      [fact] 
            FROM   
            (
					SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
							Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
							[Fact] 
					FROM   target.flexfactinstance I 
					INNER JOIN target.flexfact F 
							ON I.factkey = F.factkey 
					INNER JOIN target.flexfacthierarchy H 
							ON F.flexfacthierarchykey = H.flexfacthierarchykey 
					INNER JOIN (SELECT [date] AS offsetDate 
								FROM   target.calendar 
								WHERE left([date],10) = @Previousdate
							   ) AS TT 
							ON F.busdate = TT.offsetdate 
					INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
								FROM   target.F_targetdate() 
								ORDER  BY targetdate) AS TT2 
							ON F.start <= TT2.versiondatetime 
							   AND F.finish > TT2.versiondatetime 
					LEFT OUTER JOIN target.source AS D_Source 
								 ON F.sourcekey = D_Source.sourcekey 
					WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
			) x 
			PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([count] AS INT)) AS ''Count'' , 
                  [start], 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
					  ''Reconciliation'' AS [Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.factkey = F.factkey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
						) x 
		PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename] 
				      
    

select busdate + '' ('' +	left(DATENAME(dw,busdate),2) + '')'' as busdate
	,InterfaceName 
	,[Count] 
	,Start 
	,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(7)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates
', N'Data to power the pivot on the the monitor sheet', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (58, N'2017-05-11 10:38:45', N'2017-05-11 14:35:31', 11, N'Monitor Summary', N'MonSum', 3, N'SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
	and WorkingDay = ''Y'' 
	and [DATE] < @offsetdate
order by [DATE] desc)

--set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
	busdate varchar(10)
	,InterfaceName varchar(100)
	,[Count] int
	,Start varchar(50)
	,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([count] AS INT)) AS ''Count'' , 
                  [start], 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
						Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
						[Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.factkey = F.factkey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
		) x 
		PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
			SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [start], 
                      [fact] 
            FROM   
            (
					SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
							Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
							[Fact] 
					FROM   target.flexfactinstance I 
					INNER JOIN target.flexfact F 
							ON I.factkey = F.factkey 
					INNER JOIN target.flexfacthierarchy H 
							ON F.flexfacthierarchykey = H.flexfacthierarchykey 
					INNER JOIN (SELECT [date] AS offsetDate 
								FROM   target.calendar 
								WHERE left([date],10) = @Previousdate
							   ) AS TT 
							ON F.busdate = TT.offsetdate 
					INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
								FROM   target.F_targetdate() 
								ORDER  BY targetdate) AS TT2 
							ON F.start <= TT2.versiondatetime 
							   AND F.finish > TT2.versiondatetime 
					LEFT OUTER JOIN target.source AS D_Source 
								 ON F.sourcekey = D_Source.sourcekey 
					WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
			) x 
			PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([count] AS INT)) AS ''Count'' , 
                  [start], 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
					  ''Reconciliation'' AS [Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.factkey = F.factkey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
						) x 
		PIVOT (Max([value]) FOR [key] IN ([Count], [Start], [Finish])) p
	GROUP  BY [busdate], 
          [start], 
          [finish], 
          [fact], 
          [interfacename] 
				      
    

select busdate + '' ('' +	left(DATENAME(dw,busdate),2) + '')'' as busdate
	,InterfaceName 
	,[Count] 
	,Start 
	,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(7)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates
', N'Data to power the pivot on the the monitor sheet', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (59, N'2017-05-11 14:35:31', N'2017-05-22 09:51:56', 11, N'Monitor Summary', N'MonSum', 4, N'SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
    and WorkingDay = ''Y'' 
    and [DATE] < @offsetdate
order by [DATE] desc)

--set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
    busdate varchar(10)
    ,InterfaceName varchar(100)
    ,[Count] float
    ,Start varchar(50)
    ,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS Float)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                        Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                        [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                    and [KEY] like ''Active.%''
        ) x 
        PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
            SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [active.Start] AS ''Start'', 
                      [fact] 
            FROM   
            (
                    SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
                            Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                            [Fact] 
                    FROM   target.flexfactinstance I 
                    INNER JOIN target.flexfact F 
                            ON I.FlexFactKey = F.FlexFactKey 
                    INNER JOIN target.flexfacthierarchy H 
                            ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                    INNER JOIN (SELECT [date] AS offsetDate 
                                FROM   target.calendar 
                                WHERE left([date],10) = @Previousdate
                               ) AS TT 
                            ON F.busdate = TT.offsetdate 
                    INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                                FROM   target.F_targetdate() 
                                ORDER  BY targetdate) AS TT2 
                            ON F.start <= TT2.versiondatetime 
                               AND F.finish > TT2.versiondatetime 
                    LEFT OUTER JOIN target.source AS D_Source 
                                 ON F.sourcekey = D_Source.sourcekey 
                    WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                        and [KEY] like ''Active.%''
            ) x 
            PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([Difference] AS Float)) AS ''Count'' , 
                  [Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                      ''Reconciliation'' AS [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
                        ) x 
        PIVOT (Max([value]) FOR [key] IN ([Difference], [Start], [Finish])) p
    GROUP  BY [busdate], 
          [Start], 
          [Finish], 
          [fact], 
          [interfacename] 
                      
    

select busdate + '' ('' +   left(DATENAME(dw,busdate),2) + '')'' as busdate
    ,InterfaceName 
    ,(case when Fact = ''Reconciliation'' and [Count] = 0 then 1 
           when Fact = ''Reconciliation'' and [Count] > 0 then -1 
           when Fact = ''FXSpot'' and [Count] = 1 then -1 
           else cast(round([Count],0) as Int) end) as ''Count''
    ,Start 
    ,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(20)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates', N'Data to power the pivot on the the monitor sheet', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (60, N'2017-05-18 12:00:39', N'2017-05-22 13:55:14', 11, N'Support Flex_Rex', N'SFR', 2, N'DECLARE @BUSDATE AS DATETIME
SELECT @BUSDATE = (select busdate from target.f_BusDate())
	
-- PnL 1 Day
select ''PnL 1 Day'' as ''Reconciliation'', (case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR1DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR1DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end) as ''Status''
union all
select ''PnL 10 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR10DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR10DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end 
union all
select ''Stress PnL 1 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR1DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR1DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end 
union all
select ''Stress PnL 10 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR10DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR10DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end ', N'Returns the results of the data reconciliation', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (62, N'2017-05-22 09:51:56', N'2017-05-22 10:23:45', 11, N'Monitor Summary', N'MonSum', 5, N'	 
				
SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
	and WorkingDay = ''Y'' 
	and [DATE] < @offsetdate
order by [DATE] desc)

set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
	busdate varchar(10)
	,InterfaceName varchar(100)
	,[Count] int
	,Start varchar(50)
	,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS INT)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
						Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
						[Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.FlexFactKey = F.FlexFactKey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
					and [KEY] like ''Active.%''
		) x 
		PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
	GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
			SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [active.Start] AS ''Start'', 
                      [fact] 
            FROM   
            (
					SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
							Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
							[Fact] 
					FROM   target.flexfactinstance I 
					INNER JOIN target.flexfact F 
							ON I.FlexFactKey = F.FlexFactKey 
					INNER JOIN target.flexfacthierarchy H 
							ON F.flexfacthierarchykey = H.flexfacthierarchykey 
					INNER JOIN (SELECT [date] AS offsetDate 
								FROM   target.calendar 
								WHERE left([date],10) = @Previousdate
							   ) AS TT 
							ON F.busdate = TT.offsetdate 
					INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
								FROM   target.F_targetdate() 
								ORDER  BY targetdate) AS TT2 
							ON F.start <= TT2.versiondatetime 
							   AND F.finish > TT2.versiondatetime 
					LEFT OUTER JOIN target.source AS D_Source 
								 ON F.sourcekey = D_Source.sourcekey 
					WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
						and [KEY] like ''Active.%''
			) x 
			PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
	GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS INT)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
	SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
					  ''Reconciliation'' AS [Fact] 
				FROM   target.flexfactinstance I 
				INNER JOIN target.flexfact F 
						ON I.FlexFactKey = F.FlexFactKey 
				INNER JOIN target.flexfacthierarchy H 
						ON F.flexfacthierarchykey = H.flexfacthierarchykey 
				INNER JOIN (SELECT [date] AS offsetDate 
							FROM   target.calendar 
							WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
						   ) AS TT 
						ON F.busdate = TT.offsetdate 
				INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
							FROM   target.F_targetdate() 
							ORDER  BY targetdate) AS TT2 
						ON F.start <= TT2.versiondatetime 
						   AND F.finish > TT2.versiondatetime 
				LEFT OUTER JOIN target.source AS D_Source 
							 ON F.sourcekey = D_Source.sourcekey 
				WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
						) x 
		PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
	GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
				      
    

select busdate + '' ('' +	left(DATENAME(dw,busdate),2) + '')'' as busdate
	,InterfaceName 
	,[Count] 
	,Start 
	,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(7)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates
', N'Data to power the pivot on the the monitor sheet', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (63, N'2017-05-22 10:23:45', N'2017-08-24 10:59:14', 11, N'Monitor Summary', N'MonSum', 6, N'  
                
SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
    and WorkingDay = ''Y'' 
    and [DATE] < @offsetdate
order by [DATE] desc)

set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
    busdate varchar(10)
    ,InterfaceName varchar(100)
    ,[Count] int
    ,Start varchar(50)
    ,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS INT)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                        Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                        [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                    and [KEY] like ''Active.%''
        ) x 
        PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
            SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [active.Start] AS ''Start'', 
                      [fact] 
            FROM   
            (
                    SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
                            Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                            [Fact] 
                    FROM   target.flexfactinstance I 
                    INNER JOIN target.flexfact F 
                            ON I.FlexFactKey = F.FlexFactKey 
                    INNER JOIN target.flexfacthierarchy H 
                            ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                    INNER JOIN (SELECT [date] AS offsetDate 
                                FROM   target.calendar 
                                WHERE left([date],10) = @Previousdate
                               ) AS TT 
                            ON F.busdate = TT.offsetdate 
                    INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                                FROM   target.F_targetdate() 
                                ORDER  BY targetdate) AS TT2 
                            ON F.start <= TT2.versiondatetime 
                               AND F.finish > TT2.versiondatetime 
                    LEFT OUTER JOIN target.source AS D_Source 
                                 ON F.sourcekey = D_Source.sourcekey 
                    WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                        and [KEY] like ''Active.%''
            ) x 
            PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS INT)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                      ''Reconciliation'' AS [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
                        ) x 
        PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
                      
    

select busdate + '' ('' +   left(DATENAME(dw,busdate),2) + '')'' as busdate
    ,InterfaceName 
    ,isnull([Count],0) as ''Count''
    ,Start 
    ,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(7)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates
', N'Data to power the pivot on the the monitor sheet', N'SQL', N'', N'', N'England, Alex (c008631)', 1, N'MARKETS\C008631 as MARKETS\C008631', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (64, N'2017-05-22 13:55:14', N'1999-12-31 00:00:00', 11, N'Support Flex_Rex', N'SFR', 3, N'DECLARE @BUSDATE AS DATETIME
SELECT @BUSDATE = (select busdate from target.f_BusDate())
	
-- PnL 1 Day
select ''PnL 1 Day'' as ''Reconciliation'', (case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR1DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR1DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end) as ''Status''
union all
select ''PnL 10 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR10DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraVaR10DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end 
union all
select ''Stress PnL 1 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR1DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR1DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end 
union all
select ''Stress PnL 10 Day'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR10DPnLs''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraSVaR10DPnLs''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end
union all
select ''Stress Tests'', case when
	(select COUNT(*) from   target.FlexFactHierarchy FFH
	INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
	INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
	INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraCore1StressTests''
	WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE) > 0
then
	(select (case when [COUNT] = 0 then -1 else [COUNT] end) as [Count] from
	(
		SELECT COUNT(*) as ''Count'' 
		FROM target.FlexFactHierarchy FFH
		INNER JOIN target.FlexFact FF ON FFH.FlexFactHierarchyKey = FF.FlexFactHierarchyKey
		INNER JOIN target.FlexFactInstance FFI ON FFI.FlexFactKey = FF.FlexFactKey
		INNER JOIN target.[Source] S ON FF.SourceKey = S.SourceKey AND S.InterfaceName = ''SimraCore1StressTests''
		WHERE FFH.Description = ''Reconciliation.Pnl.Data'' AND FF.[BusDate] = @BUSDATE 
		 AND FF.HierarchyKey Is NOT NULL AND FF.Finish > GETUTCDATE()
	 )a)

else
	0
end  

', N'Returns the results of the data reconciliation', N'SQL', N'', N'', N'Zajda, Juliusz (C008489)', 1, N'MARKETS\C008489 as MARKETS\C008489', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (89, N'2017-08-24 10:59:14', N'1999-12-31 00:00:00', 11, N'Monitor Summary', N'MonSum', 7, N'  
                
SET NOCOUNT ON

DECLARE @Offsetdate AS DATETIME2(7), @Previousdate AS DATETIME2(7); 

SET @OffsetDate = Isnull((SELECT Cast(busdate AS VARCHAR(10)) AS busdate 
                           FROM   target.F_busdate()), Getutcdate()) 

set @PreviousDate = (select top 1 date from target.Calendar 
where [weekday] = (select [WeekDay] from target.calendar where [DATE] = @offsetdate) 
    and WorkingDay = ''Y'' 
    and [DATE] < @offsetdate
order by [DATE] desc)

set @PreviousDate = ''20170420''

select REPLACE(Item,'''''''','''') as date into #dates FROM target.f_split((select target.f_Calendarvalues (''-0d,-1d,-2d,-3d,-4d,-5d'',@OffsetDate)),'','')

create table #summary
(
    busdate varchar(10)
    ,InterfaceName varchar(100)
    ,[Count] int
    ,Start varchar(50)
    ,Fact varchar(50)
)
    --Get past 10 days activity
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS INT)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                        Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                        [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                    and [KEY] like ''Active.%''
        ) x 
        PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
    
    --Get previous activity for current weekday
     insert into #summary
     select * from
    (
            SELECT busdate, 
                      Isnull([interfacename], '''') AS [InterfaceName], 
                      --Isnull([origin], '''')        AS [Origin], 
                      0 as [Count],
                      [active.Start] AS ''Start'', 
                      [fact] 
            FROM   
            (
                    SELECT @Offsetdate as busdate, 
                          D_Source.[interfacename], 
                          D_Source.[origin], 
                          I.[key], 
                          I.value, 
                            Replace(Replace(H.[description], ''FeedLoadCheck.'', ''''), ''.Data'', '''') AS 
                            [Fact] 
                    FROM   target.flexfactinstance I 
                    INNER JOIN target.flexfact F 
                            ON I.FlexFactKey = F.FlexFactKey 
                    INNER JOIN target.flexfacthierarchy H 
                            ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                    INNER JOIN (SELECT [date] AS offsetDate 
                                FROM   target.calendar 
                                WHERE left([date],10) = @Previousdate
                               ) AS TT 
                            ON F.busdate = TT.offsetdate 
                    INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                                FROM   target.F_targetdate() 
                                ORDER  BY targetdate) AS TT2 
                            ON F.start <= TT2.versiondatetime 
                               AND F.finish > TT2.versiondatetime 
                    LEFT OUTER JOIN target.source AS D_Source 
                                 ON F.sourcekey = D_Source.sourcekey 
                    WHERE  H.[description] LIKE ( ''FeedLoadCheck.%'' )
                        and [KEY] like ''Active.%''
            ) x 
            PIVOT (Max([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename]     
          )c
    where (select COUNT(1) from #summary S where busdate = @Offsetdate and S.InterfaceName = c.InterfaceName and S.Fact = c.Fact)=0      
          
    --Get Reconciliation
    insert into #summary
         SELECT busdate, 
                  Isnull([interfacename], '''') AS [InterfaceName], 
                  --Isnull([origin], '''')        AS [Origin], 
                  Sum(Cast([active.Count] AS INT)) AS ''Count'' , 
                  [active.Start] AS ''Start'', 
                  [fact] 
        FROM   
        (
    SELECT F.busdate, 
                      D_Source.[interfacename], 
                      D_Source.[origin], 
                      I.[key], 
                      I.value, 
                      ''Reconciliation'' AS [Fact] 
                FROM   target.flexfactinstance I 
                INNER JOIN target.flexfact F 
                        ON I.FlexFactKey = F.FlexFactKey 
                INNER JOIN target.flexfacthierarchy H 
                        ON F.flexfacthierarchykey = H.flexfacthierarchykey 
                INNER JOIN (SELECT [date] AS offsetDate 
                            FROM   target.calendar 
                            WHERE left([date],10) in(select cast([DATE] as varchar(10)) from #dates)
                           ) AS TT 
                        ON F.busdate = TT.offsetdate 
                INNER JOIN (SELECT TOP 1 targetdate AS VersionDateTime 
                            FROM   target.F_targetdate() 
                            ORDER  BY targetdate) AS TT2 
                        ON F.start <= TT2.versiondatetime 
                           AND F.finish > TT2.versiondatetime 
                LEFT OUTER JOIN target.source AS D_Source 
                             ON F.sourcekey = D_Source.sourcekey 
                WHERE   H.[description] LIKE ( ''Reconciliation.%'' )
                        ) x 
        PIVOT (Min([value]) FOR [key] IN ([active.Count], [active.Start], [active.Finish])) p
    GROUP  BY [busdate], 
          [active.Start], 
          [active.Finish], 
          [fact], 
          [interfacename] 
                      
    

select busdate + '' ('' +   left(DATENAME(dw,busdate),2) + '')'' as busdate
    ,InterfaceName 
    ,isnull([Count],0) as ''Count''
    ,Start 
    ,Fact 
    ,busdate + '' : '' + cast([Count] as varchar(7)) + '' rows at '' + left(Start,16) as info
from #Summary

drop table #summary
drop table #dates
', N'Data to power the pivot on the the monitor sheet, displaying firm load for a business date', N'SQL', N'', N'', N'Davis, Ray (C006857)', 1, N'MARKETS\C006857 as MARKETS\C006857', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (91, N'2017-11-06 12:41:55', N'2017-11-06 12:56:52', 11, N'Monitor_Load_Volume_Analysis', N'MoLloadTrend', 1, N'USE MARS		
		
--		
/* Return the last ten days of Load statistics together with Thesholds and Comments*/		
--		
		
DECLARE @FlexExtractSQL nvarchar(4000)		
DECLARE @CurrentBusdate datetime2		
DECLARE @SDwindow int		
DECLARE @AnalysisDays int		
		
SET @SDwindow = 20		
SET @AnalysisDays = 20		
		
SET @CurrentBusdate = (select BusDate from target.f_BusDate())		
		
DECLARE @strBusDates Table (BusDate varchar(27))		
INSERT INTO @strBusDates		
SELECT C.[Date] 		
FROM target.Calendar C		
CROSS JOIN (SELECT target.f_CalendarOffset(''-9d'',(select BusDate from target.f_BusDate())) BusDate) StartDate		
CROSS JOIN (select BusDate from target.f_BusDate() BusDate ) EndDate		
WHERE C.[Date] >= StartDate.BusDate		
	AND C.[Date] <= EndDate.BusDate	
	AND C.WorkingDay = ''Y''	
		
PRINT ''Thresholds''		
DECLARE @Thresholds Table ( 		
	--Username varchar(255),	
	--Start DatetIme2,	
	InterfaceName varchar(64),	
	Environment varchar(50),	
	Source varchar(50),	
	Origin varchar(MAX),	
	ThresholdValue Float,	
	AppliedRules varchar(1000) NULL)	
SET @FlexExtractSQL= '' ''		
EXEC [target].[p_Get_DenormalisedSQLForFlexFacts] 		
	N''FeedLoadCheck.Threshold''	
	, N''''	
	, N''SELECT [InterfaceName],[Environment],[Source],[Origin],[ThresholdValue],[AppliedRules] FROM dbo.FeedLoadCheck.Threshold ''	
	, @FlexExtractSQL output	
INSERT @Thresholds EXEC sp_executesql @FlexExtractSQL		
DELETE FROM @Thresholds WHERE Environment = ''No Data Returned''		
		
PRINT ''Comments''		
DECLARE @Comments Table ( 		
	BusDate varchar(27),	
	AppliedRules varchar(1000) NULL,	
	Environment varchar(50),	
	InterfaceName varchar(64),	
	Origin varchar(MAX),	
	Source varchar(50),	
	Comment varchar(1000) NULL)	
SET @FlexExtractSQL= '' ''		
EXEC [target].[p_Get_DenormalisedSQLForFlexFacts] 		
	N''FeedLoadCheck.Comment''	
	, N''''	
	, N''SELECT [BusDate],[Comment],[InterfaceName],[Environment],[Source],[Origin],[AppliedRules] FROM dbo.FeedLoadCheck.Comment''	
	, @FlexExtractSQL output	
INSERT @Comments EXEC sp_executesql @FlexExtractSQL		
DELETE FROM @Comments WHERE BusDate = ''No Data Returned''		
		
PRINT ''STATS''		
Declare @Statistics Table ( 		
	BusDate datetime2, 	
	SourceKey bigint,	
	DateRowCount int,	
	MovingAverage int,	
	StandardDeviation int,	
	StandardDeviationDiff Float,	
	InterfaceName varchar(64),	
	Origin varchar(MAX),	
	[Source] varchar(50)	
)		
INSERT @Statistics EXEC [target].[p_Get_LoadStats] @CurrentBusdate, @SDwindow, @AnalysisDays		
		
EXEC [target].[p_Get_LoadStats] ''2017-06-01'', 20, 20		
--SELECT failed because the following SET options have incorrect settings: ''ANSI_WARNINGS''. 		
		
Declare @StatisticsSummary Table ( 		
	BusDate datetime2, 	
	SourceKey bigint,	
	DateRowCount int,	
	MovingAverage int,	
	StandardDeviation int,	
	StandardDeviationDiff Float,	
	InterfaceName varchar(64),	
	Origin varchar(MAX),	
	[Source] varchar(50))	
INSERT INTO @StatisticsSummary		
	SELECT	
		BusDate, 
		SourceKey,
		DateRowCount,
		AVG(MovingAverage) MovingAverage,
		AVG(StandardDeviation) StandardDeviation,
		AVG(StandardDeviationDiff) StandardDeviationDiff,
		InterfaceName,
		Origin,
		[Source]
	FROM @Statistics 	
	WHERE MovingAverage is not NULL	
	GROUP BY	
		BusDate, 
		SourceKey,
		DateRowCount,
		InterfaceName,
		Origin,
		[Source]
		
--SELECT * FROM @Statistics		
--SELECT * FROM @StatisticsSummary		
--SELECT * FROM @Thresholds		
--SELECT * FROM @Comments 		
		
SELECT Analysis.*, CASE WHEN DateRowCount < LCL THEN -1 ELSE (CASE WHEN DateRowCount > LCL THEN 1 ELSE 0 END) END Status		
FROM (		
	SELECT S.BusDate, ISNULL(S.InterfaceName,ISNULL(T.InterfaceName,Note.InterfaceName)) + '' ('' + T.Environment + ''-'' + T.Source + ''-'' + T.Origin + '')'' DataFeed,	
		S.InterfaceName, T.Environment, T.Source, T.Origin, 
		T.ThresholdValue, 
		S.DateRowCount, S.MovingAverage, S.StandardDeviation, 
		S.MovingAverage - (S.StandardDeviation * T.ThresholdValue) LCL,
		S.MovingAverage + (S.StandardDeviation * T.ThresholdValue) UCL,
		ISNULL(Note.Comment,'''') Comment
	FROM @Statistics  S	
	FULL OUTER JOIN @strBusDates B ON S.BusDate = B.BusDate	
	LEFT JOIN @Thresholds T ON S.InterfaceName = T.InterfaceName	
	FULL OUTER JOIN @Comments Note ON Note.InterfaceName = T.InterfaceName AND Note.Environment = T.Environment	
		AND Note.Source = T.Source AND Note.Origin = T.Origin AND Note.BusDate = S.BusDate
	WHERE S.MovingAverage is not NULL	
	) Analysis	
ORDER BY DataFeed, BusDate		
', N'Return load statistics for the various automated load processes', N'SQL', N'', N'', N'Davis, Ray (C006857)', 1, N'MARKETS\C006857 as MARKETS\C006857', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (92, N'2017-11-06 12:56:52', N'1999-12-31 00:00:00', 11, N'Monitor_Load_Volume_Analysis', N'MoLloadTrend', 2, N'USE MARS		
		
--		
/* Return the last ten days of Load statistics together with Thesholds and Comments*/		
--		
		
DECLARE @FlexExtractSQL nvarchar(4000)		
DECLARE @CurrentBusdate datetime2		
DECLARE @SDwindow int		
DECLARE @AnalysisDays int		
		
SET @SDwindow = 20		
SET @AnalysisDays = 20		
		
SET @CurrentBusdate = (select BusDate from target.f_BusDate())		
		
DECLARE @strBusDates Table (BusDate varchar(27))		
INSERT INTO @strBusDates		
SELECT C.[Date] 		
FROM target.Calendar C		
CROSS JOIN (SELECT target.f_CalendarOffset(''-9d'',(select BusDate from target.f_BusDate())) BusDate) StartDate		
CROSS JOIN (select BusDate from target.f_BusDate() BusDate ) EndDate		
WHERE C.[Date] >= StartDate.BusDate		
	AND C.[Date] <= EndDate.BusDate	
	AND C.WorkingDay = ''Y''	
		
PRINT ''Thresholds''		
DECLARE @Thresholds Table ( 		
	--Username varchar(255),	
	--Start DatetIme2,	
	InterfaceName varchar(64),	
	Environment varchar(50),	
	Source varchar(50),	
	Origin varchar(MAX),	
	ThresholdValue Float,	
	AppliedRules varchar(1000) NULL)	
SET @FlexExtractSQL= '' ''		
EXEC [target].[p_Get_DenormalisedSQLForFlexFacts] 		
	N''FeedLoadCheck.Threshold''	
	, N''''	
	, N''SELECT [InterfaceName],[Environment],[Source],[Origin],[ThresholdValue],[AppliedRules] FROM dbo.FeedLoadCheck.Threshold ''	
	, @FlexExtractSQL output	
INSERT @Thresholds EXEC sp_executesql @FlexExtractSQL		
DELETE FROM @Thresholds WHERE Environment = ''No Data Returned''		
		
PRINT ''Comments''		
DECLARE @Comments Table ( 		
	BusDate varchar(27),	
	AppliedRules varchar(1000) NULL,	
	Environment varchar(50),	
	InterfaceName varchar(64),	
	Origin varchar(MAX),	
	Source varchar(50),	
	Comment varchar(1000) NULL)	
SET @FlexExtractSQL= '' ''		
EXEC [target].[p_Get_DenormalisedSQLForFlexFacts] 		
	N''FeedLoadCheck.Comment''	
	, N''''	
	, N''SELECT [BusDate],[Comment],[InterfaceName],[Environment],[Source],[Origin],[AppliedRules] FROM dbo.FeedLoadCheck.Comment''	
	, @FlexExtractSQL output	
INSERT @Comments EXEC sp_executesql @FlexExtractSQL		
DELETE FROM @Comments WHERE BusDate = ''No Data Returned''		
		
PRINT ''STATS''		
Declare @Statistics Table ( 		
	BusDate datetime2, 	
	SourceKey bigint,	
	DateRowCount int,	
	MovingAverage int,	
	StandardDeviation int,	
	StandardDeviationDiff Float,	
	InterfaceName varchar(64),	
	Origin varchar(MAX),	
	[Source] varchar(50)	
)		
INSERT @Statistics EXEC [target].[p_Get_LoadStats] @CurrentBusdate, @SDwindow, @AnalysisDays		
		
--EXEC [target].[p_Get_LoadStats] ''2017-06-01'', 20, 20		
--SELECT failed because the following SET options have incorrect settings: ''ANSI_WARNINGS''. 		
		
Declare @StatisticsSummary Table ( 		
	BusDate datetime2, 	
	SourceKey bigint,	
	DateRowCount int,	
	MovingAverage int,	
	StandardDeviation int,	
	StandardDeviationDiff Float,	
	InterfaceName varchar(64),	
	Origin varchar(MAX),	
	[Source] varchar(50))	
INSERT INTO @StatisticsSummary		
	SELECT	
		BusDate, 
		SourceKey,
		DateRowCount,
		AVG(MovingAverage) MovingAverage,
		AVG(StandardDeviation) StandardDeviation,
		AVG(StandardDeviationDiff) StandardDeviationDiff,
		InterfaceName,
		Origin,
		[Source]
	FROM @Statistics 	
	WHERE MovingAverage is not NULL	
	GROUP BY	
		BusDate, 
		SourceKey,
		DateRowCount,
		InterfaceName,
		Origin,
		[Source]
		
--SELECT * FROM @Statistics		
--SELECT * FROM @StatisticsSummary		
--SELECT * FROM @Thresholds		
--SELECT * FROM @Comments 		
		
SELECT Analysis.*, CASE WHEN DateRowCount < LCL THEN -1 ELSE (CASE WHEN DateRowCount > LCL THEN 1 ELSE 0 END) END Status		
FROM (		
	SELECT S.BusDate, ISNULL(S.InterfaceName,ISNULL(T.InterfaceName,Note.InterfaceName)) + '' ('' + T.Environment + ''-'' + T.Source + ''-'' + T.Origin + '')'' DataFeed,	
		S.InterfaceName, T.Environment, T.Source, T.Origin, 
		T.ThresholdValue, 
		S.DateRowCount, S.MovingAverage, S.StandardDeviation, 
		S.MovingAverage - (S.StandardDeviation * T.ThresholdValue) LCL,
		S.MovingAverage + (S.StandardDeviation * T.ThresholdValue) UCL,
		ISNULL(Note.Comment,'''') Comment
	FROM @Statistics  S	
	FULL OUTER JOIN @strBusDates B ON S.BusDate = B.BusDate	
	LEFT JOIN @Thresholds T ON S.InterfaceName = T.InterfaceName	
	FULL OUTER JOIN @Comments Note ON Note.InterfaceName = T.InterfaceName AND Note.Environment = T.Environment	
		AND Note.Source = T.Source AND Note.Origin = T.Origin AND Note.BusDate = S.BusDate
	WHERE S.MovingAverage is not NULL	
	) Analysis	
ORDER BY DataFeed, BusDate		
', N'Return load statistics for the various automated load processes', N'SQL', N'', N'', N'Davis, Ray (C006857)', 1, N'MARKETS\C006857 as MARKETS\C006857', N'Public/Monitor/')
INSERT INTO [core].[QueryCatalogue] ([ID], [Start], [Finish], [HierarchyNode], [Name], [Alias], [VersionID], [Query], [Comment], [DesignedBy], [QuestionAsked], [LegoXML], [UserName], [Active], [SystemUserName], [VersionPath]) VALUES (88, N'2017-06-30 10:33:08', N'1999-12-31 00:00:00', 47, N'Pnl_Breaks', N'pnlbreak', 1, N'SELECT InterfaceName, BusDate, Value, NodeName, NodeType, BookCad2, Trading, [Group], Business, BusinessArea, BookSystem, HierarchyString FROM target.FlexFact F 
INNER JOIN target.FlexFactHierarchy H on F.FlexFactHierarchyKey = H.FlexFactHierarchyKey
INNER JOIN target.FlexFactInstance I on F.FlexFactKey = I.FlexFactKey
INNER JOIN target.Hierarchy TH ON TH.HierarchyKey = F.HierarchyKey 
INNER JOIN target.Source S on F.SourceKey = S.SourceKey
WHERE Description LIKE ''Reconciliation.Pnl.Data'' and BusDate = (select busdate from target.vTimeTravel)', N'Shows pnl breaks for set business date', N'SQL', N'', N'', N'Gorzynski, Marcin (c007860)', 1, N'MARKETS\C007860 as MARKETS\C007860', N'Public/Support/Reconciliation/')
SET IDENTITY_INSERT [core].[QueryCatalogue] OFF
