SET IDENTITY_INSERT [core].[Log_Type] ON
INSERT [core].[Log_Type] ([MessageType_ID], [Name], [Description], [ChangeDate]) VALUES (1, N'Debug Info', N'Code Generated Information', CAST(0x0000A67300000000 AS DateTime))
INSERT [core].[Log_Type] ([MessageType_ID], [Name], [Description], [ChangeDate]) VALUES (2, N'Error', N'System Generated Error', CAST(0x0000A67300000000 AS DateTime))
INSERT [core].[Log_Type] ([MessageType_ID], [Name], [Description], [ChangeDate]) VALUES (3, N'Information', N'Code Generated Information', CAST(0x0000A67300000000 AS DateTime))
INSERT [core].[Log_Type] ([MessageType_ID], [Name], [Description], [ChangeDate]) VALUES (4, N'Warning', N'Code Generated Warnning', CAST(0x0000A67300000000 AS DateTime))
SET IDENTITY_INSERT [core].[Log_Type] OFF
GO
