insert into raw.Position_Control
values(getutcdate(),getutcdate())