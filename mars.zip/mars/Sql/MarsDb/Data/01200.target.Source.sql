--Too enable flex to insert from addin
insert into target.Source 
select 
	'20170101'
	,'99991231'
	,'FLEX'
	,'PROD'
	,'FLEX'
	,'FLEX'
	,null