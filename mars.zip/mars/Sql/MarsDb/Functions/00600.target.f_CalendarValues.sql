IF OBJECT_ID ('target.f_CalendarValues') IS NOT NULL
	DROP FUNCTION target.f_CalendarValues
GO

CREATE FUNCTION [target].[f_CalendarValues]
-- Converts business day references to a string of quote delimited, comma seperated, business date
-- values suitable for embedding within an IN function within a WHERE clause.
--
--		@Offsets = List of Calendar Offset Codes. See target.f_Calendaroffset for a full description 
--                 of the individual input period specifications
--		@CALDATE = The business Date to which the offsets are to be applied
--
-- Example call...
--		SELECT [target].[f_Calendarvalues] ( '-0d,  -1m,    -2m,-3m,','2016-02-25') CALDATEs
--			...would return...
--			CALDATEs
--			'2016-02-25','2016-01-31','2016-12-31','2016-11-30'
--
(
	@Offsets varchar(MAX),
	@CalDate DATETIME2
)
RETURNS varchar(MAX) 
AS 
BEGIN

	DECLARE @Ret varchar(MAX)
	DECLARE @Components TABLE (CalDate varchar(10))
		
	SET @Ret = Null
	SELECT @Ret = COALESCE(@Ret + '","', '') + target.f_Calendaroffset(LTRIM(RTRIM(Item)) ,@CalDate)
	FROM target.f_split(@Offsets,',')
	WHERE LTRIM(RTRIM(Item))<>''
	
	SET @Ret = '"' + @Ret + '"'
	SET @Ret = replace (@Ret,'"',char(39))
	
--	PRINT @Ret
    RETURN @ret;

END
GO
