IF OBJECT_ID ('core.f_TableToCsv') IS NOT NULL
	DROP FUNCTION core.f_TableToCsv
GO

Create FUNCTION [core].[f_TableToCsv]
(
	@TableOfVarchar		core.Core2TargetParameter readonly ,
	@alias			varchar(30),
	@SquareBracesFlag	Binary	= 0
)
/*
	Name: f_TableToCsv
	Return Values: varchar
	Description: Receives a table of parameters and returns them as
	a comma delimited varchar.
	Optional parameter 2 to add and alias
	Optional parameter 3 to have parameter enclosed in square braces '[parameter]'
*/
RETURNS VarChar(max)
AS
BEGIN
	Declare
		@outCsv		varchar(MAX),
		@l_alias	varchar(30),
		@l_closingBrace	varchar(1)	= '';

	set @l_alias = isnull(@alias,'')
	if len(@l_alias) > 0 set @l_alias = @l_alias + '.';

	if @SquareBracesFlag = 1
	begin
		set @l_alias = @l_alias + '[';
		set @l_closingBrace = ']'
	end

	SET @outCsv = null
	SELECT @outCsv = COALESCE( @outCsv + ', ', '') + @l_alias + id + @l_closingBrace FROM @TableOfVarchar;
	RETURN @outCsv
END
GO
