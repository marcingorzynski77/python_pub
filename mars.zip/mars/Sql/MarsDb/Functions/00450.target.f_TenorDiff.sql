IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[f_TenorDiff]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [target].[f_TenorDiff]
GO


CREATE FUNCTION [target].[f_TenorDiff]
--
-- Returns the number of business days between the date supplied as the second parameter and the date offset from that
-- by the offset supplied in the first parameter.
--
-- Determined using the Calander table in target, which also reflects holidays
--
-- Offset  = -iO
--
--		i = signed integer in range -9999 to +9999 (note, -ve sign is before the supplied busdate, +ve is after)
--		O = one of the following offsets.
--			d - Business days
--			w - Weeks
--			m - months
--			y - years
--
--	CalDate  = Datetime2 or string for the reference Calendar date e.g. '2016-01-01'
--
-- e.g. SELECT [target].[[f_TenorDiff]]('-2Q','2016-02-24') would return 2015-09-30 (i.e the end of the last quarter)
--      SELECT [target].[[f_TenorDiff]]('0M','2016-02-24') would return 2016-02-29 (i.e. the end of the current month)
(
	 @Offset			VARCHAR(128)
	,@CalDate		DATETIME2
)
RETURNS INT 
AS 

BEGIN
	DECLARE @intNumber INT
	DECLARE @strPeriod varchar(1)

	-- Remove the Numeric component. If no numeric, then use the value 1
	SET @intNumber = CAST(LEFT(@Offset, PATINDEX('%[^0-9+-]%', @Offset) - 1) as integer)
	
	SET @strPeriod = UPPER(SUBSTRING(@Offset, PATINDEX('%[^0-9+-]%', @Offset), 1))

	RETURN datediff(d, @CalDate, CASE @StrPeriod
								WHEN 'd' THEN dateadd(day, @intNumber, @CalDate)
								WHEN 'w' THEN dateadd(week, @intNumber, @CalDate)
								WHEN 'm' THEN dateadd(month, @intNumber, @CalDate)
								WHEN 'y' THEN dateadd(year, @intNumber, @CalDate)
								END
						)
END
GO
