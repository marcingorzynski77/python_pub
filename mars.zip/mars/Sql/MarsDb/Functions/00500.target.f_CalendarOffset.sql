IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[f_CalendarOffset]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [target].[f_CalendarOffset]
GO


CREATE FUNCTION [target].[f_CalendarOffset]
--
-- Returns the date which is a specified number of business days away from the date supplied as the second parameter.
-- Determined using the Calander table in target, which also reflects holidsys
--
-- Offset  = -iO
--
--		i = signed integer in range -9999 to +9999 (note, -ve sign is before the supplied busdate, +ve is after)
--		O = one of the following offsets.
--			d - Business days
--			w - weeks
--			m - month end, based on the month of the date provided
--			q - quarter end, based on the month falling in a quarter month
--			y - year end - Note these are year ends from the supplied year
--
--	CalDate  = Datetime2 or string for the reference Calendar date e.g. '2016-01-01'
--
-- e.g. SELECT [target].[[f_CalendarOffset]]('-2Q','2016-02-24') would return 2015-09-30 (i.e the end of the last quarter)
--      SELECT [target].[[f_CalendarOffset]]('0M','2016-02-24') would return 2016-02-29 (i.e. the end of the current month)
(
	@Offset varchar(MAX),
	@CalDate DATETIME2
)
RETURNS varchar(2000) 
AS 

BEGIN

--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

	DECLARE @Ret varchar(2000)
	DECLARE @Positive bit
	DECLARE @intNumber int
	DECLARE @strPeriod varchar(1)
	declare @operator char(1)
	
	--DECLARE @Offset varchar(MAX); SET @Offset = '-0Y' --'-3Y'
	--DECLARE @CalDate DATETIME2; SET @CalDate = '2016-12-31' -- '2016-12-31'
	
	SET @operator = '='
	
	-- Extract sign, if there is one.
	IF LEFT(LTRIM(@Offset),1) = '-'
	BEGIN
		SET @Positive = 0
		SET @Offset = SUBSTRING(@Offset,2,LEN(@Offset)-1)		
	END
	ELSE IF LEFT(LTRIM(@Offset),2) = '>-'
	BEGIN
		SET @Positive = 0
		SET @Offset = SUBSTRING(@Offset,3,LEN(@Offset)-1)
		SET @operator = '<'
	END
	ELSE
	
		IF LEFT(LTRIM(@Offset),1) = '+'
		BEGIN
			SET @Positive = 1
			SET @Offset = SUBSTRING(@Offset,2,LEN(@Offset)-1)
		END
		ELSE
			SET @Positive = 1
			
	
	
	-- Remove the Numeric component. If no numeric, then use the value 1
	SET @intNumber = CAST(LEFT(@Offset,PATINDEX('%[^0-9]%', @Offset)-1) as integer) 
	--PRINT @intNumber
	SET @strPeriod = UPPER(SUBSTRING(@Offset,PATINDEX('%[^0-9]%', @Offset),1))

	if @intNumber <> 0 set @intnumber = @intnumber + 1


	declare @dates table
	(
		[Date] datetime2
		,[NextWorkingDate] datetime2
		,[PreviousWorkingDate] datetime2
	)

	IF @strPeriod = 'D' -- Business Days, Prefixed by Number of business days
	BEGIN 
		IF @POSITIVE = 1 or @intNumber = 0
		BEGIN
			if @operator = '='
			begin
				-- Business dates ahead 
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= @CalDate AND WorkingDay = 'Y') A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= @CalDate AND WorkingDay = 'Y') A
				WHERE A.SEQUENCE < @intNumber
			end
		END
		ELSE
		BEGIN
			if @operator = '='
			begin
				-- Business dates behind
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= @CalDate AND WorkingDay = 'Y') A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= @CalDate AND WorkingDay = 'Y') A
				WHERE A.SEQUENCE <= @intNumber
			end
		END
	END
	ELSE IF @strPeriod = 'W' -- Week (5 business days), Prefixed by Number of weeks
	BEGIN
		IF @POSITIVE = 1 or @intNumber = 0
		BEGIN
			if @operator = '='
			begin
				-- Business dates ahead 
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= @CalDate AND WorkingDay = 'Y' and [WeekDay] = (select [WeekDay] from target.Calendar where [DATE] = @caldate)) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= @CalDate AND WorkingDay = 'Y' and [WeekDay] = (select [WeekDay] from target.Calendar where [DATE] = @caldate)) A
				WHERE A.SEQUENCE < @intNumber
			end
		END
		ELSE
		BEGIN
			if @operator = '='
			begin
				-- Business dates behind
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= @CalDate AND WorkingDay = 'Y'and [WeekDay] = (select [WeekDay] from target.Calendar where [DATE] = @caldate)) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= @CalDate AND WorkingDay = 'Y'and [WeekDay] = (select [WeekDay] from target.Calendar where [DATE] = @CalDate)
					
					) A
				WHERE A.SEQUENCE <= @intNumber
			end
		END
	END
	ELSE IF @strPeriod = 'M' -- Month, Prefixed by Number representing the number of Months
	BEGIN 
		IF @POSITIVE = 1 or @intNumber = 0
		BEGIN
			if @operator = '='
			begin
				-- Business dates ahead 
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('M','Q','Y')) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('M','Q','Y')) A
				WHERE A.SEQUENCE < @intNumber
			end
		END
		ELSE
		BEGIN
			if @operator = '='
			begin
				-- Business dates behind
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('M','Q','Y')) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('M','Q','Y')) A
				WHERE A.SEQUENCE <= @intNumber
			end
		END
	END	
	ELSE IF @strPeriod = 'Q' -- Quarters, Prefixed by Number of Quarters
	BEGIN		
		IF @POSITIVE = 1 or @intNumber = 0
		BEGIN
			if @operator = '='
			begin
				-- This or future years ahead 
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('Q','Y')) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('Q','Y')) A
				WHERE A.SEQUENCE < @intNumber
			end
		END
		ELSE
		BEGIN
			if @operator = '='
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('Q','Y')) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= (cast(year(@CalDate) as varchar(4)) + '-' + cast(Month(@CalDate) as varchar(2)) + '-15') 
						AND PeriodEnd in ('Q','Y')) A
				WHERE A.SEQUENCE <= @intNumber
			end
		END
	END		
	ELSE IF @strPeriod = 'Y' -- Year, Prefixed by Number of Years
	BEGIN 
		IF @POSITIVE = 1 or @intNumber = 0
		BEGIN
			if @operator = '='
			begin
				-- This or future years ahead 
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= cast(year(@CalDate) as varchar(4)) AND PeriodEnd = ('Y')) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] >= cast(year(@CalDate) as varchar(4)) AND PeriodEnd = ('Y')) A
				WHERE A.SEQUENCE < @intNumber
			end
		END
		ELSE
		BEGIN
			if @operator = '='
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= cast(year(@CalDate) as varchar(4)) AND PeriodEnd = ('Y')) A
				WHERE A.SEQUENCE = @intNumber
			end
			else
			begin
				insert into @dates
				SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM (
					SELECT 	convert(varchar(10),[Date],120) [Date]
							, convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]
							, convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]
							, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE
					FROM [target].[Calendar]
					WHERE [Date] <= cast(year(@CalDate) as varchar(4)) AND PeriodEnd = ('Y')) A
				WHERE A.SEQUENCE <= @intNumber
			end
		END
	END	


	select @Ret = ''

	if @operator = '='
	begin
		if right(@Offset,2) = 'ND' select @Ret = (select [NextWorkingDate] from @dates)
		else if right(@Offset,2) = 'PD' select @Ret = (select [PreviousWorkingDate] from @dates)
		else select @Ret = (select [Date] from @dates)		
	end
	else
	begin
		if right(@Offset,2) = 'ND' select @Ret = @ret + ',''' + cast([NextWorkingDate] as varchar(10)) + '''' from @dates 
		else if right(@Offset,2) = 'PD' select @Ret = @ret + ',''' + cast([PreviousWorkingDate] as varchar(10)) + '''' from @dates 
		else select @Ret = @ret + ',"' + cast([DATE] as varchar(10)) + '"' from @dates 
		set @ret = right(@ret,LEN(@ret)-1)
	end

	-- PRINT @ret
    return @ret

END

GO


