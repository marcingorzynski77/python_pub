/****** Object:  UserDefinedFunction [target].[f_Dim_Hierarchy]    Script Date: 09/27/2017 12:47:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[f_Dim_Hierarchy]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [target].[f_Dim_Hierarchy]
GO


CREATE FUNCTION [target].[f_Dim_Hierarchy]()

RETURNS @RetTable TABLE

(	HierarchyKey INT
	,NodeId INT
	,NodeParentID INT
	,NodeName VARCHAR(255)
	,NodeType VARCHAR(255)
	,BookLegalEntity VARCHAR(255)
	,BookCad2 BIT
	,Ordinality BIT
	,Reporting BIT
	,Trading BIT
	,[Group] VARCHAR(255)
	,SubGroup VARCHAR(255)
	,Business  VARCHAR(255)
	,BusinessArea VARCHAR(255)
	,Division VARCHAR(255)
	,Desk VARCHAR(255)
	,SubDesk VARCHAR(255)
	,Book VARCHAR(255)
	,Booksystem VARCHAR(255)
	,HierarchyString VARCHAR(255)
)

AS 

BEGIN
   
    DECLARE @ret			datetime2
    DECLARE @strDate		varchar(19)
    DECLARE @SessionContext varbinary(128)
	DECLARE @XML			XML;

    DECLARE @SessionContextVaR varchar(max)

	SET @SessionContext = CONTEXT_INFO()
	SET @SessionContextVar = (SELECT CONVERT(VARCHAR(MAX),@SessionContext))

    --if @SessionContextVaR is not null
    if CHARINDEX('<T></T>',@SessionContextVaR) = 0
    begin
		--Convert session context to xml ready to parse	 
		SET @xml = CAST(replace( @SessionContextVaR COLLATE Latin1_General_BIN, nchar(0x00) COLLATE Latin1_General_BIN, '') as xml )


		--Parse XML to get the date
		SELECT @strDate = b.value('(./T/text())[1]','Varchar(50)') 		
		FROM @xml.nodes('/C') as a(b)
	end 

	
	IF  @strDate is not null and LEN(@strDate) > 0 --context date set and so keep target date floating
	begin
		INSERT INTO @RetTable
		SELECT     ISNULL(A.HierarchyKey, ' ') AS HierarchyKey, ISNULL(A.NodeId, ' ') AS NodeId, ISNULL(A.NodeParentID, ' ') 
							  AS NodeParentID, ISNULL(A.NodeName, ' ') AS NodeName, ISNULL(A.NodeType, ' ') AS NodeType, ISNULL(A.BookLegalEntity, ' ') AS BookLegalEntity, 
							  ISNULL(A.BookCad2, ' ') AS BookCad2, ISNULL(A.Ordinality, ' ') AS Ordinality, ISNULL(A.Reporting, ' ') AS Reporting, ISNULL(A.Trading, ' ') AS Trading, 
							  ISNULL(A.[Group], ' ') AS [Group],ISNULL(A.[SubGroup], ' ') AS [SubGroup], ISNULL(A.Business, ' ') AS Business, ISNULL(A.BusinessArea, ' ') AS BusinessArea, ISNULL(A.Division, ' ') AS Division, 
							  ISNULL(A.Desk, ' ') AS Desk, ISNULL(A.SubDesk, ' ') AS SubDesk, ISNULL(A.Book, ' ') AS Book, ISNULL(A.BookSystem, ' ') AS Booksystem, ISNULL(A.HierarchyString, 
							  ' ') AS HierarchyString
		FROM         target.vHierarchyConsolidated AS A 
			INNER JOIN (SELECT  TOP 1 TargetDate as VersionDateTime 
						from target.f_TargetDate() ORDER BY TargetDate ) AS TT2
			ON A.Start <= TT2.VersionDateTime and A.Finish > TT2.VersionDateTime     
	end
	ELSE
	begin --context date set to null and so fix target date as business date + 1 
		INSERT INTO @RetTable
		SELECT     ISNULL(A.HierarchyKey, ' ') AS HierarchyKey, ISNULL(A.NodeId, ' ') AS NodeId, ISNULL(A.NodeParentID, ' ') 
							  AS NodeParentID, ISNULL(A.NodeName, ' ') AS NodeName, ISNULL(A.NodeType, ' ') AS NodeType, ISNULL(A.BookLegalEntity, ' ') AS BookLegalEntity, 
							  ISNULL(A.BookCad2, ' ') AS BookCad2, ISNULL(A.Ordinality, ' ') AS Ordinality, ISNULL(A.Reporting, ' ') AS Reporting, ISNULL(A.Trading, ' ') AS Trading, 
							  ISNULL(A.[Group], ' ') AS [Group],ISNULL(A.[SubGroup], ' ') AS [SubGroup], ISNULL(A.Business, ' ') AS Business, ISNULL(A.BusinessArea, ' ') AS BusinessArea, ISNULL(A.Division, ' ') AS Division, 
							  ISNULL(A.Desk, ' ') AS Desk, ISNULL(A.SubDesk, ' ') AS SubDesk, ISNULL(A.Book, ' ') AS Book, ISNULL(A.BookSystem, ' ') AS Booksystem, ISNULL(A.HierarchyString, 
							  ' ') AS HierarchyString
		FROM         target.vHierarchyConsolidated AS A 
			INNER JOIN (select left(NextWorkingDate,10) + ' 23:59:59' as VersionDateTime 
						from target.Calendar where [DATE] = (select busdate from target.f_BusDate())) AS TT2
			ON A.Start <= TT2.VersionDateTime and A.Finish > TT2.VersionDateTime                   
	end                

    RETURN;
END;


GO


