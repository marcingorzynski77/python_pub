IF OBJECT_ID ('target.f_GetBusinessDate') IS NOT NULL
	DROP FUNCTION target.f_GetBusinessDate
GO

CREATE FUNCTION [target].[f_GetBusinessDate]
(
	@BusDate DATETIME2,
	@Offset INT,
	@Increment varchar(1) = 'D'	
)
RETURNS DATETIME2 
AS 
BEGIN

    DECLARE @PrevBusDate DATETIME2
    
    IF @Offset = 0
    BEGIN
		--No offsetting required
		SET @PrevBusDate = @BusDate
    END
    ELSE
    BEGIN
		if @Increment = 'D' 
		begin
			--Deduce previous date from calendar
			SET @PrevBusDate = (select MAX([Date]) AS PreviousWorkingDate 
				  			 from target.Calendar 
							 where DATE <= DATEADD(DAY, @Offset,@BusDate) 
								and WorkingDay = 'Y')
		end
		else if @Increment = 'M' 
		begin
			--Deduce previous month from calendar			
			SET @PrevBusDate = (select MAX(date) 
				  			 from target.Calendar 
							 where DATE <= DATEADD(MONTH,@Offset,@BusDate)
								and WorkingDay = 'Y')
		end
		else if @Increment = 'Y' 
		begin
			--Deduce previous month from calendar			
			SET @PrevBusDate = (select MAX(date) 
				  			 from target.Calendar 
							 where DATE <= DATEADD(YEAR,@Offset,@BusDate)
								and WorkingDay = 'Y')
		end
	END
	
    RETURN @PrevBusDate
END
GO
