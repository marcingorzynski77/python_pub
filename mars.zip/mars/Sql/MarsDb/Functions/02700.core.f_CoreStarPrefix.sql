/****** Object:  UserDefinedFunction [target].[f_CoreStarPrefix]    Script Date: 09/08/2017 11:08:28 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[f_CoreStarPrefix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [target].[f_CoreStarPrefix]
GO


CREATE FUNCTION [target].[f_CoreStarPrefix]
(
	@Datafeed VARCHAR(64)
)
RETURNS varchar(50) 
AS 
BEGIN

	declare @CoreStarPrefix as varchar(50) 

    -- Core Synchronisation Parameters
	SELECT @CoreStarPrefix =
		CASE
			WHEN
				@DATAFEED in (
					 'Murex-ComData31'
					,'Murex-ComGrk'
					,'Murex-COmiCommod'
					,'Murex-ComPvbp'
				) THEN 'MurexSensitivities'	
			WHEN
				@DATAFEED in (
					 'Hierarchy'
					,'HierarchyT'
				) THEN 'Hierarchy'
			WHEN
				@DATAFEED in (
					 'Limit'
					,'LimitT'
				) THEN 'Limit'
			WHEN	@DataFeed in( 
					 'SimraVaR1DPnLs'
					,'SimraVaR10DPnLs'
					,'SimraSVaR1DPnLs'
					,'SimraSVaR10DPnLs'
					,'SimraCore1StressTests'
				) THEN 'SimraPnLs'
			WHEN
				@DataFeed in (
					 'SimraMD_BondSwapSpread'
					,'SimraMD_CashSwapRate'
					,'SimraMD_CreditAssetSwap'
					,'SimraMD_CreditCDSCompositesSpread'
					,'SimraMD_CreditCDSIndex'
					,'SimraMD_ForeignExchangeVolatilitySwaps'
					,'SimraMD_FRASwap'
					,'SimraMD_FXSpotRates'
					,'SimraMD_FXVol'
					,'SimraMD_InflationVol'
					,'SimraMD_InflationRate'
					,'SimraMD_InterestRateCrossCurrencyBasisSpreadSwaps'
					,'SimraMD_InterestRateCrossCurrencyBasisSpreadSwapsOIS'
					,'SimraMD_InterestRateFRASwapsOIS'
					,'SimraMD_InterestRateTenorBasisSpreadSwaps'
					,'SimraMD_InterestRateTenorBasisSpreadSwapsOIS'
					,'SimraMD_InterestRateVolatilitySwaps'
					,'SimraMD_InterestRateVolatilitySwapsOIS'
					,'SimraMD_IRVol'
					,'SimraMD_LIBORSpread'
					,'SimraMD_TenorBasisSpread'
					,'SimraMD_X-CCYBasisSpread'
					,'SimraMD_ZeroForward'
				) THEN 'SimraMarketData'
			WHEN
				@DATAFEED in (
					'RRR-Counterparty'
					,'RRR-Hierarchy' 
					,'RRR-InstrumentType'
					,'RRR-RiskFactor' 
					,'RRR-RiskFactorType'
					,'RRR-RiskMeasureType'
					,'RRR-Trade' 
					,'RRR-TradeRule'
					,'RRR-TradeResults' 
					,'RRR-AggregatedResults'					 
				) THEN 'RRR'
			WHEN	@DataFeed in( 
					 'Var 1D PnL'
					,'Var 10D PnL'
					,'Stressed Var 1D PnL'
					,'Stressed Var 10D PnL'					
				) THEN 'MarsVaRs'
			WHEN    @Datafeed in (
					 'GDI_Inflation_ILDelta'
					,'GDI_Inflation_ILSeasonalDelta'
					,'GDI_Inflation_ILVolSmile'
					,'GDI_Inflation_ILCorrDelta'
					,'GDI_TInflation_Delta'
					,'GDI_HBOSInflation_ILDelta'
					,'GDI_HBOSInflation_ILSeasonalDelta'
					,'GDI_HBOSInflation_ILVega'
					,'GDI_HBOSInflation_ILVolSmile'
					,'GDI_HBOSInflation_ILCorrDelta'
					,'GDI_HBOSInflation_Vega'
				) THEN 'GDIRiskMeasureTrade'
			ELSE 
				@DataFeed
		END + '_'
	
    RETURN @CoreStarPrefix
END

GO


