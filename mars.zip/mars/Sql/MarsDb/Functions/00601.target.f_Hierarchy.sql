IF OBJECT_ID ('target.f_Hierarchy') IS NOT NULL
	DROP FUNCTION target.f_Hierarchy
GO

-- User Defined Function


-- User Defined Function
-- select * from [target].[f_Hierarchy]()
CREATE FUNCTION [target].[f_Hierarchy]()
-- Obatin the hierarchy from the session context.
-- If this has not been set, return default value 0
--
RETURNS @RetTable TABLE

( [Hierarchy] int NOT NULL) --with schemabinding
AS 

BEGIN

    DECLARE @ret			datetime2
    DECLARE @hierarchy		varchar(10)
    DECLARE @SessionContext varbinary(128)
	DECLARE @XML			XML;

    DECLARE @SessionContextvAR varchar(max)


	--Get existing context
	SET @SessionContext = CONTEXT_INFO()
	SET @SessionContextVar = (SELECT CONVERT(VARCHAR(MAX),@SessionContext))

	--SET @SessionContextVar = 	(SELECT CONVERT(VARCHAR(MAX),context_info) FROM sys.dm_exec_sessions
	--					where session_id = 										
	--						(select top 1 session_id FROM sys.dm_exec_sessions
	--						WHERE original_login_name = SYSTEM_USER 
	--							AND status in ('running','sleeping')
	--							AND NOT context_info = 0x
	--						ORDER BY login_time desc))


	if @SessionContextVar is not null
	begin


		--Convert session context to xml ready to parse	 
		SET @xml = CAST(replace( @SessionContextvAR COLLATE Latin1_General_BIN, nchar(0x00) COLLATE Latin1_General_BIN, '') as xml )


		--Get the date	
		SELECT @hierarchy = b.value('(./H/text())[1]','Varchar(50)') 		
		FROM @xml.nodes('/C') as a(b) 
	end

	--If the context has not been set.
	IF  @hierarchy is null OR LEN(@hierarchy) = 0
	BEGIN
		
		SET @hierarchy = '0'
	END

	INSERT @RetTable SELECT cast(@hierarchy as int)

    RETURN;
END;

GO

