IF OBJECT_ID ('core.f_PositionFactMonitor') IS NOT NULL
	DROP FUNCTION core.f_PositionFactMonitor
GO

CREATE FUNCTION [core].[f_PositionFactMonitor]
(
	 @FactType	VARCHAR(64)
	,@Interface	VARCHAR(64)
	,@ENV		VARCHAR(4)
	,@BusDate	DATETIME2
	,@Now		DATETIME2
)
RETURNS @Stats TABLE (
	  Start					DATETIME2
	, Finish				DATETIME2
	, SourceKey				BIGINT
	, RiskMeasureTypeKey	BIGINT
	, RiskFactorTypeKey		BIGINT
	, InstrumentTypeKey		BIGINT
	, Status				VARCHAR (128)
	, Count					BIGINT
)
AS
BEGIN
	--
	-- Summarise Position Fact loads
	--

	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT
		 F.Start
		,F.Finish
		,F.SourceKey
		,NULL as RiskMeasureTypeKey
		,NULL as RiskFactorTypeKey
		,F.InstrumentTypeKey
		,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END
		,count(*)
	FROM
		target.Position_Fact F
		JOIN
		target.Source S
		ON
			F.SourceKey = S.SourceKey
	WHERE
		F.Busdate = @BusDate
		AND
		S.InterfaceName = @Interface
	GROUP BY
		 F.BusDate
		,F.Start
		,F.Finish
		,F.SourceKey
		,S.InterfaceName
		,F.InstrumentTypeKey
		,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END
		
	-- capture raw stats
	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT
		 Null
		,Null
		,(SELECT TOP 1 SourceKey FROM target.Source S WHERE S.InterfaceName = @Interface AND S.Environment = @ENV) as SourceKey
		,NULL as RiskMeasureTypeKey
		,NULL as RiskFactorTypeKey
		,NULL as InstrumentTypeKey
		,'Raw'
		,count(*)
	FROM
		raw.Position_Control F	

	RETURN
END
GO
