IF OBJECT_ID ('core.ChecksumRows') IS NOT NULL
	DROP FUNCTION core.ChecksumRows
GO

CREATE FUNCTION [core].[ChecksumRows](@TargetTable varchar(50), @RefDateTime as datetime2(7), @ReturnColumn as varchar(50))
	RETURNS @ChecksumRows TABLE (
	   RecordKey	varchar(100) NULL,
	   RecordHash	int NULL,
	   Start		datetime2(7) NULL,
	   Finish		datetime2(7) NULL
) 
AS
BEGIN
	DECLARE @lTimeTravelSelect as varchar(50)
	DECLARE @ExcludeColumns as varchar(200)

	SET @ExcludeColumns = '"' + @ReturnColumn + '","Start","Finish","AppliedRules"'
	SELECT @lTimeTravelSelect = case when count(name) = 2 then 1 else 0 end
		FROM sys.columns WHERE object_id = OBJECT_ID(@TargetTable) 
			AND name in ('Start','Finish') and system_type_id = 42 -- Datetime2
	DECLARE @SQL nvarchar(1000)
	SET @SQL = ''
	SET @SQL = @SQL + ' DECLARE @lCompareColumns VARCHAR(4000)'
	SET @SQL = @SQL + ' DECLARE @lTimeTravelWhere as varchar(200)'
	SET @SQL = @SQL + ' SELECT @lCompareColumns = COALESCE(@lCompareColumns + ", ", "") + "[" + Name + "]"'
	SET @SQL = @SQL + '	FROM sys.columns WHERE object_id = OBJECT_ID("' + @TargetTable + '")' 
	SET @SQL = @SQL + '		and name not in (' + @ExcludeColumns + ')'
	SET @SQL = @SQL + ' PRINT "Compare columns " + @lCompareColumns'
	IF @lTimeTravelSelect = 0
		BEGIN
		SET @SQL = @SQL + ' SELECT ' + @ReturnColumn + ' RecordKey, BINARY_CHECKSUM(@lCompareColumns) RecordHash, Start, Finish'
		SET @SQL = @SQL + ' FROM ' + @TargetTable
		END
	ELSE
		BEGIN
		SET @SQL = @SQL + ' SELECT ' + @ReturnColumn + ' RecordKey, BINARY_CHECKSUM(@lCompareColumns) RecordHash, Start, Finish'
		SET @SQL = @SQL + ' FROM ' + @TargetTable + ' WHERE Start <= "' + CONVERT(NVARCHAR,ISNULL(@RefDateTime,GETUTCDATE()),120) + '" and Finish > "' + CONVERT(NVARCHAR,isnull(@RefDateTime,GETUTCDATE()),120) + '"'
		END
	SET @SQL = replace (@SQL,'"',char(39))
	--PRINT @SQL
	EXEC sp_executesql @SQL, N'@TargetTable varchar(50)', @TargetTable;
	
	RETURN;
END

GO

