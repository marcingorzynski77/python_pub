/****** Object:  UserDefinedFunction [core].[f_RRRTradeLevelFactMonitor]    Script Date: 01/10/2018 15:11:14 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[core].[f_RRRTradeLevelFactMonitor]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [core].[f_RRRTradeLevelFactMonitor]
GO


CREATE FUNCTION [core].[f_RRRTradeLevelFactMonitor]
(
	 @FactType	VARCHAR(64)
	,@Interface	VARCHAR(64)
	,@ENV		VARCHAR(4)
	,@BusDate	DATETIME2
	,@Now		DATETIME2
)
RETURNS @Stats TABLE (
	  Start					DATETIME2
	, Finish				DATETIME2
	, SourceKey				BIGINT
	, RiskMeasureTypeKey	BIGINT
	, RiskFactorTypeKey		BIGINT
	, InstrumentTypeKey		BIGINT
	, Status				VARCHAR (128)
	, Count					BIGINT
)
AS
BEGIN
	--
	-- Summarise RiskMeasure Fact loads
	--

	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT
		 F.Start
		,F.Finish
		,F.SourceKey
		,F.RiskMeasureTypeKey
		,NULL as RiskFactorTypeKey
		,NULL as InstrumentTypeKey
		,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END
		,count(*)
	FROM
		target.RRRTradeLevel_Fact F
		JOIN
		target.Source S
		ON
			F.SourceKey = S.SourceKey
	WHERE
		F.Busdate = @BusDate
		AND
		S.InterfaceName = @Interface
	GROUP BY
		 F.Start
		,F.Finish
		,F.SourceKey
		,S.InterfaceName
		,F.RiskMeasureTypeKey
		,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END

    
	-- capture raw stats
	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, RiskFactorTypeKey
		, InstrumentTypeKey
		, Status
		, Count
	)
	SELECT
		 Null
		,Null
		,(SELECT TOP 1 SourceKey FROM target.Source S WHERE S.InterfaceName = @Interface AND S.Environment = @ENV) as SourceKey
		,NULL as RiskMeasureTypeKey
		,NULL as RiskFactorTypeKey
		,NULL as InstrumentTypeKey
		,'Raw'
		,count(*)
	FROM
		raw.RRR_TradeResults F	
	
			
	RETURN
END

GO


