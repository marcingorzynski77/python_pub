IF OBJECT_ID ('core.f_LimitFactMonitor') IS NOT NULL
	DROP FUNCTION core.f_LimitFactMonitor
GO

CREATE FUNCTION [core].[f_LimitFactMonitor]
(
	 @FactType	VARCHAR(64)
	,@Interface	VARCHAR(64)
	,@ENV		VARCHAR(4)
	,@BusDate	DATETIME2
	,@Now		DATETIME2
)
RETURNS @Stats TABLE (
	  Start					DATETIME2
	, Finish				DATETIME2
	, SourceKey				BIGINT
	, RiskMeasureTypeKey	BIGINT
	, RiskFactorTypeKey		BIGINT
	, InstrumentTypeKey		BIGINT
	, Status				VARCHAR (128)
	, Count					BIGINT
)
AS
BEGIN
	--
	-- Summarise Limit Fact loads
	--

	DECLARE @NUM BIGINT

	SELECT @NUM = count(*) FROM target.Limit_Fact WHERE Start = @Now or Finish = @Now
	
	IF @NUM <> 0
	BEGIN
		INSERT INTO @Stats (
			  Start
			, Finish
			, SourceKey
			, RiskMeasureTypeKey
			, RiskFactorTypeKey
			, InstrumentTypeKey
			, Status
			, Count
		)
		SELECT
			 F.Start
			,F.Finish
			,F.SourceKey
			,F.RiskMeasureTypeKey
			,NULL as RiskFactorTypeKey
			,NULL as InstrumentTypeKey
			,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END
			,count(*)
		FROM
			target.Limit_Fact F
			JOIN
			target.Source S
			ON
				F.SourceKey = S.SourceKey
		WHERE
			S.InterfaceName = @Interface
		GROUP BY
			 F.Start
			,F.Finish
			,F.SourceKey
			,S.InterfaceName
			,F.RiskMeasureTypeKey
			,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END
			
		-- capture raw stats
		INSERT INTO @Stats (
			  Start
			, Finish
			, SourceKey
			, RiskMeasureTypeKey
			, RiskFactorTypeKey
			, InstrumentTypeKey
			, Status
			, Count
		)
		SELECT
			 Null
			,Null
			,(SELECT TOP 1 SourceKey FROM target.Source S WHERE S.InterfaceName = @Interface AND S.Environment = @ENV) as SourceKey
			,NULL as RiskMeasureTypeKey
			,NULL as RiskFactorTypeKey
			,NULL as InstrumentTypeKey
			,'Raw'
			,count(*)
		FROM
			raw.Limit F	
			
	END
	
	RETURN
END
GO
