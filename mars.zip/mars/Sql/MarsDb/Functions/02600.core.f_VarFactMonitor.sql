IF OBJECT_ID ('core.f_VaRFactMonitor') IS NOT NULL
	DROP FUNCTION core.f_VaRFactMonitor
GO

CREATE FUNCTION [core].[f_VaRFactMonitor]
(
	 @FactType	VARCHAR(64)
	,@Interface	VARCHAR(64)
	,@Env		VARCHAR(4)
	,@BusDate	DATETIME2
	,@Now		DATETIME2
)
RETURNS @Stats TABLE (
	  Start					DATETIME2
	, Finish				DATETIME2
	, SourceKey				BIGINT
	, RiskMeasureTypeKey	BIGINT
	, RiskFactorTypeKey		BIGINT
	, InstrumentTypeKey		BIGINT
	, Status				VARCHAR (128)
	, Count					BIGINT
)
AS
BEGIN
	--
	-- Summarise SIMRA VaR feed loads
	--

	INSERT INTO @Stats (
		  Start
		, Finish
		, SourceKey
		, RiskMeasureTypeKey
		, Status
		, Count
	)
	SELECT
		 F.Start
		,F.Finish
		,F.SourceKey
		,F.RiskMeasureTypeKey
		,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END
		,count(*)
	FROM target.VaR_Fact F
   INNER JOIN target.Source S
	  ON F.SourceKey = S.SourceKey
   WHERE F.Busdate = @BusDate
	 AND S.InterfaceName = @Interface
   GROUP BY
		 F.BusDate
		,F.Start
		,F.Finish
		,F.SourceKey
		,S.InterfaceName
		,F.RiskMeasureTypeKey
		,CASE WHEN F.finish > @Now THEN 'Active' ELSE 'Dead' END

    -- capture raw stats
	INSERT INTO @Stats (
		   Start
		  ,Finish
		  ,SourceKey
		  ,RiskMeasureTypeKey
		  ,Status
		  ,Count)
	SELECT NULL
		  ,NULL
		  ,(SELECT top 1 SourceKey FROM target.Source S WHERE S.InterfaceName = @Interface and S.Environment = @Env) as SourceKey
		  ,NULL RiskMeasureTypeKey
		  ,'Raw'
		  ,count(*)
	FROM
		raw.MarsVaRs F	
		
	RETURN
END
GO