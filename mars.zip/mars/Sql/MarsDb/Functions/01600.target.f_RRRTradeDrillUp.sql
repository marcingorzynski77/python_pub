/****** Object:  UserDefinedFunction [target].[f_RRRTradeDrillUp]    Script Date: 10/05/2017 15:14:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[f_RRRTradeDrillUp]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [target].[f_RRRTradeDrillUp]
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [target].[f_RRRTradeDrillUp]
(
	-- Add the parameters for the function here
	@TradeRef as varchar(255)
	
)
RETURNS @RetTable TABLE 
(
	-- Add the column definitions for the TABLE variable here
	TradeReference varchar(255)
	,FiredAt datetime2(7)	
	,AggregationID	varchar(2000)
	,AggregationType varchar(255)
	,AggregationRule varchar(1000)
	,RiskMeasureTypeName varchar(255)
	,RiskMeasureFamily varchar(255)
	--,InstrumentType varchar(255)	
	--,AssetClass varchar(255)
	--,Internal bit
	--,DerivativeFlag bit
	--,OptionFlag bit
	--,LegalEntity varchar(255)
	--,CounterpartyLegalName varchar(255)
	--,MaturityBucket varchar(255)
	--,Book varchar(50)
	--,SubDesk varchar(50)
	--,Desk varchar(50)
	--,Division varchar(50)
	--,BusinessArea varchar(50)
	--,Business varchar(50)
	--,SubGroup varchar(50)
	--,IncludedTrades varchar(50)
	--,ValueGbp float
	--,ValueCurrency varchar(3)
)
AS
BEGIN

	--bottom up
	insert into @RetTable
	SELECT 
		TradeReference
		,FiredAt	
		,RuleName as AggregationID
		,AggregationType
		,AggregationRule	
		,RiskMeasureTypeName
		,isnull(RiskMeasureFamily,'')
		--,isnull(InstrumentType,'')
		--,isnull(AssetClass,'')
		--,isnull(Internal,'')
		--,isnull(DerivativeFlag,'')
		--,isnull(OptionFlag,'')
		--,isnull(LegalEntity,'')
		--,isnull(CounterpartyLegalName,'')
		--,isnull(MaturityBucket,'')
		--,isnull(Book,'')
		--,isnull(SubDesk,'')
		--,isnull(Desk,'')
		--,isnull(Division,'')
		--,isnull(BusinessArea,'')
		--,isnull(Business,'')
		--,isnull(SubGroup,'')
		--,IncludedTrades
		--,ValueGbp
		--,ValueCurrency
	FROM [target].[TradeRule] R
	left outer join target.RRRAggregated_Fact A
	on A.AggregationID = r.RuleName
	left outer join target.RiskMeasureType M
	on A.RiskMeasureTypeKey = M.RiskMeasureTypeKey
	left outer join target.Hierarchy H
	on A.HierarchyKey = H.HierarchyKey
	where TradeReference = @TradeRef
	and r.BusDate = (select top 1 BusDate from target.f_BusDate())
	and a.BusDate = (select top 1 BusDate from target.f_BusDate())
	--and a.AggregationID = 'Net_Agg_Derivative_By_LegalEntity^LTSB|FxDelta'
	group by TradeReference
		,FiredAt 
		,RuleName	
		,AggregationType 
		,AggregationRule
		,RiskMeasureTypeName
		,RiskMeasureFamily 
	order by FiredAt 

	Return
	
END


GO


