IF OBJECT_ID ('target.f_BusDate') IS NOT NULL
	DROP FUNCTION target.f_BusDate
GO

-- User Defined Function

CREATE FUNCTION [target].[f_BusDate]()
-- Obatin the Buisnes Date from the session context.
-- If this has not been set, obtain the previous Business Date, before the time set by the 
-- time traveling function target.f_TargetDate
--	
-- IMPORTANT - This is needed to access SYS.DM_EXEC_SESSIONS
--
--		USE MASTER
--		GO
--		GRANT VIEW SERVER STATE TO [public]
--		GO
--
RETURNS @RetTable TABLE

( [BusDate] datetime2(7) NOT NULL) --with schemabinding
AS 

BEGIN

    DECLARE @ret			datetime2
    DECLARE @strDate		varchar(11)
    DECLARE @SessionContext varbinary(128)
	DECLARE @XML			XML;

    DECLARE @SessionContextvAR varchar(max)


	SET @SessionContext = CONTEXT_INFO()
	SET @SessionContextVar = (SELECT CONVERT(VARCHAR(MAX),@SessionContext))

	--SET @SessionContextVaR = 	(SELECT CONVERT(VARCHAR(MAX),context_info) FROM sys.dm_exec_sessions
	--					where session_id = 										
	--						(select top 1 session_id FROM sys.dm_exec_sessions
	--						WHERE original_login_name = SYSTEM_USER 
	--							AND status in ('running','sleeping')
	--							AND NOT context_info = 0x
	--						ORDER BY cast(context_info as varchar(max)) desc))


	--if @SessionContextVar is not null
	if CHARINDEX('<B></B>',@SessionContextVaR) = 0
	begin


		--Convert session context to xml ready to parse	 
		SET @xml = CAST(replace( @SessionContextvAR COLLATE Latin1_General_BIN, nchar(0x00) COLLATE Latin1_General_BIN, '') as xml )


		--Get the date	
		SELECT @strDate = b.value('(./B/text())[1]','Varchar(50)') 		
		FROM @xml.nodes('/C') as a(b) 
	end

	--If the context has not been set.
	IF  @strDate is null OR LEN(@strDate) = 0
	BEGIN
		-- Get the previous working day from the Calander
		SET @strDate = (SELECT PreviousWorkingDate from target.calendar where date = convert(date,getutcdate(),110))
		--if @ret is not null INSERT @RetTable SELECT @strDate

		-- If the Calander is missing, use the previous day (NOT previous working day)
		IF @strDate is null or LEN(@strDate) = 0
			SET @strDate = (SELECT DATEADD(DAY, -1, GETUTCDATE()) PreviousDate)
	END

	IF  @strDate is not null and LEN(@strDate) > 0
	BEGIN
		INSERT @RetTable SELECT @strDate
	END

    RETURN;
END;

GO
