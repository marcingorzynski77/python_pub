IF OBJECT_ID ('target.f_FactNames') IS NOT NULL
	DROP FUNCTION target.f_FactNames
GO

CREATE FUNCTION [target].[f_FactNames]
-- Return a list of all target fact tables 
--
()

RETURNS @RetTable TABLE
( [Facts] varchar(50))
AS 
BEGIN

	DECLARE @nSQL nVARCHAR(4000)
	SET @nSQL = ''
	SET @nSQL = @nSQL + ' DECLARE @genSQL nVARCHAR(4000); '
	SET @nSQL = @nSQL + 'SET @genSQL = ~SELECT SUBSTRING(T.Name,1,LEN(T.Name)-5) Fact
		FROM SYS.columns C
		JOIN SYS.tables T ON C.object_id = T.object_id
		JOIN SYS.schemas S ON S.schema_id = T.schema_id
		WHERE S.name = #TARGET#
			AND T.name LIKE #%_FACT# AND type_desc = #USER_TABLE#
			AND C.name in (#Start#,#Finish#) and system_type_id = 42 -- Datetime2
		GROUP BY T.Name
		HAVING COUNT(T.Name)=2 ~;'
	SET @nSQL = @nSQL + ' SET @genSQL = replace (@genSQL,char(35),char(39)); ' -- Exchange # for quote
	SET @nSQL = @nSQL + ' exec sp_executesql @genSQL'
	SET @nSQL = replace (@nSQL,char(126),char(39))
	--exec sp_executesql @nSQL
	--exec(@nSQL)
	--exec xp_exec @nSQL
	--EXECUTE(nSQL)
	-- Only functions and some extended stored procedures can be executed from within a function.
	
	-- xp_exec
	
    RETURN

END
GO
