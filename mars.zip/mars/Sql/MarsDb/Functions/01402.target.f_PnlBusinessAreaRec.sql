
-- User Defined Function

-- User Defined Function , 
-- select * from [target].[f_PnlDeskRec](0.01) 
-- select * from [target].[f_PnlBusinessAreaRec](0.01, '2017-02-15', '2017-02-15','SimraSVaR1DPnLs','PROD','SSF00003570')
CREATE FUNCTION [target].[f_PnlBusinessAreaRec]
(
	@ToleranceLevelInPercentage float = 1.00,
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(30),
	@Env		VARCHAR(6),
	@ExternalReference  VARCHAR(50),
	@Start datetime2,
	@SourceKey bigint
	--@Finish datetime2
)
RETURNS @RetTableBusinessArea TABLE
( IsMatch bit NULL
  ,DiffReason varchar(100)
  ,MarsPnL float
  ,MarsBusinessArea varchar(200)
  ,MarsLegalEntity varchar(50)
  ,MarsCad2 bit
  ,BridgePnL float
  ,BridgeBusinessArea varchar(200)
  ,BridgeLegalEntity varchar(50)
  ,BridgeCad2 bit
  ,[Difference] float
  --,ScenarioHierarchyKey bigint
  )
  
--( IsMatch bit NULL
--  ,DiffReason varchar(100)
--  ,MarsPnL float
--  ,MarsDesk varchar(200)
--  ,MarsBusinessArea varchar(200)
--  ,MarsLegalEntity varchar(50)
--  ,MarsCad2 bit
--  ,BridgePnL float
--  ,BridgeDesk varchar(200)
--  ,BridgeLegalEntity varchar(50)
--  ,BridgeCad2 bit
--)-- with schemabinding

AS 
BEGIN

	--Declare @RetTableBusinessArea TABLE
	--( IsMatch bit NULL
	--  ,DiffReason varchar(100)
	--  ,MarsPnL float
	--  ,MarsBusinessArea varchar(200)
	--  ,MarsLegalEntity varchar(50)
	--  ,MarsCad2 bit
	--  ,BridgePnL float
	--  ,BridgeBusinessArea varchar(200)
	--  ,BridgeLegalEntity varchar(50)
	--  ,BridgeCad2 bit)
	--Declare @root bigint
	--set @root = (select top 1 HierarchyKey from Hierarchy where NodeName like 'root' )

	INSERT @RetTableBusinessArea 
	SELECT 
		IsMatch, 
		CASE WHEN BridgeBusinessArea IS NULL Then 'No matching business area in bridge'
		WHEN MarsBusinessArea IS NULL Then 'No matching business area in mars'
		WHEN IsMatch = 0 Then 'Pnl difference grater than a threshold' 
		END DiffReason,
		MarsPnL,
		MarsBusinessArea,
		MarsLegalEntity,
		MarsCad2,
		BridgePnL,
		BridgeBusinessArea,
		BridgeLegalEntity,
		BridgeCad2,
		[Difference]--,
		--ScenarioHierarchyKey
	FROM
	(
	SELECT CASE WHEN ValueGBP IS NULL OR PnL IS NULL THEN 0 WHEN ValueGBP = 0 AND PnL = 0 THEN 1 WHEN PnL = 0 THEN 0 WHEN ABS(((ValueGBP/PnL))-1) * 100.00 > 1.00 Then 0 Else 1 End IsMatch, Mars.BusinessArea As MarsBusinessArea, Bridge.BusinessArea as BridgeBusinessArea, ValueGBP as MarsPnL, PnL as BridgePnL,IsNull(ValueGBP,0)- IsNull(PnL,0) as [Difference], Mars.BookCAD2 as MarsCad2, Bridge.Cad2 BridgeCad2, Mars.LegalEntity MarsLegalEntity, Bridge.LegalEntity BridgeLegalEntity--, ScenarioHierarchyKey
	FROM
	(
		SELECT SUM(ValueGBP) ValueGBP, LegalEntity, BusinessArea as BusinessArea, BookCAD2--, ScenarioHierarchyKey
		FROM
		(
			SELECT				  
				ISNULL(target.PnL_Fact.BusDate, ' ') AS BusDate,
				ISNULL(target.PnL_Fact.AnalysisTypeName, ' ') AS AnalysisTypeName, 
				target.PnL_Fact.ScenarioHierarchyKey AS ScenarioHierarchyKey, 
				--ISNULL(target.PnL_Fact.LegalEntity, ' ') AS LegalEntity,
				ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS LegalEntity,
				-- ISNULL(target.PnL_Fact.Cad2, ' ') AS Cad2,
				ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS Cad2,
				ISNULL(target.PnL_Fact.[Value], 0) AS [Value],
				ISNULL(target.PnL_Fact.[ValueGBP], 0) AS [ValueGBP],
				ISNULL(target.vHierarchyConsolidated.NodeId, ' ') AS NodeID, 
				ISNULL(target.vHierarchyConsolidated.NodeName, ' ') AS NodeName,
				--CASE target.vHierarchyConsolidated.NodeType WHEN 'BU' THEN 'Business' WHEN 'BA' THEN 'Business Area' WHEN 'DE' THEN 'Desk' WHEN 'SD' Then 'Sub Desk' WHEN 'BO' THEN 'Book' ELSE '' END BusinessEntityType,
				ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS BookLegalEntity,
				ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS BookCAD2,
				ISNULL(target.vHierarchyConsolidated.BusinessArea, ' ') AS BusinessArea,
				ISNULL(target.vHierarchyConsolidated.Business, ' ') AS Business,
				ISNULL(target.vHierarchyConsolidated.Division, ' ') AS Division, 
				ISNULL(target.vHierarchyConsolidated.Desk, ' ') AS Desk, 
				ISNULL(target.vHierarchyConsolidated.SubDesk, ' ') AS SubDesk,
				ISNULL(target.vHierarchyConsolidated.Book, ' ') AS Book,
				ISNULL(target.vHierarchyConsolidated.BookSystem, ' ') AS BookSystem,
				ISNULL(target.PnL_Fact.SourceKey, ' ') AS SourceKey,
				ISNULL(target.vHierarchyConsolidated.HierarchyKey, '') AS HierarchyKey
			FROM target.PnL_Fact 
			INNER JOIN target.vHierarchyConsolidated ON target.PnL_Fact.HierarchyKey = target.vHierarchyConsolidated.HierarchyKey 
			WHERE target.vHierarchyConsolidated.NodeType = 'BO'  --and [target].[f_IsBookInReportingDesk](target.vHierarchyConsolidated.HierarchyString) = 1
				--AND target.PnL_Fact.Start <= @Start and target.PnL_Fact.Finish > @Start and target.PnL_Fact.BusDate = @BusDate
				--AND target.vHierarchyConsolidated.Start <= @Start and target.vHierarchyConsolidated.Finish > @Start
				AND target.vHierarchyConsolidated.Start <= target.PnL_Fact.Start and target.vHierarchyConsolidated.Finish > target.PnL_Fact.Start and target.PnL_Fact.BusDate = @BusDate
				And target.PnL_Fact.SourceKey = @SourceKey
     
		)  AS REC 
		GROUP BY LegalEntity, BusinessArea, BookCAD2--, ScenarioHierarchyKey
	) AS Mars 
	FULL OUTER JOIN
	(
		SELECT SUM(RiskValue) as PnL, REC.NodeName as BusinessArea, Cad2, LegalEntity, BusinessEntityType FROM
		(
			SELECT
				 [ReportDate]    
				,[BusinessEntity]
				,[BusinessEntitySource]
				,[BusinessEntityType]
				,[DataType]
				,[RiskType]
				,Cast([RiskValue] as float) AS [RiskValue]
				,LEFT(BusinessEntity,CHARINDEX('CAD2',BusinessEntity)-2) [NodeName]
				,[2] [Cad2]
				,[3] [LegalEntity] 
			 FROM (select * from [raw].[SimraRiskPnL_Reconciliation] 
				   WHERE DataType like @ExternalReference
					  and cast (ReportDate as datetime2)=@BusDate
				   ) R 
			CROSS APPLY 
			target.f_split(RIGHT(R.BusinessEntity,LEN(R.BusinessEntity)-CHARINDEX('CAD2',R.BusinessEntity)),'_')
			PIVOT
			(
			 MAX(Item) FOR Position IN ([1],[2],[3],[4])
			) as P
		) AS REC 
		GROUP BY REC.NodeName, Cad2, LegalEntity, REC.BusinessEntityType
		HAVING BusinessEntityType like 'Business Area'
	) as Bridge 
	ON Mars.LegalEntity = Bridge.LegalEntity AND Mars.BusinessArea = Bridge.BusinessArea AND Mars.BookCAD2 = Bridge.Cad2
	--LEFT OUTER JOIN hc BH ON BH.BusinessArea =  Bridge.BusinessArea and BH.NodeType = 'BA' 
	) AS RES where IsMatch = 0
										

RETURN
END

