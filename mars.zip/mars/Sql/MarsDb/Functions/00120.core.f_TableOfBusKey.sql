
IF OBJECT_ID ('core.f_TableOfBusKey') IS NOT NULL
      DROP FUNCTION core.f_TableOfBusKey
GO

Create FUNCTION [core].[f_TableOfBusKey]
(  @SchemaName VARCHAR(50)
  ,@TableName  VARChar(50)
)
/*
Name: core.f_TableOfBusKey
Return Values: TABLE ( ( VarChar ) Id ) -- identical to core.Core2TargetParameter
Description: Receives a schema name and table name, it will find and exisitng index with name 'IX_BusKey_'+TableName
and return all the column as a table
*/
RETURNS @tblReturn TABLE (Id VarChar( MAX ))
AS
BEGIN

INSERT INTO @tblReturn ( [Id] ) 
SELECT  col.[name] AS Id
FROM    sys.indexes ind
        INNER JOIN sys.index_columns ic
            ON ind.object_id = ic.object_id
               AND ind.index_id = ic.index_id
        INNER JOIN sys.columns col
            ON ic.object_id = col.object_id
               AND ic.column_id = col.column_id
WHERE  ind.name like 'IX_BusKey_'+@TableName  + '%'              -- Index name
   and OBJECT_SCHEMA_NAME(ind.object_id) = @SchemaName -- Schema name
   and OBJECT_NAME(ind.object_id) = @TableName         -- Table name
      and col.[name] <> 'Start' and col.[name] <> 'Finish'
ORDER BY ic.key_ordinal

RETURN

END

Go
