IF OBJECT_ID ('target.f_LimitDate') IS NOT NULL
	DROP FUNCTION target.f_LimitDate
GO

-- User Defined Function

CREATE FUNCTION [target].[f_LimitDate]()
RETURNS @RetTable TABLE
( [LimitDate] date NOT NULL) --with schemabinding
AS 
BEGIN

    DECLARE @ret			datetime2
    DECLARE @strDate		varchar(11)
	DECLARE @SessionContext varbinary(128)
	DECLARE @XML			XML;
    DECLARE @SessionContextVaR varchar(max)

	SET @SessionContext = CONTEXT_INFO()
	SET @SessionContextVar = (SELECT CONVERT(VARCHAR(MAX),@SessionContext))

	--SET @SessionContextVaR = 	(SELECT CONVERT(VARCHAR(MAX),context_info) FROM sys.dm_exec_sessions
	--					where session_id = 										
	--						(select top 1 session_id FROM sys.dm_exec_sessions
	--						WHERE original_login_name = SYSTEM_USER 
	--							AND status in ('running','sleeping')
	--							AND NOT context_info = 0x
	--						ORDER BY cast(context_info as varchar(max)) desc))

	--if @SessionContextVaR is not null
	if CHARINDEX('<L></L>',@SessionContextVaR) = 0
	begin
		--Convert session context to xml ready to parse	 
		SET @xml = CAST(replace( @SessionContextVaR COLLATE Latin1_General_BIN, nchar(0x00) COLLATE Latin1_General_BIN, '') as xml )

		--Parse XML to get the date
		SELECT @strDate = b.value('(./L/text())[1]','Varchar(50)') 		
		FROM @xml.nodes('/C') as a(b) 

	end

	-- No date found, so use default of current Date & Time
	IF  @strDate is not null and LEN(@strDate) > 0 and @strDate <> ' '
		SET @ret = CONVERT(datetime2,@strDate,120)
	ELSE
		SET @ret = GETUTCDATE()

	INSERT @RetTable SELECT @RET

    RETURN;
END;

GO

