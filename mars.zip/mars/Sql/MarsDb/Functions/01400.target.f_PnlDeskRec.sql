IF OBJECT_ID ('target.f_PnlDeskRec') IS NOT NULL
	DROP FUNCTION target.f_PnlDeskRec
GO

-- User Defined Function
-- select * from [target].[f_PnlDeskRec](0.01)
CREATE FUNCTION [target].[f_PnlDeskRec]
(
	@ToleranceLevelInPercentage float = 1.00,
	@BusDate	DATETIME2,
	@NowDate	DATETIME2,
	@DataFeed	VARCHAR(30),
	@Env		VARCHAR(6),
	@ExternalReference  VARCHAR(50),
	@Start datetime2,
	@SourceKey int
)
RETURNS @RetTable TABLE
( IsMatch bit NULL
  ,DiffReason varchar(100)
  ,MarsPnL float
  ,MarsDesk varchar(200)
  ,MarsBusinessArea varchar(200)
  ,MarsLegalEntity varchar(50)
  ,MarsCad2 bit
  ,BridgePnL float
  ,BridgeDesk varchar(200)
  ,BridgeLegalEntity varchar(50)
  ,BridgeCad2 bit
)-- with schemabinding
AS 
BEGIN


INSERT @RetTable 
SELECT 
IsMatch, 
CASE WHEN BridgeDesk IS NULL Then 'No matching desk in bridge'
WHEN MarsDesk IS NULL Then 'No matching desk in mars'
WHEN IsMatch = 0 Then 'Pnl difference grater than a threshold' 
END DiffReason,
MarsPnL,
MarsDesk,
MarsBusinessArea,
MarsLegalEntity,
MarsCad2,
BridgePnL,
BridgeDesk,
BridgeLegalEntity,
BridgeCad2
FROM
(
SELECT CASE WHEN ValueGBP IS NULL OR PnL IS NULL THEN 0 WHEN ValueGBP = 0 AND PnL = 0 THEN 1 WHEN PnL = 0 THEN 0 WHEN ABS(((ValueGBP/PnL))-1) * 100.00 > 1.00 Then 0 Else 1 End IsMatch, Mars.Desk As MarsDesk, Bridge.Desk as BridgeDesk, ValueGBP as MarsPnL, PnL as BridgePnL, BookCAD2 as MarsCad2, Bridge.Cad2 BridgeCad2, Mars.LegalEntity MarsLegalEntity, Bridge.LegalEntity BridgeLegalEntity, BusinessArea as MarsBusinessArea  FROM
(
SELECT SUM(ValueGBP) ValueGBP, LegalEntity, Desk , BookCAD2, BusinessArea
FROM
(
SELECT				  ISNULL(target.PnL_Fact.BusDate, ' ') AS BusDate,
					  ISNULL(target.PnL_Fact.AnalysisTypeName, ' ') AS AnalysisTypeName, 
                      --ISNULL(target.PnL_Fact.LegalEntity, ' ') AS LegalEntity,
                      ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS LegalEntity,
                     -- ISNULL(target.PnL_Fact.Cad2, ' ') AS Cad2,
                      ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS Cad2,
                      ISNULL(target.PnL_Fact.[Value], 0) AS [Value],
                      ISNULL(target.PnL_Fact.[ValueGBP], 0) AS [ValueGBP],
                      ISNULL(target.vHierarchyConsolidated.NodeId, ' ') AS NodeID, 
                      ISNULL(target.vHierarchyConsolidated.NodeName, ' ') AS NodeName,
                      --CASE target.vHierarchyConsolidated.NodeType WHEN 'BU' THEN 'Business' WHEN 'BA' THEN 'Business Area' WHEN 'DE' THEN 'Desk' WHEN 'SD' Then 'Sub Desk' WHEN 'BO' THEN 'Book' ELSE '' END BusinessEntityType,
                      ISNULL(target.vHierarchyConsolidated.BookLegalEntity, ' ') AS BookLegalEntity,
                      ISNULL(target.vHierarchyConsolidated.BookCad2, ' ') AS BookCAD2,
                      ISNULL(target.vHierarchyConsolidated.BusinessArea, ' ') AS BusinessArea,
                      ISNULL(target.vHierarchyConsolidated.Business, ' ') AS Business,
                      ISNULL(target.vHierarchyConsolidated.Division, ' ') AS Division, 
                      ISNULL(target.vHierarchyConsolidated.Desk, ' ') AS Desk, 
                      ISNULL(target.vHierarchyConsolidated.SubDesk, ' ') AS SubDesk,
                      ISNULL(target.vHierarchyConsolidated.Book, ' ') AS Book,
                      ISNULL(target.vHierarchyConsolidated.BookSystem, ' ') AS BookSystem,
                      ISNULL(target.PnL_Fact.SourceKey, ' ') AS SourceKey
FROM         target.PnL_Fact 
					  --INNER JOIN (SELECT  TOP 1 busdate from target.f_BusDate() ORDER BY BusDate ) AS TT on target.PnL_Fact.BusDate = TT.BusDate
                      --INNER JOIN (SELECT  TOP 1 TargetDate as VersionDateTime from target.f_TargetDate() ORDER BY TargetDate ) AS TT2
                      INNER JOIN
                      target.vHierarchyConsolidated ON target.PnL_Fact.HierarchyKey = target.vHierarchyConsolidated.HierarchyKey 
                      WHERE target.vHierarchyConsolidated.NodeType = 'BO'  --and [target].[f_IsBookInReportingDesk](target.vHierarchyConsolidated.HierarchyString) = 1
                      --AND target.PnL_Fact.Start <= @Start and target.PnL_Fact.Finish > @Start and target.PnL_Fact.BusDate = @BusDate
					  --AND target.vHierarchyConsolidated.Start <= @Start and target.vHierarchyConsolidated.Finish > @Start
					  AND target.vHierarchyConsolidated.Start <= target.PnL_Fact.Start and target.vHierarchyConsolidated.Finish > target.PnL_Fact.Start and target.PnL_Fact.BusDate = @BusDate
					  AND target.PnL_Fact.SourceKey = @SourceKey
                      )  AS REC 
GROUP BY LegalEntity, Desk, BookCAD2, BusinessArea
) AS Mars FULL OUTER JOIN
(
SELECT SUM(RiskValue) as PnL, NodeName as Desk, Cad2, LegalEntity, BusinessEntityType FROM
(
	SELECT
	 [ReportDate]    
	,[BusinessEntity]
	,[BusinessEntitySource]
	,[BusinessEntityType]
	,[DataType]
	,[RiskType]
	,Cast([RiskValue] as float) AS [RiskValue]
	,[1] [NodeName]
	,[3] [Cad2]
	,[4] [LegalEntity] 
	 FROM [raw].[SimraRiskPnL_Reconciliation] R CROSS APPLY target.f_split(R.BusinessEntity,'_')
	PIVOT
	(
	 MAX(Item) FOR Position IN ([1],[2],[3],[4])
	  
	) as P  WHERE DataType like @ExternalReference and cast(ReportDate as datetime2) = @BusDate
) AS REC
GROUP BY NodeName, Cad2, LegalEntity, BusinessEntityType
HAVING BusinessEntityType in ('Desk')
) as Bridge 
ON Mars.LegalEntity = Bridge.LegalEntity AND Mars.Desk = Bridge.Desk AND Mars.BookCAD2 = Bridge.Cad2
) AS RES where IsMatch = 0

    RETURN
END

GO
