IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[target].[f_CalendarOffset]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	DROP FUNCTION [target].[f_CalendarOffset]
GO


CREATE FUNCTION [target].[f_CalendarOffset]
--
-- Returns the date which is a specified number of business days away from the date supplied as the second parameter.
-- Determined using the Calander table in target, which also reflects holidsys
--
-- Offset  = -iO
--
--		i = signed integer in range -9999 to +9999 (note, -ve sign is before the supplied busdate, +ve is after)
--		O = one of the following offsets.
--			d - Business days
--			w - weeks
--			m - month end, based on the month of the date provided
--			q - quarter end, based on the month falling in a quarter month
--			y - year end - Note these are year ends from the supplied year
--
--	CalDate  = Datetime2 or string for the reference Calendar date e.g. '2016-01-01'
--
-- e.g. SELECT [target].[[f_CalendarOffset]]('-2Q','2016-02-24') would return 2015-09-30 (i.e the end of the last quarter)
--      SELECT [target].[[f_CalendarOffset]]('0M','2016-02-24') would return 2016-02-29 (i.e. the end of the current month)
(
	@Offset varchar(MAX),
	@CalDate DATETIME2
)
RETURNS varchar(10) 
AS 

BEGIN

--#---------------------------------------------- END OF STANDARD HEADER ----------------------------------------------#--
--#====================================================================================================================#--

	DECLARE @Ret varchar(10)
			,@Positive bit
			,@intNumber int
			,@strPeriod varchar(1)
			,@SQL nvarchar(4000)
			,@Operator varchar(2)
			,@CalDateString as varchar(10)
			,@CalDateDay as varchar(2)
			,@CalDateMonth as varchar(2)
			,@CalDateYear as varchar(4);
	
	Set @CalDateString = CAST(@CalDate as varchar(10))
	Set @CalDateDay = CAST(day(@CalDate) as varchar(2))
	Set @CalDateMonth = CAST(month(@CalDate) as varchar(2))
	Set @CalDateYear = CAST(year(@CalDate) as varchar(4))
	set @SQL = ''
	set @Operator = '='

	
	-- Extract sign, if there is one.
	IF LEFT(LTRIM(@Offset),1) = '-'
	BEGIN
		SET @Positive = 0
		SET @Offset = SUBSTRING(@Offset,2,LEN(@Offset)-1)
	END
	ELSE
		IF LEFT(LTRIM(@Offset),1) = '+'
		BEGIN
			SET @Positive = 1
			SET @Offset = SUBSTRING(@Offset,2,LEN(@Offset)-1)
		END
		ELSE
			SET @Positive = 1
	
	-- Remove the Numeric component. If no numeric, then use the value 1
	SET @intNumber = CAST(LEFT(@Offset,PATINDEX('%[^0-9]%', @Offset)-1) as integer)
	--PRINT @intNumber
	SET @strPeriod = UPPER(SUBSTRING(@Offset,PATINDEX('%[^0-9]%', @Offset),1))


	declare @dates table
	(
		[Date] datetime2
		,[NextWorkingDate] datetime2
		,[PreviousWorkingDate] datetime2
	)

	-- Business dates ahead 
	set @sql = @sql + 'SELECT A.[Date],A.NextWorkingDate,A.PreviousWorkingDate FROM ('
					+ '	SELECT 	convert(varchar(10),[Date],120) [Date]'
					+ ' , convert(varchar(10),[NextWorkingDate],120) [NextWorkingDate]'
					+ ' , convert(varchar(10),[PreviousWorkingDate],120) [PreviousWorkingDate]'


	IF @strPeriod = 'D' 
	BEGIN 	
		-- Business Days, Prefixed by Number of business days
		IF @POSITIVE = 1 or @intNumber = 0		
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE	FROM [target].[Calendar] WHERE [Date] >= ' + @CalDateString + ' AND WorkingDay = ''Y'') A'
		ELSE
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE FROM [target].[Calendar] WHERE [Date] < ' + @CalDateString + ' AND WorkingDay = ''Y'') A'
		
		set @SQL = @SQL + ' WHERE A.SEQUENCE ' + @operator + ' ' + cast(@intNumber as varchar(4)) --+')B'

	END
	ELSE IF @strPeriod = 'W' 
	BEGIN
		-- Week (5 business days), Prefixed by Number of weeks
		IF @POSITIVE = 1 or @intNumber = 0		
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE	FROM [target].[Calendar] '
							+ 'WHERE [Date] >= ' + @CalDateString + ' AND WorkingDay = ''Y'' '
							+ 'and [WeekDay] = (select [WeekDay] from target.Calendar where [DATE] = ' + @CalDateString + ')) A'
		ELSE
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE FROM [target].[Calendar] '
							+ 'WHERE [Date] < ' + @CalDateString + ' AND WorkingDay = ''Y'' '
							+ 'and [WeekDay] = (select [WeekDay] from target.Calendar where [DATE] = ' + @CalDateString + ')) A'
		
		set @SQL = @SQL + ' WHERE A.SEQUENCE ' + @operator + ' ' + cast(@intNumber as varchar(4)) --+')B'
	
	END
	ELSE IF @strPeriod = 'M' 
	BEGIN 
		-- Month, Prefixed by Number representing the number of Months
		IF @POSITIVE = 1 or @intNumber = 0					
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE	FROM [target].[Calendar] ' 
							+ ' WHERE [Date] >= (''' + @CalDateYear + '-' + @CalDateMonth + '-' + @CalDateDay + ''') ' 
							+ ' AND PeriodEnd in (''M'',''Q'',''Y'')) A'
		ELSE
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE FROM [target].[Calendar] '
							+ ' WHERE [Date] < (''' + @CalDateYear + '-' + @CalDateMonth + '-' + @CalDateDay + ''') ' 
							+ ' AND PeriodEnd in (''M'',''Q'',''Y'')) A'
		
		set @SQL = @SQL + ' WHERE A.SEQUENCE ' + @operator + ' ' + cast(@intNumber as varchar(4)) --+')B'
		
	END	
	ELSE IF @strPeriod = 'Q' 
	BEGIN 
		-- Quarters, Prefixed by Number of Quarters
		IF @POSITIVE = 1 or @intNumber = 0		
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE	FROM [target].[Calendar] '
							+ 'WHERE [Date] >= (''' + @CalDateYear + ' + ''-'' + ' + @CalDateMonth + '-' + @CalDateDay + ''') ' 
							+ 'AND PeriodEnd in (''Q'',''Y'')) A'
		ELSE
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE FROM [target].[Calendar] '
							+ 'WHERE [Date] < (''' + @CalDateYear + ' + ''-'' + ' + @CalDateMonth + '-' + @CalDateDay + ''') ' 
							+ 'AND PeriodEnd in (''Q'',''Y'')) A'
		
		set @SQL = @SQL + ' WHERE A.SEQUENCE ' + @operator + ' ' + cast(@intNumber as varchar(4)) --+')B'
	
	END		
	ELSE IF @strPeriod = 'Y' 
	BEGIN 
		-- Year, Prefixed by Number of Years
		IF @POSITIVE = 1 or @intNumber = 0		
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] ASC) -1 SEQUENCE	FROM [target].[Calendar] '
							+ 'WHERE [Date] >= ' + @CalDateYear
							+ 'AND PeriodEnd = ''Y'') A'
		ELSE
			set @SQL = @SQL + '	, RANK() OVER (ORDER BY [Date] DESC)  SEQUENCE FROM [target].[Calendar] '
							+ 'WHERE [Date] < ' + @CalDateYear
							+ 'AND PeriodEnd = ''Y'') A'
		
		set @SQL = @SQL + ' WHERE A.SEQUENCE ' + @operator + ' ' + cast(@intNumber as varchar(4))-- +')B'
	
	END	
	

	--execute the SQL and insert into table
	INSERT into @Dates execute (@SQL)

	--extract required columns
	if right(@Offset,2) = 'ND' set @Ret = (select [NextWorkingDate] from @dates)
	else if right(@Offset,2) = 'PD' set @Ret = (select [PreviousWorkingDate] from @dates)
	else set @Ret = (select [DATE] from @dates)
	
	
    RETURN @ret

END
GO
