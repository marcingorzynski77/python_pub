﻿IF OBJECT_ID ('core.f_Target2CoreGetColumnGroups') IS NOT NULL
	DROP FUNCTION target.f_Hierarchy
GO

CREATE FUNCTION [core].[f_Target2CoreGetColumnGroups]
(
	@TargetTable	NVARCHAR(100),
	@CoreTable		NVARCHAR(100)
)
RETURNS @ColumTable TABLE
(
	[GROUPING] VARCHAR(20),
	[ColumnName]   VARCHAR(100)
)
AS
BEGIN

;WITH coreColumns AS
	( 
		SELECT	Name 
		FROM sys.columns 
		WHERE object_id = OBJECT_ID(@CoreTable) 
		AND RIGHT(Name,3) <> 'Key'
	), targetColumns AS
	( 
		SELECT	Name 
		FROM	sys.columns 
		WHERE	object_id = OBJECT_ID(@TargetTable)
		AND NOT NAME IN ('Start','Finish')
		AND	RIGHT(Name,3) <> 'Key'
	), [Columns] AS
	(
		SELECT	C.name C_COLUMN, 
				T.Name T_COLUMN 
		FROM				coreColumns C 
		FULL OUTER JOIN		targetColumns T ON C.name = T.Name
	) 
	INSERT INTO @ColumTable ([GROUPING], [ColumnName]) 
	SELECT 
		'Common' [GROUPING], 
		C_Column [ColumnName] 
	FROM [Columns] 
	WHERE C_COLUMN is not null AND T_COLUMN is not null
	UNION
	SELECT 
		'UniqueToCore' [GROUPING], 
		C_Column [ColumnName] 
	FROM [Columns] 
	WHERE C_COLUMN is not null AND T_COLUMN is null
	UNION
	SELECT 
		'UniqueToTarget' [GROUPING], 
		T_Column [ColumnName] 
	FROM [Columns] 
	WHERE C_COLUMN is null AND T_COLUMN is not null;

	RETURN;

END
