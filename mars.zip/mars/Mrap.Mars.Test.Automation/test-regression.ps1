
[CmdletBinding(SupportsShouldProcess=$True)]
param (
[Parameter(Mandatory=$true)]
[string] $db_server, 
[Parameter(Mandatory=$true)]
[string] $db_name, 
[bool] $build_db = $false 
)

$VerbosePreference = "Continue"
$DebugPreference = "Continue"

Write-Debug "Setting APP_CONFIG_FILE path to $PSScriptRoot\config\app-regression.config"
[appdomain]::CurrentDomain.SetData("APP_CONFIG_FILE", "$PSScriptRoot\config\app-regression.config")
Add-Type -AssemblyName System.Configuration

."$PSScriptRoot\logger.ps1"
$path = (get-item $PSScriptRoot).Parent.FullName
$log = New-Logger -Configuration "$PSScriptRoot\log4net.config" -Dll "$path\log4net.dll"
Import-Module "$path\Mrap.ScenarioVault.Powershell.dll"
Import-Module "$path\Mrap.Simra.ScenarioAdapter.dll"

# import script - create db
if ($build_db){
	Try {
		Write-Debug "Running data seed for $db_server $db_name $PSScriptRoot"
		$success = Get-runscript "$PSScriptRoot\data_seed.cs" $db_server $db_name "$PSScriptRoot"
	} Catch {
		$ErrorMessage = $_.Exception.Message
		Write-Host "Database creation failed with: '$ErrorMessage'"
		break
	}
}

# get run id
$run_id_file = "$PSScriptRoot/run_id.txt"
[int]$run_id = 1
if (Test-Path "$run_id_file") {
	$run_id = [int](Get-Content "$run_id_file" -First 1)
	$run_id ++
	$run_id | Out-File $run_id_file
} else {
    $run_id | Out-File $run_id_file
}

# prepare test results folder
#$results_folder_name = "$PSScriptRoot\TestsResults\Run $run_id ($((Get-Date).ToString()))"  
$results_folder_name = "$PSScriptRoot\TestsResults\Run $run_id"  
New-Item "$results_folder_name" -ItemType Directory

# read and execute tests
$defintions_folder_name = "$PSScriptRoot\TestsDefinitions"
$expected_file_name = "expected.csv"
$parameters_file_name = "parameters.txt"
$diff_file_name = "diff.html"

if (-Not (Test-Path "$defintions_folder_name")) {
    $missing_folder_error = [string] "The test harness folder does not contain test defintion folder ('$defintions_folder_name'), which is required."
    Throw $missing_folder_error
}

Write-Debug "Definitions folder: $defintions_folder_name" 

$tests_definitions = Get-ChildItem -Path $defintions_folder_name -Include $expected_file_name -Recurse

if ($tests_definitions -eq $null) {
    $missing_tests_error = [string] "The test folder ('$defintions_folder_name') does not contain any test."
    Throw $missing_tests_error
}

ForEach($test_definition in $tests_definitions) { # loop through tests
	$test_name = $test_definition.Directory.Name
	Write-Debug "Test name: $test_name" 
	$defintion_folder_name = $test_definition.Directory.FullName

	# check if all required files are there
	$params_file_name = "$defintion_folder_name\$parameters_file_name"

	if (-Not (Test-Path "$defintion_folder_name\$parameters_file_name")) {
		"Missing file: $parameters_file_name in $defintion_folder"
		Continue
	}

	# create result folder
	$result_folder_name = "$defintion_folder_name".Replace("$defintions_folder_name", "$results_folder_name")
	Write-Debug "Result folder: $result_folder_name"
	New-Item "$result_folder_name" -ItemType Directory

	$(
		# invoke test
		# New-TestRun ExportFilePath ScriptDbServer ScriptDbName InputParameterPath AdapterConfigPath IsTraceabilityEnabled IsOptimizationEnabled TimeoutInSec
		$result_file_name = "$result_folder_name\result.csv"
		Write-Debug "Invoking tests. Params: '$result_file_name' '$db_server' '$db_name' '$defintion_folder_name' '$PSScriptRoot' '$false' '$true' 60"
#		Read-Host -Prompt "Press Enter ($pid) ..."

		Try {
			##   StressHarnessScript
			New-TestRun "$result_file_name" "$db_server" "$db_name" "$defintion_folder_name" "$PSScriptRoot" $false $true 60
		} Catch {
			$ErrorMessage = $_.Exception.Message
			Write-Host "SIMRA Adapter failed with: '$ErrorMessage'"
			Write-Debug $_.Exception|format-list -force
			break
		}
	) *>&1 > "$result_folder_name\run.log"

#	$csv_diff_file_name = "$result_folder_name\$diff_file_name"
#	$base_file_name = "$test_definition"
#	# run diff 
#    $command = "&""$PSScriptRoot\csv-diff.ps1"" $run_id ""$test_name"" ""$params_file_name"" ""$base_file_name"" ""$result_file_name"" ""$csv_diff_file_name"""
#    Write-Debug "Running diff. Command: $command"
#	Invoke-Expression $command
}

# create the summary file
$command = "&""$PSScriptRoot\diff-summary.ps1"" $run_id ""$results_folder_name"""
Write-Debug "Running summary. Command: $command"
Invoke-Expression $command

Write-Host "Done Run $run_id" 
