USE master
GO
IF EXISTS(select * from sys.databases where name='MaRs_Regression')
BEGIN
alter database MaRs_Regression set single_user with rollback immediate
DROP DATABASE MaRs_Regression
END
GO