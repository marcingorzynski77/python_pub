
USE [master]


IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'MaRS_Regression')
BEGIN
	RAISERROR('Database MaRS_Regression already exists.  Drop database first.', 1, 1) WITH NOWAIT
	
	SELECT '!! ERROR !!', 'Database MaRS_Regression already exists.  Drop database first.'
	RETURN
END
ELSE
BEGIN
	IF 'BRIDGED01' = 'TRIDENTD01'
	BEGIN
		CREATE DATABASE [MaRS_Regression] ON  PRIMARY 
		( NAME = N'MaRS_Regression', FILENAME = N'G:\Data\MSSQL10_50.BRIDGED01\MSSQL\DATA\MaRS_Regression.mdf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1048576KB )
		 LOG ON 
		( NAME = N'MaRS_Regression_log', FILENAME = N'G:\Log\MSSQL10_50.BRIDGED01\MSSQL\Log\MaRS_Regression_log.ldf' , SIZE = 1000000KB , MAXSIZE = 2048GB , FILEGROWTH = 1048576KB )
		
		ALTER DATABASE [MaRS_Regression] ADD FILEGROUP [MaRS_Regression_FG_PnlFact_Part_Unallocated]
		ALTER DATABASE [MaRS_Regression] ADD FILE ( NAME = N'MaRS_Regression_FG_PnlFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGED01\MSSQL\DATA\MaRS_Regression_FG_PnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_Regression_FG_PnlFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_Regression] ADD FILEGROUP [MaRS_Regression_FG_RiskMeasurePnlFact_Part_Unallocated]
		ALTER DATABASE [MaRS_Regression] ADD FILE ( NAME = N'MaRS_Regression_FG_RiskMeasurePnlFact_Part_Unallocated', FILENAME = N'G:\Data\MSSQL10_50.BRIDGED01\MSSQL\DATA\MaRS_Regression_FG_RiskMeasurePnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_Regression_FG_RiskMeasurePnlFact_Part_Unallocated]
		
		
		
	END
	ELSE IF 'BRIDGED01' = 'BRIDGED01' OR 'BRIDGED01' = 'BRIDGEU01'
	BEGIN
		CREATE DATABASE [MaRS_Regression] ON  PRIMARY 
		( NAME = N'MaRS_Regression', FILENAME = N'H:\Data\MSSQL10_50.BRIDGED01\MSSQL\DATA\MaRS_Regression.mdf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1048576KB )
		 LOG ON 
		( NAME = N'MaRS_Regression_log', FILENAME = N'H:\Log\MSSQL10_50.BRIDGED01\MSSQL\Log\MaRS_Regression_log.ldf' , SIZE = 1000000KB , MAXSIZE = 2048GB , FILEGROWTH = 1048576KB )
		

		ALTER DATABASE [MaRS_Regression] ADD FILEGROUP [MaRS_Regression_FG_PnlFact_Part_Unallocated]
		ALTER DATABASE [MaRS_Regression] ADD FILE ( NAME = N'MaRS_Regression_FG_PnlFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGED01\MSSQL\DATA\MaRS_Regression_FG_PnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_Regression_FG_PnlFact_Part_Unallocated]
		
		ALTER DATABASE [MaRS_Regression] ADD FILEGROUP [MaRS_Regression_FG_RiskMeasureFact_Part_Unallocated]
		ALTER DATABASE [MaRS_Regression] ADD FILE ( NAME = N'MaRS_Regression_FG_RiskMeasureFact_Part_Unallocated', FILENAME = N'H:\Data\MSSQL10_50.BRIDGED01\MSSQL\DATA\MaRS_Regression_FG_RiskMeasurePnlFact_Part_Unallocated.ndf' , SIZE = 1000000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1000000KB ) TO Filegroup [MaRS_Regression_FG_RiskMeasureFact_Part_Unallocated]
		
		
		--Create Partition Function PnlFact_RangePartFunction (datetime2) as Range LEFT For Values ()
		

		--Create Partition Scheme PnlFact_RangePartScheme as Partition PnlFact_RangePartFunction To ([MaRS_Regression_FG_PnlFact_Part_Unallocated])
		--use [master]
		--go
	END
	
	
END




ALTER DATABASE [MaRS_Regression] SET COMPATIBILITY_LEVEL = 100


IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
	EXEC [MaRS_Regression].[dbo].[sp_fulltext_database] @action = 'enable'
end


ALTER DATABASE [MaRS_Regression] SET ANSI_NULL_DEFAULT OFF 

ALTER DATABASE [MaRS_Regression] SET ANSI_NULLS OFF 

ALTER DATABASE [MaRS_Regression] SET ANSI_PADDING OFF 

ALTER DATABASE [MaRS_Regression] SET ANSI_WARNINGS OFF 

ALTER DATABASE [MaRS_Regression] SET ARITHABORT OFF 

ALTER DATABASE [MaRS_Regression] SET AUTO_CLOSE OFF 

ALTER DATABASE [MaRS_Regression] SET AUTO_CREATE_STATISTICS ON 

ALTER DATABASE [MaRS_Regression] SET AUTO_SHRINK OFF 

ALTER DATABASE [MaRS_Regression] SET AUTO_UPDATE_STATISTICS ON 

ALTER DATABASE [MaRS_Regression] SET CURSOR_CLOSE_ON_COMMIT OFF 

ALTER DATABASE [MaRS_Regression] SET CURSOR_DEFAULT  GLOBAL 

ALTER DATABASE [MaRS_Regression] SET CONCAT_NULL_YIELDS_NULL OFF 

ALTER DATABASE [MaRS_Regression] SET NUMERIC_ROUNDABORT OFF 

ALTER DATABASE [MaRS_Regression] SET QUOTED_IDENTIFIER OFF 

ALTER DATABASE [MaRS_Regression] SET RECURSIVE_TRIGGERS OFF 

ALTER DATABASE [MaRS_Regression] SET  DISABLE_BROKER 

ALTER DATABASE [MaRS_Regression] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 

ALTER DATABASE [MaRS_Regression] SET DATE_CORRELATION_OPTIMIZATION OFF 

ALTER DATABASE [MaRS_Regression] SET TRUSTWORTHY ON 

ALTER DATABASE [MaRS_Regression] SET ALLOW_SNAPSHOT_ISOLATION OFF 

ALTER DATABASE [MaRS_Regression] SET PARAMETERIZATION SIMPLE 

ALTER DATABASE [MaRS_Regression] SET READ_COMMITTED_SNAPSHOT OFF 

ALTER DATABASE [MaRS_Regression] SET HONOR_BROKER_PRIORITY OFF 

ALTER DATABASE [MaRS_Regression] SET READ_WRITE 

ALTER DATABASE [MaRS_Regression] SET RECOVERY SIMPLE 

ALTER DATABASE [MaRS_Regression] SET  MULTI_USER 

ALTER DATABASE [MaRS_Regression] SET PAGE_VERIFY CHECKSUM  

ALTER DATABASE [MaRS_Regression] SET DB_CHAINING OFF 



EXEC sys.sp_db_vardecimal_storage_format N'MaRS_Regression', N'ON'


PRINT 'MaRS database created'
