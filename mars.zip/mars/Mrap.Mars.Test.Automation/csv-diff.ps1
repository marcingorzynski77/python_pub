﻿
[CmdletBinding(SupportsShouldProcess=$True)]
param (
[Parameter(Mandatory=$true)]
[int] $run_id,
[Parameter(Mandatory=$true)]
[string] $test_name,
[Parameter(Mandatory=$true)]
[string] $params_file_name,
[Parameter(Mandatory=$true)]
[string] $base_file_name,
[Parameter(Mandatory=$true)]
[string] $result_file_name,
[Parameter(Mandatory=$true)]
[string] $diff_file_name,
[Parameter(Mandatory=$true)]
[int] $write_header	 
)

if($write_header -eq 1)
{
	Write-Debug "reading tmp path $global:tmp_file"
	$tmp_f = Get-Content $global:tmp_file
	$global:header | Out-File $diff_file_name
	$global:summary | Out-File $diff_file_name -Append 	 
	$tmp_f | Out-File $diff_file_name -Append  
	$global:footer | Out-File $diff_file_name -Append  
	Remove-Item $global:tmp_file
	
	return;
}
else
{
    Write-Debug "setting tmp path $diff_file_name"
	$global:tmp_file = $diff_file_name
}

#$bf = Get-Content $base_file_name -First 1
#$rf = Get-Content $result_file_name -First 1

#$bf = $bf -split ',' 
#$rf = $rf -split ',' 
Write-Debug "load csv files for comparison"
$base = Import-Csv $base_file_name #| Sort-Object $bf
$result = Import-Csv $result_file_name #| Sort-Object $rf
$params = Get-Content $params_file_name

$errors_fields = 0
$errors_rows = 0
$line_count = 0
$run_time = (Get-Date).ToString()

$diff_table = @()
Write-Debug "loop through base file"
## loop through base file
$diff_table += "<table class=""diff"">"
ForEach ($base_line in $base)
{
Write-Debug "checking $base_line"
    if ($line_count -eq 0) {
        $diff_table += "<tr>"
        $base_line.PSObject.Properties | foreach-object {
            $name = $_.Name
            $diff_table += "<th>$name</th>"
        }
        $diff_table += "</tr>"
    }

    $result_line = $result[$line_count]
    $failed_line = $false

    $diff_table += "<tr>"
    $base_line.PSObject.Properties | foreach-object {
        $name = $_.Name
        $base_value = $_.value
        $result_value=$result_line."$($_.Name)"

        if ($base_value -eq $result_value){
            $diff_table += "<td class=""ok"">$base_value</td>"
        } else {
            $diff_table += "<td class=""fail""><span class=""base"">$base_value</span><br/><span class=""result"">$result_value</span></td>"
            $errors_fields++
            if ($failed_line -eq $false){
                $failed_line = $true
                $errors_rows++
            }
        }   
    }
    $diff_table += "</tr>"

	$line_count++

}
Write-Debug "loop through the rest of the result file - in case there are extra rows"
## loop through the rest of the result file - in case there are extra rows
while ($line_count -lt $result.length) {

	$result_line = $result[$line_count]
    $failed_line = $false

	$diff_table += "<tr>"
	$result_line.PSObject.Properties | foreach-object {
        $name = $_.Name
        $result_value = $_.value
		$diff_table += "<td class=""fail""><span class=""base"">N/A</span><br/><span class=""result"">$result_value</span></td>"
		$errors_fields++
        if ($failed_line -eq $false){
            $failed_line = $true
            $errors_rows++
        }
	}

	$diff_table += "</tr>"
	$line_count++
}

$diff_table += "</table>"


$params = $params.Split("`r`n")
$param_table = "<table>"
ForEach($p in $params) {
	$pa = $p.Split("=")
	$param_table += "<tr><td><span class=""field"">" + $pa[0] + "</span></td><td><span class=""value"">" + $pa[1] + "</span></td></tr>"
}
$param_table += "</table>"

$global:errors_fields = $global:errors_fields + $errors_fields
$global:errors_rows = $global:errors_rows + $errors_rows
### Summary for the top of the page ###

$diff_summary = @()
$diff_summary += "<div class=""summary"">"
if ($global:errors_fields -eq 0) {
    $diff_summary += "<span class=""result"">Result:</span><span class=""result_pass"">PASS</span><br/>"
} else {
    $diff_summary += "<span class=""result"">Result:</span><span class=""result_fail"">FAIL</span><br/>"
}
#$diff_summary += "<span class=""field"">Base file:</span><span class=""value"">$base_file_name</span><br/>"
$diff_summary += "<span class=""field"">Run ID:</span><span class=""value"">$run_id</span><br/>"
$diff_summary += "<span class=""field"">Run time:</span><span class=""value"">$run_time</span><br/>"
$diff_summary += "<span class=""field"">All Errors (fields):</span><span class=""value"">$global:errors_fields</span><br/>"
$diff_summary += "<span class=""field"">All Errors (rows):</span><span class=""value"">$global:errors_rows</span><br/>"
$diff_summary += "<span class=""field"">Parameters:</span><span>$param_table</span><br/>"
$diff_summary += "</div>"

$diff_section_summary = @()
$diff_section_summary += "<div>"
$diff_section_summary += "<span class=""field"">Base file:</span><span class=""value"">$base_file_name</span><br/>"
$diff_section_summary += "<span class=""field"">Errors (fields):</span><span class=""value"">$errors_fields</span><br/>"
$diff_section_summary += "<span class=""field"">Errors (rows):</span><span class=""value"">$errors_rows</span><br/>"
$diff_section_summary += "</div>"

### HTML file elements ###

$diff_header = @()
$diff_header += "<html>"
$diff_header += "<head>"
$diff_header += "<title>$test_name at $run_time</title>"
$diff_header += "<meta name=""test_name"" content=""$test_name""/>"
$diff_header += "<meta name=""run_time"" content=""$run_time""/>"
$diff_header += "<meta name=""errors_fields"" content=""$global:errors_fields""/>"
$diff_header += "<meta name=""errors_rows"" content=""$global:errors_rows""/>"
$diff_header += "<style>"
$diff_header += "    body {font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif}"
$diff_header += "    div.summary {padding-left:100px;}"
$diff_header += "    div.summary span.field {}"
$diff_header += "    div.summary span.value {font-weight: bold;}"
$diff_header += "    div.summary span.result {font-size:large; }"
$diff_header += "    div.summary span.result_pass {color:#008000; font-size:large; font-weight:bold}"
$diff_header += "    div.summary span.result_fail {color:#ff0000; font-size:large; font-weight:bold}"
$diff_header += "    table.diff {font-size:x-small; text-align:center}"
$diff_header += "    table.diff th {font-size:small; background-color:#3b3b3b; color:whitesmoke;padding-left:5px; padding-right:5px}"
$diff_header += "    table.diff td {padding-left:5px; padding-right:5px}"
$diff_header += "    table.diff td.ok {background-color:#d8efbb}"
$diff_header += "    table.diff td.fail {background-color:#ff9c92}"
$diff_header += "    table.diff td.fail span.base {text-decoration:line-through}"
$diff_header += "    table.diff td.fail span.result {font-weight:bold}"
$diff_header += "</style>"
$diff_header += "</head>"
$diff_header += "<body>"

$diff_footer = @()
$diff_footer += "</body>"
$diff_footer += "</html>"

$global:header = $diff_header
$global:summary = $diff_summary
$global:footer = $diff_footer

Write-Debug "Create the file"
### Create the file ###
$diff_section_summary | Out-File $diff_file_name -Append 
$diff_table | Out-File $diff_file_name -Append 


