﻿
[CmdletBinding(SupportsShouldProcess=$True)]
param (
[Parameter(Mandatory=$true)]
[int] $run_id,
[Parameter(Mandatory=$true)]
[string] $results_folder_name, 
[string] $diff_file_name = "diff.html"
)

$diffs = Get-ChildItem -Path $results_folder_name -Include $diff_file_name -Recurse

$tests_passed = 0
$tests_failed = 0

$summary_table = @()

$summary_table += "<div span=""table_title"">Failed test details:</div>"
$summary_table += "<table class=""summary"">"
$summary_table += "<tr><th>Test</th><th>Run At</th><th>Failed fields</th><th>Failed rows</th></tr>"

ForEach ($diff_file in $diffs) {

    $html = New-Object -ComObject "HTMLFile";
    $source = Get-Content -Path $diff_file -Raw;
    $html.IHTMLDocument2_write($source);

    $meta = $html.getElementsByTagName("META");

    $errors_fields = $meta | Where-Object Name -eq "errors_fields" | Select-Object -first 1
    $errors_rows = $meta | Where-Object Name -eq "errors_rows" | Select-Object -first 1
    $run_time = $meta | Where-Object Name -eq "run_time" | Select-Object -first 1
    $test_name = $meta | Where-Object Name -eq "test_name" | Select-Object -first 1

    if ($errors_fields.Length -eq 0) {
        $diff_format_error = [string] "Diff file does not have information about failures in fields in a meta tag"
        Throw $diff_format_error
    }

    if ($errors_rows.Length -eq 0) {
        $diff_format_error = [string] "Diff file does not have information about failures in rows a meta tag"
        Throw $diff_format_error
    }

    if ($run_time.Length -eq 0) {
        $diff_format_error = [string] "Diff file does not have information about run time in a meta tag"
        Throw $diff_format_error
    }

    if ($test_name.Length -eq 0) {
        $diff_format_error = [string] "Diff file does not have information about test name in a meta tag"
        Throw $diff_format_error
    }

    if ([int]$errors_fields[0].content -gt 0) {

        $summary_table += "<tr>"
        $summary_table += "<td><a href=""$diff_file"">" + $test_name[0].content + "</a></td>"
        $summary_table += "<td>" + $run_time[0].content + "</td>"
        $summary_table += "<td>" + [int]$errors_fields[0].content + "</td>"
        $summary_table += "<td>" + [int]$errors_rows[0].content + "</td>"
        $summary_table += "</tr>"
        $tests_failed ++
    } else {
        $tests_passed ++
    }

}

$summary_table += "</table>"


### Summary for the top of the page ###

$summary_summary = @()
$summary_summary += "<div class=""summary"">"
$summary_summary += "<span class=""field"">Run ID:</span><span class=""value"">$run_id</span><br/>"
$summary_summary += "<span class=""result"">Total tests:</span><span class=""value"">"+ ([int]$tests_passed + [int]$tests_failed) +"</span><br/>"
$summary_summary += "<span class=""result"">Tests passed:</span><span class=""result_pass"">$tests_passed</span><br/>"
$summary_summary += "<span class=""result"">Tests failed:</span><span class=""result_fail"">$tests_failed</span><br/>"
$summary_summary += "</div>"

### HTML file elements ###

$summary_header = @()
$summary_header += "<html>"
$summary_header += "<head>"
$summary_header += "<title>Summary for run: $run_id</title>"
$summary_header += "<style>"
$summary_header += "    body {font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif}"
$summary_header += "    div.summary {padding-left:100px; font-size:large;}"
$summary_header += "    div.summary span.field {}"
$summary_header += "    div.summary span.value {font-weight: bold;}"
$summary_header += "    div.summary span.result {}"
$summary_header += "    div.summary span.result_pass {color:#008000; font-weight:bold}"
$summary_header += "    div.summary span.result_fail {color:#ff0000; font-weight:bold}"
$summary_header += "    table.summary {font-size:small; text-align:center}"
$summary_header += "    table.summary th {font-size:small; background-color:#3b3b3b; color:whitesmoke;padding-left:5px; padding-right:5px}"
$summary_header += "    table.summary td {padding-left:5px; padding-right:5px}"
$summary_header += "    table.summary td.ok {background-color:#d8efbb}"
$summary_header += "    table.summary td.fail {background-color:#ff9c92}"
$summary_header += "    table.summary td.fail span.base {text-decoration:line-through}"
$summary_header += "    table.summary td.fail span.result {font-weight:bold}"
$summary_header += "    div.comment {font-size:small; font-style: italic}"
$summary_header += "</style>"
$summary_header += "</head>"
$summary_header += "<body>"

$run_time = (Get-Date).ToString()
$summary_footer = @()
$summary_footer += "<div class=""comment""> Generated at: $run_time</div>"
$summary_footer += "</body>"
$summary_footer += "</html>"

### Create the file ###

$summary_file_name = $results_folder_name + "/summary.html"

$summary_header | Out-File $summary_file_name 
$summary_summary | Out-File $summary_file_name -Append 
if ([int]$tests_failed -ne 0) {
	$summary_table | Out-File $summary_file_name -Append 
}

$summary_footer | Out-File $summary_file_name -Append  