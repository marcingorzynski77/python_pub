function New-Logger
{
#Write-Host "BEGIN: New-Logger"
<#
.SYNOPSIS
      This function creates a log4net logger instance already configured
.OUTPUTS
      The log4net logger instance ready to be used
#>
     [CmdletBinding()]
     Param
     (
          [string]
          # Path of the configuration file of log4net
          $Configuration,
          [Alias("Dll")]
          [string]
          # Log4net dll path
          $log4netDllPath
     )
     Write-Verbose "[New-Logger] Logger initialization"
     $log4netDllPath = Resolve-Path $log4netDllPath -ErrorAction SilentlyContinue -ErrorVariable Err
     if ($Err)
     {
          throw "Log4net library cannot be found on the path $log4netDllPath"
     }
     else
     {
          Write-Verbose "[New-Logger] Log4net dll path is : '$log4netDllPath'"
          [Reflection.Assembly]::LoadFrom($log4netDllPath) | Out-Null
          # Log4net configuration loading
          $log4netConfigFilePath = Resolve-Path $Configuration -ErrorAction SilentlyContinue -ErrorVariable Err
          if ($Err)
          {
               throw "Log4Net configuration file $Configuration cannot be found"
          }
          else
          {
               Write-Verbose "[New-Logger] Log4net configuration file is '$log4netConfigFilePath' "
               $FileInfo = New-Object System.IO.FileInfo($log4netConfigFilePath)
               [log4net.Config.XmlConfigurator]::Configure($FileInfo)
               $script:MyCommonLogger = [log4net.LogManager]::GetLogger("root")
               Write-Verbose "[New-Logger] Logger is configured"
               return $MyCommonLogger
          }
     }
}

function New-LoggerWithFileAppender
{
#Write-Host "BEGIN: New-LoggerWithFileAppender"
<#
.SYNOPSIS
      This function creates a log4net logger instance and configure it for a new appender
.OUTPUTS
      The log4net logger instance ready to be used
#>
     [CmdletBinding()]
     Param
     (
		  [string]
          # Test name
          $TestName,
          [string]
          # Path of the log file
          $LogFilePath,
          [Alias("Dll")]
          [string]
          # Log4net dll path
          $log4netDllPath
     )
     Write-Verbose "[LoggerWithFileAppender] Logger initialization"
     $log4netDllPath = Resolve-Path $log4netDllPath -ErrorAction SilentlyContinue -ErrorVariable Err
     if ($Err)
     {
          throw "Log4net library cannot be found on the path $log4netDllPath"
     }
     else
     {
          Write-Verbose "[LoggerWithFileAppender] Log4net dll path is : '$log4netDllPath'"
          [Reflection.Assembly]::LoadFrom($log4netDllPath) | Out-Null
          
		  # Log4net appender set-up
		  $logpattern = "%-5level [%x] - %message%newline"
          $patternLayout = new-object log4net.Layout.PatternLayout($logpattern) 
          
		  $appender = new-object log4net.Appender.FileAppender($patternLayout, $LogFilePath, $TRUE)
		  $appender.Threshold = [log4net.Core.Level]::Info
		
          [log4net.Config.BasicConfigurator]::Configure($appender) 
		  $Logger = [log4net.LogManager]::GetLogger($TestName)
          return $Logger
     }
}