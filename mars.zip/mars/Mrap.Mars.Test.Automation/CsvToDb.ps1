﻿param(
		# start of mandatory arguments
    [string]$env, 
	[string]$job,
	[string]$executionId,
	[string]$date,
		# end of mandatory arguments
	[string]$source,
	[string]$destinationTable,
	[string]$destination,
	[string]$postProcessTask,
	[string]$truncate,
	[string]$businessDateFileFormat,
	[string]$performenceScriptStart,
	[string]$performenceScriptEnd,
	[string]$externalReferenceFormat

)

$executionTime = [System.DateTime]::UtcNow.ToString("o");

if($executionId)
{
    $log=[log4net.LogManager]::GetLogger($job)
    $log.Info("Running script for job: '$job', execution id: '$executionId', BusDate: '$date', ExecutionTime: '$executionTime' ")
}

."$PSScriptRoot\Infrastructure.ps1"

try {
	
	$parsedDate=[System.DateTime]::UtcNow

	if([System.String]::IsNullOrEmpty($businessDateFileFormat) -eq $false)
	{
		$dateTimeString = [Mrap.Scheduler.Domain.PowerShellJob]::GetRegexBusinessDate($source,$businessDateFileFormat)
		if([System.String]::IsNullOrEmpty($dateTimeString) -eq $false)
		{
            if($log)
            {
			    $log.Info('business date set from reg ex  ' + $dateTimeString)
            }
			$parsedDate=[System.DateTime]::ParseExact($dateTimeString,"yyyyMMdd", [System.Globalization.CultureInfo]::InvariantCulture)
			[Mrap.Scheduler.Domain.PowerShellJob]::StoreTriggerValue($executionId,"BusinessDate",$parsedDate.ToString("yyyy-MMM-dd"))
		}
		else
		{
			$parsedDate=[System.DateTime]::ParseExact($date,"yyyyMMdd", [System.Globalization.CultureInfo]::InvariantCulture)
		}
	}
	else
	{
		$parsedDate=[System.DateTime]::ParseExact($date,"yyyyMMdd", [System.Globalization.CultureInfo]::InvariantCulture)
	}

	$formattedDate=$parsedDate.ToString("yyyy-MMM-dd")
	
	#see if we have a date pattern here and f yes resolve it
	if($log)
    {
	    $log.InfoFormat('parsed date to ' + $parsedDate)
    }
	$source=[System.String]::Format($source, $parsedDate)

    if($log)
    {
        $log.InfoFormat('source : ' + $source)
    }
	
	# split
	$splitResult=$source.Split("^", [System.StringSplitOptions]::RemoveEmptyEntries)
	if($splitResult.Length -eq 2)
	{
		$source_resolved=$appSettings[$splitResult[0]]
        if($log)
        {
		    $log.Debug(' about to combine:' + $source_resolved + "  " + $splitResult[1])
        }
		$source=[System.IO.Path]::Combine($source_resolved, $splitResult[1])
        if($log)
        {
		    $log.Debug('source after ^ split ' + $splitResult[0] + " resolved to " + $source_resolved)
        }
	}
	else
	{
		$source_resolved = $appSettings[$source]
        if($log)
        {
		    $log.Info('source ' + $source + " resolved to " + $source_resolved)
        }
		if($source_resolved)
		{
			$source=$source_resolved
		}
	}

    if($log)
    {
	    $log.Info('getting connection for ' + $destination)
    }

	$MaRSDbConnection = $appSettings[$destination]

    if($log)
    {
	    $log.Info(' Db conection resolved to ' + $MaRSDbConnection)
    }
    else
    {
        Write-Output "Db conection resolved to $MaRSDbConnection"
        Write-Output "Source resolved to $source"
    }
	

    $MaRSServer = Parse-Ado-Connection -ServerInstance $MaRSDbConnection
    $MaRSDatabase = Parse-Ado-Connection -Database $MaRSDbConnection

    #Extract and insert data into staging table
    #$start = Get-Date
    #$log.Info('Loading ' + $source)
    #$log.Info('Start at: ' + $start)
	#[Mrap.Scheduler.Domain.PowerShellJob]::StoreTriggerValue($executionId,"StartTime",$start)

	$externalRef=''
	# select latest only , this loop will execute only once because it has select latest file flag set to true
	[System.Reflection.Assembly]::Load("Mrap.Scheduler.Powershell")
	$files= [Mrap.Scheduler.Powershell.FileDataReader]::GetFiles($source, $true)
	Foreach ($file in $files)
	{
		if([System.String]::IsNullOrEmpty($externalReferenceFormat) -eq $false)
		{
			$externalRef = [Mrap.Scheduler.Domain.PowerShellJob]::GetRegexBusinessDate([System.IO.Path]::GetFileName($file),$externalReferenceFormat)
			if([System.String]::IsNullOrEmpty($externalRef) -eq $false)
			{
				if($log)
				{
					$log.Info('external ref set from reg ex  ' + $externalRef)
				}
			}
			#else
			#{
				#$parsedDate=[System.DateTime]::ParseExact($date,"yyyy-MMM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
			#}
		}
		#else
		#{
			#$parsedDate=[System.DateTime]::ParseExact($date,"yyyy-MMM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
		#}

        if($log)
        {
		    $log.Info("processing: " + $file.FullName)
        }
		#[Mrap.Scheduler.Powershell.FileDataReader]::Create($file.FullName)

		$provider = [Mrap.Scheduler.Powershell.FileDataReader]::Create($file.FullName)

		if([System.String]::IsNullOrEmpty($truncate) -eq $false)
		{
			if([System.Boolean]::Parse($truncate) -eq $true)
			{
				 #Clear staging table
                if($log)
                {
				    $log.Info("Clearing Staging Table: $destinationTable")
                }
				Invoke-SqlCmd2 -ServerInstance $MaRSServer -Database $MaRSDataBase -Query ("truncate table " + $destinationTable) -SupressResult $true
			}
		}
		else
		{
			 #Clear staging table
			#$log.Info("Clearing Staging Table: $destinationTable")
			#Invoke-SqlCmd2 -ServerInstance $MaRSServer -Database $MaRSDataBase -Query ("truncate table " + $destinationTable) -SupressResult $true
		}

        if($log)
        {
		    $log.Info('Data ready to load')
        }

		$recordsAffected = Write-csv-to-db -Provider $provider -ServerInstance $MaRSServer -Database $MaRSDataBase -TableName $destinationTable
		
        if($log)
        {
		    $log.Info("Successfully loaded source: " + $source)
        }

		if(![System.String]::IsNullOrEmpty($postProcessTask))
		{
            if($log)
            {
			    $log.Info("Evaluating: " + $postProcessTask)
            }
			$postProcessTask=$postProcessTask.Replace("{BusinessDate}", $parsedDate.ToString("yyyy-MMM-dd"))
			$postProcessTask=$postProcessTask.Replace("{ExternalRef}", $externalRef)
			$postProcessTask=$postProcessTask.Replace("{ExecutionTime}", $executionTime)
			
            if($log)
            {
			    $log.Info("Invoking post load task: " + $postProcessTask)
            }
			Invoke-SqlCmd2 -ServerInstance $MaRSServer -Database $MaRSDataBase -Query ("exec " + $postProcessTask) -SupressResult $true
            if($log)
            {
			    $log.Info("finished post load task")
            }
		}
	}
    
} catch {
    $ex = $_.Exception
    if($log)
    {
        $log.Error("Exception detected", $ex) 
    }
	throw
}
