
[CmdletBinding(SupportsShouldProcess=$True)]
param (
[Parameter(Mandatory=$true)]
[string] $db_server, 
[Parameter(Mandatory=$true)]
[string] $db_name
)
 
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"

."$PSScriptRoot\logger.ps1"
."$PSScriptRoot\Infrastructure.ps1"

#Invoke-SqlCmd2 -ServerInstance $db_server -Database $db_name -Query ("select top 10 * from  raw.SimraFORiskMeasures" ) -SupressResult $false | Export-CSV -Path "C:\Development\mars\Mrap.Mars.Test.Automation\TestsDefinitions\Regression-0\result.csv" -NoTypeInformation

$path = (get-item $PSScriptRoot).FullName
$log = New-Logger -Configuration "$PSScriptRoot\log4net.config" -Dll "$path\log4net.dll"

Import-Module "$PSScriptRoot\Mrap.Scheduler.Powershell.dll"
Import-Module "$PSScriptRoot\Mrap.Scheduler.Domain.dll"
Import-Module "$PSScriptRoot\CsvHelper.dll"

# get run id
$run_id_file = "$PSScriptRoot/run_id.txt"
[int]$run_id = 1
if (Test-Path "$run_id_file") {
	$run_id = [int](Get-Content "$run_id_file" -First 1)
	$run_id ++
	$run_id | Out-File $run_id_file
} else {
	$run_id | Out-File $run_id_file
}

# prepare test results folder
#$results_folder_name = "$PSScriptRoot\TestsResults\Run $run_id ($((Get-Date).ToString()))"  
$results_folder_name = "$PSScriptRoot\TestsResults\Run $run_id"  
New-Item "$results_folder_name" -ItemType Directory

# read and execute tests
$defintions_folder_name = "$PSScriptRoot\TestsDefinitions"
$feeds_folder_name = "$PSScriptRoot\TestsDefinitions\Feeds"
$expected_file_name = ""
$parameters_file_name = "parameters.json"
$diff_file_name = "diff.html"

$diff_script = "&""$PSScriptRoot\csv-diff.ps1"""

if (-Not (Test-Path "$defintions_folder_name")) {
	$missing_folder_error = [string] "The test harness folder does not contain test defintion folder ('$defintions_folder_name'), which is required."
	Throw $missing_folder_error
}
Write-Debug "Definitions folder: $defintions_folder_name" 

if (-Not (Test-Path "$feeds_folder_name")) {
	$missing_folder_error = [string] "The test harness folder does not contain feeds folder ('$feeds_folder_name'), which is required."
	Throw $missing_folder_error
}
Write-Debug "Feeds folder: $feeds_folder_name" 

$tests_definitions = Get-ChildItem -Path $defintions_folder_name -Include $parameters_file_name -Recurse

if ($tests_definitions -eq $null) {
	$missing_tests_error = [string] "The test folder ('$defintions_folder_name') does not contain any test."
	Throw $missing_tests_error
}

Write-Debug "Creating database. Params:  '$db_server' '$db_name' "
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.ConnectionInfo.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Management.Sdk.Sfc.dll"
Import-Module "$PSScriptRoot\lib\Microsoft.SqlServer.Smo.dll"

Write-Debug "Running  000.Prepare.sql"
Invoke-Sqlcmd-Smo -ServerInstance $db_server -Database 'master' -InputFile "$PSScriptRoot\Sql\000.Prepare.sql"
Write-Debug "Running  100.BootStrap.sql"
Invoke-Sqlcmd-Smo -ServerInstance $db_server -Database 'master' -InputFile "$PSScriptRoot\Sql\100.BootStrap.sql"
Write-Debug "Running  200.BootStrap.sql"
Invoke-Sqlcmd-Smo -ServerInstance $db_server -Database $db_name -InputFile "$PSScriptRoot\Sql\200.BootStrap.sql"

ForEach ($test_definition in $tests_definitions) { # loop through tests
	
	$test_name = $test_definition.Directory.Name
	
	if($test_name -eq "Feeds")
	{
		continue;
	}
	
	Write-Host "Running block for $test_name" -foreground "Green"
	$defintion_folder_name = $test_definition.Directory.FullName

	#$feed_definitions = Get-ChildItem -Path "$defintions_folder_name\"

	# check if all required files are there
	$params_file_name = "$defintion_folder_name\$parameters_file_name"
	if (-Not (Test-Path "$defintion_folder_name\$parameters_file_name")) {
		"Missing file: $parameters_file_name in $defintion_folder"
	}
	else {
	
		# create result folder
		$result_folder_name = "$defintion_folder_name".Replace("$defintions_folder_name", "$results_folder_name")
		Write-Debug -Message "Result folder: $result_folder_name"
		New-Item "$result_folder_name" -ItemType Directory
		#$counter=0
		$result_file_name = "$result_folder_name\${counter}.result.csv"
	    $expected_file_name = "$result_folder_name\${counter}.expected.csv"
	    $source_expected_file_name = "$defintion_folder_name\${counter}.expected.csv"

		$log_file_name = "$result_folder_name\run.log"
		$test_logger = New-LoggerWithFileAppender -TestName $test_name -LogFilePath $log_file_name -Dll "$path\log4net.dll"

		$start_time = Get-Date
		$jsonObject = "Input"
		# invoke test
		$test_logger.Info("Invoking tests. '$db_server' '$db_name' '$defintion_folder_name' '$PSScriptRoot' '$false' '$true' 60")
		Try {
			##   StressHarnessScript
			Write-Debug -Message "reading json config file: $defintion_folder_name\$parameters_file_name"
			$config = Get-Content -Raw "$defintion_folder_name\$parameters_file_name" | ConvertFrom-Json
			
				if ($config.PSobject.Properties.Name -contains $jsonObject)
				{
					if($log)
					{
						$log.Info("Reading configuration for '$jsonObject'")
					}

					$inputs = $config."$jsonObject" 

					foreach ($param in $inputs)
					{
						$feed=$param.feed
						$business_date=$param.business_date
						$raw_table=$param.raw_table
						$interface_name=$param.interface_name
						$post_process_task=$param.post_process_task
						$post_process_param_AsOfDate = $param.post_process_param_AsOfDate
						
						$feed_folder = "$feeds_folder_name"
						
						Write-Debug -Message "Loading feeds from  $feed_folder\$feed"
						$feeds_to_load = Get-ChildItem -Path "$feed_folder\$feed"
						
						if (-Not (Test-Path "$feed_folder\$feed")) {
								$missing_folder_error = [string] "Feeds $feed_folder\$feed can not be found"
								Throw $missing_folder_error
							}

						foreach ($load in $feeds_to_load)
						{
							$feedFile=$load.FullName
							$execution="$PSScriptRoot\CsvToDb.ps1 -ExecutionId '$run_id' -Job '$feed' -Date '$business_date' -Source '$feedFile' -DestinationTable '$raw_table' -Destination 'mars' -PerformenceScriptStart '' -PerformenceScriptEnd '' -PostProcessTask '$post_process_task @Datafeed=''$interface_name'', @Env=''REGR'',@ExecutionTime=''$post_process_param_AsOfDate'', @AsOfBusDate=''$business_date'''"
							Write-Debug -Message "Invoking expression $execution"
							Invoke-Expression $execution
							Write-Debug -Message "Finished executing expression"
						}
					}
					
					$outputs = $config.Output
					$counter=0
					$source_expected_file_name = "$defintion_folder_name\${counter}.expected.csv"
					Write-Debug -Message "$source_expected_file_name"
					if (-Not (Test-Path "$source_expected_file_name")) {
							$test_logger.Info("$defintion_folder_name does not have $source_expected_file_name file, creating one")
							foreach ($output in $outputs)
							{
								$source_expected_file_name = "$defintion_folder_name\${counter}.expected.csv"
								$test_logger.Info("producing expected file $source_expected_file_name for output $output")
								Invoke-SqlCmd2 -ServerInstance $db_server -Database $db_name -Query ("select * from  " + $output.table) -SupressResult $false | Export-CSV -Path "$source_expected_file_name" -NoTypeInformation -Append
								Write-Debug -Message "Done"
								$counter=$counter + 1
							}
						}
						
						Get-childitem -path "$defintion_folder_name" -filter '*.expected.csv' -recurse | copy-item -destination $result_folder_name
						
						$test_logger.Info("writing results to $result_folder_name")
						$counter=0
						foreach ($output in $outputs)
							{
								$result_file_name = "$result_folder_name\${counter}.result.csv"
								$test_logger.Info("producing result file for output $output")
								Invoke-SqlCmd2 -ServerInstance $db_server -Database $db_name -Query ("select * from  " + $output.table ) -SupressResult $false | Export-CSV -Path $result_file_name -NoTypeInformation -Append
								Write-Debug -Message "Done"
								$counter=$counter + 1
							}
				}
				else
				{
					if($log)
					{
						$log.Info(" No configuration found for '$jsonObject'")
					}
				}
		} Catch {
			$ErrorMessage = $_.Exception.Message
			$test_logger.Error("script failed with: '$ErrorMessage'")
			$test_logger.Error($_.Exception)
			Write-Host "script failed with: '$ErrorMessage'"
			Write-Host $_.Exception|format-list -Force
		}

		$csv_diff_file_name = "$result_folder_name\$diff_file_name"
		$csv_diff_file_name_tmp = "$result_folder_name\diff_tmp.html"
		
		$counter=0
		$global:errors_fields = 0
		$global:errors_rows = 0
		$global:tmp_file = ""
		$global:summary
		$global:header = ""
		$global:footer = ""
		
		foreach ($output in $config.Output)
		{
			$base_file_name = "$defintion_folder_name\${counter}.expected.csv"
			$result_file_name = "$result_folder_name\${counter}.result.csv"
			# run diff 
			$command = "$diff_script $run_id ""$test_name"" ""$params_file_name"" ""$base_file_name"" ""$result_file_name"" ""$csv_diff_file_name_tmp"" 0"
			$test_logger.Info("Running tmp diff. Command: $command")
			
			Try {
				
				Invoke-Expression $command
			} Catch 
			{ 
				$ErrorMessage = $_.Exception.Message
				$test_logger.Error("script failed with: '$ErrorMessage'")
				$test_logger.Error($_.Exception)
				throw
			}
			$counter=$counter + 1
		}
		
		$command = "$diff_script $run_id ""$test_name"" ""$params_file_name"" ""$base_file_name"" ""$result_file_name"" ""$csv_diff_file_name"" 1"
		$test_logger.Info("Running diff. Command: $command")
		Invoke-Expression $command

		$end_time = Get-Date
		$test_logger.Info("Execution time: $(($end_time-$start_time).ToString("c"))")
		$test_logger.Logger.Repository.Shutdown()
	}
}

# create the summary file
$command = "&""$PSScriptRoot\diff-summary.ps1"" $run_id ""$results_folder_name"""
Write-Debug "Running summary. Command: $command"
Invoke-Expression $command

Write-Host "Done Run $run_id" 
