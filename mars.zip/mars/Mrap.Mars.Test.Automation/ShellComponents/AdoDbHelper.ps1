function Parse-Ado-Connection
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$false)] [string]$ServerInstance, 
    [Parameter(Position=1, Mandatory=$false)] [string]$Database
    ) 
    if($ServerInstance)
    {
        $server = $ServerInstance.Substring($ServerInstance.IndexOf('Source=')+7, ($ServerInstance.IndexOf(';',$ServerInstance.IndexOf('Source='))- ($ServerInstance.IndexOf('Source=')+7)))
        return $server
    }

    if($Database)
    {
        $db = $Database.Substring($Database.IndexOf('Catalog=')+8, ($Database.IndexOf(';',$Database.IndexOf('Catalog=')) - ($Database.IndexOf('Catalog=')+8)))
        return $db
    }
} 