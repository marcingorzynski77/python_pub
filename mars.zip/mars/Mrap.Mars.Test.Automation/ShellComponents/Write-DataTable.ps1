####################### 
<# 
.SYNOPSIS 
Writes data only to SQL Server tables. 
.DESCRIPTION 
Writes data only to SQL Server tables. However, the data source is not limited to SQL Server; any data source can be used, as long as the data can be loaded to a DataTable instance or read with a IDataReader instance. 
.INPUTS 
None 
    You cannot pipe objects to Write-DataTable 
.OUTPUTS 
None 
    Produces no output 
.EXAMPLE 
$dt = Invoke-Sqlcmd2 -ServerInstance "Z003\R2" -Database pubs "select *  from authors" 
Write-DataTable -ServerInstance "Z003\R2" -Database pubscopy -TableName authors -Data $dt 
This example loads a variable dt of type DataTable from query and write the datatable to another database 
.NOTES 
Write-DataTable uses the SqlBulkCopy class see links for additional information on this class.
Version History 
.LINK 
http://msdn.microsoft.com/en-us/library/30c3y597%28v=VS.90%29.aspx 
#> 
function Write-DataTable 
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$true)] [string]$ServerInstance, 
    [Parameter(Position=1, Mandatory=$true)] [string]$Database, 
    [Parameter(Position=2, Mandatory=$true)] [string]$TableName, 
    [Parameter(Position=3, Mandatory=$true)] $Data, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$BatchSize=50000, 
    [Parameter(Position=7, Mandatory=$false)] [Int32]$QueryTimeout=0, 
    [Parameter(Position=8, Mandatory=$false)] [Int32]$ConnectionTimeout=15 
    ) 
     
    $conn=new-object System.Data.SqlClient.SQLConnection 
 
    if ($Username) {
        $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance,$Database,$Username,$Password,$ConnectionTimeout
    } else {
        $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout
    } 
 
    $conn.ConnectionString=$ConnectionString 
 
    try 
    { 
        $conn.Open() 
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString 
        $bulkCopy.DestinationTableName = $tableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut 
        $bulkCopy.WriteToServer($Data) 
        $conn.Close() 
    } 
    catch 
    { 
        $ex = $_.Exception 
        Write-Error "$ex.Message" 
        continue 
    } 
 
} #Write-DataTable


function Write-csv-to-db
{ 
    [CmdletBinding()] 
    param( 
    [Parameter(Position=0, Mandatory=$true)] [System.Data.IDataReader]$provider,
    [Parameter(Position=1, Mandatory=$true)] [string]$ServerInstance, 
    [Parameter(Position=2, Mandatory=$true)] [string]$Database, 
    [Parameter(Position=3, Mandatory=$true)] [string]$TableName, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$BatchSize=50000, 
    [Parameter(Position=7, Mandatory=$false)] [Int32]$QueryTimeout=0, 
    [Parameter(Position=8, Mandatory=$false)] [Int32]$ConnectionTimeout=15 
    ) 
     
   $conn=new-object System.Data.SqlClient.SQLConnection 
 
    if ($Username) {
        $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance,$Database,$Username,$Password,$ConnectionTimeout
    } else {
        $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout
    } 
 
    $conn.ConnectionString=$ConnectionString 
 
    try 
    { 
        $conn.Open() 
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString 
        $bulkCopy.DestinationTableName = $tableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut 
        $bulkCopy.WriteToServer($provider) 
		return [Mrap.Scheduler.Powershell.SqlBulkHelper]::GetRowsCopied($bulkCopy)
        #$conn.Close() 
		#$provider.Close()
    } 
    catch 
    { 
        $ex = $_.Exception 
        Write-Error "$ex.Message" 
        continue 
    } 
	finally
	{
		$conn.Close() 
		$provider.Close()
	}
}


function Write-db-to-db
{ 
    [CmdletBinding()] 
    param(
    [Parameter(Position=0, Mandatory=$true)] [string]$FromServerInstance, 
    [Parameter(Position=1, Mandatory=$true)] [string]$FromDatabase, 
    [Parameter(Position=2, Mandatory=$true)] [string]$FromQuery, 
    [Parameter(Position=3, Mandatory=$true)] [string]$ToServerInstance, 
    [Parameter(Position=4, Mandatory=$true)] [string]$ToDatabase, 
    [Parameter(Position=5, Mandatory=$true)] [string]$ToTableName, 
    [Parameter(Position=6, Mandatory=$false)] [string]$FromUsername, 
    [Parameter(Position=7, Mandatory=$false)] [string]$FromPassword, 
    [Parameter(Position=8, Mandatory=$false)] [string]$ToUsername, 
    [Parameter(Position=9, Mandatory=$false)] [string]$ToPassword, 
    [Parameter(Position=10, Mandatory=$false)] [Int32]$BatchSize=50000, 
    [Parameter(Position=11, Mandatory=$false)] [Int32]$QueryTimeout=0, 
    [Parameter(Position=12, Mandatory=$false)] [Int32]$ConnectionTimeout=15 
    ) 
     
    $conn_in = new-object System.Data.SqlClient.SQLConnection 
    $conn_out = new-object System.Data.SqlClient.SQLConnection 
 
    if ($FromUsername) {
        $FromConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $FromServerInstance, $FromDatabase, $FromUsername, $FromPassword, $ConnectionTimeout
    } else {
        $FromConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $FromServerInstance, $FromDatabase, $ConnectionTimeout
    } 
 
    if ($ToUsername) {
        $ToConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ToServerInstance, $ToDatabase, $ToUsername, $ToPassword, $ConnectionTimeout
    } else {
        $ToConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ToServerInstance, $ToDatabase, $ConnectionTimeout
    } 

    try
    {
        $conn_in.ConnectionString = $FromConnectionString 
        $conn_in.open()
        $cmd = new-object System.Data.SqlClient.SqlCommand($FromQuery, $conn_in)
        $dataReader = $cmd.ExecuteReader()

        $bulkCopy = new-object Data.SqlClient.SqlBulkCopy($ToConnectionString)
        $bulkCopy.DestinationTableName = $ToTableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut 
        $bulkCopy.WriteToServer($DataReader)

		$rowsAffected=[Mrap.Scheduler.Powershell.SqlBulkHelper]::GetRowsCopied($bulkCopy)

        $bulkCopy.close()
        $bulkCopy.dispose() | Out-Null
        $datareader.close()
        $datareader.dispose() | Out-Null
        $cmd.dispose() | Out-Null
        return $rowsAffected
    }
    catch 
    { 
        $ex = $_.Exception 
        Write-Error "$ex.Message" 
        continue 
    } 
	finally
	{
		$conn_in.close()
        $conn_in.Dispose() | Out-Null
	}
}
