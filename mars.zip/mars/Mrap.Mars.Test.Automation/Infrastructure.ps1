."$PSScriptRoot\ShellComponents\Invoke-SqlCmd2.ps1"
."$PSScriptRoot\ShellComponents\Write-DataTable.ps1"
."$PSScriptRoot\ShellComponents\Out-DataTable.ps1"
."$PSScriptRoot\ShellComponents\Logger.ps1"
."$PSScriptRoot\ShellComponents\AdoDbHelper.ps1"
."$PSScriptRoot\ShellComponents\Common-Functions.ps1"

$VerbosePreference = "continue"
$DebugPreference = "Continue"

$result = [Environment]::GetEnvironmentVariable("PowerShellMode", "Machine")

if($result -eq "Server")
{
    Import-Module "D:\LBG\Services\PowerShellDependencies\Mrap.Common.PowerShell.dll"
}
else
{
    Import-Module "$PSScriptRoot\lib\Mrap.Common.PowerShell.dll"   
}

$appSettings = Get-Env 'Regression' "$PSScriptRoot\appSettings.xml"
