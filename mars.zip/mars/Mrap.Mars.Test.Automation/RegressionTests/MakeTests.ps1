
$folder = "C:\tmp\TestsDefinitions\"
$prefix = "Regression"

$PSScriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$dates = Get-Content $PSScriptRoot\Dates.txt
$rf = Get-Content $PSScriptRoot\RF.txt
$sc = Get-Content $PSScriptRoot\SC.txt


$d = 0
foreach ($date in $dates)
{

    $n = 0
    foreach ($group in $sc)
    {
    
        $i = 0    
	    foreach ($factor in $rf)
        {
        
            $f = $folder + $prefix + "-D" + $d + "-G" + $n.ToString("00") + "-F" + $i.ToString("00")
            if (!(Test-Path $f))
            {
                New-Item $f -type directory    
                New-Item $f/parameters.txt -type file -force -value "AsOfDate = $date`r`nScenarioGroupId = $group`r`nRiskFactorTypeID = $factor"
                New-Item $f/expected.csv -type file -Force -Value "Scenario,Risk Factor Type,Shift Generation Type,Shift Type,Shift,Shift Unit,MarketData Curve Identifier,NO-1,NO-2,NO-3,NO-4,OD-1,OD-2,OD-3,OD-4,OND-Lin-1,OND-Lin-2,OND-Lin-3,OND-Lin-4,OND-Log-1,OND-Log-2,OND-Log-3,OND-Log-4,Ordinality,LoginName"
            }
            $i++
        }

        $n++ 
    }
    $d++
}