  
$path_results = "C:\Dev\Mrap.ScenarioVault\SimraAdapter\Mrap.Simra.ScenarioAdapter.Test\bin\Release\TestHarness\TestsResults\Run 17\"
$path_definitions = "C:\Dev\Mrap.ScenarioVault\SimraAdapter\Mrap.Simra.ScenarioAdapter.Test\TestHarness\TestsDefinitions\"

$folders = Get-ChildItem $path_results -dir 

ForEach($folder in $folders){
    $expected = "$path_definitions$($folder.Name)\expected.csv"
    Write-Host "Copying $($folder.FullName)\result.csv to $expected"
    Copy-Item "$($folder.FullName)\result.csv" $expected -Force
}
