#!/usr/bin/sh

folder="/cygdrive/c/tmp/TestsDefinitions/"
prefix="Regression-"

sn=0
rn=0

exec < SC.txt

while read a
do
	s[$sn]="$a"
	sn=`expr $sn + 1`
done

exec < RF.txt

while read a
do
	r[$rn]="$a"
	rn=`expr $rn + 1`
done

for (( j=0; j<$sn; ++j ))
do
	sc=${s[$j]}

	for (( k=0; k<$rn; ++k ))
	do
		rf=${r[$k]}
		f=$folder$prefix`echo $j $k | awk '{ printf "%4.4d", $1*100 + $2 }'`

		if [ ! -d $f ]
		then
			mkdir "$f"
			( echo "ScenarioGroupId=$sc"$'\r'; echo "RiskFactorTypeID=$rf"$'\r' ) >> "$f"/parameters.txt
			echo "Scenario,Risk Factor Type,Shift Generation Type,Shift Type,Shift,Shift Unit,MarketData Curve Identifier,NO-1,NO-2,NO-3,NO-4,OD-1,OD-2,OD-3,OD-4,OND-Lin-1,OND-Lin-2,OND-Lin-3,OND-Lin-4,OND-Log-1,OND-Log-2,OND-Log-3,OND-Log-4,Ordinality,LoginName" > "$f"/expected.csv
		fi
	done
done
