
[CmdletBinding(SupportsShouldProcess=$True)]
param (
[Parameter(Mandatory=$true)]
[string] $db_server, 
[Parameter(Mandatory=$true)]
[string] $db_name, 
[Parameter(Mandatory=$true)]
[string] $config_file, 
[bool] $build_db = $false 
)

Write-Debug "Setting APP_CONFIG_FILE path to $PSScriptRoot\$config_file"
[appdomain]::CurrentDomain.SetData("APP_CONFIG_FILE", "$PSScriptRoot\$config_file")
Add-Type -AssemblyName System.Configuration

$VerbosePreference = "Continue"
$DebugPreference = "Continue"

."$PSScriptRoot\logger.ps1"
$path = (get-item $PSScriptRoot).Parent.FullName
$log = New-Logger -Configuration "$PSScriptRoot\log4net.config" -Dll "$path\log4net.dll"
Import-Module "$path\Mrap.ScenarioVault.Powershell.dll"
Import-Module "$path\Mrap.Simra.ScenarioAdapter.dll"

# import script - create db
if ($build_db){
	Try {
		Write-Debug "Running data seed for $db_server $db_name $PSScriptRoot"
		$success = Get-runscript "$PSScriptRoot\data_seed.cs" $db_server $db_name "$PSScriptRoot"
	} Catch {
		$ErrorMessage = $_.Exception.Message
		Write-Error "Database creation failed with: '$ErrorMessage'"
		break
	}
}

# get run id
$run_id_file = "$PSScriptRoot/run_id.txt"
[int]$run_id = 1
if (Test-Path "$run_id_file") {
	$run_id = [int](Get-Content "$run_id_file" -First 1)
	$run_id ++
	$run_id | Out-File $run_id_file
} else {
	$run_id | Out-File $run_id_file
}

# prepare test results folder
#$results_folder_name = "$PSScriptRoot\TestsResults\Run $run_id ($((Get-Date).ToString()))"  
$results_folder_name = "$PSScriptRoot\TestsResults\Run $run_id"  
New-Item "$results_folder_name" -ItemType Directory

# read and execute tests
$defintions_folder_name = "$PSScriptRoot\TestsDefinitions"
$expected_file_name = "expected.csv"
$parameters_file_name = "parameters.txt"
$diff_file_name = "diff.html"

$diff_script = "&""$PSScriptRoot\csv-diff.ps1"""

if (-Not (Test-Path "$defintions_folder_name")) {
	$missing_folder_error = [string] "The test harness folder does not contain test defintion folder ('$defintions_folder_name'), which is required."
	Throw $missing_folder_error
}
Write-Debug -Message "Definitions folder: $defintions_folder_name" 


$SingleTestScriptBlock = {
	Param (
		[string]$test_name
	)

	."$PSScriptRoot\logger.ps1"

	#Write-Debug "Setting APP_CONFIG_FILE path to $script_root\$config_file"
	#[appdomain]::CurrentDomain.SetData("APP_CONFIG_FILE", "$script_root\$config_file")
	#Add-Type -AssemblyName System.Configuration
 	
	$path = (get-item $script_root).Parent.FullName
	Import-Module "$path\Mrap.ScenarioVault.Powershell.dll"
	Import-Module "$path\Mrap.Simra.ScenarioAdapter.dll"

	Write-Host "Running block for $test_name" -foreground "Green"

	$defintion_folder_name = "$defintions_folder_name\$test_name"

	# check if all required files are there
	$params_file_name = "$defintion_folder_name\$parameters_file_name"
	if (-Not (Test-Path "$defintion_folder_name\$parameters_file_name")) {
		Write-Error "Missing file: $params_file_name in $defintion_folder" -foreground "Yellow"
	}
	else {
		
		# create result folder
		$result_folder_name = "$results_folder_name\$test_name"
		Write-Debug "Result folder: $result_folder_name" 
		New-Item "$result_folder_name" -ItemType Directory
		
		Try {
			$log_file_name = "$result_folder_name\run.log"
			$test_logger = New-LoggerWithFileAppender -TestName $test_name -LogFilePath $log_file_name -Dll "$path\log4net.dll"
		} Catch {
			$ErrorMessage = $_.Exception.Message
			Write-Host "Log4Net failed with: '$ErrorMessage'"
			Write-Host $_.Exception|format-list -Force
		}
		$start_time = Get-Date

		# invoke test
		# New-TestRun ExportFilePath ScriptDbServer ScriptDbName InputParameterPath AdapterConfigPath IsTraceabilityEnabled IsOptimizationEnabled TimeoutInSec
		$result_file_name = "$result_folder_name\result.csv"
		Write-Debug "Invoking tests. Params: '$result_file_name' '$db_server' '$db_name' '$defintion_folder_name' '$PSScriptRoot' '$false' '$true' 60" 

		Try {
			##   StressHarnessScript
			Write-Debug "SIMRA Adapter Config file: $([appdomain]::CurrentDomain.GetData(""APP_CONFIG_FILE""))" 
			New-TestRun -ExportFilePath "$result_file_name" -ScriptDbServer "$db_server" -ScriptDbName "$db_name" -InputParameterPath "$defintion_folder_name" -AdapterConfigPath "$script_root" -IsTraceabilityEnabled $false -IsOptimizationEnabled $true -TimeoutInSec 60
		} Catch {
			$ErrorMessage = $_.Exception.Message
			$test_logger.Error("SIMRA Adapter failed with: '$ErrorMessage'")
			$test_logger.Error($_.Exception)
			Write-Host "SIMRA Adapter failed with: '$ErrorMessage'"
			Write-Host $_.Exception|format-list -Force
			return
		}

		$csv_diff_file_name = "$result_folder_name\$diff_file_name"
		$base_file_name = "$defintions_folder_name\$test_name\$expected_file_name"
		# run diff 
		$command = "$diff_script $run_id ""$test_name"" ""$params_file_name"" ""$base_file_name"" ""$result_file_name"" ""$csv_diff_file_name"""
		$test_logger.Info("Running diff. Command: $command")
		Invoke-Expression $command
		$end_time = Get-Date
		$test_logger.Info("Execution time: $(($end_time-$start_time).ToString("c"))")
		$test_logger.Shutdown()
	}
}

$tests_definitions = Get-ChildItem -Path $defintions_folder_name -Include $parameters_file_name -Recurse

if ($tests_definitions -eq $null) {
	$missing_tests_error = [string] "The test folder ('$defintions_folder_name') does not contain any test."
	Throw $missing_tests_error
}

# Create session state
$sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "db_server", $db_server, "SQL Server instance" ))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "db_name", $db_name, "SQL DB name"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "defintions_folder_name", $defintions_folder_name, "Root definition folder"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "results_folder_name", $results_folder_name, "Root result folder"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "parameters_file_name", $parameters_file_name, "Parameter file name"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "expected_file_name", $expected_file_name, "Expected result file name"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "diff_file_name", $diff_file_name, "Diff file name"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "script_root", $PSScriptRoot, "Script root"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "config_file", $config_file, "SIMRA Adapter config file"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "run_id", $run_id, "Run Id"))
$sessionstate.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList "diff_script", $diff_script, "Diff script"))

$threadsNumber = 5
# Create runspace pool consisting of $threadsNumber runspaces
$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1, $threadsNumber, $sessionState, $Host)
$RunspacePool.Open()

$Jobs = @()
ForEach ($test_definition in $tests_definitions) { # loop through tests
	$test_name = $test_definition.Directory.Name
	#Write-Host "Adding test: $test_name"

	$Job = 	[powershell]::Create().AddScript($SingleTestScriptBlock).AddParameter("test_name", $test_name)
	$Job.RunspacePool = $RunspacePool
	$Jobs += New-Object PSObject -Property @{
		Job = $Job
		Result = $Job.BeginInvoke()
	}
}

Do {
   Write-Host "Remaining jobs: " ($Jobs.Result.IsCompleted -eq  $false).Count
   Start-Sleep -Seconds 1
} While ( $Jobs.Result.IsCompleted -contains $false)

# create the summary file
$command = "&""$PSScriptRoot\diff-summary.ps1"" $run_id ""$results_folder_name"""
Write-Debug "Running summary. Command: $command"
Invoke-Expression $command

Write-Host "Done Run $run_id" 
