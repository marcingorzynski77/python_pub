﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mrap.Mars.Domain;

namespace Mrap.Mars.Test
{
    [TestClass]
    public class DBTest
    {
        [TestMethod]
        [Ignore]
        public void TestConnectivity()
        {
            //TODO : connection string is specified in test
            var conn = @"data source=FMD-D8-3076\BridgeD01;initial catalog=Mars_RC6;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework";
            var db = new MarsDbContext(conn, null);
            var result1 = db.FlexFactHierarchy.ToList();
            var result2 = db.Hierarchy.ToList();
            var result3 = db.FlexFact.ToList();
            var result4 = db.FlexFactInstance.ToList();
        }
    }
}
