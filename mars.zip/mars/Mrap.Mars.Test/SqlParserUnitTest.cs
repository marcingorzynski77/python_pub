﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mrap.Mars.Common;

namespace Mrap.Mars.Test
{
    [TestClass]
    public class SqlParserUnitFailingTests
    {

        [TestMethod]
        [Ignore]
        public void TestSqlParserCustom()
        {
            var samples = new string[]
            {
               "RiskNode Brak,RiskNode Break=Test",
               "RiskNode Break->{1;2} & TYPE COLUMN >100"
            };

            var responses = new string[]
          {
               "SELECT [RiskNode Brak] FROM vHierarchy WHERE [RiskNode Break]='Test'",
               "SELECT [RiskNode Break],[TYPE COLUMN] FROM vHierarchy WHERE [RiskNode Break] IN ('1','2')  AND  [TYPE COLUMN] >100"
          };

            Dictionary<string, ColumnInfoDTO> schema = new Dictionary<string, ColumnInfoDTO>();
            schema.Add("RISKNODE BREAK", new ColumnInfoDTO() { Name = "RISKNODE BREAK", SqlType = SqlDbType.NText, Type = "String", ClrType = typeof(string) });
            schema.Add("TYPE COLUMN", new ColumnInfoDTO() { Name = "TYPE COLUMN", SqlType = SqlDbType.Float, Type = "int", ClrType = typeof(float) });

            var tmp = new SqlParser().ParseString(samples[1], "vHierarchy", schema);

            for (int index = 0; index < samples.Length; index++)
            {
                var result = new SqlParser().ParseString(samples[index], "vHierarchy", schema);
                var expected = responses[index];
                Assert.AreEqual(expected, result.Sql);
            }
        }

        [TestMethod]
        [Ignore]
        public void TestSqlParserPositiveFailing()
        {
            //TODO : use NUNIT testcase
            var tests = new string[,]
            {
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeName=2 | RiskNodeName=7}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeName]='2' OR [RiskNodeName]='7')" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeName=2 | RiskNodeType=7} & {RiskNodeType=Hello Test}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeName]='2' OR [RiskNodeType]='7') AND ([RiskNodeType]='Hello Test')" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeName=2|RiskNodeName=7}&{RiskNodeType=Hello   Test}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeName]='2' OR [RiskNodeName]='7') AND ([RiskNodeType]='Hello   Test')" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeName=LBG |RiskNodeName=LBG1 }",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeName]='LBG'  OR [RiskNodeName]='LBG1 ')" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeType=BSS_narrows | RiskNodeType=AUD +15%} & {RiskNodeType>2016-09-02}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeType]='BSS_narrows'  OR  [RiskNodeType]='AUD +15%')  AND  ([RiskNodeType]>'2016-09-02')" },
                {
                    "RiskNodeName,RiskNodeType,{{RiskNodeName=FX Vol -0.15} & {RiskNodeType=GBP}}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE (([RiskNodeName]='FX VOL -0.15')  AND  ([RiskNodeType]='GBP'))" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeName ->{FX Vol -0.15} & RiskNodeType ->{GBP}}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeName]  IN  ('FX VOL -0.15')  AND  [RiskNodeType] IN ('GBP'))" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeType=gbp & HierarchyKEY>1} | {RiskNodeType=usd} | {RiskNodeType=aud} | {HierarchyKEY<1} | {RiskNodeType->{gbp; usd; aud}}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeType]='gbp'  AND  [HierarchyKEY]>1)  OR  ([RiskNodeType]='usd')  OR  ([RiskNodeType]='aud')  OR  ([HierarchyKEY]<1)  OR  ([RiskNodeType] IN ('gbp','usd','aud'))" },
                {
                    "RiskNodeName,{RiskNodeName ->{FX Spot -0.005%;FX Spot -0.01%;FX Spot -0.015%} & VALUE=1}",
                    "SELECT [RiskNodeName] FROM vHierarchy WHERE ([RiskNodeName]  IN ('FX SPOT -0.005%','FX SPOT -0.01%','FX SPOT -0.015%')  AND  [VALUE]=1)" },
                {
                    "RiskNodeName,RiskNodeType,{RiskNodeName =a | RiskNodeName =b | RiskNodeName =c | RiskNodeName =d }",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE ([RiskNodeName] ='a'  OR  [RiskNodeName] ='b'  OR  [RiskNodeName] ='c'  OR  [RiskNodeName] ='d ')" }
            };

            Dictionary<string, ColumnInfoDTO> schema = new Dictionary<string, ColumnInfoDTO>();
            schema.Add("RISKNODENAME", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNodeName", SqlType = SqlDbType.VarChar, Type = "varchar" });
            schema.Add("RISKNODETYPE", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNodeType", SqlType = SqlDbType.VarChar, Type = "varchar" });
            schema.Add("HIERARCHYKEY", new ColumnInfoDTO() { ClrType = typeof(int), Name = "HierarchyKEY", SqlType = SqlDbType.Int, Type = "int" });
            schema.Add("VALUE", new ColumnInfoDTO() { ClrType = typeof(float), Name = "Value", SqlType = SqlDbType.Float, Type = "float" });
            schema.Add("BUSDATE", new ColumnInfoDTO() { ClrType = typeof(DateTime), Name = "BusDate", SqlType = SqlDbType.DateTime, Type = "datetime" });
            schema.Add("CAD2", new ColumnInfoDTO() { ClrType = typeof(Boolean), Name = "Cad2", SqlType = SqlDbType.Bit, Type = "bit" });

            for (int index = 0; index < tests.Length / 2; index++)
            {
                var input = tests[index, 0];
                var result = new SqlParser().ParseString(input, "vHierarchy", schema);
                var expected = tests[index, 1];
                Assert.AreEqual(expected, result.Sql);
                Assert.AreEqual(0, result.Messages.Count);
            }
        }
    }

    [TestClass]
    public class SqlParserUnitTests
    {

        [TestMethod]
        public void TestSqlParserPositive()
        {

            var tests = new[,]
            {
                {
                    "RiskNodeName,RiskNodeType,RiskNodeName=5",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeName]='5'" },
                {
                    "RiskNodeName,RiskNodeType,RiskNodeName=5*",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeName] LIKE '5%'"},
                {
                    "RiskNodeName,RiskNodeType,RiskNodeName='5'",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeName]='5'"},
                {
                    "",
                    "SELECT [RISKNODENAME],[RISKNODETYPE],[HIERARCHYKEY],[VALUE],[BUSDATE],[CAD2] FROM vHierarchy " },
                {
                    "  ",
                    "SELECT [RISKNODENAME],[RISKNODETYPE],[HIERARCHYKEY],[VALUE],[BUSDATE],[CAD2] FROM vHierarchy " },
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType<>'5'",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType]<>'5'" },
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType<>'5*'",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType] NOT LIKE '5%'"},
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType > 5",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType] > '5'"},
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType >= 5",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType] >= '5'"},
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType <= 5",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType] <= '5'"},
                {
                    "RiskNodeName,RiskNodeType,HierarchyKEY <> 5",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [HierarchyKEY] <> 5"},
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType -> {'5';'6'}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType]  IN  ('5','6')"},
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType -> {'5 Test';'6 Test'}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType]  IN  ('5 Test','6 Test')" },
                {
                    "RiskNodeName,RiskNodeType,RiskNodeType -> {5;6}",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeType]  IN  ('5','6')"},
                {
                    "RiskNodeName , RiskNodeType , HierarchyKEY <> 5 ",
                    "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE  [HierarchyKEY] <> 5" },
                {
                    "RiskNodeType->{' 5 ';'6'}",
                    "SELECT [RiskNodeType] FROM vHierarchy WHERE [RiskNodeType] IN ('5','6')" },
                {
                    "RiskNodeType->{ usd;aud;gbp }",
                    "SELECT [RiskNodeType] FROM vHierarchy WHERE [RiskNodeType] IN ('usd','aud','gbp')" },
                {
                    "RiskNodeName,{VALUE=1 & RiskNodeName ->{FX Spot -0.005%; FX Spot -0.01%; FX Spot -0.015%}}",
                    "SELECT [RiskNodeName] FROM vHierarchy WHERE ([VALUE]=1 AND  [RiskNodeName]  IN ('FX Spot -0.005%','FX Spot -0.01%','FX Spot -0.015%'))" },
                {
                    "RiskNodeName,VALUE->{1;2;3}",
                    "SELECT [RiskNodeName] FROM vHierarchy WHERE [VALUE] IN (1,2,3)" },
                {
                    "BusDate=2016-OCT-25 12:12:12",
                    "SELECT [BusDate] FROM vHierarchy WHERE [BusDate]='2016-OCT-25 12:12:12'" },
                {
                    "Cad2=1",
                    "SELECT [Cad2] FROM vHierarchy WHERE [Cad2]=1" }

            };


            Dictionary<string, ColumnInfoDTO> schema = new Dictionary<string, ColumnInfoDTO>();
            schema.Add("RISKNODENAME", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNodeName", SqlType = SqlDbType.VarChar, Type = "varchar" });
            schema.Add("RISKNODETYPE", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNodeType", SqlType = SqlDbType.VarChar, Type = "varchar" });
            schema.Add("HIERARCHYKEY", new ColumnInfoDTO() { ClrType = typeof(int), Name = "HierarchyKEY", SqlType = SqlDbType.Int, Type = "int" });
            schema.Add("VALUE", new ColumnInfoDTO() { ClrType = typeof(float), Name = "Value", SqlType = SqlDbType.Float, Type = "float" });
            schema.Add("BUSDATE", new ColumnInfoDTO() { ClrType = typeof(DateTime), Name = "BusDate", SqlType = SqlDbType.DateTime, Type = "datetime" });
            schema.Add("CAD2", new ColumnInfoDTO() { ClrType = typeof(Boolean), Name = "Cad2", SqlType = SqlDbType.Bit, Type = "bit" });

            for (int index = 0; index < tests.Length / 2; index++)
            {
                var input = tests[index, 0];
                var expected = tests[index, 1];
                var result = new SqlParser().ParseString(input, "vHierarchy", schema);

                if (expected != result.Sql)
                {
                    Debug.Print($"index {index}");
                    Debug.Print($"expected: {expected}");
                    Debug.Print($"result: {result.Sql}");
                }
                Assert.AreEqual(expected, result.Sql);
                Assert.AreEqual(0, result.Messages.Count);
            }
        }

        [TestMethod]
        public void TestSqlParserPositiveNegative()
        {
            var samples = new string[]
            {
               "RiskNodeName,RiskNodeType,RiskNode -> {'5';'6'}",
               "RiskNode,RiskNodeType,RiskNodeTy='5'",
               "RiskNodeName,,RiskNodeType='5'",
               "RiskNodeName,  ,RiskNodeType='5'",
               "HierarchyKEY>=Test",
               "VersionDateTime=2014--15",
               "VersionDateTime=2014-OCT-15"
            };

            var responses = new int[]
            {
               1,2,1,1,1,1,0
            };


            Dictionary<string, ColumnInfoDTO> schema = new Dictionary<string, ColumnInfoDTO>();
            schema.Add("RISKNODENAME", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNodeName", SqlType = SqlDbType.VarChar, Type = "varchar" });
            //schema.Add("RISKNODE", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNode", SqlType = SqlDbType.VarChar, Type = "varchar" });
            schema.Add("RISKNODETYPE", new ColumnInfoDTO() { ClrType = typeof(string), Name = "RiskNodeType", SqlType = SqlDbType.VarChar, Type = "varchar" });
            schema.Add("HIERARCHYKEY", new ColumnInfoDTO() { ClrType = typeof(int), Name = "HierarchyKEY", SqlType = SqlDbType.Int, Type = "int" });
            schema.Add("VERSIONDATETIME", new ColumnInfoDTO() { ClrType = typeof(DateTime), Name = "VersionDateTime", SqlType = SqlDbType.Date, Type = "datetime" });


            for (int index = 0; index < samples.Length; index++)
            {
                var result = new SqlParser().ParseString(samples[index], "vHierarchy", schema);
                var expected = responses[index];
                Assert.AreEqual(expected, result.Messages.Count);
            }
        }


        [TestMethod]
        public void TestSqlParserValidate()
        {
            // Note sql parser has been removed

            var samples = new string[]
            {
               "SELECT [RiskNodeName],[RiskNodeType] FROM vHierarchy WHERE [RiskNodeName]='5'"
              // "SELECT [RiskNodeName,[RiskNodeType] FROM vHierarchy  [RiskNodeName]='5'"
            };

            var responses = new int[]
          {
              0
          };

            //var res = new GetSchemaInfo(@"Data Source=FMD-D8-3076\TRIDENTD01;Initial Catalog=MaRS;Trusted_Connection=Yes").Build("vHierarchy", "target");
            //Dictionary<string, ColumnInfoDTO> schema = new Dictionary<string, ColumnInfoDTO>();
            //schema.Add("RISKNODE BREAK", new ColumnInfoDTO() { Name = "RISKNODE BREAK", SqlType = SqlDbType.NText, Type = "String", ClrType = typeof(string) });

            //var tmp = new SqlParser().ParseString(samples[2], "vHierarchy", res);

            for (int index = 0; index < samples.Length; index++)
            {
                var parser = new SqlParser();
                var expected = responses[index];

                var sql = new SqlParser.SqlParserResponse();
                sql.Sql = samples[index];
                //parser.ValidateSyntaxt(sql);
                Assert.AreEqual(expected, sql.Messages.Count);
            }
        }
    }
}
