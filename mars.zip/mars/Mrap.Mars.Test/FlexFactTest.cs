﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mrap.Mars.Common;
using Mrap.Mars.Domain;
using Mrap.Mars.XLL.Ribbon;

namespace Mrap.Mars.Test
{
    [TestClass]
    public class FlexFactTest
    {

        private static string Connection { get; set; }

        [TestInitialize]
        public void Initialize()
        {

            Connection = ConfigurationManager.ConnectionStrings["MaRS"].ConnectionString;

            using (var context = new MarsDbContext(Connection, null))
            {
                var testSchema = context.FlexFactHierarchy.FirstOrDefault(f => f.Name == "System Schema" && f.Description == "UnitTestSchema");

                if (testSchema == null)
                {
                    var schema = new FlexFactHierarchy { Name = "System Schema", Description = "UnitTestSchema", ParentFlexFactHierarchyKey = 1, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(schema);

                    var data = new FlexFactHierarchy { Name = "Data", Description = "UnitTestSchema.Data", ParentFlexFactHierarchy = schema, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(data);

                    var metaData = new FlexFactHierarchy { Name = "MetaData", Description = "UnitTestSchema.MetaData", ParentFlexFactHierarchy = schema, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(metaData);

                    var dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    var dimName = new FlexFactHierarchy { Name = "RiskFactorKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "RiskFactorTypeKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "RiskMeasureTypeKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "ScenarioHierarchyKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "HierarchyKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "InstrumentKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "InstrumentTypeKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "SourceKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "TenorKey", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "BusDate", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    var dimType = new FlexFactHierarchy { Name = "DateTime2", Description = "UnitTestSchema.MetaData.Dimension.Type", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimType);

                    dim = new FlexFactHierarchy { Name = "Dimension", Description = "UnitTestSchema.MetaData.Dimension", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dim);

                    dimName = new FlexFactHierarchy { Name = "UserName", Description = "UnitTestSchema.MetaData.Dimension.Name", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimName);

                    dimType = new FlexFactHierarchy { Name = "VarChar", Description = "UnitTestSchema.MetaData.Dimension.Type", ParentFlexFactHierarchy = dim, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(dimType);

                    var fact = new FlexFactHierarchy { Name = "Fact", Description = "UnitTestSchema.MetaData.Fact", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(fact);

                    var factName = new FlexFactHierarchy { Name = "Count", Description = "UnitTestSchema.MetaData.Fact.Name", ParentFlexFactHierarchy = fact, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(factName);

                    var factType = new FlexFactHierarchy { Name = "Int", Description = "UnitTestSchema.MetaData.Fact.Type", ParentFlexFactHierarchy = fact, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(factType);

                    fact = new FlexFactHierarchy { Name = "Fact", Description = "UnitTestSchema.MetaData.Fact", ParentFlexFactHierarchy = metaData, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(fact);

                    factName = new FlexFactHierarchy { Name = "Value", Description = "UnitTestSchema.MetaData.Fact.Name", ParentFlexFactHierarchy = fact, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(factName);

                    factType = new FlexFactHierarchy { Name = "Float", Description = "UnitTestSchema.MetaData.Fact.Type", ParentFlexFactHierarchy = fact, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.FlexFactHierarchy.Add(factType);

                    context.SaveChanges();

                }

                Source source = context.Source.FirstOrDefault(f => f.InterfaceName == "Reconciliation.PnL" && f.Environment == "TEST" && f.DataSource == "FLEX" && f.Origin == "FLEX");
                if (source == null)
                {
                    source = new Source { InterfaceName = "Reconciliation.PnL", Environment = "TEST", DataSource = "FLEX", Origin = "FLEX", Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.Source.Add(source);
                    context.SaveChanges();
                }

                source = context.Source.FirstOrDefault(f => f.InterfaceName == "FeedLoadCheck.Threshold" && f.Environment == "TEST" && f.DataSource == "FLEX" && f.Origin == "FLEX");
                if (source == null)
                {
                    source = new Source { InterfaceName = "FeedLoadCheck.Threshold", Environment = "TEST", DataSource = "FLEX", Origin = "FLEX", Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.Source.Add(source);
                    context.SaveChanges();
                }

                source = context.Source.FirstOrDefault(f => f.InterfaceName == "UnitTestSchema" && f.Environment == "TEST" && f.DataSource == "FLEX" && f.Origin == "FLEX");
                if (source == null)
                {
                    source = new Source { InterfaceName = "UnitTestSchema", Environment = "TEST", DataSource = "FLEX", Origin = "FLEX", Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.Source.Add(source);
                    context.SaveChanges();
                }

                source = context.Source.FirstOrDefault(f => f.InterfaceName == "VaR" && f.Environment == "TEST" && f.DataSource == "FLEX" && f.Origin == "FLEX");
                if (source == null)
                {
                    source = new Source { InterfaceName = "VaR", Environment = "TEST", DataSource = "FLEX", Origin = "FLEX", Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.Source.Add(source);
                    context.SaveChanges();
                    
                }

                var sourceKey = context.Source.First(f => f.InterfaceName == "VaR" && f.Environment == "TEST" && f.DataSource == "FLEX" && f.Origin == "FLEX").SourceKey;
                var riskMeasureType = context.RiskMeasureType.FirstOrDefault(t => t.SourceKey == sourceKey && t.RiskMeasureTypeName == "VaR Historical");
                if (riskMeasureType == null)
                {
                    riskMeasureType = new RiskMeasureType { RiskMeasureTypeName = "VaR Historical", RiskMeasureFamily = "Valuation",  SourceKey = sourceKey, Start = DateTime.MinValue, Finish = DateTime.MaxValue };
                    context.RiskMeasureType.Add(riskMeasureType);
                    context.SaveChanges();
                }
            }

            WorkbookContext.SetContextValue(Context.Environment, "TEST");
            WorkbookContext.SetContextValue(Context.Db, Connection);

        }

        [TestMethod]
        [Ignore]
        public void TestSaveFlexData()
        {

            var schema = "UnitTestSchema";
            var env = "TEST";

            var header = new List<Tuple<string, SqlDbType>>
            {
                new Tuple<string, SqlDbType>("Count", SqlDbType.Int),
                new Tuple<string, SqlDbType>("Value", SqlDbType.Float),
                new Tuple<string, SqlDbType>("BusDate", SqlDbType.DateTime2),
                new Tuple<string, SqlDbType>("UserName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("RiskFactorName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("RiskFactorTypeName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("RiskMeasureTypeName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("ScenarioHierarchyString", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("NodeName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("NodeType", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("BookSystem", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Product", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InstrumentIdType", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InstrumentId", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InstrumentType", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InstrumentSubType", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InterfaceName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Environment", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Source", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Origin", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("TenorName", SqlDbType.VarChar)
            };

            var busDate = DateTime.Today;

            var data = new List<object[]>();
            var record = new object[]
            {
                100, 201.12, busDate, "Test User", "RiskFactorName", "RiskFactorTypeName", "RiskMeasureTypeName", "/TEST/TEST", "TEST", "BOOK", "MUREX", "Product", "ISIN",
                "Instrument Id", "Instrument Type", "InstrumentSubType", schema, env, "FLEX", "FLEX", "1D"
            };
            Assert.AreEqual(header.Count, record.Length);
            data.Add(record);

            var msgs = FlexFactStorage.PopulateStorage(header, data, schema, env, busDate, busDate, false);

            Assert.AreNotEqual(null, msgs);

        }

        [TestMethod]
        [Ignore]
        public void TestSaveFlexDataReconciliationPnL()
        {
            var schema = "Reconciliation.PnL";
            var env = "TEST";

            var header = new List<Tuple<string, SqlDbType>>
            {
                new Tuple<string, SqlDbType>("Difference", SqlDbType.Float),
                new Tuple<string, SqlDbType>("BusDate", SqlDbType.DateTime2),
                new Tuple<string, SqlDbType>("UserName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("NodeName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("NodeType", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("BookSystem", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InterfaceName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Environment", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Source", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Origin", SqlDbType.VarChar)
            };

            var busDate = DateTime.Today;

            var data = new List<object[]>();

            var record = new object[] {100, busDate, "Test User", "LBG", "GR", "Risk Management", schema, env, "FLEX", "FLEX"};
            Assert.AreEqual(header.Count, record.Length);

            data.Add(record);

            var msgs = FlexFactStorage.PopulateStorage(header, data, schema, env, busDate, busDate, false);

            Assert.AreEqual(null, msgs);

        }


        [Ignore]
        [TestMethod] public void TestSaveFlexDataVarHistorical()
        {
            var schema = "VaR.Historical-1D";
            var env = "TEST";
            
            var header = new List<Tuple<string, SqlDbType>>
            {
                new Tuple<string, SqlDbType>("ValueGBP", SqlDbType.Float),
                new Tuple<string, SqlDbType>("BusDate", SqlDbType.DateTime2),
                new Tuple<string, SqlDbType>("UserName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("RiskMeasureTypeName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("ScenarioHierarchyString", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("NodeName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("NodeType", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("BookSystem", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("InterfaceName", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Environment", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Source", SqlDbType.VarChar),
                new Tuple<string, SqlDbType>("Origin", SqlDbType.VarChar)
            };

            var busDate = DateTime.Today;

            var data = new List<object[]>();
            
            data.Add(new object[] {100, busDate, "Test User", "VaR Historical 1D", "`LBG`Historical VaR 300 days", "LBG", "GR", "Risk Management", schema, env, "FLEX", "FLEX"});
            data.Add(new object[] {200, busDate, "Test User", "VaR Historical 1D", "`LBG`Historical VaR 300 days", "Financial Markets", "BU", "Risk Management", schema, env, "FLEX", "FLEX" });
            data.Add(new object[] {300, busDate, "Test User", "VaR Historical 1D", "`LBG`Historical VaR 300 days", "Rates Trading", "BA", "Risk Management", schema, env, "FLEX", "FLEX" });
            data.Add(new object[] {400, busDate, "Test User", "VaR Historical 1D", "`LBG`Historical VaR 300 days", "FX Trading", "BA", "Risk Management", schema, env, "FLEX", "FLEX" });

            var msgs = FlexFactStorage.PopulateStorage(header, data, schema, env, busDate, busDate, false);

            Assert.AreEqual(null, msgs);
        }

        [TestMethod]
        [Ignore]
        public void TestUserFuncStoreDataVarHistorical()
        {
            var schema = "VaR";
            var data = new string[3, 13];

            //populate header
            data[0, 0] = "BusDate";
            data[0, 1] = "RiskMeasureTypeName";
            data[0, 2] = "ScenarioHierarchyString";
            data[0, 3] = "NodeName";
            data[0, 4] = "NodeType";
            data[0, 5] = "BookSystem";
            data[0, 6] = "InterfaceName";
            data[0, 7] = "Source";
            data[0, 8] = "Origin";
            data[0, 9] = "ValueGBP";
            data[0, 10] = "UserName";
            data[0, 11] = "Environment";
            data[0, 12] = "VaRID";

            //data
            data[1, 0] = DateTime.Today.AddDays(-1).ToString("yyyy-MM-dd");
            data[1, 1] = "VaR Historical";
            data[1, 2] = "`LBG`Historical VaR 300 days";
            data[1, 3] = "Financial Markets";
            data[1, 4] = "BU";
            data[1, 5] = "Risk Management";
            data[1, 6] = schema;
            data[1, 7] = "FLEX";
            data[1, 8] = "FLEX";
            data[1, 9] = "100.00";
            data[1, 10] = "TEST_USER";
            data[1, 11] = "TEST";
            data[1, 12] = "99";

            data[2, 0] = DateTime.Today.ToString("yyyy-MM-dd"); 
            data[2, 1] = "VaR Historical";
            data[2, 2] = "`LBG`Historical VaR 300 days";
            data[2, 3] = "LBG";
            data[2, 4] = "GR";
            data[2, 5] = "Risk Management";
            data[2, 6] = schema;
            data[2, 7] = "FLEX";
            data[2, 8] = "FLEX";
            data[2, 9] = "100.00";
            data[2, 10] = "TEST_USER";
            data[2, 11] = "TEST";
            data[2, 12] = "99";

            var msgs = UserFunc.SaveFlexData(data, schema, false);

            Assert.AreEqual(null, msgs);

        }

        [TestMethod]
        [Ignore]
        public void TestUserFuncDataVarHistoricalWithPatching()
        {
            var schema = "VaR";
            var data = new string[3, 13];

            //populate header
            data[0, 0] = "BusDate";
            data[0, 1] = "RiskMeasureTypeName";
            data[0, 2] = "ScenarioHierarchyString";
            data[0, 3] = "NodeName";
            data[0, 4] = "NodeType";
            data[0, 5] = "BookSystem";
            data[0, 6] = "InterfaceName";
            data[0, 7] = "Source";
            data[0, 8] = "Origin";
            data[0, 9] = "ValueGBP";
            data[0, 10] = "UserName";
            data[0, 11] = "Environment";
            data[0, 12] = "VaRID";

            //data
            data[1, 0] = DateTime.Today.AddDays(-200).ToString("yyyy-MM-dd");
            data[1, 1] = "VaR Historical";
            data[1, 2] = "`LBG`Historical VaR 300 days";
            data[1, 3] = "Financial Markets";
            data[1, 4] = "BU";
            data[1, 5] = "Risk Management";
            data[1, 6] = schema;
            data[1, 7] = "FLEX";
            data[1, 8] = "FLEX";
            data[1, 9] = "100.00";
            data[1, 10] = "TEST_USER";
            data[1, 11] = "TEST";
            data[1, 12] = "99";

            data[2, 0] = DateTime.Today.AddDays(-201).ToString("yyyy-MM-dd");
            data[2, 1] = "VaR Historical";
            data[2, 2] = "`LBG`Historical VaR 300 days";
            data[2, 3] = "LBG";
            data[2, 4] = "GR";
            data[2, 5] = "Risk Management";
            data[2, 6] = schema;
            data[2, 7] = "FLEX";
            data[2, 8] = "FLEX";
            data[2, 9] = "100.00";
            data[2, 10] = "TEST_USER";
            data[2, 11] = "TEST";
            data[2, 12] = "99";

            var msgs = UserFunc.SaveFlexData(data, schema, true);

            Assert.AreEqual(null, msgs);

        }

        [TestMethod]
        [Ignore]
        public void TestUserFuncColumnNumberMismatch()
        {
            var schema = "VaR";
            var data = new string[2, 4];

            //populate header
            data[0, 0] = "BusDate";
            data[0, 1] = "RiskMeasureTypeName";
            data[0, 2] = "ScenarioHierarchyString";
            data[0, 3] = "NodeName";
            
            //data
            data[1, 0] = DateTime.Today.ToString("yyyy-MM-dd");
            data[1, 1] = "VaR Historical";
            data[1, 2] = "`LBG`Historical VaR 300 days";
            data[1, 3] = "LBG";
            
            var msgs = UserFunc.SaveFlexData(data, schema, false);

            Assert.AreEqual(1, msgs.Length);
            Assert.AreEqual("Supplied number of columns does not match schema definition", msgs[0, 0]);
        }


        [TestMethod]
        [Ignore]
        public void TestUserFuncColumnNameMismatch()
        {
            var schema = "VaR.Historical-1D";
            var data = new string[2, 13];

            //populate header
            data[0, 0] = "Environment";
            data[0, 1] = "BusDate";
            data[0, 2] = "RiskMeasureTypeName";
            data[0, 3] = "ScenarioHierarchyString";
            data[0, 4] = "NodeName";
            data[0, 5] = "NodeType";
            data[0, 6] = "BookSystem";
            data[0, 7] = "InterfaceName";
            data[0, 8] = "Source";
            data[0, 9] = "Origin";
            data[0, 10] = "ValueEUR";
            data[0, 11] = "UserName";
            data[0, 12] = "VaRID";

            // data
            data[1, 0] = "TEST";
            data[1, 1] = DateTime.Today.ToString("yyyy-MM-dd");
            data[1, 2] = "VaR Historical";
            data[1, 3] = "`LBG`Historical VaR 300 days";
            data[1, 4] = "LBG";
            data[1, 5] = "GR";
            data[1, 6] = "Risk Management";
            data[1, 7] = "VaR";
            data[1, 8] = "SIMRA";
            data[1, 9] = "FLEX";
            data[1, 10] = "100.00";
            data[1, 11] = "TEST_USER";
            data[1, 12] = "99";

            var msgs = UserFunc.SaveFlexData(data, schema, false);

            Assert.AreEqual(1, msgs.Length);
            Assert.AreEqual("Required column 'ValueGBP' not found in the header", msgs[0, 0]);
        }


        [TestMethod]
        [Ignore]
        public void TestUserFuncThreshold()
        {
            var schema = "FeedLoadCheck.Threshold";
            var data = new string[2, 6];

            //populate header
            data[0, 0] = "ThresholdValue";
            data[0, 1] = "InterfaceName";
            data[0, 2] = "Source";
            data[0, 3] = "Origin";
            data[0, 4] = "UserName";
            data[0, 5] = "Environment";

            //data
            //data[1, 0] = "1.938";
            //data[1, 1] = "FeedLoadCheck.Threshold";
            //data[1, 2] = "FLEX";
            //data[1, 3] = "FLEX";
            //data[1, 4] = "TEST USER";
            //data[1, 5] = "TEST";

            data[1, 0] = "1.938";
            data[1, 1] = "Position";
            data[1, 2] = "Summit";
            data[1, 3] = "Summit";
            data[1, 4] = "TEST USER";
            data[1, 5] = "PROD";

            var msgs = UserFunc.SaveFlexData(data, schema, false);

            Assert.AreEqual(null, msgs);
        }

        [TestMethod]
        [Ignore]
        public void TestUserFuncComment()
        {
            var schema = "FeedLoadCheck.Comment";
            var data = new string[2, 7];
            
            //populate header
            data[0, 0] = "Comment";
            data[0, 1] = "InterfaceName";
            data[0, 2] = "Source";
            data[0, 3] = "Origin";
            data[0, 4] = "UserName";
            data[0, 5] = "Environment";
            data[0, 6] = "BusDate";

            //real data
            data[1, 0] = "Comment Test";
            data[1, 1] = "FeedLoadCheck.Threshold";
            data[1, 2] = "FLEX";
            data[1, 3] = "FLEX";
            data[1, 4] = "TEST USER";
            data[1, 5] = "TEST";
            data[1, 6] = DateTime.Today.ToString("yyyy-MM-dd");

            var msgs = UserFunc.SaveFlexData(data, schema, false);

            Assert.AreEqual(null, msgs);

        }
    }
}
