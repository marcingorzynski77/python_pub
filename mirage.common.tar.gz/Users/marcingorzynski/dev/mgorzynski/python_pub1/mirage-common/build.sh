#!/usr/bin/env bash
python setup.py bdist_wheel
devpi login bad --password London18
devpi upload dist/$(ls dist -t | head -1)
