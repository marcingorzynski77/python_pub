GX
========

Common utility component shared by all services



