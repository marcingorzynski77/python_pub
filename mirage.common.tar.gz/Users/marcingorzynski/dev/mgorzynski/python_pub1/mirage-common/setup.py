#!/usr/bin/env python
""" Common service utilities installation package"""
import os
from setuptools import setup

REQUIREMENTS = [line.strip() for line in open(os.path.join(os.path.dirname(__file__), 'requirements.txt')).readlines()]

version = {}
with open("common/version.py") as fp:
    exec(fp.read(), version)


setup(
    name='mirage-common',
    version=version['__version__'],
    packages=['common', 'common.storage', 'common.messaging', 'common.messaging.actor', 'common.messaging.model',
              'common.model', 'common.model.trade', 'common.rest', 'common.util', 'common.logging', 'common.cache'],
    description='Common service utilities Python implementation',
    author='GX',
    license='GX',
    author_email='contact@gosavex.com',
    install_requires=REQUIREMENTS,
    include_package_data=True,
    keywords='Common service utilities Python implementation',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
)
