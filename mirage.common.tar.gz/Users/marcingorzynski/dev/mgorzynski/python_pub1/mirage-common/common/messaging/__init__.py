from enum import Enum


class MessageType(Enum):
    unknown = 1
    event = 2
    control = 3
    checkpoint = 4
    journal = 5
    schedule = 6
