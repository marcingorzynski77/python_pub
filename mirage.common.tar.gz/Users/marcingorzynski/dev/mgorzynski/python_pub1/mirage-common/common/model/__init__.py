from enum import Enum


class DealType(Enum):
    none = 1
    trade = 2
    position = 3


class InternalStatusType(Enum):
    valid = 1
    quality_issue = 2


class ProductType(Enum):
    none = 1
    bond = 2
    sn_cds = 3
    index_cds = 4
    index_constituent = 6
    index_cds_decomposed = 7
    trs = 8
    repo = 9
    swap = 10
    cross_currency_swap = 11
    cap_floor = 12
    swaption = 13
    inflation_swap = 14
    inflation_option = 15
    fra = 16
    interest_rate_future = 17
    bond_future = 18
    fx_spot = 19
    fx_fwd = 20
    fx_swap = 21
    money_market = 22
    cash = 23
    fx_ndf = 24
    fx_option = 25
    commodity_option = 26
    commodity_swap = 27
    bond_pos = 28
    prdc = 29
    bond_pos_inflation = 30
    equity = 31


class LongShort(Enum):
    none = 1
    long = 2
    short = 3
