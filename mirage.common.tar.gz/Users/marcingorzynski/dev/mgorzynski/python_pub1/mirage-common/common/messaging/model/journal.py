import datetime as dt
import uuid
from .. import MessageType
from .base_message import BaseMessage


class Journal(BaseMessage):
    """ Journal """

    def __init__(self, message_type: MessageType = MessageType.journal):
        message_id = uuid.uuid4()
        time_created = dt.datetime.utcnow()
        super(Journal, self).__init__(time_created=time_created,
                                      message_id=message_id,
                                      message_type=message_type)
