import logging
from common.messaging.rabbitmq_api import EventSinkActor
from common.messaging.producer import Producer
from common.messaging.model.event import Event
from common.util.metric import stats


logging = logging.getLogger(__name__)


class ServiceEventSinkActor(EventSinkActor):
    """ handler for all global event messages on the service bus """

    def __init__(self, mq_producer: Producer):
        super(ServiceEventSinkActor, self).__init__(mq_producer)
        self.success_event_message = None
        self.failure_event_message = None
        self.data_available_message = None

    # noinspection PyBroadException
    def handler_event(self, event: Event):

        if not any(interesting_event in event.event_name for interesting_event in self.interesting_events):
            logging.debug('Not interested in message: %s', event.event_name)
            stats.on_ignore_event()
            return

        if self.running_journal_events:
            logging.info('Processing mq event message from journal: %s', event.event_name)
        else:
            logging.info('Received mq event message: %s', event.event_name)

        logging.info('Business date event: %s', event.bus_date)

        stats.on_process_event()
        original_message_id = event.message_id

        try:
            logging.info('Calling validation handler for: %s', event)
            result, exception_msg = self.handler_validation(event)
            if result:  # True: if validation successful
                # only add event to the collection if it is valid
                self.add_event_to_received(event)
                logging.debug('Calling pre-processing handler')
                self.handler_pre_processing(event)
                logging.debug('Calling processing handler')
                self.handler_processing(event)
                if self.success_event_message is not None:
                    logging.info('Sending global event: %s', self.success_event_message)
                    self.mq_producer.send_event(Event(event_name=self.success_event_message,
                                                      bus_date=event.bus_date,
                                                      correlated_message_id=original_message_id,
                                                      source=self.service_name))
                logging.debug('Calling post-processing handler')
                self.handler_post_processing(event)
                if self.send_data_available_message and self.data_available_message is not None:
                    logging.info('Sending global event: %s', self.data_available_message)
                    self.mq_producer.send_event(Event(event_name=self.data_available_message,
                                                      bus_date=event.bus_date,
                                                      correlated_message_id=original_message_id,
                                                      source=self.service_name))
                    self.send_data_available_message = False
            else:
                logging.info("Skipping processing as validation was not successful")
                self.mq_producer.create_and_send_event(Event(event_name=self.failure_event_message,
                                                             bus_date=event.bus_date,
                                                             source=self.service_name,
                                                             correlated_message_id=original_message_id,
                                                             event_payload=exception_msg))
        except Exception as ex:
            stats.on_error_event()
            logging.exception(ex)

            if self.failure_event_message is not None:
                logging.info("Sending global event: %s", self.failure_event_message)
                self.mq_producer.send_event(Event(event_name=self.failure_event_message,
                                                  bus_date=event.bus_date,
                                                  source=self.service_name,
                                                  event_payload=f"{type(ex).__name__}: {str(ex)}",
                                                  correlated_message_id=original_message_id))
            return

    def handler_processing(self, event: Event):
        pass

    # noinspection PyMethodMayBeStatic,PyUnusedLocal
    def handler_validation(self, event: Event) -> (bool, str):
        return True, ""

    # noinspection PyMethodMayBeStatic
    def handler_pre_processing(self, event: Event):
        pass

    # noinspection PyMethodMayBeStatic
    def handler_post_processing(self, event: Event):
        pass
