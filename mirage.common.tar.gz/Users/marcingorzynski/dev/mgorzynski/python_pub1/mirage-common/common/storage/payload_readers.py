""" class responsible for reading csv payloads"""
import csv
import itertools
import logging
import os
import gzip

logging = logging.getLogger(__name__)


class CsvPayloadReader:
    """ csv reader"""

    def __init__(self, delimiter=","):
        self.delimiter = delimiter

    def read(self, filename, skip_n_lines=0, skip_footer=False):
        # check if file exists
        if not os.path.exists(filename):
            raise ValueError(f'File {filename} does not exists')

        if skip_footer == False:
            if filename.endswith("gz"):
                with gzip.open(filename, 'rt', newline="") as csv_file:
                    reader = csv.DictReader(itertools.islice(csv_file, skip_n_lines, None), delimiter=self.delimiter,
                                            quotechar='"')
                    # next(reader)  # assume here we always have headers , skip one . TO DO make it optional
                    try:
                        for row in reader:
                            yield row
                    except csv.Error as e:
                        logging.error('file %s, line %s: %s'.format(filename, reader.line_num, e))
            else:
                with open(filename, 'r', newline="") as csv_file:
                    reader = csv.DictReader(itertools.islice(csv_file, skip_n_lines, None), delimiter=self.delimiter,
                                            quotechar='"')
                    # next(reader)  # assume here we always have headers , skip one . TO DO make it optional
                    try:
                        for row in reader:
                            yield row
                    except csv.Error as e:
                        logging.error('file %s, line %s: %s'.format(filename, reader.line_num, e))
        else:
            if filename.endswith("gz"):
                with open(filename) as file:
                    row_count = sum(1 for line in file) - skip_n_lines - 1
                counter = 0
                with gzip.open(filename, 'rt', newline="") as csv_file:
                    reader = csv.DictReader(itertools.islice(csv_file, skip_n_lines, None), delimiter=self.delimiter,
                                            quotechar='"')
                    # next(reader)  # assume here we always have headers , skip one . TO DO make it optional
                    try:
                        for row in reader:
                            counter = counter + 1
                            if counter == row_count -1:
                                continue
                            yield row
                    except csv.Error as e:
                        logging.error('file %s, line %s: %s'.format(filename, reader.line_num, e))
            else:
                with open(filename) as file:
                    row_count = sum(1 for line in file) - skip_n_lines - 1

                counter = 0
                with open(filename, 'r', newline="") as csv_file:
                    reader = csv.DictReader(itertools.islice(csv_file, skip_n_lines, None), delimiter=self.delimiter,
                                            quotechar='"')
                    # next(reader)  # assume here we always have headers , skip one . TO DO make it optional
                    try:
                        for row in reader:
                            counter = counter + 1
                            if counter == row_count:
                                continue
                            yield row
                    except csv.Error as e:
                        logging.error('file %s, line %s: %s'.format(filename, reader.line_num, e))


class CsvPayloadWriter:
    """ csv reader"""

    def __init__(self, delimiter=","):
        self.delimiter = delimiter

    # noinspection PyMethodMayBeStatic
    def write(self, filename, fieldnames, rows):
        # check if file exists
        if not os.path.exists(filename):
            raise ValueError("File {0} does not exists".format(filename))

        with open(filename, 'wb') as outcsv:
            writer = csv.DictWriter(outcsv, fieldnames)
            writer.writeheader()

            for row in rows:
                writer.writerow(row)
