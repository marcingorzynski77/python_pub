""" Flask startup module"""
import os
import sys
import getopt
from common.config import Configuration, instantiate_global_config
from common.logging.log import LogSetup


class AppStart:
    """ Handle rest startup operations"""

    def __init__(self):
        self.app_config_file = None
        self.log_config_file = None
        self.message_file = None

    def setup_logging(self):
        LogSetup.setup(self.log_config_file)

    def configure_app(self, config=Configuration()):
        if self.app_config_file is not None:
            config.load(self.app_config_file)

        instantiate_global_config(config)
        from common.util.metric import MetricCollector, instantiate_global_metric
        collector = MetricCollector(config.service_name, config.rest.statd_server, config.rest.statd_server_port)
        instantiate_global_metric(collector)

    # noinspection PyBroadException
    def parse_args(self, argv):
        print('Received arguments:{0}'.format(argv))
        try:
            opts = None
            try:
                opts, args = getopt.getopt(argv, "hc:l:m:", ["configfile=", "logfile=", "messagefile="])
            except getopt.GetoptError:
                print('No args supplied app.py -c <configfile> -l <logfile> -m <messagefile>')

            if opts:
                for opt, arg in opts:
                    if opt == "-h":
                        print('app.py -c <configfile> -l <logfile> -m <messagefile>')
                        sys.exit()
                    elif opt in ("-c", "--configfile"):
                        self.app_config_file = os.path.abspath(arg)
                    elif opt in ("-l", "--logfile"):
                        self.log_config_file = os.path.abspath(arg)
                    elif opt in ("-m", "--messagefile"):
                        self.message_file = os.path.abspath(arg)

            if self.app_config_file is None:
                print('Searching for config in parent directory {0} of {1}'.format(os.pardir, os.getcwd()))
                # check if exists in default location
                config_file = os.path.join(os.pardir, 'config', 'config.yml')
                if os.path.exists(config_file):
                    self.app_config_file = config_file
                else:
                    print('Config file not found, searching for config in current directory {0} of {1}'
                          .format(os.curdir, os.getcwd()))
                    config_file = os.path.join(os.curdir, 'config', 'config.yml')
                    if os.path.exists(config_file):
                        self.app_config_file = config_file

            if self.log_config_file is None:
                logging_yml = os.path.join(os.pardir, 'logging.yml')
                if os.path.exists(logging_yml):
                    self.log_config_file = logging_yml

            if self.message_file is None:
                messages_ini = os.path.join(os.pardir, 'messages.ini')
                if os.path.exists(messages_ini):
                    self.message_file = messages_ini

        except Exception:
            print("Exception when parsing args {0}".format(Exception))
