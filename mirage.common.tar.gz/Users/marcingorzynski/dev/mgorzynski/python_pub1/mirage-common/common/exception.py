"""Exception module"""
import logging
import sys
import time

logging = logging.getLogger(__name__)


class ServiceExit(Exception):
    """
    Custom exception which is used to trigger the clean exit
    of all running threads and the main program.
    """
    pass


# noinspection PyBroadException,PyUnusedLocal
def service_shutdown(signum, frame):
    # noinspection PyPep8
    try:
        logging.info('Caught signal %d' % signum)
        from common.messaging.rabbitmq_api import MqCoordinator
        # MqCoordinator.global_queue.put(PoisonPill())
        # MqCoordinator.consumer.close()
        # MqCoordinator.sink_actor_thread.join()
        time.sleep(2)  # sleep and let consumer to close
    except:
        logging.warning("error while closing threads, ignoring as we are shutting down process anyway")
    finally:
        sys.exit()
