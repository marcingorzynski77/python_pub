import unittest2
import datetime
import uuid
import os
from flask import Flask
from common.storage.file_api import FileApi
from common.config import Configuration
from common.storage.sql_api import SqlApi
from common.storage.sql_models import SqlWrapper, Store


class TestDb(unittest2.TestCase):
    Session = None
    Config = Configuration()

    def setUp(self):
        wrapper = SqlWrapper(TestDb.Config.storage.get_internal_storage_path())
        app = Flask(__name__)
        wrapper.reset_storage(app)

        TestDb.Session = wrapper.create_session()
        store = Store("Murex", "file_payload.csv", "File", datetime.date(2012, 3, 3), "")

        TestDb.Session.add(store)
        TestDb.Session.commit()

        TestDb.Config.storage.file_storage_root_path = os.path.dirname(__file__)
        TestDb.Config.storage.data_source = "STORE_NAME"

        TestDb.Config.storage.archive_enabled = False

    def test_db_interactions(self):
        print(f'*** Running {self.id()} ***')
        record = TestDb.Session.query(Store).first()
        self.assertEqual(record.data_source, "Murex")

    # def test_reading_file(self):
    #     print(f'*** Running {self.id()} ***')
    #     api = FileApi(TestDb.Config)
    #     for row in api.read(datetime.date(2012, 3, 3)):
    #         if row["column1"] == "1":
    #             self.assertEqual(row["column2"], "2")
    #         elif row["column1"] == "2":
    #             self.assertEqual(row["column2"], "4")

    def test_inserting_file(self):
        print(f'*** Running {self.id()} ***')
        api = FileApi(TestDb.Config)
        file = os.path.join(os.path.dirname(__file__), "file_payload.csv")
        api.insert(file, datetime.date(2012, 3, 3), "HPE PROD")

    def test_inserting_payload(self):
        print(f'*** Running {self.id()} ***')
        api = SqlApi(TestDb.Config)
        g = uuid.uuid4()
        api.insert(datetime.date(2012, 3, 3), g, 'F1.TimelinessInputFileProcess.Start',
                   '{"ParisMarkToMarketAndCash": "2018-05-15T17:21:20.2314264Z"}')
        for record in api.query(bus_date=datetime.date(2012, 3, 3),
                                tags='F1.TimelinessInputFileProcess.Start',
                                correlation_id=g):
            self.assertEqual(record.tags, "F1.TimelinessInputFileProcess.Start")
            break

    def test_inserting_file_no_tags(self):
        print(f'*** Running {self.id()} ***')
        api = FileApi(TestDb.Config)
        file = os.path.join(os.path.dirname(__file__), "file_payload.csv")
        api.insert(file, datetime.date(2012, 3, 3), "")
