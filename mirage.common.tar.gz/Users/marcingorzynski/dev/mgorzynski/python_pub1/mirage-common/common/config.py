""" configuration module"""
import os
import logging
import yaml
from common.storage.config import StorageConfiguration
from common.messaging.config import RabbitMqConfiguration
from common.messaging.config import JournalConfiguration
from common.rest.config import RestConfiguration

logging = logging.getLogger(__name__)


class Configuration(object):

    def __init__(self):
        """ class holding common mirage settings"""
        self.config_file_name = None
        self.config_collection = None
        self.wsgi_server_name = None
        # if service support caching set iot to true
        self.cache_enabled = False
        # (this is used to build MQ name)
        self.service_name = ""
        # type of service , can be gateway or service (this is used to build MQ name)
        self.service_type = ""
        self._storage_config = StorageConfiguration()
        self._rest_config = RestConfiguration()
        self._rabbit_mq_config = RabbitMqConfiguration()
        self._journal_config = JournalConfiguration()
        self.settings = None

    @property
    def rabbit_mq(self) -> RabbitMqConfiguration:
        return self._rabbit_mq_config

    @property
    def rest(self) -> RestConfiguration:
        return self._rest_config

    @property
    def storage(self) -> StorageConfiguration:
        return self._storage_config

    @property
    def journal(self) -> JournalConfiguration:
        return self._journal_config

    def load(self, config_file_name: str):
        """ load configuration from the provided file, if not provided defaults will be used"""
        if not config_file_name:
            logging.info('File name was not supplied, using default values')
            return

        if not os.path.exists(config_file_name):
            logging.warning('File with the provided file name: %s does not exist; using default values',
                            config_file_name)
            return

        self.config_file_name = config_file_name
        logging.info('Reading configuration from %s', config_file_name)
        cwd = os.getcwd()
        with open(os.path.join(cwd, self.config_file_name), 'r') as yml_file:
            self.config_collection = yaml.safe_load(yml_file)

        for section in self.config_collection:
            logging.info("Section: %s ", section)
            logging.info(self.config_collection[section])

        if 'common_settings' not in self.config_collection:
            logging.error('Required section "common_settings" was not found in the configuration file: %s',
                          config_file_name)
            return

        self.settings = self.config_collection['common_settings']

        if 'service_name' in self.settings:
            self.service_name = self.settings['service_name']
        if 'service_type' in self.settings:
            self.service_type = self.settings['service_type']
        if 'cache_enabled' in self.settings:
            self.cache_enabled = self.settings['cache_enabled']

        self.rabbit_mq.load(self.settings)
        self.storage.load(self.settings)
        self.rest.load(self.settings)
        self.journal.load(self.settings)


config: Configuration = None


def instantiate_global_config(config_instance: Configuration):
    global config
    config = config_instance
