""" Basic interactions with rabbit mq"""
import signal
import multiprocessing
import logging
import queue
import time
from concurrent.futures import ThreadPoolExecutor
from common.config import config
from common.exception import service_shutdown, ServiceExit
from . import MessageType
from .actor.event_sink import EventSinkActor
from .actor.waiting_thread import WaitingThreadActor
from .consumer import Consumer
from .producer import Producer


logging = logging.getLogger(__name__)
executor = None
manager = None


class MqCoordinator:
    """ Mq coordinator responsible for starting the event listener on a dedicated thread"""

    def __init__(self):
        pass

    sink_actor = None
    sink_actor_thread = None
    consumer = None
    global_queue = None

    # noinspection PyUnusedLocal
    @staticmethod
    def start_async(sink_actor=None):
        multiprocessing.freeze_support()
        try:
            # Register the signal handlers
            signal.signal(signal.SIGTERM, service_shutdown)
            signal.signal(signal.SIGINT, service_shutdown)

            logging.info('Initializing MqCoordinator')
            if sink_actor is None:
                MqCoordinator.sink_actor = EventSinkActor
            else:
                MqCoordinator.sink_actor = sink_actor

            # MqCoordinator.manager = multiprocessing.Manager()
            # MqCoordinator.global_queue = MqCoordinator.manager.Queue()
            MqCoordinator.global_queue = queue.Queue()
            MqCoordinator.executor = ThreadPoolExecutor(multiprocessing.cpu_count())
            # start sink actor and mq message listener on different threads
            futures = [MqCoordinator.executor.submit(MqCoordinator.start_sink_actor, MqCoordinator.global_queue),
                       MqCoordinator.executor.submit(MqCoordinator.start_mq_client, MqCoordinator.global_queue),
                       MqCoordinator.executor.submit(MqCoordinator.start_storage_cleaning, MqCoordinator.global_queue)]
            # wait(futures)
        except ServiceExit:
            logging.info('Received exit event, closing threads')

    @staticmethod
    def start_sink_actor(queue_obj):
        logging.info('Starting sink actor')
        # Register the signal handlers
        try:
            sink_proxy = MqCoordinator.sink_actor.start(Producer())
            logging.info('Sending journal message')
            sink_proxy.tell({'type': MessageType.journal, 'message': 'App start'})
            MqCoordinator.sink_actor_thread = WaitingThreadActor(sink_proxy, queue_obj)
            MqCoordinator.sink_actor_thread.start()
        except Exception as e:
            logging.exception('Unable to start sink actor: %s', str(e))
            # TODO stop starting

    @staticmethod
    def start_mq_client(queue_obj):
        logging.info('Starting MqCoordinator consumer (listener)')
        # Register the signal handlers
        time.sleep(2)  # sleep and let sink actor to initialize first
        try:
            MqCoordinator.consumer = Consumer(queue_obj)
            MqCoordinator.consumer.start_listening()
        except Exception as e:
            logging.exception('Unable to start MqCoordinator: %s', str(e))
            # TODO stop starting

    # noinspection PyUnusedLocal
    @staticmethod
    def start_storage_cleaning(queue_obj):
        try:
            if config.storage.number_of_bus_days_to_keep > 0:
                logging.info('Starting storage cleaning')
                from common.storage.config import StorageType
                if config.storage.storage_type == StorageType.file:
                    from common.storage.file_api import FileApi
                    file_api = FileApi(config)
                    file_api.clean_old_data(config.storage.number_of_bus_days_to_keep)
                elif config.storage.storage_type == StorageType.sql:
                    from common.storage.sql_api import SqlApi
                    sql_api = SqlApi(config)
                    sql_api.clean_old_data(config.storage.number_of_bus_days_to_keep)
                elif config.storage.storage_type == StorageType.noSql:
                    from common.storage.nosql_api import ElasticApi
                    # noinspection PyUnusedLocal
                    nosql_api = ElasticApi()
                    # TO DO implement
            else:
                logging.info('Storage cleaning is turned off')
        except Exception as e:
            logging.exception('Unable to clean old data', e)


