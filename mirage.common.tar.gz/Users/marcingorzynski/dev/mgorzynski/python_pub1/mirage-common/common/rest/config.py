""" configuration module"""
import logging

logging = logging.getLogger(__name__)


class RestConfiguration(object):

    def __init__(self):
        """ class holding application settings"""

        # use only for debugging by default we are not using it
        self.flask_server_name = ""
        self.flask_debug = False

        # rest attributes
        self.rest_plus_swagger_ui_doc_expansion = "list"
        self.rest_plus_validate = True
        self.rest_plus_mask_swagger = False
        self.rest_plus_error_404_help = False
        # server name for rest interface, cherrypi
        self.wsgi_server_name: str = '127.0.0.1'
        # server port for rest interface
        self.wsgi_server_port: int = 8080
        # port that metrics are being exposed
        self.metric_port = self.wsgi_server_port + 1
        # metric persistence service (telegraf)
        self.statd_server = None
        # metric persistence service port (telegraf)
        self.statd_server_port = None

    def load(self, app_settings):
        """ Get configuration from the provided dictionary, if a key is not present - a default value will be used"""

        if 'flask_server_name' in app_settings:
            self.flask_server_name = app_settings['flask_server_name']
        if 'flask_debug' in app_settings:
            self.flask_debug = app_settings['flask_debug']

        if 'rest_plus_swagger_ui_doc_expansion' in app_settings:
            self.rest_plus_swagger_ui_doc_expansion = app_settings['rest_plus_swagger_ui_doc_expansion']
        if 'rest_plus_validate' in app_settings:
            self.rest_plus_validate = app_settings['rest_plus_validate']
        if 'rest_plus_mask_swagger' in app_settings:
            self.rest_plus_mask_swagger = app_settings['rest_plus_mask_swagger']
        if 'rest_plus_error_404_help' in app_settings:
            self.rest_plus_error_404_help = app_settings['rest_plus_error_404_help']
        if 'wsgi_server_name' in app_settings:
            self.wsgi_server_name = app_settings['wsgi_server_name']
        if 'wsgi_server_port' in app_settings:
            self.wsgi_server_port = app_settings['wsgi_server_port']
        if 'metric_port' in app_settings:
            self.metric_port = app_settings['metric_port']
        else:
            self.metric_port = int(self.wsgi_server_port) + 1
            logging.info('Port for metrics is not configured, defaulting to: %s ', self.metric_port)
        if 'statd_server' in app_settings:
            self.statd_server = app_settings['statd_server']
        if 'statd_server_port' in app_settings:
            self.statd_server_port = app_settings['statd_server_port']
