""" Elastic storage API """
import logging
import datetime as dt
from elasticsearch import Elasticsearch
from common.storage.sql_models import SqlWrapper, Store
from common.config import config
from common.storage.config import StorageType

logging = logging.getLogger(__name__)


class ElasticApi(object):
    def __init__(self):
        self.es = Elasticsearch([config.storage.elastic_search])

    # noinspection PyMethodMayBeStatic
    def __get_index_name(self, busdate: dt.date, index_name, version):
        return "{0}.{1}.{2}".format(index_name, busdate.strftime('%d-%m-%Y'), version)

    def __create_index(self, index_name):
        logging.info("checking if index {0} exists".format(index_name))
        if self.es.indices.exists(index=index_name):
            raise ValueError("{0} index already exists".format(index_name))
        else:
            self.es.indices.create(index=index_name)
            # noinspection PyUnresolvedReferences,PyUnresolvedReferences,PyUnresolvedReferences
            self.es.indices.put_mapping(index=index_name, doc_type=doc_type, body=mapping)
        return index_name

    def check_index_exists(self, index_name):
        return self.es.indices.exists(index=index_name)

    def get_index_name(self, busdate: dt.date, index_name, version):
        self.__get_index_name(busdate, index_name, version)

    # noinspection PyMethodMayBeStatic
    def get_stored_index(self, busdate: dt.date):
        if config.storage.data_source is None:
            raise ValueError("DATA_SOURCE is not set")

        sql = SqlWrapper(config.storage.get_internal_storage_path())
        data = sql.query(busdate)

        if data is None:
            return None

        return data.location

    def insert(self, busdate: dt.date, index_name_prefix, tags):
        if config.storage.data_source is None:
            raise ValueError("DATA_SOURCE is not set")

        sql = SqlWrapper(config.storage.get_internal_storage_path())
        data = sql.query(busdate)

        if data is None:
            index = self.__get_index_name(busdate, index_name_prefix, 1)
            logging.info("inserting to local storage for index %s", index)
            store = Store(config.storage.data_source, index,
                          StorageType.noSql.name,
                          busdate,
                          tags, '')
            sql.insert(store)
            data = store
        else:
            splits = data.location.split(".")
            version = splits[len(splits) - 1]
            data.location = self.__get_index_name(busdate, index_name_prefix, int(version) + 1)
            logging.info("updating local storage index version from %s to %s", version, data.location)
            sql.update(data)

        return data.location

    # noinspection PyMethodMayBeStatic
    def update(self, busdate: dt.date, tags):
        sql = SqlWrapper(config.storage.get_internal_storage_path())
        data = sql.query(busdate)

        if data is None:
            return None
        else:
            data.tags = data.tags + ';' + tags
            sql.update(data)

        logging.info("updating local storage index tags to %s", data.tags)

        return data.location
