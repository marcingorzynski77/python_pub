import functools
import logging
import pika
import threading
import time
from common.config import config
from .rabbitmq_base import RabbitMqBase

logging = logging.getLogger(__name__)


class Consumer(RabbitMqBase):
    """ Consumer listens on signaling bus for any ecosystem related messages """
    internal_lock = threading.Lock()
    
    def __init__(self, queue_obj):
        super(Consumer, self).__init__()
        self._queue = queue_obj
        if config.rabbit_mq.service_queue is None:
            raise ValueError('RabbitMq Service Queue is not specified')
        self._threads = []

    def _declare_queues(self):
        self._channel.queue_declare(queue=config.rabbit_mq.service_queue, durable=True)
        self._channel.queue_bind(exchange=config.rabbit_mq.global_event_exchange, queue=config.rabbit_mq.service_queue)

    # noinspection PyUnusedLocal,PyUnusedLocal
    def _on_message(self, channel, method_frame, head_frame, body, args):
        logging.debug('Received message: %s', body)
        t = threading.Thread(self._queue.put(body))
        t.start()
        self._threads.append(t)

    def start_listening(self):
        if config.rabbit_mq.service_queue is None:
            logging.info('Mq server not set up, Mq listener will be disabled')
            return

        logging.info('Listening for messages on queue %s', config.rabbit_mq.service_queue)
        sleep_time = 1
        while sleep_time < self.MAX_SLEEP_TIME:
            try:
                self._connect()

                on_message_callback = functools.partial(self._on_message, args=())
                self._channel.basic_consume(on_message_callback, queue=config.rabbit_mq.service_queue, no_ack=True)
                logging.info('Waiting for messages...')

                # while True:
                #     with self.internal_lock:
                #         self._connection.process_data_events()
                #         time.sleep(0.1)

                self._channel.start_consuming()
                break
            except pika.exceptions.ConnectionClosed:
                logging.info("Connection closed by, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Do not recover on channel errors
            except pika.exceptions.AMQPChannelError as err:
                logging.error("Caught a channel error: {0}".format(err))
                break
            # Recover on all other connection errors
            except pika.exceptions.AMQPConnectionError:
                logging.info("Connection was closed, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Exception
            except Exception as ex:
                logging.exception("Exception: %s", ex)
                break

    def close_connection(self):
        # Wait for threads to finish
        for thread in self._threads:
            thread.join()

        super().close_connection()
