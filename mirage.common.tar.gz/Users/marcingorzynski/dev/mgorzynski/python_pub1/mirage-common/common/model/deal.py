""" common related schemas"""
import toastedmarshmallow
from marshmallow import Schema, fields, post_load
from common.util.marshmallow_enum import EnumField
from . import DealType, ProductType, InternalStatusType

# ------------------ Common Deal Details ---------------------


class DealSchema(Schema):
    class Meta:
        jit = toastedmarshmallow.Jit
    """ deal schema used for serialization"""
    book = fields.Str(allow_none=True)
    source = fields.Str(allow_none=True)
    deal_type = EnumField(DealType)
    product_type = EnumField(ProductType)
    external_status = fields.Str(allow_none=True)
    internal_status = EnumField(InternalStatusType)
    original_source = fields.Str(allow_none=True)

    @post_load
    def make_event(self, data):
        return Deal(**data)


class Deal:
    schema = DealSchema()
    schema.jit = toastedmarshmallow.Jit
    """ deal object """

    def __init__(self,
                 book: str = None,
                 source: str = None,
                 product_type: ProductType = ProductType.none,
                 deal_type: DealType = DealType.none,
                 original_source: str = None,
                 internal_status: InternalStatusType = InternalStatusType.valid,
                 external_status: str = ""):
        self.book: str = book
        self.source: str = source
        self.product_type: ProductType = product_type
        self.deal_type: DealType = deal_type
        self.internal_status: InternalStatusType = internal_status
        self.external_status: str = external_status
        self.original_source: str = original_source
