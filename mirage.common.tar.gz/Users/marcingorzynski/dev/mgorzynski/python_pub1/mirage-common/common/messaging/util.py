""" Mq util module"""
import dateutil
import logging
import uuid
from common.messaging.producer import Producer
from common.messaging.model.event import Event
from common.messaging.model.control import Control
from common.messaging.model.schedule import Schedule

logging = logging.getLogger(__name__)


def publish_event(event_name, bus_date, file):
    Producer().send_event(Event(event_name, bus_date, file))


def process_startup_messages(messagefile):
    if messagefile is None:
        return

    with open(messagefile, 'r') as file:
        for line in file.readlines():
            if line is None or line.startswith('--'):
                continue

            items = line.split(',')
            logging.info("processing %s", line)

            if items[0] == 'S':
                # schedule request
                job_name = items[1]
                bus_date = dateutil.parser.parse(items[2], dayfirst=False)
                params = {items[3]: items[4]}
                run_id = items[5].rstrip()
                schedule = Schedule(job_name=job_name, bus_date=bus_date,
                                    correlated_message_id=uuid.UUID(run_id), parameters=params)
                Producer().send_schedule(schedule)
            elif items[0] == 'C':
                # control request
                category = items[1]
                bus_date = dateutil.parser.parse(items[2], dayfirst=False)
                payload = {items[3]: items[4]}
                run_id = items[5].rstrip()
                control = Control(category=category, bus_date=bus_date,
                                  correlated_message_id=uuid.UUID(run_id), payload=payload)
                Producer().send_control(control)
            else:
                # global event
                if len(items) == 4:
                    event_name = items[0]
                    bus_date = dateutil.parser.parse(items[1], dayfirst=False)
                    source = items[2].rstrip()
                    payload = items[3].rstrip()
                    Producer().send_event(Event(event_name, bus_date, source, payload))
                elif len(items) == 5:
                    event_name = items[0]
                    bus_date = dateutil.parser.parse(items[1], dayfirst=False)
                    run_id = items[2]
                    source = items[3].rstrip()
                    payload = items[4].rstrip()
                    event = Event(event_name, bus_date, source, payload, correlated_message_id=uuid.UUID(run_id))
                    Producer().send_event(event)
