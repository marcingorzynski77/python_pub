import logging
from common.util.metric import stats, CacheMetricTimer
from common.cache.domain import DataDomainBase
from common.config import Configuration
from ..model.event import Event
from ..producer import Producer
from .gateway_event_sink import GatewayEventSinkActor


logging = logging.getLogger(__name__)


class CollateGatewayEventSinkActor(GatewayEventSinkActor):

    def __init__(self, mq_producer: Producer, config: Configuration, data_domain: DataDomainBase):
        super(CollateGatewayEventSinkActor, self).__init__(mq_producer, config, data_domain)
        self.data_available_message = None
        self.file_row_count_message = None
        self.success_event_message = None
        self.failure_event_message = None

    def handler_data_insert(self, event: Event):
        logging.debug('Executing handler data insert')
        file_path = event.event_payload
        logging.info('File path: %s', file_path)
        self.file_api.insert(file_path, event.bus_date, event.event_name)

    def handler_processing(self, event: Event):
        pass

    def handler_post_processing(self, event: Event):
        events = self.received_events[event.bus_date]

        if sorted(events.keys()) == self.interesting_events and not self.running_journal_events:
            if self.config.cache_enabled:
                logging.info("Cache enabled. Processing event: %s", event.event_payload)
                timer = CacheMetricTimer(stats)
                timer.invoke(self.data_domain.build_cache, event.bus_date)

            logging.info('We have received all events for %s', event.bus_date)
            self.send_data_available_message = True
