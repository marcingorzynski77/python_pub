import logging
from common.logging.log import LogSetup


LogSetup.setup('logging.yml')
logging = logging.getLogger(__name__)
logging.debug('DEBUG event')
logging.info('INFO event')
logging.warning('WARNING event')
logging.error('ERROR event')
