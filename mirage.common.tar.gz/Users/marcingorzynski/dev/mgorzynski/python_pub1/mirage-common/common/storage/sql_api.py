""" Sql storage API """
import datetime as dt
import logging
from typing import List
import uuid
from common.storage.sql_models import SqlWrapper, Store
from common.storage.config import StorageType
from common.config import Configuration

logging = logging.getLogger(__name__)


class SqlApi(object):
    """ Define access methods to internal storage"""

    def __init__(self, config: Configuration):
        self.storage_type = StorageType.sql
        self.config = config
        self._sql = SqlWrapper(self.config.storage.get_internal_storage_path())

    def read_with_pagination(self) -> List[Store]:
        data = self._sql.read_with_pagination()
        if data is None:
            return []
        return data

    def read_record(self, bus_date: dt.date) -> Store:
        data = self._sql.query(bus_date)
        return data
        # if data is None:
        # raise ValueError("Unable to locate any data for business date {0}".format(bus_date))

    def read_all_records(self) -> List[Store]:
        data = self._sql.read_all()
        if data is None:
            return []

        return data

    def query(self, bus_date: dt.date, tags: str = "",
              correlation_id: uuid = None, latest_only: bool = False) -> List[Store]:
        data = self._sql.query(bus_date, tags, correlation_id, latest_only)

        if data is None:
            return []

        return data

        # if data is None:
        #     raise ValueError("Unable to locate any data for business date {0}".format(bus_date))
        #
        # if not data:
        #     raise ValueError("Unable to locate any metric details for correlation_id {0} and tag {1}"
        #                      .format(correlation_id, tags))
        # for row in data:
        #     yield row

    def query_by_source_trigger(self, source: str, trigger: str) -> List[Store]:
        data = self._sql.query_by_source_trigger(source, trigger)
        return data

    def query_by_trigger(self, trigger: str) -> List[Store]:
        data = self._sql.query_by_trigger(trigger)
        return data

    def query_by_source(self, source: str) -> List[Store]:
        data = self._sql.query_by_source(source)
        return data
    
    def query_by_tag(self, tags: str) -> List[Store]:
        sql = SqlWrapper(self.config.storage.get_internal_storage_path())
        data = self.query_by_tags(tags)
        return data

    def insert(self, bus_date: dt.date, correlation_id: uuid, tags: str, payload):
        # always add
        logging.debug('Inserting to local storage')
        store = Store(data_source=self.config.storage.data_source,
                      location=payload,
                      storage_type=self.storage_type.name,
                      bus_date=bus_date,
                      tags=tags,
                      correlation_id=str(correlation_id))
        self._sql.insert(store)

    def insert_tags_payload(self, tags: str, payload: str) -> None:
        # always add
        logging.debug('Inserting to local storage')
        store = Store(data_source=self.config.storage.data_source,
                      location=payload,
                      storage_type=self.storage_type.name,
                      tags=tags)
        self._sql.insert(store)

    def clean_old_data(self, number_of_days_to_keep):
        if self.storage_type == StorageType.file:
            records_ro_be_removed = self._sql.get_records_to_be_removed(number_of_days_to_keep)
            if records_ro_be_removed is None:
                pass
            else:
                for data in records_ro_be_removed:
                    self._sql.delete(data.id)
        else:
            raise ValueError('Not implemented for storage type %s', self.storage_type)
