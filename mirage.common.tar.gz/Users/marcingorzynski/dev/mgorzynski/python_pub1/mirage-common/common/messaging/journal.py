import logging
import datetime as dt
from common.config import Configuration
from .journal_db import JournalDb
from .config import JournalConfiguration
from . import MessageType
from .model.base_message import BaseMessage
from .model.event import Event
from .model.checkpoint import Checkpoint


logging = logging.getLogger(__name__)


class Journal:
    """Journal wrapper for persisting events"""
    def __init__(self, config: Configuration):
        self.journalDb = JournalDb(config.journal.get_journal_db_path())
        self.config: JournalConfiguration = config.journal
        if self.config.journal_days is not None:
            self.__remove_by_age(self.config.journal_days)

    """Get events from journal - the range depends on configuration"""
    def get_events(self) -> [Event]:
        if self.config.journal_full_load:
            logging.info('Processing all events')
            return self.get_events_all()
        else:
            logging.info('Processing events since last checkpoint')
            return self.get_events_since_last_checkpoint()

    """Get all events from the journal"""
    def get_events_all(self) -> [Event]:
        data = self.journalDb.retrieve_events()
        if not data:
            return []
        return [Event(event_name=d.event_name,
                      bus_date=d.bus_date,
                      event_payload=d.event_payload,
                      time_created=d.time_created,
                      message_id=d.message_id,
                      correlated_message_id=d.correlated_message_id,
                      source=d.source,
                      host=d.host,
                      run_id=d.run_id)
                for d in data]

    """Get events for a business date"""
    def get_events_by_bus_date(self, bus_date: dt.date) -> [Event]:
        data = self.journalDb.retrieve_events_by_bus_date(bus_date)
        if not data:
            return []
        return [Event(event_name=d.event_name,
                      bus_date=d.bus_date,
                      event_payload=d.event_payload,
                      time_created=d.time_created,
                      message_id=d.message_id,
                      correlated_message_id=d.correlated_message_id,
                      source=d.source,
                      host=d.host,
                      run_id=d.run_id)
                for d in data]

    """Get events for a business date and name pattern"""
    def get_events_by_bus_date_and_pattern(self, bus_date: dt.date, pattern: str, latest_only: bool = False) -> [Event]:
        # TODO switch to this code after sqlite upgrade
        # if latest_only:
        #    data = self.journalDb.retrieve_events_by_bus_date_and_pattern_latest(bus_date, pattern)
        # else:
        #    data = self.journalDb.retrieve_events_by_bus_date_and_pattern(bus_date, pattern)

        data = self.journalDb.retrieve_events_by_bus_date_and_pattern(bus_date, pattern)
        if not data:
            return []

        if not latest_only:
            return [Event(event_name=d.event_name,
                          bus_date=d.bus_date,
                          event_payload=d.event_payload,
                          time_created=d.time_created,
                          message_id=d.message_id,
                          correlated_message_id=d.correlated_message_id,
                          source=d.source,
                          host=d.host,
                          run_id=d.run_id)
                    for d in data]
        else:
            latest = {}
            for d in data:
                latest[d.event_name] = Event(event_name=d.event_name,
                                             bus_date=d.bus_date,
                                             event_payload=d.event_payload,
                                             time_created=d.time_created,
                                             message_id=d.message_id,
                                             correlated_message_id=d.correlated_message_id,
                                             source=d.source,
                                             host=d.host,
                                             run_id=d.run_id)
            return latest.values()  # return list of unique values

    """Get events since the last checkpoint - default behaviour when a service is started and journal enabled"""
    def get_events_since_last_checkpoint(self) -> [Event]:
        data = self.journalDb.retrieve_events_since_last_checkpoint()
        if not data:
            return []
        return [Event(event_name=d.event_name,
                      bus_date=d.bus_date,
                      event_payload=d.event_payload,
                      time_created=d.time_created,
                      message_id=d.message_id,
                      correlated_message_id=d.correlated_message_id,
                      source=d.source,
                      host=d.host)
                for d in data]

    """Get full journal - events and checkpoints"""
    def get_journal(self) -> [BaseMessage]:
        data = self.journalDb.retrieve_journal()
        if not data:
            return []
        for d in data:
            if d.message_type == MessageType.event.name:
                yield Event(event_name=d.event_name,
                            bus_date=d.bus_date,
                            event_payload=d.event_payload,
                            time_created=d.time_created,
                            message_id=d.message_id,
                            correlated_message_id=d.correlated_message_id,
                            source=d.source,
                            host=d.host)
            elif d.message_type == MessageType.checkpoint.name:
                yield Checkpoint(checkpoint_name=d.event_name,
                                 time_created=d.time_created)

    """Add event the the journal"""
    def add_event(self, event: Event):
        self.journalDb.store_event(event)

    """Add checkpoint the the journal"""
    def add_checkpoint(self, checkpoint: Checkpoint):
        self.journalDb.store_checkpoint(checkpoint)

    """Remove old entries from journal"""
    def __remove_by_age(self, journal_days: int):
        self.journalDb.remove_events_by_age(journal_days)

    """Remove all entries from journal"""
    def clear(self):
        self.journalDb.clear_journal()
