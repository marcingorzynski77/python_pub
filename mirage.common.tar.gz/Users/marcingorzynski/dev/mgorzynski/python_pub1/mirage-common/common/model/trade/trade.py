import datetime as dt
from marshmallow import fields, post_load
import toastedmarshmallow
from .. import DealType, ProductType, InternalStatusType
from ..deal import Deal, DealSchema


class TradeSchema(DealSchema):
    class Meta:
        jit = toastedmarshmallow.Jit
    """ schema used for serialization"""
    trade_id = fields.Str(allow_none=True)
    counterparty = fields.Str(allow_none=True)
    currency = fields.Str(allow_none=True)
    maturity_date = fields.Date(allow_none=True)
    trade_date = fields.Date(allow_none=True)
    trade_type = fields.Str(allow_none=True)
    sub_type = fields.Str(allow_none=True)

    @post_load
    def make_event(self, data):
        return Trade(**data)


class Trade(Deal):
    schema = TradeSchema()
    schema.jit = toastedmarshmallow.Jit
    
    def __init__(self,
                 trade_id: str,
                 book: str,
                 counterparty: str,
                 currency: str,
                 source: str,
                 original_source: str = None,
                 product_type: ProductType = ProductType.none,
                 trade_type: str = None,
                 sub_type: str = None,
                 maturity_date: dt.date = None,
                 trade_date: dt.date = None,
                 internal_status: InternalStatusType = InternalStatusType.valid,
                 external_status: str = "",
                 deal_type: DealType = DealType.trade):
        super(Trade, self).__init__(book=book,
                                    source=source,
                                    product_type=product_type,
                                    deal_type=deal_type,
                                    original_source=original_source,
                                    internal_status=internal_status,
                                    external_status=external_status)
        self.trade_id: str = trade_id
        self.currency: str = currency
        self.trade_date: dt.date = trade_date
        self.maturity_date: dt.date = maturity_date
        self.trade_type = trade_type
        self.sub_type = sub_type
        self.counterparty = counterparty
