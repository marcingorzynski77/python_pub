# noinspection PyPackageRequirements
import unittest2
import datetime as dt
import dateutil
from common.config import Configuration
from common.messaging.model.event import Event, EventSchema


class TestMessaging(unittest2.TestCase):

    def setUp(self):
        config = Configuration()
        config.rabbit_mq.user = "admin"
        config.rabbit_mq.password = "London18"
        config.rabbit_mq.server = "fmd-a8-2700"
        config.rabbit_mq.port = "5672"

    def test_message_serialization(self):
        print(f'*** Running {self.id()} ***')
        msg = Event("START", dt.datetime.utcnow().date(), 'TEST')
        schema = EventSchema()
        result = schema.dumps(msg)
        self.assertTrue(result.data is not None)

        des_result = schema.loads(result.data)
        self.assertTrue(isinstance(des_result.data, Event))

    def test_serialization(self):
        from enum import Enum
        import toastedmarshmallow
        from marshmallow import fields, Schema

        from common.util.marshmallow_enum import EnumField

        class Level(Enum):
            LOW = '0'
            MEDIUM = '1'
            HIGH = '2'

        class UserSchema(Schema):
            class Meta:
                jit = toastedmarshmallow.Jit

            name = fields.String()
            level = EnumField(Level)

        class User:
            def __init__(self, name, level):
                self.name = name
                self.level = level

        schema = UserSchema()

        user = User(name='John Doe', level=Level.HIGH)
        print(schema.dump(user).data)

        d = schema.load(schema.dump(user).data).data
        al = User(**d)

    # def test_elastic_create(self):
    #     trade = Trade()
    #     trade.set_connection()
    #     trade.create()
    #
    # def test_elastic_read(self):
    #
    #     trade = Trade()
    #     trade.set_connection()
    #     trade.read()

    def test_bus_date_parsing(self):
        print(f'*** Running {self.id()} ***')
        date = dateutil.parser.parse('10-04-2018', dayfirst=True)
        self.assertTrue(date.date() == dt.date(2018, 4, 10))

    # def test_elastic_search(self):
    #     # TO DO REMOVE
    #     from elasticsearch import Elasticsearch
    #     from elasticsearch_dsl import Search
    #     client = Elasticsearch(['W7D6644'])
    #
    #     s = Search(using=client, index="trade").query("match_all")
    #
    #     response = s.execute()
    #
    #     for hit in response:
    #         print(hit.book)

    # def test_sending_event(self):
    #     # send message
    #     producer = EventProducer()
    #     producer.send_event("SOME_EVENT")
    #
    #     MqCoordinator.start_async()

#
# class Trade(DocType):
#     book = Text()
#     tags = Keyword()
#     business_date = Date()
#
#     class Meta:
#         index = 'trade'
#
#     def save(self, ** kwargs):
#         return super(Trade, self).save(** kwargs)
#
#     def set_connection(self):
#         connections.create_connection(hosts=['W7D6644'])
#         # create the mappings in elasticsearch
#         Trade.init()
#
#     def create(self):
#         # create and save and article
#         trade = Trade(meta={'id': 'ABC123'}, book='Book1', tags=['murex'])
#         trade.save()
#
#     def read(self):
#         trade = Trade.get(id='ABC123')
#         print(trade.book)
#
#         # Display cluster health
#         print(connections.get_connection().cluster.health())
