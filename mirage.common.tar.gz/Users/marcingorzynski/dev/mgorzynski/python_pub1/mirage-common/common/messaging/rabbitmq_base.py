import pika
import pika.exceptions
import logging
from common.config import config


class RabbitMqBase:
    """ Produces significant signal messages related to ecosystem overall status """
    MAX_SLEEP_TIME = 900  # 15 mins = 900 seconds which means 10 re-trials

    def __init__(self):
        if config.rabbit_mq.server is None:
            raise ValueError('RabbitMq Server is not specified')
        if config.rabbit_mq.port == 0:
            raise ValueError('RabbitMq Port is not specified')
        if config.rabbit_mq.user is None:
            raise ValueError('RabbitMq User is not specified')
        if config.rabbit_mq.password is None:
            raise ValueError('RabbitMq Password is not specified')
        if config.rabbit_mq.global_event_exchange is None:
            raise ValueError('RabbitMq Global Event Exchange is not specified')

        credentials = pika.PlainCredentials(config.rabbit_mq.user, config.rabbit_mq.password)
        self._parameters = pika.ConnectionParameters(host=config.rabbit_mq.server,
                                                     port=config.rabbit_mq.port,
                                                     virtual_host='/',
                                                     credentials=credentials,
                                                     heartbeat=0)
        self._connection: pika.BlockingConnection = None
        self._channel: pika.adapters.blocking_connection.BlockingChannel = None
        self._connect()

    def __del__(self):
        self.close_connection()

    def _connect(self):
        if not self._connection or self._connection.is_closed:
            self._connection = pika.BlockingConnection(self._parameters)
        if not self._channel or self._channel.is_closed:
            self._channel = self._connection.channel()
            self._channel.exchange_declare(exchange=config.rabbit_mq.global_event_exchange,
                                           exchange_type='fanout', durable=True)
            self._declare_queues()

    def _declare_queues(self):
        pass

    def close_connection(self):
        logging.info('Closing mq connection')
        if self._channel and not self._channel.is_closed:
            self._channel.close()
        if self._connection and not self._connection.is_closed:
            self._connection.close()
