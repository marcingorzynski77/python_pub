""" Flask startup module"""
import os
import sys
import logging
from typing import Type
from flask import Flask, Blueprint
from flask_restplus import Api
from common.config import config
from common.storage.config import StorageType
from common.messaging.rabbitmq_api import MqCoordinator, EventSinkActor
from common.messaging.journal_db import JournalDb
from common.storage.sql_models import SqlWrapper
from common.util.args import AppStart

logger = logging.getLogger(__name__)


# noinspection PyProtectedMember
class Startup:
    """ Handle rest startup operations"""

    def __init__(self, app_start: AppStart):
        self.app_start = app_start

    if getattr(sys, 'frozen', False):
        # noinspection PyUnresolvedReferences
        template_folder = os.path.join(sys._MEIPASS, 'templates')
        # noinspection PyUnresolvedReferences
        static_folder = os.path.join(sys._MEIPASS, 'swaggerui')
        logger.info('Template folder: %s', template_folder)
        app = Flask(__name__, template_folder=template_folder, static_folder=static_folder)
    else:
        app = Flask(__name__)

    @staticmethod
    def setup_flask_config(flask_app: Flask):
        if config.rest.wsgi_server_name is None:
            flask_app.config['SERVER_NAME'] = config.rest.flask_server_name

        flask_app.config['SWAGGER_UI_DOC_EXPANSION'] = config.rest.rest_plus_swagger_ui_doc_expansion
        flask_app.config['RESTPLUS_VALIDATE'] = config.rest.rest_plus_validate
        flask_app.config['RESTPLUS_MASK_SWAGGER'] = config.rest.rest_plus_mask_swagger
        flask_app.config['ERROR_404_HELP'] = config.rest.rest_plus_error_404_help

    @staticmethod
    def print_header(version: str):
        logger.info('======================= Starting %s %s version %s ========================'
                    % (config.service_name, config.service_type, version))

    def __configure_app(self, flask_app: Flask):
        if flask_app is not None:
            self.setup_flask_config(flask_app)

    def initialize_app(self, swagger_namespace, api: Api, event_sink: Type[EventSinkActor]):
        self.__configure_app(Startup.app)

        # initialise storage if does not exist
        if config.storage.storage_type is not StorageType.noStorage:
            storage_path = config.storage.get_internal_storage_path()
            if not os.path.exists(storage_path):
                logging.info('Internal storage does not exists, creating a new one: %s', storage_path)
                SqlWrapper(storage_path).reset_storage(Startup.app)
            else:
                logging.info('Internal storage path: %s', storage_path)

        # initialise journal.db if does not exist
        if config.journal.journal_enabled:
            journal_path = config.journal.get_journal_db_path()
            if not os.path.exists(journal_path):
                logging.info('Journal storage does not exists, creating a new one: %s', journal_path)
                JournalDb(journal_path).reset_storage(Startup.app)
            else:
                logging.info('Journal db path: %s', journal_path)

        # build rest api gui based on rest definitions
        blueprint = Blueprint('api', __name__, url_prefix='/api')
        # noinspection PyTypeChecker
        api.init_app(blueprint)
        api.add_namespace(swagger_namespace)
        Startup.app.register_blueprint(blueprint)
        logger.info('>>>>> System storage information available on http://%s:%s/system/ <<<<<',
                    config.rest.wsgi_server_name, config.rest.wsgi_server_port)

        # add system rest interface
        from common.rest.system import blueprint_system
        Startup.app.register_blueprint(blueprint_system)
        if config.rabbit_mq.enabled:
            # start global event listener
            MqCoordinator.start_async(event_sink)

    def start(self):
        import greplin.scales.flaskhandler as statserver
        logging.info('>>>>> App metrics available on http://%s:%s/status <<<<<', config.rest.wsgi_server_name,
                     config.rest.metric_port)
        statserver.serveInBackground(config.rest.metric_port, serverName=config.service_name)

        if config.rest.wsgi_server_name is not None:
            logger.info('>>>>> Starting wsgi at http://%s:%s/api/ <<<<<', config.rest.wsgi_server_name,
                        config.rest.wsgi_server_port)
            self.run_server(Startup.app)
        else:
            logger.info('>>>>> Starting flask server at http://%s/api/ <<<<<', config.rest.flask_server_name)
            self.app.run(debug=config.rest.flask_debug, port=config.rest.wsgi_server_port)

    # noinspection PyMethodMayBeStatic
    def run_server(self, app: Flask):
        import cherrypy
        from paste.translogger import TransLogger
        # Enable WSGI access logging via Paste
        app_logged = TransLogger(app)

        # Mount the WSGI callable object (app) on the root directory
        cherrypy.tree.graft(app_logged, '/')
        #cherrypy.log.access_log.propagate = False
        #cherrypy.log.screen = False

        server = config.rest.wsgi_server_name
        port = config.rest.wsgi_server_port

        # Set the configuration of the web server

        cherrypy.config.update({
            'environment': 'production',
            'log.screen': False,
            'server.socket_port': int(port),
            'server.socket_host': server
        })

        # Start the CherryPy WSGI web server
        cherrypy.engine.start()
        cherrypy.engine.block()
