""" Actor sink for all message bus events """
import datetime as dt
import logging
import json
import threading
from marshmallow import ValidationError
from common.config import config
from .. import MessageType
from ..model.poison_pill import PoisonPill
from ..model.event import Event
from ..model.control import Control
from ..model.checkpoint import Checkpoint
from ..journal import Journal


logging = logging.getLogger(__name__)


class WaitingThreadActor(threading.Thread):
    """ sink for all message bus events """

    def __init__(self, event_sink_actor, queue=None):
        super(WaitingThreadActor, self).__init__()
        self.event_sink_actor = event_sink_actor
        self.queue = queue
        self.daemon = True
        logging.info('Initialized actor thread')
        # self.shutdown_flag = threading.Event()

    # noinspection PyBroadException
    def run(self):
        while True:
            # ctrl + c is not being handled properly
            data = self.queue.get(block=True)

            if isinstance(data, PoisonPill):
                logging.info('Received PoisonPill. Stopping EventSinkActor')
                if config.journal.journal_enabled:
                    journal = Journal(config)
                    journal.add_checkpoint(Checkpoint(f'GRACEFUL.SHUTDOWN.{dt.datetime.utcnow():%Y%m%d%H%M%S}'))
                self.event_sink_actor.stop()
                break
            else:
                # noinspection PyPep8
                try:
                    msg = data.decode("utf-8")
                    if 'message_type' not in msg:
                        logging.warning('"message_type" key not found in message: %s', msg)
                        break
                    res = json.loads(msg)
                    if res['message_type'] == MessageType.event.name:
                        des_json = Event.des_json(data)
                        if len(des_json.errors) == 0:
                            self.event_sink_actor.tell({'type': MessageType.event, 'message': des_json.data})
                        else:
                            logging.warning('Deserialisation errors: %s', des_json.errors)
                    elif res['message_type'] == MessageType.journal.name:
                        self.event_sink_actor.tell({'type': MessageType.journal, 'message': ''})
                    elif res['message_type'] == MessageType.control.name:
                        des_json = Control.des_json(data)
                        if len(des_json.errors) == 0:
                            self.event_sink_actor.tell({'type': MessageType.control, 'message': des_json.data})
                        else:
                            logging.warning('Deserialisation errors: %s', des_json.errors)
                    else:
                        logging.warning('Unknown message type %s (full message: %s)', res['message_type'], data)
                except ValidationError as err:
                    logging.warning(err.messages)
                except Exception as ex:  # catch *all* exceptions
                    logging.exception('Could not deserialize message %s. Exception: %s', data, ex)

        logging.info('Sink thread exiting.')
