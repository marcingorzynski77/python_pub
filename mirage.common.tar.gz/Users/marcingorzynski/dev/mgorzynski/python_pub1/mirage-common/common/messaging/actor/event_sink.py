""" Actor sink for all message bus events """
import logging
import pykka
import datetime as dt
from typing import Dict, List
from common.config import config
from .. import MessageType
from ..journal import Journal
from ..producer import Producer
from ..model.event import Event


logging = logging.getLogger(__name__)


class EventSinkActor(pykka.ThreadingActor):
    """ handler for all global event messages on the service bus """

    def __init__(self, mq_producer: Producer):
        super(EventSinkActor, self).__init__()
        logging.info('Creating event sink actor')
        self.mq_producer = mq_producer
        self.service_name = config.service_name
        self.handlers = {MessageType.event: self.handler_event,
                         MessageType.journal: self.handler_journal}
        self.interesting_events: List[str] = []
        self.received_events: Dict[dt.date, Dict[str, Event]] = {}
        self.running_journal_events = False
        self.journal = None
        self.send_data_available_message = False

    def on_failure(self, exception_type, exception_value, traceback):
        logging.error('Error detected, exception _type: %s, exception_value: %s, traceback: %s',
                      exception_type, exception_value, traceback)

    def on_receive(self, message: {}):
        if message['type'] in self.handlers.keys():
            self.handlers[message['type']](message['message'])
        else:
            logging.info('Received unhandled message type: %s', message['type'])

    def handler_event(self, event: Event):
        self.add_event_to_received(event)

    def add_event_to_received(self, event: Event):
        if event.bus_date not in self.received_events:
            self.received_events[event.bus_date] = {}
        events = self.received_events[event.bus_date]
        events[event.event_name] = event

        if not self.running_journal_events and config.journal.journal_enabled:
            if self.journal is None:
                self.journal = Journal(config)
            self.journal.add_event(event)

    # noinspection PyUnusedLocal
    def handler_journal(self, message):
        if config.journal.journal_enabled:
            logging.info('Journal enabled.')
            self.running_journal_events = True
            self.journal = Journal(config)
            for event in self.journal.get_events():
                self.handler_event(event)
            self.running_journal_events = False

    # noinspection PyUnusedLocal
    def handler_stop(self, message):
        self.mq_producer.close_connection()
        self.stop()
