# noinspection PyPackageRequirements
import unittest2
import datetime as dt
import os
import uuid
from common.config import Configuration
from common.messaging import MessageType
from common.messaging.model.event import Event
from common.messaging.model.checkpoint import Checkpoint
from common.messaging.journal import Journal
from common.messaging.journal_db import JournalDb
from flask import Flask


class TestJournal(unittest2.TestCase):
    config: Configuration = Configuration()

    @classmethod
    def setUpClass(cls):
        if os.path.exists(cls.config.journal.get_journal_db_path()):
            os.remove(cls.config.journal.get_journal_db_path())
        app = Flask(__name__)
        JournalDb(cls.config.journal.get_journal_db_path()).reset_storage(app)

    @classmethod
    def tearDownClass(cls):
        if os.path.exists(cls.config.journal.get_journal_db_path()):
            os.remove(cls.config.journal.get_journal_db_path())

    def setUp(self):
        journal = Journal(self.config)
        journal.clear()

    def test_add_checkpoint(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_checkpoint(Checkpoint('TEST.JOURNAL.ADD.CHECKPOINT.1'))
        full = journal.get_journal()
        checkpoint = next((e for e in full if e.message_type == MessageType.checkpoint), None)
        self.assertIsNotNone(checkpoint)
        self.assertEqual('TEST.JOURNAL.ADD.CHECKPOINT.1', checkpoint.checkpoint_name)

    def test_add_event(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_event(Event('TEST.JOURNAL.ADD.EVENT.1', dt.date(2018, 9, 18), 'TEST', 'PAYLOAD TEST 1', None,
                                uuid.UUID('7a78834f-333e-48b9-8376-4722f388e3ba'),
                                uuid.UUID('a4178e4c-e9b1-4d93-b61d-504490f9737d')))
        journal.add_event(Event('TEST.JOURNAL.ADD.EVENT.2', dt.date(2018, 9, 19), 'TEST', 'PAYLOAD TEST 2', None,
                                uuid.UUID('0330c67c-127d-4b51-bd3d-3f8fae660fcd'),
                                uuid.UUID('ea64a247-9636-4c7f-9812-634567130a2e')))
        events = journal.get_events()
        event1 = next((e for e in events if e.event_name == 'TEST.JOURNAL.ADD.EVENT.1'), None)
        self.assertIsNotNone(event1)
        self.assertEqual(dt.date(2018, 9, 18), event1.bus_date)
        self.assertEqual('PAYLOAD TEST 1', event1.event_payload)
        self.assertEqual(uuid.UUID('7a78834f-333e-48b9-8376-4722f388e3ba'), event1.message_id)
        self.assertEqual(uuid.UUID('a4178e4c-e9b1-4d93-b61d-504490f9737d'), event1.correlated_message_id)
        event2 = next((e for e in events if e.event_name == 'TEST.JOURNAL.ADD.EVENT.2'), None)
        self.assertIsNotNone(event2)
        self.assertEqual(dt.date(2018, 9, 19), event2.bus_date)
        self.assertEqual('PAYLOAD TEST 2', event2.event_payload)
        self.assertEqual(uuid.UUID('0330c67c-127d-4b51-bd3d-3f8fae660fcd'), event2.message_id)
        self.assertEqual(uuid.UUID('ea64a247-9636-4c7f-9812-634567130a2e'), event2.correlated_message_id)

    def test_get_events_all(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.1', dt.date(2018, 9, 17), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.2', dt.date(2018, 9, 18), 'TEST'))
        journal.add_checkpoint(Checkpoint('TEST.JOURNAL.GET.CHECKPOINT.1'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.3', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.4', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.5', dt.date(2018, 9, 19), 'TEST'))
        journal.add_checkpoint(Checkpoint('TEST.JOURNAL.GET.CHECKPOINT.2'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.6', dt.date(2018, 9, 20), 'TEST'))
        events = journal.get_events_all()
        self.assertEqual(6, len(events))
        event1 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.1'), None)
        self.assertIsNotNone(event1)
        event6 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.6'), None)
        self.assertIsNotNone(event6)

    def test_get_events_since_last_checkpoint(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.1', dt.date(2018, 9, 17), 'TEST'))
        journal.add_event(Event('2TEST.JOURNAL.GET.EVENT.2', dt.date(2018, 9, 18), 'TEST'))
        journal.add_checkpoint(Checkpoint('TEST.JOURNAL.GET.CHECKPOINT.1'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.3', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.4', dt.date(2018, 9, 19), 'TEST'))
        journal.add_checkpoint(Checkpoint('TEST.JOURNAL.GET.CHECKPOINT.2'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.5', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.6', dt.date(2018, 9, 20), 'TEST'))
        events = journal.get_events_since_last_checkpoint()
        self.assertEqual(2, len(events))
        event5 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.5'), None)
        self.assertIsNotNone(event5)
        event6 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.6'), None)
        self.assertIsNotNone(event6)

    def test_get_events_by_bus_date(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.1', dt.date(2018, 9, 17), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.2', dt.date(2018, 9, 18), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.3', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.4', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.5', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.6', dt.date(2018, 9, 20), 'TEST'))
        events = journal.get_events_by_bus_date(dt.date(2018, 9, 19))
        self.assertEqual(3, len(events))
        event3 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.3'), None)
        self.assertIsNotNone(event3)
        event5 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.5'), None)
        self.assertIsNotNone(event5)

    def test_get_events_by_bus_date_and_pattern(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.1', dt.date(2018, 9, 17), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.2', dt.date(2018, 9, 18), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.3', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.4', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.5', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.6', dt.date(2018, 9, 20), 'TEST'))
        events = journal.get_events_by_bus_date_and_pattern(dt.date(2018, 9, 19),
                                                            'TEST.JOURNAL.GET.INTERESTING.EVENT', False)
        self.assertEqual(1, len(events))
        event4 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.INTERESTING.EVENT.4'), None)
        self.assertIsNotNone(event4)
        event6 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.EVENT.6'), None)
        self.assertIsNone(event6)

    def test_get_events_by_bus_date_and_pattern_latest(self):
        print(f'*** Running {self.id()} ***')
        journal = Journal(self.config)
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.1', dt.date(2018, 9, 17), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.2', dt.date(2018, 9, 18), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.EVENT.3', dt.date(2018, 9, 19), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.4', dt.date(2018, 9, 19), 'TEST',
                                'PAYLOAD TEST 4 A', None,
                                uuid.UUID('7a78834f-333e-48b9-8376-4722f388e3ba'),
                                uuid.UUID('a4178e4c-e9b1-4d93-b61d-504490f9737d')))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.4', dt.date(2018, 9, 19), 'TEST',
                                'PAYLOAD TEST 4 B', None,
                                uuid.UUID('7a78834f-333e-48b9-8376-4722f388e3ba'),
                                uuid.UUID('a4178e4c-e9b1-4d93-b61d-504490f9737d')))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.5', dt.date(2018, 9, 19), 'TEST',
                                'PAYLOAD TEST 5 A', None,
                                uuid.UUID('7a78834f-333e-48b9-8376-4722f388e3ba'),
                                uuid.UUID('a4178e4c-e9b1-4d93-b61d-504490f9737d')))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.5', dt.date(2018, 9, 19), 'TEST',
                                'PAYLOAD TEST 5 B', None,
                                uuid.UUID('7a78834f-333e-48b9-8376-4722f388e3ba'),
                                uuid.UUID('a4178e4c-e9b1-4d93-b61d-504490f9737d')))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.6', dt.date(2018, 9, 20), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.7', dt.date(2018, 9, 20), 'TEST'))
        journal.add_event(Event('TEST.JOURNAL.GET.INTERESTING.EVENT.8', dt.date(2018, 9, 20), 'TEST'))

        events = journal.get_events_by_bus_date_and_pattern(dt.date(2018, 9, 19),
                                                            'TEST.JOURNAL.GET.INTERESTING.EVENT', True)
        self.assertEqual(2, len(events))
        event4 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.INTERESTING.EVENT.4'), None)
        self.assertIsNotNone(event4)
        self.assertEqual('PAYLOAD TEST 4 B', event4.event_payload)
        event5 = next((e for e in events if e.event_name == 'TEST.JOURNAL.GET.INTERESTING.EVENT.5'), None)
        self.assertIsNotNone(event5)
        self.assertEqual('PAYLOAD TEST 5 B', event5.event_payload)

