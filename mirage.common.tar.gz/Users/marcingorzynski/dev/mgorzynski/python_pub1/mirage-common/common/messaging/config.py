""" configuration module"""
import os
from common.util.file_system import FileSystem


class RabbitMqConfiguration:
    """ class holding mq settings"""

    def __init__(self):
        """ class holding application settings"""
        # mq user details
        self.user: str = None
        # mq user details
        self.password: str = None
        # mq listening port
        self.port: int = 0
        # mq server
        self.server: str = None
        self.global_event_exchange: str = "MIRAGE.GLOBAL.EVENTS"
        # mq service queue which is build from service_name & service_type
        self.service_queue = None
        self.control_service_queue = "MIRAGE.SERVICE.CONTROL.INPUT"
        self.schedule_service_queue = "MRAP.SERVICE.SCHEDULE.INPUT"
        self.enabled = True

    def load(self, app_settings):
        """ load configuration from the provided collection"""
        if 'service_name' in app_settings \
                and 'service_type' in app_settings \
                and app_settings['service_name'] \
                and app_settings['service_type']:
            self.service_queue = "MIRAGE.{0}.{1}.INPUT".format(app_settings['service_type'].upper(),
                                                               app_settings['service_name'].upper().replace("-", "."))
        if 'mq_enabled' in app_settings:
            self.enabled = app_settings['mq_enabled']
        if 'mq_user' in app_settings:
            self.user = app_settings['mq_user']
        if 'mq_pass' in app_settings:
            self.password = app_settings['mq_pass']
        if 'mq_server' in app_settings:
            self.server = app_settings['mq_server']
        if 'mq_port' in app_settings:
            self.port = app_settings['mq_port']
        if 'control_service_queue' in app_settings:
            self.control_service_queue = app_settings['control_service_queue']
        if 'schedule_service_queue' in app_settings:
            self.schedule_service_queue = app_settings['schedule_service_queue']


class JournalConfiguration:
    """ class holding journal settings"""

    def __init__(self):
        # is journal enabled
        self.journal_enabled: bool = False
        # number of days to be kept in journal
        self.journal_days: int = None
        # should all events from journal be loaded
        # if False only events since last checkpoint are loaded
        self.journal_full_load: bool = False
        # journal storage path
        self.journal_path: str = None
        # journal db name
        self.journal_db_name: str = "local-service-journal.db"

    def load(self, app_settings):
        """ load configuration from the provided collection"""
        
        if 'journal_enabled' in app_settings:
            self.journal_enabled = app_settings['journal_enabled']
            if 'journal_days' in app_settings:
                self.journal_days = app_settings['journal_days']
            if 'journal_full_load' in app_settings:
                self.journal_full_load = app_settings['journal_full_load']
            if 'journal_path' in app_settings:
                self.journal_path = app_settings['journal_path']
            if 'journal_db_name' in app_settings:
                self.journal_db_name = app_settings['journal_db_name']

    def get_journal_db_path(self):
        current = os.getcwd()

        if self.journal_path is not None:
            current = self.journal_path

        storage_path = os.path.join(current, 'journal')
        FileSystem.ensure_dir(storage_path)
        return os.path.join(storage_path, self.journal_db_name)
