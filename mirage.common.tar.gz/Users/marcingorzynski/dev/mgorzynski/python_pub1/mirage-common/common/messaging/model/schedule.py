import datetime as dt
import uuid
from toastedmarshmallow import Jit
from marshmallow import Schema, fields, post_load
from common.util.marshmallow_enum import EnumField
from .. import MessageType
from .base_message import BaseMessage


class Schedule(BaseMessage):
    """ Message bus metric """

    def __init__(self,
                 bus_date: dt.date,
                 source: str = '',
                 job_name: str = '',
                 host: str = '',
                 parameters: {} = None,
                 time_created: dt.datetime = None,
                 message_id: uuid = None,
                 correlated_message_id: uuid = None,
                 run_id: uuid = None,
                 message_type: MessageType = MessageType.schedule):
        if message_id is None:
            message_id = uuid.uuid4()
        if time_created is None:
            time_created = dt.datetime.utcnow()
        super(Schedule, self).__init__(bus_date=bus_date,
                                       time_created=time_created,
                                       message_id=message_id,
                                       correlated_message_id=correlated_message_id,
                                       run_id=run_id,
                                       message_type=message_type,
                                       source=source,
                                       host=host)
        if parameters is None:
            parameters = {}
        self.job_name = job_name
        self.parameters = parameters
        self.schema = ScheduleSchema()
        self.schema.jit = Jit

    def __repr__(self):
        return f'<Schedule bus_date: "{self.bus_date: %Y-%m-%d}", source: "{self.source}", ' \
               f'job_name: "{self.job_name}", parameters: "{self.parameters}", ' \
               f'correlated_message_id: "{self.correlated_message_id}">'

    def __eq__(self, other):
        if self.bus_date == other.bus_date \
                and self.source == other.source \
                and self.job_name == other.job_name \
                and self.parameters == other.parameters \
                and self.correlated_message_id == other.correlated_message_id:
            return True
        else:
            return False

    def to_json(self):
        json_result = self.schema.dumps(self).data
        return json_result

    @staticmethod
    def des_json(data):
        schema = ScheduleSchema()
        schema.jit = Jit
        return schema.loads(data)


class ScheduleSchema(Schema):
    class Meta:
        jit = Jit

    time_created = fields.DateTime()
    message_id = fields.UUID()
    correlated_message_id = fields.UUID(required=False, allow_none=True)
    run_id = fields.UUID(required=False, allow_none=True)
    source = fields.Str()
    job_name = fields.Str()
    host = fields.Str()
    bus_date = fields.Date()
    parameters = fields.Dict()
    message_type = EnumField(MessageType)

    @post_load
    def make_schedule(self, data):
        return Schedule(**data)
