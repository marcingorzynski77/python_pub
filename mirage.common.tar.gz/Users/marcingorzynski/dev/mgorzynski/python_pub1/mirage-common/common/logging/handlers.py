import datetime as dt
import os
from logging import FileHandler
from common.util.file_system import FileSystem


class MirageFileHandler(FileHandler):

    def __init__(self, directory: str, file_name_pattern: str, mode: str = 'a', encoding: str = None, delay=False):
        FileSystem.ensure_dir(directory)
        formatted_file_name = dt.datetime.now().strftime(file_name_pattern)
        super().__init__(os.path.join(directory, formatted_file_name), mode, encoding, delay)
