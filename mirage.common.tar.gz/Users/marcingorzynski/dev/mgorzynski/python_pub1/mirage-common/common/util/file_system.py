""" all kind of utils """
import os
import errno
import time
import logging

logging = logging.getLogger(__name__)


class FileSystem:
    """ File system related operations"""

    @staticmethod
    def ensure_dir(directory):
        if not os.path.exists(directory):
            os.makedirs(directory)

    @staticmethod
    def ensure_dir_from_file(file_path):
        directory = os.path.dirname(file_path)
        if not os.path.exists(directory):
            os.makedirs(directory)

    @staticmethod
    def delete_files_older_than(file_path, days):
        logging.info("removing files older than %s from %s", days, file_path)
        now = time.time()
        cutoff = now - (days * 86400)

        files = os.listdir(file_path)
        for xfile in files:
            if os.path.isfile(file_path + xfile):
                t = os.stat(file_path + xfile)
                c = t.st_ctime

                # delete file if older than a week
                if c < cutoff:
                    file_to_remove = file_path + xfile
                    logging.info("removing file %s", file_to_remove)
                    try:
                        os.remove(file_to_remove)
                    except OSError as e:  # this would be "except OSError, e:" before Python 2.6
                        if e.errno != errno.ENOENT:  # errno.ENOENT = no such file or directory
                            logging.exception(e)
                        else:
                            logging.warning("no such file or directory: %s", file_path)

    @staticmethod
    def delete_file(file_to_remove):
        try:
            os.remove(file_to_remove)
        except OSError as e:
            if e.errno != errno.ENOENT:  # errno.ENOENT = no such file or directory
                logging.exception(e)
            else:
                logging.warning("no such file or directory: %s", file_to_remove)
