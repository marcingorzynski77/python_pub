import logging
import os
import json
import threading
import datetime as dt
import cherrypy
from typing import Generator
import toastedmarshmallow
from flask import Response, Blueprint, request
from flask_restplus import reqparse, fields, Api, Resource
from common.messaging.rabbitmq_api import MqCoordinator
from common.messaging.model.poison_pill import PoisonPill
from common.storage.sql_api import SqlApi
from common.config import config
from common.storage.sql_models import StoreSchema
from common.util.metric import stats

system_api = Api(version='1.0', title='System API',
                 description='System RestPlus powered API')

system_ns = system_api.namespace('api', description='Operations related to process')
blueprint_system = Blueprint('system', __name__, url_prefix='/system')
# noinspection PyTypeChecker
system_api.init_app(blueprint_system)
system_api.add_namespace(system_ns)

pagination_arguments = reqparse.RequestParser()
pagination_arguments.add_argument('page', type=int, required=False, default=1, help='Page number')
pagination_arguments.add_argument('bool', type=bool, required=False, default=1, help='Page number')
pagination_arguments.add_argument('per_page', type=int, required=False, choices=[2, 10, 20, 30, 40, 50],
                                  default=10, help='Results per page {error_msg}')

pagination = system_api.model('A page of results', {
    'page': fields.Integer(description='Number of this page of results'),
    'pages': fields.Integer(description='Total number of pages of results'),
    'per_page': fields.Integer(description='Number of items per page of results'),
    'total': fields.Integer(description='Total number of results'),
})


# noinspection PyUnresolvedReferences
@system_ns.route('/v1/command/<string:command>')
class Commands(Resource):
    # noinspection PyMethodMayBeStatic
    def get(self, command):
        command = command.lower()
        logging.info('Received command: %s', command)
        if 'stop' in command:
            logging.info('Executing command: %s', command)
            logging.info('Stopping application')
            MqCoordinator.global_queue.put(PoisonPill())
            MqCoordinator.consumer.close_connection()
            cherrypy.engine.stop()
            for t in threading.enumerate():
                logging.info('Live thread before exit %s', t.name)
            # sys.exit(0)
            # noinspection PyProtectedMember
            os._exit(0)
            logging.info('Exited')
            for t in threading.enumerate():
                logging.info("live threads after exit %s", t.name)
        else:
            logging.info('Unknown command: %s', command)


@system_ns.route('/v1/storage/json', defaults={'mime_type': 'application/json'})
@system_ns.route('/v1/storage/text', defaults={'mime_type': 'text/plain'})
class Storage(Resource):
    @system_api.expect(pagination_arguments, validate=True)
    def get(self, mime_type: str):
        """
        Returns list of storage records.
        """
        sql_api = SqlApi(config)
        schema = StoreSchema()
        schema.jit = toastedmarshmallow.Jit

        def generate():
            try:
                for row_item in sql_api.read_with_pagination():
                    if row_item is None:
                        continue
                    else:
                        # select the required fields

                        item = schema.dumps(row_item)
                        if item is not None:
                            yield item.data + '\n'

            except ValueError as e:
                yield json.dumps({'error': str(e)}) + '\n'
            except Exception as e:
                logging.exception(e)
                yield json.dumps({'error': str(e)}) + '\n'

        return Response(generate(), mimetype=mime_type)


class BasicCollection(Resource):
    def get(self, bus_date: dt.date, mime_type: str, verified_only: str):

        logging.info('Request: %s', request.full_path)
        stats.on_request()

        bus_date_parsed = None
        try:
            bus_date_parsed = dt.datetime.strptime(bus_date, '%Y-%m-%d').date()
        except ValueError:
            msg = f'Unable to parse business date: {bus_date}'
            logging.info(msg)
            return {'message': msg}, 500

        verified_only_parsed = None
        try:
            verified_only_parsed = bool(int(verified_only))
        except ValueError:
            msg = f'Unable to parse verification flag: {verified_only}. Accepted values : 0 (False), 1 (True)'
            logging.info(msg)
            return {'message': msg}, 500

        def generate():
            try:
                for item in self.iter_items(bus_date_parsed, verified_only_parsed):
                    yield item
            except ValueError as e:
                yield json.dumps({'error': str(e)}) + '\n'
            except Exception as e:
                logging.exception(e)
                yield json.dumps({'error': str(e)}) + '\n'

        res = Response(generate(), mimetype=mime_type)
        return res

    def iter_items(self, bus_date: dt.date, verified_only: bool) -> Generator:
        pass
