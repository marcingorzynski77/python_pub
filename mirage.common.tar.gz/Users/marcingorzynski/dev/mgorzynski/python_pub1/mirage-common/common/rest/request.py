""" rest helper functions """
import requests
import logging

logging = logging.getLogger(__name__)


class RequestService(object):

    # noinspection PyMethodMayBeStatic
    def read_from_service(self, endpoint: str):
        logging.info("connecting to %s", endpoint)
        res = requests.get(endpoint, stream=True)
        if res.status_code != 200:
            raise ValueError('GET {0}/{1}'.format(endpoint, res.status_code))

        for line in res.iter_lines(chunk_size=1024):
            if line:
                yield line

        res.close()

        # return res.iter_lines(chunk_size=1024)
