import unittest2
import datetime as dt
import os
from common.messaging.model.event import Event
from common.messaging.model.checkpoint import Checkpoint
from common.messaging.journal_db import JournalDb
from flask import Flask
from common.config import Configuration


class TestJournalDb(unittest2.TestCase):
    Config: Configuration = Configuration()
    db: JournalDb = None

    @classmethod
    def setUpClass(cls):
        if os.path.exists(cls.Config.journal.get_journal_db_path()):
            os.remove(cls.Config.journal.get_journal_db_path())
        app = Flask(__name__)
        JournalDb(cls.Config.journal.get_journal_db_path()).reset_storage(app)

    @classmethod
    def tearDownClass(cls):
        if os.path.exists(cls.Config.journal.get_journal_db_path()):
            os.remove(cls.Config.journal.get_journal_db_path())

    def setUp(self):
        self.db = JournalDb(self.Config.journal.get_journal_db_path())
        self.db.clear_journal()

    def test_insert_event(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_event(Event('TEST.EVENT.1', dt.date(2018, 9, 20), 'TEST'))
        journal = self.db.retrieve_journal()
        matches = [x for x in journal if x.event_name == 'TEST.EVENT.1']
        self.assertEqual(1, len(matches))

    def test_insert_checkpoint(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.1'))
        journal = self.db.retrieve_journal()
        matches = [x for x in journal if x.event_name == 'TEST.JOURNAL.CHECKPOINT.1']
        self.assertEqual(1, len(matches))

    def test_retrieve_events(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_event(Event('TEST.EVENT.RETRIEVE.1', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.RETRIEVE'))
        self.db.store_event(Event('TEST.EVENT.RETRIEVE.2', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.RETRIEVE.3', dt.date(2018, 9, 20), 'TEST'))
        events = self.db.retrieve_events()
        self.assertEqual(3, len(events))

    def test_retrieve_journal(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_event(Event('TEST.EVENT.JOURNAL.1', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.RETRIEVE.1'))
        self.db.store_event(Event('TEST.EVENT.JOURNAL.2', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.JOURNAL.3', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.RETRIEVE.2'))
        self.db.store_event(Event('TEST.EVENT.JOURNAL.4', dt.date(2018, 9, 20), 'TEST'))
        journal = self.db.retrieve_journal()
        self.assertEqual(6, len(journal))

    def test_retrieve_events_since_last_checkpoint(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_event(Event('TEST.EVENT.LAST.1', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.LAST'))
        self.db.store_event(Event('TEST.EVENT.LAST.2', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.LAST.3', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.LAST.4', dt.date(2018, 9, 20), 'TEST'))
        journal = self.db.retrieve_journal()
        self.assertEqual(5, len(journal))
        events = self.db.retrieve_events_since_last_checkpoint()
        self.assertEqual(3, len(events))

    def test_retrieve_events_since_checkpoint(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.HISTORY.1'))
        self.db.store_event(Event('TEST.EVENT.HISTORY.1', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.HISTORY.2', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.HISTORY.2'))
        self.db.store_event(Event('TEST.EVENT.HISTORY.3', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.HISTORY.3'))
        self.db.store_event(Event('TEST.EVENT.HISTORY.4', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.HISTORY.5', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.HISTORY.6', dt.date(2018, 9, 20), 'TEST'))
        journal = self.db.retrieve_journal()
        self.assertEqual(9, len(journal))
        events = self.db.retrieve_events_since_checkpoint('TEST.JOURNAL.CHECKPOINT.HISTORY.2')
        self.assertEqual(4, len(events))

    def test_delete_events_by_age(self):
        print(f'*** Running {self.id()} ***')
        self.db.store_checkpoint(Checkpoint('TEST.JOURNAL.CHECKPOINT.DELETE'))
        self.db.store_event(Event('TEST.EVENT.DELETE.1', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.DELETE.2', dt.date(2018, 9, 20), 'TEST'))
        self.db.store_event(Event('TEST.EVENT.DELETE.3', dt.date(2018, 9, 20), 'TEST'))
        journal = self.db.retrieve_journal()
        self.assertEqual(4, len(journal))
        self.db.remove_events_by_age(0)
        journal = self.db.retrieve_journal()
        self.assertEqual(0, len(journal))
