import os
import logging
from common.storage.file_api import FileApi
from common.cache.domain import DataDomainBase
from common.config import Configuration
from common.util.metric import stats, CacheMetricTimer
from ..model.event import Event
from ..model.control import Control
from ..producer import Producer
from .event_sink import EventSinkActor


logging = logging.getLogger(__name__)


class GatewayEventSinkActor(EventSinkActor):
    """ handler for all global event messages on the service bus """

    def __init__(self, mq_producer: Producer, config: Configuration, data_domain: DataDomainBase):
        super(GatewayEventSinkActor, self).__init__(mq_producer)
        self.success_event_message = None
        self.failure_event_message = None
        self.data_available_message = None
        self.file_row_count_message = None
        self.data_row_count_message = None
        self.ignored_event_message = None
        self.file_api = FileApi(config)
        self.config = config
        self.data_domain = data_domain

    # noinspection PyBroadException
    def handler_event(self, event: Event):

        if event.event_name not in self.interesting_events:
            logging.debug('Not interested in message: %s', event.event_name)
            stats.on_ignore_event()
            return

        self.set_success_failure_messages(event)

        if self.running_journal_events:
            logging.info('Processing mq message from journal: %s', event.event_name)
        else:
            logging.info('Received mq message: %s', event.event_name)
        logging.info('Business date event: %s', event.bus_date)

        stats.on_process_event()
        original_message_id = event.message_id

        try:
            logging.info('Calling source validation handler for: %s', event.event_payload)
            result, exception_msg = self.handler_source_validation(event)
            if not result:  # False: if validation unsuccessful
                logging.info('Skipping processing as data validation was not successful')
                self.mq_producer.send_event(Event(event_name=self.failure_event_message,
                                                  bus_date=event.bus_date,
                                                  event_payload=exception_msg,
                                                  correlated_message_id=original_message_id,
                                                  source=self.service_name))
                return

            logging.info('Calling duplication check handler for: %s', event.event_payload)
            result, exception_msg = self.handler_duplication_check(event)
            if result:  # True: it is a duplicate
                self.add_event_to_received(event)
                logging.info('Skipping processing as source was already received and loaded')
                self.mq_producer.send_event(Event(event_name=self.ignored_event_message,
                                                  bus_date=event.bus_date,
                                                  event_payload=exception_msg,
                                                  correlated_message_id=original_message_id,
                                                  source=self.service_name))
                return

            logging.info('Calling source validation handler for: %s', event.event_payload)
            result, exception_msg = self.handler_data_validation(event)
            if not result:  # False: if validation unsuccessful
                logging.info('Skipping processing as data validation was not successful')
                self.mq_producer.send_event(Event(event_name=self.failure_event_message,
                                                  bus_date=event.bus_date,
                                                  event_payload=exception_msg,
                                                  correlated_message_id=original_message_id,
                                                  source=self.service_name))
                return

            # only add event to collection if it is valid
            self.add_event_to_received(event)
            logging.debug('Calling data insert handler')
            self.handler_data_insert(event)
            logging.debug('Calling pre-processing handler')
            self.handler_pre_processing(event)
            logging.debug('Calling processing handler')
            self.handler_processing(event)
            if self.success_event_message is not None:
                logging.info('Sending global event: %s', self.success_event_message)
                self.mq_producer.send_event(Event(event_name=self.success_event_message,
                                                  bus_date=event.bus_date,
                                                  event_payload=event.event_payload,
                                                  correlated_message_id=original_message_id,
                                                  source=self.service_name))
            logging.debug('Calling post-processing handler')
            self.handler_post_processing(event)
            if self.send_data_available_message and self.data_available_message is not None:
                logging.info('Sending global event: %s', self.data_available_message)
                self.mq_producer.send_event(Event(event_name=self.data_available_message,
                                                  bus_date=event.bus_date,
                                                  source=self.service_name,
                                                  correlated_message_id=original_message_id))
                self.handler_data_available_control(event)
                self.send_data_available_message = False

        except Exception as ex:
            logging.exception('File %s could not be loaded.', event.event_payload)
            stats.on_error_event()

            if self.failure_event_message is not None:
                logging.info('Sending global event: %s', self.failure_event_message)
                self.mq_producer.send_event(Event(event_name=self.failure_event_message,
                                                  bus_date=event.bus_date,
                                                  event_payload=f"{type(ex).__name__}: {str(ex)}",
                                                  correlated_message_id=original_message_id,
                                                  source=self.service_name))
            return

    def handler_data_insert(self, event: Event):
        logging.debug('Executing handler data insert')
        file_path = event.event_payload
        logging.info('File path: %s', file_path)
        self.file_api.insert(file_path, event.bus_date, event.event_name)

    # standard processing for single source gateways
    def handler_processing(self, event: Event):
        if self.config.cache_enabled:
            logging.info("Cache enabled. Processing payload: %s", event.event_payload)
            timer = CacheMetricTimer(stats)
            # build cache and measure time
            timer.invoke(self.data_domain.build_cache, event.bus_date)

    # validation of a source - override in inherited classes if needed
    # noinspection PyMethodMayBeStatic
    def handler_source_validation(self, event: Event) -> (bool, str):
        file_path = event.event_payload
        if not os.path.exists(file_path):
            exception_msg = f'File {file_path} does not exist'
            logging.warning(exception_msg)
            return False, f'File {file_path} does not exist'
        return True, None

    # duplication check
    def handler_duplication_check(self, event: Event) -> (bool, str):

        file_path = event.event_payload
        logging.info('Checking if file was already loaded: %s', file_path)

        stored_file_info = self.file_api.get_meta_data(event.bus_date, event.event_name)
        if stored_file_info:
            if 'file_path' in stored_file_info:
                stored_file_path = stored_file_info['file_path']
                if stored_file_path != file_path:
                    return False, f'File {file_path} already received and the file had been loaded'

            if 'modified_at' in stored_file_info:
                stored_modified_at = stored_file_info['modified_at']
                modified_at = os.path.getmtime(file_path)
                if stored_modified_at != modified_at:
                    return False, None

            if 'size' in stored_file_info:
                stored_size = stored_file_info['size']
                size = os.path.getsize(file_path)
                if stored_size != size:
                    return False, None

            return True, f'File {file_path} has already been received and loaded'
        else:
            return False, None

    # standard validation of the file import - override in inherited classes if needed
    def handler_data_validation(self, event: Event) -> (bool, str):

        file_path = event.event_payload
        count, exception_msg = self.data_domain.try_parsing_all_records(file_path)
        if count is None:
            return False, exception_msg
        else:
            self.mq_producer.send_control(Control(bus_date=event.bus_date,
                                                  correlated_message_id=event.message_id,
                                                  category=self.file_row_count_message,
                                                  payload={'total': count},
                                                  source=self.config.service_name))
            return True, ""

    # noinspection PyMethodMayBeStatic
    def set_success_failure_messages(self, event: Event):
        if event.event_name in self.interesting_events:
            self.success_event_message = event.event_name.replace('AVAILABLE', 'LOADED')
            self.failure_event_message = event.event_name.replace('AVAILABLE', 'FAILURE')
            self.file_row_count_message = event.event_name.replace('AVAILABLE', 'ROW.COUNT')
            self.ignored_event_message = event.event_name.replace('AVAILABLE', 'IGNORED')
        else:
            self.success_event_message = None
            self.failure_event_message = None
            self.file_row_count_message = None

    # noinspection PyMethodMayBeStatic
    def handler_pre_processing(self, event: Event):
        pass

    # noinspection PyMethodMayBeStatic
    def handler_post_processing(self, event: Event):
        self.send_data_available_message = True

    # standard gateway data control handler
    def handler_data_available_control(self, event: Event):
        count = len(self.data_domain.get_data(event.bus_date))
        self.mq_producer.send_control(Control(bus_date=event.bus_date,
                                              correlated_message_id=event.message_id,
                                              category=self.data_row_count_message,
                                              payload={'total': count},
                                              source=self.config.service_name))

