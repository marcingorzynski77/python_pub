import datetime as dt
import pika
import time
import pika.exceptions
import logging
from common.config import config
from common.messaging.model.event import Event
from common.messaging.model.control import Control
from common.messaging.model.schedule import Schedule
from .rabbitmq_base import RabbitMqBase


class Producer(RabbitMqBase):
    """ Produces significant signal messages related to ecosystem overall status """

    def __init__(self):
        super(Producer, self).__init__()
        if config.rabbit_mq.control_service_queue is None:
            raise ValueError('RabbitMq Control Service Queue is not specified')

    def _declare_queues(self):
        self._channel.queue_declare(queue=config.rabbit_mq.control_service_queue, durable=True)

    def send_event(self, event: Event):
        logging.info('Sending global event message for %s %s %s', event.event_name, event.bus_date, event.event_payload)
        logging.info('Publishing message on exchange %s', config.rabbit_mq.global_event_exchange)
        logging.debug(f'JSON: {event.to_json()}')
        
        sleep_time = 1
        while sleep_time < self.MAX_SLEEP_TIME:
            try:
                self._connect()
                self._channel.basic_publish(exchange=config.rabbit_mq.global_event_exchange,
                                            routing_key="", body=event.to_json())
                break  # success
            except pika.exceptions.ConnectionClosed:
                logging.info("Connection closed by, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Do not recover on channel errors
            except pika.exceptions.AMQPChannelError as err:
                logging.error("Caught a channel error:  %s", err)
                break
            # Recover on all other connection errors
            except pika.exceptions.AMQPConnectionError:
                logging.info("Connection was closed, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Exception
            except Exception as ex:
                logging.exception("Exception: %s", ex)
                break

    def create_and_send_event(self, event_name: str, bus_date: dt.date, source: str = ""):
        event = Event(event_name, bus_date, source=source)
        self.send_event(event)

    def send_control(self, control: Control):
        logging.info('Sending control message for %s %s %s', control.category, control.bus_date, control.payload)
        logging.info('Publishing message on control queue %s', config.rabbit_mq.control_service_queue)
        logging.debug(f'JSON: {control.to_json()}')

        sleep_time = 1
        while sleep_time < self.MAX_SLEEP_TIME:
            try:
                self._connect()
                self._channel.basic_publish(exchange="", routing_key=config.rabbit_mq.control_service_queue,
                                            body=control.to_json())
                break  # success
            except pika.exceptions.ConnectionClosed:
                logging.info("Connection closed by, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Do not recover on channel errors
            except pika.exceptions.AMQPChannelError as err:
                logging.error("Caught a channel error: {0}".format(err))
                break
            # Recover on all other connection errors
            except pika.exceptions.AMQPConnectionError:
                logging.info("Connection was closed, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Exception
            except Exception as ex:
                logging.exception("Exception: %s", ex)
                break

    def send_schedule(self, schedule: Schedule):
        logging.info('Sending schedule message [%s] for %s with %s',
                     schedule.job_name, schedule.bus_date, schedule.parameters)
        logging.info('Publishing message on schedule queue %s', config.rabbit_mq.schedule_service_queue)
        logging.debug(f'JSON: {schedule.to_json()}')

        sleep_time = 1
        while sleep_time < self.MAX_SLEEP_TIME:
            try:
                self._connect()
                self._channel.basic_publish(exchange="", routing_key=config.rabbit_mq.schedule_service_queue,
                                            body=schedule.to_json())
                break  # success
            except pika.exceptions.ConnectionClosed:
                logging.info("Connection closed by, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Do not recover on channel errors
            except pika.exceptions.AMQPChannelError as err:
                logging.error("Caught a channel error: {0}".format(err))
                break
            # Recover on all other connection errors
            except pika.exceptions.AMQPConnectionError:
                logging.info("Connection was closed, retrying...")
                time.sleep(sleep_time)
                sleep_time *= 2  # increase sleep time
                continue
            # Exception
            except Exception as ex:
                logging.exception("Exception: %s", ex)
                break

