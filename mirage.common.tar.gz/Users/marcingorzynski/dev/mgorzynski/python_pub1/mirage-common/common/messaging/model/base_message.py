import datetime as dt
import uuid
import socket
from .. import MessageType


class BaseMessage:
    """ Base class for remote messaging """

    def __init__(self,
                 bus_date: dt.date = None,
                 time_created: dt.datetime = dt.datetime.utcnow(),
                 message_id: uuid = uuid.uuid4(),
                 correlated_message_id: uuid = None,
                 run_id: uuid = None,
                 message_type: MessageType = MessageType.unknown,
                 source: str = "",
                 host: str = socket.gethostname()):
        self.time_created: dt.datetime = time_created
        self.message_id: uuid = message_id
        self.correlated_message_id: uuid = correlated_message_id
        self.run_id: uuid = run_id
        self.message_type: MessageType = message_type
        self.bus_date: dt.date = bus_date
        self.source: str = source
        self.host: str = host

