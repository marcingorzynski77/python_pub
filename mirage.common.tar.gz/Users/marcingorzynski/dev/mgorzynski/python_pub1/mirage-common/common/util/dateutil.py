import datetime as dt
from dateutil import tz

from_zone = tz.gettz('UTC')
to_zone = tz.gettz('Europe/London')


def local_from_utc(utc_datetime: dt.datetime) -> dt.datetime:
    utc_datetime.replace(tzinfo = from_zone)
    return utc_datetime.astimezone(to_zone)