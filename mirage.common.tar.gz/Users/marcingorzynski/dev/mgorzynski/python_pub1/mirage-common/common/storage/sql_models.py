""" storage models"""
import datetime as dt
import logging
import uuid
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import sessionmaker
import toastedmarshmallow
from marshmallow import Schema, fields
from ..util.sqlalchemy_json_dictionary import JsonDictionary

db = SQLAlchemy()
logging = logging.getLogger(__name__)


class SqlWrapper:
    def __init__(self, internal_storage):
        self.database_uri = "sqlite:///{0}".format(internal_storage)

    def reset_storage(self, app):
        logging.info('Resetting sql storage: %s', self.database_uri)
        app.config['SQLALCHEMY_DATABASE_URI'] = self.database_uri
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        db.init_app(app)
        db.app = app
        db.drop_all()
        db.create_all()

    def create_engine(self):
        engine = db.create_engine(self.database_uri, pool_recycle=3600, connect_args={'check_same_thread': False})
        return engine

    def create_session(self):
        db_session = sessionmaker(bind=self.create_engine())
        session = db_session()

        # A db_session() instance establishes all conversations with the database
        # and represents a "staging zone" for all the objects loaded into the
        # database session object. Any change made against the objects in the
        # session won't be persisted into the database until you call
        # session.commit(). If you're not happy about the changes, you can
        # revert all of them back to the last commit by calling
        # session.rollback()

        return session

    def read_with_pagination(self):
        session = self.create_session()
        records = session.query(Store).order_by(Store.business_date.desc()).all()
        session.close()
        return records

    def query(self, bus_date: dt.date, load_trigger: str = None, correlation_id: uuid = None, latest: bool = True):
        session = self.create_session()
        query = session.query(Store) \
            .filter(Store.business_date == bus_date)

        if load_trigger is not None:
            query = query.filter(Store.load_trigger == load_trigger)

        if correlation_id is not None:
            query = query.filter(Store.correlation_id == str(correlation_id))

        if latest:
            record = query.order_by(Store.id.desc()).first()
            if record is None:
                records = []
            else:
                records = [record]
        else:
            records = query.order_by(Store.id).all()

        session.close()
        return records
    
    def query_by_date_trigger(self, bus_date: dt.date, load_trigger: str):
        session = self.create_session()
        records = session.query(Store) \
            .filter(Store.business_date == bus_date) \
            .filter(Store.load_trigger == load_trigger) \
            .order_by(Store.id) \
            .all()
        session.close()
        return records

    def query_by_date(self, bus_date: dt.date):
        session = self.create_session()
        records = session.query(Store) \
            .filter(Store.business_date == bus_date) \
            .order_by(Store.id) \
            .all()
        session.close()
        return records

    def read_all(self):
        session = self.create_session()
        records = session.query(Store).all()
        session.close()
        return records

    """Get records for the removal, so the attached files stored on a disk can be deleted at the same time"""
    def get_records_to_be_removed(self, number_of_days_to_keep: int):
        #  engine = self.create_engine()
        #  result = engine.execute('SELECT DISTINCT business_date FROM Store ORDER BY business_date DESC Limit 1')
        session = self.create_session()
        result = session.query(Store.business_date).distinct.order_by(Store.business_date.desc()).first()

        if result is not None:
            for row in result:
                date_from_row = row[0]
                date = dt.datetime.strptime(date_from_row, '%Y-%m-%d')
                session = self.create_session()
                end = date - dt.timedelta(days=number_of_days_to_keep)
                records = session.query(Store) \
                    .filter(Store.business_date < end).all()
                session.close()
                return records
        return None

    def query_by_source_trigger(self, data_source: str, load_trigger: str):
        session = self.create_session()
        record = session.query(Store) \
            .filter(Store.data_source == data_source) \
            .filter(Store.load_trigger == load_trigger) \
            .order_by(Store.id) \
            .all()
        session.close()
        return record

    def query_by_trigger(self, load_trigger: str):
        session = self.create_session()
        record = session.query(Store) \
            .filter(Store.load_trigger == load_trigger) \
            .order_by(Store.id) \
            .all()
        session.close()
        return record

    def query_by_source(self, data_source: str):
        session = self.create_session()
        record = session.query(Store) \
            .filter(Store.data_source == data_source) \
            .order_by(Store.id) \
            .all()
        session.close()
        return record

    def update(self, store):
        session = self.create_session()
        item = session.query(Store).filter(Store.id == store.id).first()
        item.location = store.location
        session.flush()
        session.commit()
        session.close()

    def insert(self, store):
        session = self.create_session()
        session.add(store)
        session.commit()
        session.close()

    def delete(self, row_id):
        session = self.create_session()
        session.query(Store).filter(Store.id == row_id).delete()
        session.commit()
        session.close()

    def clear(self):
        session = self.create_session()
        session.query(Store).delete()
        session.commit()
        session.close()


class Store(db.Model):
    """ storage definition , could be file , db or something else, it is a pointer to actual data"""
    id = db.Column(db.Integer, primary_key=True)
    data_source = db.Column(db.String(100))  # example : Murex, Summit etc
    # in case of file storage this will be a file name,
    # in case of elastic that will be index details
    location = db.Column(db.Text)
    correlation_id = db.Column(db.Text)
    storage_type = db.Column(db.String(100))  # file , elastic
    business_date = db.Column(db.Date)  # business date payload is valid for
    load_trigger = db.Column(db.Text)  # load trigger to differ files
    tags = db.Column(JsonDictionary)  # additional tags than describe what is in the payload

    def __init__(self,
                 data_source: str,
                 location: str,
                 storage_type: str,
                 bus_date: dt.date = None,
                 load_trigger: str = '',
                 tags: {} = None,
                 correlation_id: str = ''):
        self.data_source = data_source
        self.location = location
        self.business_date = bus_date
        self.storage_type = storage_type
        self.load_trigger = load_trigger
        self.tags = tags
        self.correlation_id = correlation_id

    def __repr__(self):
        return "StoreModel(%s, %s, %s, %s)" % (self.data_source, self.location, self.business_date, self.storage_type)


class StoreSchema(Schema):
    class Meta:
        jit = toastedmarshmallow.Jit
    """ trade schema used for serialization"""
    id = fields.Int()
    data_source = fields.Str(allow_none=True)
    location = fields.Str(allow_none=True)
    correlation_id = fields.UUID(allow_none=True)
    storage_type = fields.Str(allow_none=True)
    business_date = fields.Str(allow_none=True)
    load_trigger = fields.Str(allow_none=True)
    tags = fields.Str(allow_none=True)

