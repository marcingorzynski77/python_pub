""" Logging set up module """
import logging.config
import os
import yaml
# noinspection PyPep8
import common.logging.handlers  # don't remove if you want to use MirageFilehandler (created from logging.yml) !!!
from common.util.file_system import FileSystem


class LogSetup:
    """ Logging set up module """

    def __init__(self):
        pass

    @staticmethod
    def setup(log_config_file=None):
        # check if file exists
        if log_config_file is None or not os.path.exists(log_config_file):
            log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            log_formatter = logging.Formatter(log_format)

            FileSystem.ensure_dir(os.path.join('logs', ''))
            root_logger = logging.getLogger()
            root_logger.setLevel(logging.DEBUG)

            file_handler = logging.FileHandler(os.path.join('logs', 'logfile.txt'))
            file_handler.setFormatter(log_formatter)
            logging.root.addHandler(file_handler)

            console_handler = logging.StreamHandler()
            console_handler.setFormatter(log_formatter)
            logging.root.addHandler(console_handler)
            logging.root.setLevel(logging.DEBUG)

            logging.info("Setting up default logging configuration")
        else:
            with open(log_config_file) as file:
                dictionary = yaml.load(file)
                dictionary.setdefault('version', 1)
                logging.config.dictConfig(dictionary)
                # this is a hacky way to stop pikka library logging exception 
                # because we are handling them and log our own exceptions
                logging.getLogger("pika.adapters.blocking_connection").setLevel(logging.CRITICAL)
                logging.getLogger("pika.adapters.base_connection").setLevel(logging.CRITICAL)

            logging.info("Setting up logging configuration from supplied file %s", log_config_file)
