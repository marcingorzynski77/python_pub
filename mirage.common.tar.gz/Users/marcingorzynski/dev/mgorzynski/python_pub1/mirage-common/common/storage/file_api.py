""" File storage API """
import datetime as dt
import os
import logging
from typing import Generator
import gzip
from common.storage.sql_models import SqlWrapper, Store
from common.storage.payload_readers import CsvPayloadReader
from common.storage.config import StorageType
from common.util.file_system import FileSystem
from common.config import Configuration

logging = logging.getLogger(__name__)


# noinspection SpellCheckingInspection
class FileApi(object):
    """ Define access methods to internal storage"""

    def __init__(self, config: Configuration, delimiter=','):
        self.storage_type = StorageType.file
        self.delimiter = delimiter
        self.config = config

    def read_first_record(self, location) -> str:
        reader = CsvPayloadReader(self.delimiter)

        if os.path.exists(location):
            for row in reader.read(location):
                return row
        else:
            msg = f'File not found: {location}'
            logging.exception(msg)
            raise ValueError(msg)

    def read_all_records(self, location, skip_n_lines=0, skip_footer=False) -> Generator:
        reader = CsvPayloadReader(self.delimiter)
        path, filename = os.path.split(location)
        no_ext = filename.split('.')[0]
        if os.path.exists(location):
            for row in reader.read(location, skip_n_lines, skip_footer):
                row.original_source = no_ext
                yield row
        else:
            msg = f'File not found: {location}'
            logging.exception(msg)
            raise ValueError(msg)

    def clean_old_data(self, number_of_days_to_keep) -> None:
        if self.storage_type == StorageType.file and self.config.storage.archive_enabled is True:
            sql = SqlWrapper(self.config.storage.get_internal_storage_path())

            records_ro_be_removed = sql.get_records_to_be_removed(number_of_days_to_keep)
            if records_ro_be_removed is None:
                pass
            else:
                if self.config.storage.file_storage_root_path is None:
                    raise ValueError("FILE_STORAGE_ROOT_PATH is not set")
                for data in records_ro_be_removed:
                    file = os.path.join(self.config.storage.file_storage_root_path,
                                        data.business_date.strftime('%Y%m%d'), data.location)
                    FileSystem.delete_file(file)
                    sql.delete(data.id)
        else:
            raise ValueError("Not implemented")

    def read(self, bus_date: dt.date) -> Generator:
        if self.storage_type == StorageType.file:
            sql = SqlWrapper(self.config.storage.get_internal_storage_path())
            reader = CsvPayloadReader(self.delimiter)
            data = sql.query_by_date(bus_date)
            if data is None:
                logging.warning('Unable to locate any data for business date %s', bus_date)
                raise ValueError('Unable to locate any data')
            else:
                if self.config.storage.file_storage_root_path is None:
                    raise ValueError('FILE_STORAGE_ROOT_PATH is not set')

                item = data[0]

                file = item.location
                if self.config.storage.archive_enabled:
                    file = os.path.join(self.config.storage.file_storage_root_path,
                                        bus_date.strftime('%Y%m%d'), item.location)

                no_ext = item.location.split('.')[0]
                for row in reader.read(file):
                    row.original_source = no_ext
                    yield row
        else:
            raise ValueError('Not implemented')

    def read_many(self, bus_date: dt.date, skip_n_lines=0, skip_footer=False) -> Generator:
        if self.storage_type == StorageType.file:
            sql = SqlWrapper(self.config.storage.get_internal_storage_path())
            reader = CsvPayloadReader(self.delimiter)
            data = sql.query_by_date(bus_date)
            if data is None:
                logging.warning('Unable to locate any data for business date %s', bus_date)
                raise ValueError('Unable to locate any data')
            else:
                if self.config.storage.file_storage_root_path is None:
                    raise ValueError('FILE_STORAGE_ROOT_PATH is not set')

            for file_record in data:
                file = file_record.location
                if self.config.storage.archive_enabled:
                    file = os.path.join(self.config.storage.file_storage_root_path,
                                        bus_date.strftime('%Y%m%d'), file_record.location)

                no_ext = file_record.location.split('.')[0]

                if skip_footer:
                    if file.endswith("gz"):
                        with gzip.open(file) as file_:
                            row_count = sum(1 for line in file_) - skip_n_lines - 1
                    else:
                        with open(file) as file_:
                            row_count = sum(1 for line in file_) - skip_n_lines - 1
                    counter = 0
                    for row in reader.read(file, skip_n_lines):
                        counter = counter + 1
                        if counter == row_count:
                            continue
                        row.original_source = no_ext
                        yield row
                else:
                    for row in reader.read(file):
                        row.original_source = no_ext
                        yield row
        else:
            raise ValueError('Not implemented')

    def insert(self, file: str, bus_date: dt.date, event_name: str) -> None:
        if self.config.storage.data_source is None:
            raise ValueError('DATA_SOURCE is not set')

        file_path = file
        modified_at = os.path.getmtime(file_path)
        size = os.path.getsize(file_path)
        tags = {"file_path": file_path, "modified_at": modified_at, "size": size}

        if self.config.storage.archive_enabled:
            file_path = os.path.join(self.config.storage.file_storage_root_path,
                                     bus_date.strftime('%Y%m%d'), file)

        sql = SqlWrapper(self.config.storage.get_internal_storage_path())
        data = sql.query_by_date_trigger(bus_date, event_name)
        path, filename = os.path.split(file_path)

        zipped_file_name = file_path

        if self.config.storage.archive_enabled:
            zipped_file_name = os.path.basename(filename) + '.gz'

        if len(data) == 0:
            logging.debug('Inserting to local storage')

            if self.config.storage.archive_enabled:
                self.__archive(file, zipped_file_name, bus_date)

            store = Store(data_source=self.config.storage.data_source,
                          location=zipped_file_name,
                          storage_type=self.storage_type.name,
                          bus_date=bus_date,
                          load_trigger=event_name,
                          tags=tags)
            sql.insert(store)
        else:
            item = data[0]
            logging.debug('Updating local storage')

            if self.config.storage.archive_enabled:
                self.__archive(file, zipped_file_name, bus_date)

            item.location = zipped_file_name
            sql.update(item)

    def __archive(self, original_file, zipped_file_name, bus_date: dt.date):
        try:
            dest = os.path.join(self.config.storage.file_storage_root_path,
                                bus_date.strftime('%Y%m%d'), zipped_file_name)

            path, filename = os.path.split(dest)

            if not os.path.exists(path):
                logging.info('Creating : %s', path)
                os.mkdir(path)

            if os.path.exists(dest):
                logging.info('Removing archive file: %s', dest)
                os.remove(dest)

            logging.info('Compressing file: %s to %s', original_file, dest)

            with open(original_file) as f_in, gzip.open(dest, 'wt') as f_out:
                f_out.writelines(f_in)

        except IOError as e:
            logging.error('error: %s' % e.strerror)

    def get_meta_data(self, bus_date: dt.date, event_name: str) -> {}:
        if self.config.storage.data_source is None:
            raise ValueError('DATA_SOURCE is not set')

        sql = SqlWrapper(self.config.storage.get_internal_storage_path())
        data = sql.query_by_date_trigger(bus_date, event_name)

        if len(data) == 0:
            return {}
        else:
            return data[0].tags
