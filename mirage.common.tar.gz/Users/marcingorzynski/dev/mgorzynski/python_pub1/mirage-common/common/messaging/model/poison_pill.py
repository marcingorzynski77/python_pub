
class PoisonPill:
    """ This message will cause actor to stop """

    def __init__(self):
        pass
