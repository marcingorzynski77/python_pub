import datetime as dt
import uuid
from .. import MessageType
from .base_message import BaseMessage


class Checkpoint(BaseMessage):
    """ Checkpoint """

    def __init__(self,
                 checkpoint_name: str,
                 time_created: dt.datetime = None,
                 message_type: MessageType = MessageType.checkpoint):
        message_id = uuid.uuid4()
        if time_created is None:
            time_created = dt.datetime.utcnow()
        super(Checkpoint, self).__init__(time_created=time_created,
                                         message_id=message_id,
                                         message_type=message_type)
        self.checkpoint_name = checkpoint_name

    def __repr__(self):
        return "<Checkpoint name: %s>" % self.checkpoint_name
