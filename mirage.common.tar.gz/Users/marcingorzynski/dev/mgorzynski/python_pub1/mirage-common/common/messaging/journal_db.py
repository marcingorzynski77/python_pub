""" storage models"""
import datetime as dt
import logging
import uuid
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from sqlalchemy.orm import sessionmaker, aliased
from common.util.sqlalchemy_guid import GUID
from . import MessageType
from .model.event import Event
from .model.checkpoint import Checkpoint
from .model.journal import Journal

db = SQLAlchemy()
logging = logging.getLogger(__name__)


class Journal(db.Model):
    """ Table for events and checkpoints"""
    id = db.Column(db.Integer, primary_key=True)
    time_created = db.Column(db.DateTime, nullable=False)
    message_type = db.Column(db.Text, nullable=False)
    source = db.Column(db.Text, nullable=False)
    host = db.Column(db.Text, nullable=False)
    event_name = db.Column(db.Text, nullable=False)
    bus_date = db.Column(db.Date, nullable=True)  # business date
    message_id = db.Column(GUID, nullable=True)
    correlated_message_id = db.Column(GUID, nullable=True)
    run_id = db.Column(GUID, nullable=True)
    event_payload = db.Column(db.Text, nullable=True)

    def __init__(self, time_created: dt.datetime, message_type: str, event_name: str, bus_date: dt.date = None,
                 source: str = "", host: str = "", message_id: uuid = None, correlated_message_id: uuid = None,
                 event_payload: str = None, run_id: uuid = None):
        self.time_created = time_created
        self.message_type = message_type
        self.event_name = event_name
        self.source = source
        self.host = host
        if bus_date is not None:
            self.bus_date = bus_date
        if message_id is not None:
            self.message_id = message_id
        if correlated_message_id is not None:
            self.correlated_message_id = correlated_message_id
        if event_payload is not None:
            self.event_payload = event_payload
        if run_id is not None:
            self.run_id = run_id

    def __repr__(self):
        return 'Journal (%s, %s, %s, %s)' % (self.bus_date, self.message_id, self.event_name, self.message_type)


class JournalDb:
    def __init__(self, db_path):
        self.database_uri = f'sqlite:///{db_path}'
        self.__create_engine()

    def __create_engine(self):
        engine = db.create_engine(self.database_uri, pool_recycle=3600, connect_args={'check_same_thread': False})
        return engine

    def __create_session(self):
        db_session = sessionmaker(bind=self.__create_engine())
        session = db_session()
        return session

    def reset_storage(self, app):
        logging.info(f'Resetting journal db: {self.database_uri}')
        app.config['SQLALCHEMY_DATABASE_URI'] = self.database_uri
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        db.init_app(app)
        db.app = app
        db.drop_all()
        db.create_all()

    def store_event(self, event: Event):
        session = self.__create_session()
        session.add(Journal(event.time_created, event.message_type.name, event.event_name, event.bus_date, event.source,
                            event.host, event.message_id, event.correlated_message_id, event.event_payload,
                            event.run_id))
        session.commit()
        session.close()

    def store_checkpoint(self, checkpoint: Checkpoint):
        session = self.__create_session()
        session.add(Journal(checkpoint.time_created, checkpoint.message_type.name, checkpoint.checkpoint_name))
        session.commit()
        session.close()

    def retrieve_journal(self) -> []:
        session = self.__create_session()
        events = session.query(Journal)\
            .order_by(Journal.time_created)\
            .all()
        session.close()
        return events

    def retrieve_events(self) -> [Event]:
        session = self.__create_session()
        events = session.query(Journal)\
            .filter(Journal.message_type == MessageType.event.name)\
            .order_by(Journal.time_created)\
            .all()
        session.close()
        return events

    def retrieve_events_by_bus_date(self, bus_date: dt.date) -> [Event]:
        session = self.__create_session()
        events = session.query(Journal)\
            .filter(Journal.message_type == MessageType.event.name, Journal.bus_date == bus_date)\
            .order_by(Journal.time_created)\
            .all()
        session.close()
        return events

    def retrieve_events_by_bus_date_and_pattern(self, bus_date: dt.date, pattern: str) -> [Event]:
        session = self.__create_session()
        events = session.query(Journal)\
            .filter(Journal.message_type == MessageType.event.name, Journal.bus_date == bus_date)\
            .filter(Journal.event_name.contains(pattern, autoescape=True))\
            .order_by(Journal.time_created)\
            .all()
        session.close()
        return events

    def retrieve_events_by_bus_date_and_pattern_latest(self, bus_date: dt.date, pattern: str) -> [Event]:
        # TODO at the moment the built-in sqlite driver does not support partitions over
        return None
        session = self.__create_session()
        subquery = session.query(Journal, 
                                 func.row_number().over(partition_by=Journal.message_type, 
                                                        order_by=Journal.time_created.desc())) \
            .filter(Journal.message_type == MessageType.event.name, Journal.bus_date == bus_date) \
            .filter(Journal.event_name.contains(pattern, autoescape=True)) \
            .subquery()
        events = session.query(aliased(Journal, subquery).filter(subquery.c.n <= 1))
        session.close()
        return events

    def retrieve_events_since_checkpoint(self, checkpoint_name: str):
        session = self.__create_session()
        checkpoint = session.query(Journal) \
            .filter(Journal.message_type == MessageType.checkpoint.name, Journal.event_name == checkpoint_name) \
            .order_by(Journal.time_created) \
            .first()
        if checkpoint is None:
            events = session.query(Journal) \
                .filter(Journal.message_type == MessageType.event.name) \
                .order_by(Journal.time_created) \
                .all()
        else:
            events = session.query(Journal) \
                .filter(Journal.message_type == MessageType.event.name,
                        Journal.time_created > checkpoint.time_created) \
                .order_by(Journal.time_created) \
                .all()
        session.close()
        return events

    def retrieve_events_since_last_checkpoint(self):
        session = self.__create_session()
        checkpoint = session.query(Journal) \
            .filter(Journal.message_type == MessageType.checkpoint.name) \
            .order_by(Journal.time_created.desc()) \
            .first()
        if checkpoint is None:
            events = session.query(Journal) \
                .filter(Journal.message_type == MessageType.event.name) \
                .order_by(Journal.time_created) \
                .all()
        else:
            events = session.query(Journal) \
                .filter(Journal.message_type == MessageType.event.name, Journal.time_created > checkpoint.time_created)\
                .order_by(Journal.time_created) \
                .all()
        session.close()
        return events

    def remove_events_by_age(self, number_of_days_to_keep: int):
        session = self.__create_session()
        end = dt.datetime.now() - dt.timedelta(days=number_of_days_to_keep)
        logging.info('Removing events from journal older than %s', end)
        session.query(Journal) \
            .filter(Journal.time_created < end)\
            .delete()
        session.commit()
        session.close()

    def clear_journal(self):
        session = self.__create_session()
        logging.info('Removing all entries from journal')
        session.query(Journal) \
            .delete()
        session.commit()
        session.close()

