""" responsible for domain"""

import logging
import datetime as dt
import json
from abc import abstractmethod, ABCMeta
from typing import Dict
from typing import List, Generator
import threading
from marshmallow import Schema
from common.config import Configuration
from common.util.metric import MetricCollector
from common.model.trade.trade import Deal, ProductType
from common.storage.file_api import FileApi
from common.rest.request import RequestService


logging = logging.getLogger(__name__)


class DataCache:

    def __init__(self):
        self.cache: Dict[str, List[Deal]] = {}

    def has_data(self, key):
        return key in self.cache

    def insert_data(self, key, trades: List[Deal]):
        self.cache[key] = trades

    def get_data(self, key) -> List[Deal]:
        if key in self.cache:
            return self.cache[key]
        else:
            return []

    def delete(self, key):
        del self.cache[key]

class ProductPartitionDataCache(DataCache):

    def has_data(self, key: dt.date):
        for cache_item_key in self.cache.keys():
            if cache_item_key.startswith(str(key)):
                return True
        return False

    def insert_data(self, key, trades: List[Deal]):
        for trade in trades:
            cache_key = ProductPartitionDataCache.build_cache_key(key, trade.product_type)
            if cache_key not in self.cache:
                self.cache[cache_key] = []

            self.cache[cache_key].append(trade)

    def get_data(self, key) -> List[Deal]:
        items = []
        for cache_item_key in self.cache.keys():
            if cache_item_key.startswith(str(key)):
                for item in self.cache[cache_item_key]:
                    items.append(item)

        return items

    def delete(self, key: dt.date):
        for cache_item_key in list(self.cache.keys()):
            if cache_item_key.startswith(str(key)):
                del self.cache[cache_item_key]

    @staticmethod
    def build_cache_key(key: str, product_type: ProductType) -> str:
        cache_key = f'{str(key)}-{product_type}.'
        return cache_key


class DataDomainBase(metaclass=ABCMeta):
    def __init__(self, config: Configuration, stats: MetricCollector, schema: Schema, cache: DataCache = None):
        self.config: Configuration = config
        self.stats: MetricCollector = stats
        self.cache: DataCache = cache
        if cache is None:
            self.cache = DataCache()
        self.schema: Schema = schema

    @abstractmethod
    def get_data(self, bus_date: dt.date, key: str = None) -> List[object]:
        pass

    @abstractmethod
    def get_data_by_partition_key(self, bus_date: dt.date, key: str = None) -> List[object]:
        pass

    @abstractmethod
    def build_cache(self, bus_date: dt.date, key: str = None) -> int:
        pass

    @abstractmethod
    def parse_record(self, row_item: dict) -> [(object, str)]:
        pass

    @abstractmethod
    def try_parsing_record(self, row_item: str) -> (bool, str):
        pass

    @abstractmethod
    def try_parsing_all_records(self, source: str) -> (int, str):
        pass

    def is_cache_enabled(self) -> bool:
        return self.config.cache_enabled


class DataDomainFileBase(DataDomainBase):
    # storage for the instance reference

    def __init__(self, file_api: FileApi, config: Configuration, stats: MetricCollector, schema: Schema = None,
                 cache: DataCache = DataCache()):
        super(DataDomainFileBase, self).__init__(config=config, stats=stats, schema=schema, cache=cache)
        self.file_api: FileApi = file_api
        #self.lock = threading.Lock()
        self.is_building_cache_in_progress = {}

    def build_cache(self, bus_date: dt.date, key: str = None) -> int:

        if bus_date in self.is_building_cache_in_progress:
            logging.info(f'Building cache is in progress for  {bus_date}, key: {key}, dropping request')
            return 0

        try:
            self.is_building_cache_in_progress[bus_date] = True

            if self.cache.has_data(bus_date):
                logging.info(f'Removing cache for {bus_date}, key: {key}')
                self.cache.delete(bus_date)

            logging.info(f'Building cache for {bus_date}, key: {key}')
            trades = list(self.get_records(bus_date))

            self.cache.insert_data(bus_date, trades)
            logging.info(f'Cache build finished for {bus_date}, key: {key}')
        finally:
            del self.is_building_cache_in_progress[bus_date]

        return len(trades)

    def get_data(self, bus_date: dt.date, key: str = None) -> List[Deal]:
        if not self.is_cache_enabled:
            return list(self.get_records(bus_date))

        if key is None:
            key = bus_date

        if self.cache.has_data(bus_date):
            logging.info(f'Getting items from cache for {bus_date}, key: {key}' )
            return self.cache.get_data(key)
        else:
            logging.info(f'Items not in cache for {bus_date}, key: {key}')
            trades = list(self.get_records(bus_date))
            return trades

    def get_data_by_partition_key(self, bus_date: dt.date, cache_key: str = None) -> List[object]:
        if not self.is_cache_enabled:
            raise NotImplemented()

        #logging.info(f'Acquiring lock for {bus_date}, key: {cache_key}')
        #self.lock.acquire()
        try:
            if self.cache.has_data(bus_date):
                # noinspection PyTypeChecker
                return self.get_data(bus_date, cache_key)
            else:
                # cache is not there
                self.build_cache(bus_date, cache_key)
                return self.get_data(bus_date, cache_key)
        finally:
            pass
            #self.lock.release()
            #logging.info(f'Releasing lock for {bus_date}, key: {cache_key}')

    def try_parsing_record(self, row_item: dict) -> (bool, str):
        item_list = self.parse_record(row_item)
        for (item, exception_msg) in item_list:
            if item is None:
                return False, exception_msg
        return True, None

    def try_parsing_first_record(self, file_location: str) -> (int, str):
        row_dict: dict = self.file_api.read_first_record(file_location)
        result, exception_msg = self.try_parsing_record(row_dict)
        if result:
            return 1, None  # number of checked records
        else:
            return None, exception_msg

    def try_parsing_all_records(self, file_location: str) -> (int, str):
        count = 0
        for row_dict in self.file_api.read_all_records(file_location):
            count += 1
            result, exception_msg = self.try_parsing_record(row_dict)
            if not result:
                exception_msg = f"Line {count}. Message: {exception_msg}"
                return None, exception_msg
        return count, None

    def get_records(self, bus_date: dt.date)-> Generator:
        for row_item in self.file_api.read(bus_date):
            if row_item is not None:
                item_list = self.parse_record(row_item)
                for (item, exception_msg) in item_list:
                    if item is not None:
                        yield item

    @abstractmethod
    def parse_record(self, row_dict: dict) -> [(object, str)]:
        return [(None, None)]


class DataDomainMultiFileBase(DataDomainFileBase):
    # storage for the instance reference

    def __init__(self, file_api: FileApi, config: Configuration, stats: MetricCollector, schema: Schema = None,
                 cache: DataCache = DataCache()):
        super(DataDomainMultiFileBase, self).__init__(file_api=file_api,
                                                      config=config,
                                                      stats=stats,
                                                      schema=schema,
                                                      cache=cache)

    def get_records(self, bus_date: dt.date) -> Generator:
        for row_item in self.file_api.read_many(bus_date):
            if row_item is not None:
                item_list = self.parse_record(row_item)
                for (item, exception_msg) in item_list:
                    if item is not None:
                        yield item

    @abstractmethod
    def parse_record(self, row_item) -> [(object, str)]:
        return [(None, None)]


class DataDomainRestBase(DataDomainBase):
    def try_parsing_record(self, row_item: str) -> (bool, str):
        pass

    # storage for the instance reference

    def __init__(self, config: Configuration, stats: MetricCollector, schema: Schema, source: str,
                 cache: DataCache = None, rest: RequestService = RequestService()):
        super(DataDomainRestBase, self).__init__(config=config, stats=stats, schema=schema, cache=cache)
        self.source = source
        self.rest = rest
        #self.lock = threading.Lock()
        self.is_building_cach_in_progress = {}

    def build_cache(self, bus_date: dt.date, key: str = None):

        if bus_date in self.is_building_cach_in_progress:
            logging.info(f'Building cache is in progress for {bus_date}, key: {key}, dropping request')
            return None

        try:
            self.is_building_cach_in_progress[bus_date] = True

            if self.cache.has_data(bus_date):
                logging.info(f'Removing cache for {bus_date}, key: {key}')
                self.cache.delete(bus_date)

            logging.info(f'Building cache for {bus_date}, key: {key}')
            trades = list(self.__get_records(bus_date, key))

            self.cache.insert_data(bus_date, trades)
            logging.info(f'Cache build finished for {bus_date}, key: {key}')
        finally:
            del self.is_building_cach_in_progress[bus_date]

    def initialize(self, bus_date: dt.date, key: str = None):
        pass

    def get_data(self, bus_date: dt.date, key: str = None) -> List[object]:
        self.initialize(bus_date, key)

        if not self.is_cache_enabled():
            return list(self.__get_records(bus_date))

        if key is None:
            key = bus_date

        if self.cache.has_data(bus_date):
            logging.info(f'Getting items from cache for {bus_date}, key: {key}')
            return self.cache.get_data(key)
        else:
            logging.info(f'Items not in cache for {bus_date}, key: {key}')
            trades = list(self.__get_records(bus_date))
            return trades

    def get_data_by_partition_key(self, bus_date: dt.date, key: str = None) -> List[object]:

        if key is None:
            key = ""

        self.initialize(bus_date, key)

        if not self.is_cache_enabled():
            raise NotImplemented()

        #logging.info(f'Acquiring lock, bus_date:{bus_date} , key: {key}')
        #self.lock.acquire()
        try:
            if self.cache.has_data(bus_date, key):
                # noinspection PyTypeChecker
                return self.get_data(bus_date, key)
            else:
                # cache is not there
                self.build_cache(bus_date, key)
                return self.get_data(bus_date, key)
        finally:
            pass
            #self.lock.release()
            #logging.info(f'Releasing lock, bus_date:{bus_date}, key {key}')

    def try_parsing_first_record(self, bus_date: dt.date) -> bool:
        result = False
        for row_item in self.__get_records(bus_date):
            result = self.parse_record(row_item)
            break
        return result is not None

    def try_parsing_all_records(self, bus_date: dt.date):
        for row_item in self.__get_records(bus_date):
            result = self.parse_record(row_item)
            if result is None:
                return False
            return True

    def parse_record(self, row_item: object) -> object:
        return row_item

    def __get_records(self, bus_date: dt.date,  key: str = None) -> Generator:
        counter = 0
        for endpoint in self.build_endpoint(bus_date):
            for row_item in self.rest.read_from_service(endpoint):
                counter += 1
                if (counter % 10000) == 0:
                    logging.info('rest received %s', counter)
    
                if row_item is None:
                    continue
                elif "error" in row_item.decode("utf-8"):
                    logging.warning(json.dump(row_item.decode("utf-8")))
                else:
                    result = self.schema.loads(row_item)
    
                    if hasattr(result, 'errors') and len(result.errors) > 0:
                        logging.warning('Errors detected while fetching record %s', result.errors)
    
                    deal = result.data
                    yield self.parse_record(deal)

        logging.info("%s loaded", self.source)

    # noinspection PyMethodMayBeStatic,PyUnusedLocal
    def build_endpoint(self, bus_date: dt.date) -> List:
        return []
