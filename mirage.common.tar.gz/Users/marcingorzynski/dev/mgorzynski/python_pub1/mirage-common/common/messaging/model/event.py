import datetime as dt
import uuid
import socket
from toastedmarshmallow import Jit
from marshmallow import Schema, fields, post_load
from common.util.marshmallow_enum import EnumField
from .. import MessageType
from .base_message import BaseMessage


class Event(BaseMessage):
    """ Message bus event """

    def __init__(self,
                 event_name: str,
                 bus_date: dt.date,
                 source: str,
                 event_payload: str = '',
                 time_created: dt.datetime = None,
                 message_id: uuid = None,
                 correlated_message_id: uuid = None,
                 run_id: uuid = None,
                 host: str = socket.gethostname(),
                 message_type: MessageType = MessageType.event):
        if not event_name:
            raise ValueError('Event name cannot be empty')
        if message_id is None:
            message_id = uuid.uuid4()
        if time_created is None:
            time_created = dt.datetime.utcnow()
        super(Event, self).__init__(bus_date=bus_date,
                                    time_created=time_created,
                                    message_id=message_id,
                                    correlated_message_id=correlated_message_id,
                                    run_id=run_id,
                                    source=source,
                                    message_type=message_type,
                                    host=host)
        self.event_name = event_name
        self.event_payload = event_payload
        self.schema = EventSchema()
        self.schema.jit = Jit

    def __repr__(self):
        return f"<Event name: {self.event_name}, " \
            f"bus_date: {self.bus_date:%Y-%m-%d}, " \
            f"source: {self.source}, " \
            f"payload: \"{self.event_payload}\">"

    def __eq__(self, other):
        if self.event_name == other.event_name \
                and self.bus_date == other.bus_date \
                and self.source == other.source \
                and self.event_payload == other.event_payload \
                and self.message_type == other.message_type:
            return True
        else:
            return False

    def to_json(self):
        json_result = self.schema.dumps(self).data
        return json_result

    @staticmethod
    def des_json(data):
        schema = EventSchema()
        schema.jit = Jit
        return schema.loads(data)


class EventSchema(Schema):
    class Meta:
        jit = Jit

    time_created = fields.DateTime()
    message_id = fields.UUID()
    correlated_message_id = fields.UUID(required=False, allow_none=True)
    run_id = fields.UUID(required=False, allow_none=True)
    source = fields.Str()
    host = fields.Str()
    event_name = fields.Str()
    bus_date = fields.Date()
    event_payload = fields.Str()
    message_type = EnumField(MessageType, by_value=False)

    @post_load
    def make_event(self, data):
        return Event(**data)
