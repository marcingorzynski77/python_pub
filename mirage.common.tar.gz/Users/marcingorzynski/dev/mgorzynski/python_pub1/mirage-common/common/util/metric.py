"""Control module"""
import logging
import statsd
from typing import Callable

try:
    from greplin import scales
except ImportError:
    raise ImportError(
        "The scales library is required for metrics support: "
        "https://pypi.org/project/scales/")


logging = logging.getLogger(__name__)


class MetricCollector(object):
    """
    A collection of timers and counters for various performance metrics.
    Timer metrics are represented as floating point seconds.
    """

    request_timer = None
    cache_timer = None
    """
    A :class:`greplin.scales.PmfStat` timer for requests. This is a dict-like
    object with the following keys:
    * count - number of requests that have been timed
    * min - min latency
    * max - max latency
    * mean - mean latency
    * stddev - standard deviation for latencies
    * median - median latency
    * 75percentile - 75th percentile latencies
    * 95percentile - 95th percentile latencies
    * 98percentile - 98th percentile latencies
    * 99percentile - 99th percentile latencies
    * 999percentile - 99.9th percentile latencies
    """

    processed_events = None
    ignored_events = None
    errored_events = None
    parse_errors = None
    parse_warnings = None
    statsd_client = None

    _stats_counter = 0

    def __init__(self, stats_name: str, statsd_server: str = None, statsd_server_port: str = None):
        logging.info("Starting metric capture")
        self.error_messages = []
        self.stats_name = stats_name
        MetricCollector._stats_counter += 1
        self.stats_name = '{0}'.format(self.stats_name)

        if statsd_server is not None and statsd_server_port is not None:
            logging.info("statsd backend is enabled on http://%s:%s", statsd_server, statsd_server_port)
            self.statsd_client = statsd.StatsClient(statsd_server, statsd_server_port)
        else:
            logging.info("statsd backend is disabled")

        self.stats = scales.collection(self.stats_name,
                                       scales.PmfStat('request_timer'),
                                       scales.PmfStat('cache_timer'),
                                       scales.IntStat('processed_events'),
                                       scales.IntStat('ignored_events'),
                                       scales.IntStat('errored_events'),
                                       scales.IntStat('parse_warnings'),
                                       scales.IntStat('parse_errors'),
                                       scales.IntStat('requests'))

        self.request_timer = self.stats.request_timer
        self.cache_timer = self.stats.cache_timer
        self.processed_events = self.stats.processed_events
        self.ignored_events = self.stats.ignored_events
        self.errored_events = self.stats.errored_events
        self.parse_warnings = self.stats.parse_warnings
        self.parse_errors = self.stats.parse_errors
        self.requests = self.stats.requests

    def on_process_event(self):
        self.processed_events += 1
        if self.statsd_client is not None:
            self.statsd_client.incr('mirage_event,name={0},type=processed'.format(self.stats_name))

    def on_ignore_event(self):
        self.ignored_events += 1
        if self.statsd_client is not None:
            self.statsd_client.incr('mirage_event,name={0},type=ignored'.format(self.stats_name))

    def on_error_event(self):
        self.errored_events += 1
        if self.statsd_client is not None:
            self.statsd_client.incr('mirage_event,name={0},type=errored'.format(self.stats_name))

    def on_parse_warning(self):
        self.parse_warnings += 1
        if self.statsd_client is not None:
            self.statsd_client.incr('mirage_data,name={0},type=warnings'.format(self.stats_name))

    def on_parse_error(self):
        self.parse_errors += 1
        if self.statsd_client is not None:
            self.statsd_client.incr('mirage_data,name={0},type=error'.format(self.stats_name))

    def on_request(self):
        self.requests += 1
        if self.statsd_client is not None:
            self.statsd_client.incr('mirage_data,name={0},type=requests'.format(self.stats_name))

    def get_stats(self):
        """
        Returns the metrics for the registered cluster instance.
        """
        return scales.getStats()[self.stats_name]

    # noinspection PyProtectedMember
    def set_stats_name(self, stats_name: str):
        """
        Set the metrics stats name.
        The stats_name is a string used to access the metris through scales: scales.getStats()[<stats_name>]
        """

        if self.stats_name == stats_name:
            return

        if stats_name in scales._Stats.stats:
            raise ValueError('"{0}" already exists in stats.'.format(stats_name))

        stats_obj = scales._Stats.stats[self.stats_name]
        del scales._Stats.stats[self.stats_name]
        self.stats_name = stats_name
        scales._Stats.stats[self.stats_name] = stats_obj


class MetricTimer(object):

    def __init__(self, metric_collector: MetricCollector, category: str):
        self.metric_collector = metric_collector
        self.category = category

    def invoke(self, method_to_measure: Callable, *args) -> object:
        if self.metric_collector.statsd_client is not None:
            with self.metric_collector.cache_timer.time():
                statsd_timer = self.metric_collector.statsd_client.timer(
                    '{0}_{1}'.format(self.metric_collector.stats_name, self.category)).start()
                ret_val = method_to_measure(*args)
                statsd_timer.stop()
                return ret_val
        else:
            with self.metric_collector.cache_timer.time():
                ret_val = method_to_measure(*args)
                return ret_val


class CacheMetricTimer(MetricTimer):
    GATEWAY_TIMINGS = "mirage_timings_cache"

    def __init__(self, metric_collector: MetricCollector):
        super(CacheMetricTimer, self).__init__(metric_collector, CacheMetricTimer.GATEWAY_TIMINGS)


stats: MetricCollector = None


def instantiate_global_metric(instance):
    global stats
    stats = instance
