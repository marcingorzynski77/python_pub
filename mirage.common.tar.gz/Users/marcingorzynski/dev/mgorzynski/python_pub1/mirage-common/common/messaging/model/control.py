import datetime as dt
import uuid
import socket
from marshmallow import Schema, fields, post_load
from common.util.marshmallow_enum import EnumField
from .. import MessageType
from .base_message import BaseMessage


class Control(BaseMessage):
    """ Message bus metric """

    def __init__(self,
                 category: str,
                 bus_date: dt.date,
                 source: str,
                 host: str = socket.gethostname(),
                 payload=None,
                 time_created: dt.datetime = None,
                 message_id: uuid = None,
                 correlated_message_id: uuid = None,
                 run_id: uuid = None,
                 message_type: MessageType = MessageType.control):
        if message_id is None:
            message_id = uuid.uuid4()
        if time_created is None:
            time_created = dt.datetime.utcnow()
        super(Control, self).__init__(bus_date=bus_date,
                                      time_created=time_created,
                                      message_id=message_id,
                                      correlated_message_id=correlated_message_id,
                                      run_id=run_id,
                                      message_type=message_type,
                                      source=source,
                                      host=host)
        if payload is None:
            payload = {}
        self.category = category
        self.payload = payload
        self.schema = ControlSchema()

    def __repr__(self):
        return f'<Control bus_date: "{self.bus_date:%Y-%m-%d}", source: "{self.source}", category: "{self.category}"' \
               f', payload: "{self.payload}", correlated_message_id: "{self.correlated_message_id}">'

    def __eq__(self, other):
        if self.bus_date == other.bus_date \
                and self.source == other.source \
                and self.category == other.category \
                and self.payload == other.payload \
                and self.correlated_message_id == other.correlated_message_id:
            return True
        else:
            return False

    def to_json(self):
        json_result = self.schema.dumps(self).data
        return json_result

    @staticmethod
    def des_json(data):
        schema = ControlSchema()
        return schema.loads(data)


class ControlSchema(Schema):
    time_created = fields.DateTime()
    message_id = fields.UUID()
    correlated_message_id = fields.UUID(required=False, allow_none=True)
    run_id = fields.UUID(required=False, allow_none=True)
    source = fields.Str()
    category = fields.Str()
    host = fields.Str()
    bus_date = fields.Date()
    payload = fields.Dict()
    message_type = EnumField(MessageType)

    @post_load
    def make_control(self, data):
        res = Control(**data)
        return res


