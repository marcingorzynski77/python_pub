""" configuration module"""
import os
from enum import Enum
from common.util.file_system import FileSystem


class StorageType(Enum):
    file = 1
    noSql = 2
    sql = 3
    noStorage = 4


class StorageConfiguration(object):

    def __init__(self):
        """ class holding application settings"""

        # only relevant for storage_type: file , store files in compressed format
        self.file_storage_root_path = None
        #  only relevant if local storage holds data from multiple sources - at the moment we do not have such a case
        self.data_source = ""
        # type of storage can be: sql , nosql, file
        # sql - means data are actually stored within service own storage
        # nosql - means that only pointer is stored in service local storage
        #         and actual payload is kept in elastic search
        # file - means that only pointer is stored in service local storage
        #         and actual payload is kept on network in zipped format
        self.storage_type = StorageType.noStorage
        # sqllite database file name
        self.internal_storage_db_name = "local-service-storage.db"
        # elastic search address
        self.elastic_search = None
        # elastic search address
        self.storage_path = None
        # number of files/records to keep
        self.number_of_bus_days_to_keep = 0  # means clearing is disabled
        self.archive_enabled = True

    def load(self, app_settings):
        """get configuration from the provided dictionary, if a key is not present - a default value will be used"""

        if 'file_storage_root_path' in app_settings:
            self.file_storage_root_path = app_settings['file_storage_root_path']

        if 'data_source' in app_settings:
            self.data_source = app_settings['data_source']

        if 'elastic_search' in app_settings:
            self.elastic_search = app_settings['elastic_search']

        # storage of payload
        if 'storage_type' in app_settings:
            if app_settings['storage_type'] == 'file':
                self.storage_type = StorageType.file
            elif app_settings['storage_type'] == 'nosql':
                self.storage_type = StorageType.noSql
            elif app_settings['storage_type'] == 'sql':
                self.storage_type = StorageType.sql
            else:
                self.storage_type = StorageType.noStorage
        else:
            self.storage_type = StorageType.noStorage

        if 'storage_path' in app_settings:
            self.storage_path = app_settings['storage_path']

        if 'archive_enabled' in app_settings:
            self.archive_enabled = app_settings['archive_enabled']

        if 'number_of_bus_days_to_keep' in app_settings:
            self.number_of_bus_days_to_keep = app_settings['number_of_bus_days_to_keep']

    def get_internal_storage_path(self):
        current = os.getcwd()

        if self.storage_path is not None:
            current = self.storage_path

        storage_path = os.path.join(current, 'storage')
        # os.path.join(current, 'storage')
        # self.file_storage_root_path,
        FileSystem.ensure_dir(storage_path)
        return os.path.join(storage_path, self.internal_storage_db_name)
