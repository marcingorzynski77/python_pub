""" testing module """
import unittest2
import os
import datetime as dt
from flask import Flask
from common.storage.file_api import FileApi, CsvPayloadReader
from common.config import Configuration, instantiate_global_config
from common.util.metric import MetricCollector, instantiate_global_metric
from common.storage.sql_models import SqlWrapper


class TestFile(unittest2.TestCase):
    config: Configuration = Configuration()
    stats: MetricCollector

    @classmethod
    def setUpClass(cls):
        # if os.path.exists(cls.config.storage.get_internal_storage_path()):
        #   os.remove(cls.config.storage.get_internal_storage_path())
        app = Flask(__name__)
        wrapper = SqlWrapper(cls.config.storage.get_internal_storage_path())
        wrapper.reset_storage(app)
        file_storage = os.path.join(os.path.dirname(__file__), 'storage')
        if not os.path.exists(file_storage):
            os.mkdir(file_storage)
        cls.config.storage.file_storage_root_path = file_storage
        cls.config.cache_enabled = True
        instantiate_global_config(cls.config)
        cls.stats = MetricCollector(cls.config.service_name)
        instantiate_global_metric(cls.stats)

    # @classmethod
    # def tearDownClass(cls):
    #    # if os.path.exists(cls.config.storage.get_internal_storage_path()):
    #        # os.remove(cls.config.storage.get_internal_storage_path())

    def test_reading_file(self):
        print(f'*** Running {self.id()} ***')
        file = os.path.join(os.path.dirname(__file__), "file_payload.csv")
        reader = CsvPayloadReader()
        for row in reader.read(file):
            if row["column1"] == "1":
                self.assertEqual(row["column2"], "2")
            elif row["column1"] == "2":
                self.assertEqual(row["column2"], "4")

    def test_reading_zipfile(self):
        print(f'*** Running {self.id()} ***')
        self.config.storage.archive_enabled = True
        api = FileApi(self.config)
        file = os.path.join(os.path.dirname(__file__), "file_payload.csv")
        bus_date = dt.date(2018, 6, 1)
        api.insert(file, bus_date, 'TEST.EVENT')

        for row in api.read(bus_date):
            if row["column1"] == "1":
                self.assertEqual(row["column2"], "2")
            elif row["column1"] == "2":
                self.assertEqual(row["column2"], "4")

    def test_reading_no_archive(self):
        print(f'*** Running {self.id()} ***')
        self.config.storage.archive_enabled = False
        api = FileApi(self.config)
        file = os.path.join(os.path.dirname(__file__), "file_payload.csv")
        bus_date = dt.date(2018, 6, 1)
        api.insert(file, bus_date, 'TEST.EVENT')

        for row in api.read(bus_date):
            if row["column1"] == "1":
                self.assertEqual(row["column2"], "2")
            elif row["column1"] == "2":
                self.assertEqual(row["column2"], "4")
