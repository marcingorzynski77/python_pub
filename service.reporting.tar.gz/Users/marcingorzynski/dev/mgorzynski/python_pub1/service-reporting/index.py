import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, ClientsideFunction
import logging

from app_dash import app
from apps import app_dash_index, app_dash_report, app_dash_loading
from storage.cache import SessionCache
from model_view import Index_callback

logging = logging.getLogger(__name__)


app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])


@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname == "/login":
        return app_dash_index.display_page("/login", None)
    elif pathname == "/loading":
        return app_dash_loading.display_page()
    elif pathname == "/logout":
        return app_dash_index.display_page("/logout", None)
    elif pathname == "/authorization":
        return app_dash_index.display_page("/authorization", None)

    user_id = SessionCache.get_user()
    if user_id is None:
        logging.info(f'user not authenticated , invoking login')
        return app_dash_index.display_page("/login", user_id)

    logging.info(f'executing request for user {user_id}')

    if 'financial-report' in pathname:
        return app_dash_report.display_page(pathname, user_id)
    elif pathname == '/index':
        return app_dash_index.display_page(pathname, user_id)
    else:
        return app_dash_index.display_page(pathname, user_id)
