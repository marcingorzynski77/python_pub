""" testing module """
import unittest2
import os
import json
import pandas as pd
import datetime as dt
from flask import Flask
from common.storage.file_api import FileApi, CsvPayloadReader
from common.config import Configuration, instantiate_global_config
from common.util.metric import MetricCollector, instantiate_global_metric
from storage.rest_mock import ErisApiMock
from common.storage.sql_models import SqlWrapper
from storage.rest import ErisApi


class TestErisApi(unittest2.TestCase):
    config: Configuration = Configuration()
    stats: MetricCollector

    @classmethod
    def setUpClass(cls):
        instantiate_global_config(cls.config)
        cls.stats = MetricCollector(cls.config.service_name)
        instantiate_global_metric(cls.stats)

    def test_user_get_data(self):
        print(f'*** Running {self.id()} ***')
        file_path = os.path.join(os.path.dirname(__file__), 'test_files', 'user.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        df = pd.json_normalize(data)
        self.assertTrue(df is not None)
        self.assertTrue(df.loc[:,'email'].get(0) is not None)

    def test_overview_get_data(self):
        print(f'*** Running {self.id()} ***')
        file_path = os.path.join(os.path.dirname(__file__), 'test_files', 'overview.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        user = pd.json_normalize(data)
        cards = pd.json_normalize(data['cards'])
        accounts = pd.json_normalize(data['accounts'])
        self.assertTrue(user is not None)
        self.assertTrue(cards is not None)
        self.assertTrue(accounts is not None)

    def test_balance_get_data(self):
        print(f'*** Running {self.id()} ***')
        file_path = os.path.join(os.path.dirname(__file__), 'test_files', 'balance1.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        balance1 = pd.json_normalize(data)
        self.assertTrue(balance1 is not None)

        file_path = os.path.join(os.path.dirname(__file__), 'test_files', 'balance2.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        balance2 = pd.json_normalize(data)
        self.assertTrue(balance2 is not None)

        bal = balance1.append(balance2)
        self.assertTrue(bal is not None)

    def test_mock_data(self):
        mock = ErisApiMock()
        data = mock.get_data()
        self.assertTrue(data is not None)



