""" responsible for handling global events"""
import logging
from common.messaging import MessageType
from common.messaging.model.control import Control
from common.messaging.model.event import Event
from common.messaging.producer import Producer
from common.messaging.actor.service_event_sink import ServiceEventSinkActor
from common.util.metric import stats
from local_config import config
from messaging import const

logging = logging.getLogger(__name__)


class EventSink(ServiceEventSinkActor):
    """ handler for all messages on the service bus """
    def __init__(self, mq_producer: Producer):
        super(EventSink, self).__init__(mq_producer)
        self.handlers[MessageType.control] = self.handler_control
        self.failure_event_message = const.SERVICE_CONTROL_DATA_FAILURE

    # The handler_global_event is overwritten to disable control over 'interesting' events
    # as service-default records all broadcast events

    def handler_event(self, event: Event):
        if self.running_journal_events:
            logging.info('Processing mq message from journal: %s', event.event_name)
        else:
            logging.info('Received mq message: %s', event.event_name)
        logging.info('Business date event: %s', event.bus_date)

        self.add_event_to_received(event)
        stats.on_process_event()

        try:
            logging.debug('Calling processing handler')
            self.handler_processing(event)
        except Exception as ex:
            logging.error('Handling error: %s', ex)
            if self.failure_event_message is not None:
                stats.on_error_event()
                logging.info('Sending global event: %s', self.failure_event_message)
                self.mq_producer.create_and_send_event(self.failure_event_message, event.bus_date)
            return

    def handler_control(self, control: Control):
        logging.info('Received control message: %s', control.category)
        try:
            pass
        except Exception as ex:
            logging.exception(ex)