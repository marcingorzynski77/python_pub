#!/usr/bin/env bash
python -m service -l logging.yml -c config.yml