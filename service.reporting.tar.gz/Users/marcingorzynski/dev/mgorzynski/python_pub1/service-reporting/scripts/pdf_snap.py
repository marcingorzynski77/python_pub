import pdfkit

if __name__ == "__main__":
    options = {
        # 'page-size': 'Letter',
        # 'margin-top': '0.75in',
        # 'margin-right': '0.75in',
        # 'margin-bottom': '0.75in',
        # 'margin-left': '0.75in',
        'encoding': "UTF-8",
        'javascript-delay': '8000',
        # 'no-outline': None
    }

    pdfkit.from_url('http://127.0.0.1:8050/financial-report/overview', 'out.pdf', options=options)