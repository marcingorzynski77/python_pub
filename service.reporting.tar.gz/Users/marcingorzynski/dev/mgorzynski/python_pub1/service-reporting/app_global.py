# -*- coding: utf-8 -*-
from flask import Flask

server: Flask = None


def instantiate_app(app_server):
    global server
    server = app_server
