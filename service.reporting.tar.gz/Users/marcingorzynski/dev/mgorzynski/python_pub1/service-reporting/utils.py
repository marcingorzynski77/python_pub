import string

import dash_html_components as html
import dash_core_components as dcc


def Header(app):
    return html.Div([get_header(app), html.Br([]), get_menu()])


def list_to_dict(lst):
    op = {lst[i]: string.capwords(lst[i]) for i in range(0, len(lst))}
    return op


def print_button():
    print_button = html.A(['Print PDF'], className="button no-print print",
                          style={'position': "absolute", 'top': '-40', 'right': '0'})
    return print_button


def back_button():
    logout_button = html.A(['Back'], href='/index', className="button no-print",
                           style={'position': "absolute", 'top': '10', 'right': '0'})
    return logout_button


def get_header(app):
    header = html.Div(
        [
            dcc.Location(id='url_logout', refresh=True),
            html.Div(
                [
                    html.A([
                        html.Img(
                            src=app.get_asset_url("logo_green.png"),
                            className="logo",
                        )], href='https://gosavex.com', target='_blank'),
                    # html.A(
                    #     html.Button("Learn More", id="learn-more-button"),
                    #     href="https://gosavex.com/",
                    # ),
                    back_button()
                ],
                className="row",
            ),
            html.Div(
                [
                    html.Div(
                        [html.H5("Personalised Financial Overview")],
                        className="seven columns main-title",
                    ),
                    html.Div(
                        [
                            dcc.Link(
                                "Full View",
                                href="/financial-report/full-view",
                                className="full-view-link",
                            )
                        ],
                        className="five columns",
                    ),
                ],
                className="twelve columns",
                style={"padding-left": "0"},
            ),
        ],
        className="row",
    )
    return header


def get_menu():
    menu = html.Div(
        [
            dcc.Link(
                "Overview",
                href="/financial-report/overview",
                className="tab first",
            ),
            dcc.Link(
                "Balances",
                href="/financial-report/balances",
                className="tab",
            ),
            dcc.Link(
                "Categories",
                href="/financial-report/categories",
                className="tab",
            ),
            dcc.Link(
                "Merchants",
                href="/financial-report/merchants",
                className="tab",
            ),
            dcc.Link(
                "Accounts",
                href="/financial-report/accounts",
                className="tab",
            ),
            dcc.Link(
                "Cards",
                href="/financial-report/cards",
                className="tab",
            ),
            # dcc.Link(
            #     "Transactions",
            #     href="/financial-report/transactions",
            #     className="tab",
            # ),
        ],
        className="row all-tabs",
    )
    return menu


def make_dash_table(df):
    """ Return a dash definition of an HTML table for a Pandas dataframe """
    table = []
    if df is not None:
        for index, row in df.iterrows():
            html_row = []
            for i in range(len(row)):
                html_row.append(html.Td([row[i]]))
            table.append(html.Tr(html_row))
    return table
