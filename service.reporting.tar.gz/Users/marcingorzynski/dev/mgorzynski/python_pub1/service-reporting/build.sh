#!/usr/bin/env bash
python setup.py bdist_wheel
devpi login bad --password x
devpi upload dist/$(ls dist -t | head -1)
