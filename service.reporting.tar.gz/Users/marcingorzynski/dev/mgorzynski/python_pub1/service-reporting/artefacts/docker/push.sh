docker build -t dash -f service-reporting/Dockerfile .
docker tag dash 192.168.4.200:6000/service-reporting
docker push 192.168.4.200:6000/service-reporting
kubectl delete -f service-reporting/artefacts/kubernetes/eris-service-reporting.yml
kubectl apply -f service-reporting/artefacts/kubernetes/eris-service-reporting.yml

kubectl delete -f service-reporting/artefacts/kubernetes/eris-service-reporting.yml
kubectl apply -f service-reporting/artefacts/kubernetes/eris-service-reporting.yml

#docker run --name cdash -p 12000:12000 dash
