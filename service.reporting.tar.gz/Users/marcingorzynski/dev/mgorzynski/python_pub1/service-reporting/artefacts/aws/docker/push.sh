
aws ecr get-login-password --region eu-west-2 | docker login --username AWS --password-stdin 107143365619.dkr.ecr.eu-west-2.amazonaws.com
docker build -t service-reporting -f service-reporting/Dockerfile .
docker tag service-reporting 107143365619.dkr.ecr.eu-west-2.amazonaws.com/gosavex
docker push 107143365619.dkr.ecr.eu-west-2.amazonaws.com/gosavex

kubectl delete -f service-reporting/artefacts/kubernetes/eris-service-reporting.yml
kubectl apply -f service-reporting/artefacts/kubernetes/eris-service-reporting.yml

#docker run --name cdash -p 12000:12000 dash
