""" configuration module"""
import logging
from common.config import Configuration

log = logging.getLogger(__name__)


class DbConfiguration:
    """ class holding journal settings"""

    def __init__(self):
        # db name
        self.db_schema: str = ""
        self.db_port: str = ""
        self.db_host: str = ""
        self.db_pass: str = ""
        self.db_user: str = ""

    def load(self, app_settings):
        """ load configuration from the provided collection"""

        if 'db_schema' in app_settings:
            self.db_schema = app_settings['db_schema']
        if 'db_port' in app_settings:
            self.db_port = app_settings['db_port']
        if 'db_user' in app_settings:
            self.db_user = app_settings['db_user']
        if 'db_pass' in app_settings:
            self.db_pass = app_settings['db_pass']
        if 'db_host' in app_settings:
            self.db_host = app_settings['db_host']


class ReportingConfiguration(Configuration):

    def __init__(self):
        """ class holding application settings"""
        super(ReportingConfiguration, self).__init__()
        self._default_db_config = DbConfiguration()
        self.session_type: str = "file"
        self.client_service: str = ""
        self.client_tran_service: str = ""
        self.location_service: str = ""
        self.auth_service: str = ""
        self.redis_server: str = ""

    def load(self, config_file_name):
        """ load configuration from the provided file, if not provided defaults will be used"""
        super(ReportingConfiguration, self).load(config_file_name)

        control_settings = self.config_collection['control_settings']
        if 'session_type' in control_settings:
            self.session_type = control_settings['session_type']

        if 'client_service' in control_settings:
            self.client_service = control_settings['client_service']

        if 'client_tran_service' in control_settings:
            self.client_tran_service = control_settings['client_tran_service']

        if 'location_service' in control_settings:
            self.location_service = control_settings['location_service']

        if 'auth_service' in control_settings:
            self.auth_service = control_settings['auth_service']

        if 'redis_server' in control_settings:
            self.redis_server = control_settings['redis_server']

        self.default_db.load(self.config_collection['control_settings'])

    @property
    def default_db(self) -> DbConfiguration:
        return self._default_db_config


config: ReportingConfiguration = None
