import logging
import io
from flask_restplus import Api, Resource
from flask import session, Response
from storage.cache import SessionCache

logging = logging.getLogger(__name__)

rest_api = Api(version='1.0', title='Mirage reporting API', description='Reporting RestPlus-Powered API')
ns = rest_api.namespace('', description='Financial Reporting')


@rest_api.errorhandler
def default_error_handler(e):
    logging.exception('An unhandled exception occurred: %s', str(e))
    return {'message': 'Error encounter handling request, operation aborted'}, 500


@ns.route('/financial-report/transaction/csv')
class Csv(Resource):
    # noinspection PyUnusedLocal
    def get(self):
        logging.info('Requested csv export')

        try:
            data = SessionCache.get_data_tran()
            if data is None:
                msg = f'data not in cache'
                logging.info(msg)
                return {'message': msg}, 500

            buffer = io.StringIO()

            tran = data.transactions[
                ['Amount', 'Date', 'Merchant', 'Category', 'Provider', 'Description', 'Currency', 'Address']]
            tran.to_csv(buffer, encoding='utf-8')
            buffer.seek(0)

            resp = Response(buffer)
            resp.headers["Content-Disposition"] = "attachment; filename=transactions.csv"
            resp.headers["Content-type"] = "text/csv"
            return resp

        except ValueError:
            msg = f'error exporting csv transactions'
            logging.info(msg)
            return {'message': msg}, 500


@ns.route('/financial-report/health')
class Health(Resource):
    # noinspection PyUnusedLocal
    def get(self):
        return {'status': 'ok'}, 200
