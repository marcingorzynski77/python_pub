#!/usr/bin/env python
import os
from setuptools import setup

REQUIREMENTS = [
    line.strip() for line in open(os.path.join(os.path.dirname(__file__),
                                               'requirements.txt')).readlines()]

version = {}
with open("default/version.py") as fp:
    exec(fp.read(), version)


setup(
    name='service-default',
    version=version['__version__'],
    packages=['default', 'control.rest'],
    description='Mirage Reporting Service Python implementation',
    author='GX',
    license='GX',
    author_email='contacty@gosavex.com',
    install_requires=REQUIREMENTS,
    include_package_data=True,
    keywords='mirage reporting service to show financial overview',
    classifiers=[
	'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
)
