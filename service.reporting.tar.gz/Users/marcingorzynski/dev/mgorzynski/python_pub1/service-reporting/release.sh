# bump version
TG=$(docker run --rm -v "$PWD":/app treeder/bump --input 0.0.2)
ECHO $TG
#version=`cat VERSION`
#echo "version: $version-SNAPSHOT"

#docker tag dash 192.168.4.200:6000/service-reporting:$version
#docker push 192.168.4.200:6000/service-reporting:$version