import dash
from app_global import server

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(
    __name__, server=server, external_stylesheets=external_stylesheets,
    meta_tags=[{"name": "viewport", "content": "width=device-width"}, {
        'name': 'description',
        'content': 'Personal Financial Dashboard. Easily track spending across all your accounts.'
    }]
)

app.title = "Personal Financial Dashboard"

server = app.server
app.config.suppress_callback_exceptions = True
