import dash_html_components as html
import dash_table
import dash_bootstrap_components as dbc
import dash
from pandas import DataFrame


def build_transactions(transactions: DataFrame,  app: dash.Dash):

    data = transactions[
        ['Amount', 'Date', 'Merchant', 'Category', 'Provider', 'Description']]


    return html.Div(
        [
            # Row 1
            html.Div(
                [
                    html.Div(
                        [
                            dbc.Button(
                                "Info", id="popover-target-tran-mini", color="info",
                                className="bg-primary badge mr-1"
                            ),
                            dbc.Popover(
                                [
                                    dbc.PopoverHeader("Underlying transactions",
                                                      style={'font-size': '11px'}),
                                    dbc.PopoverBody(
                                        "This is showing all transactions linked to the filters in main search section."),
                                ],
                                id="popover-map-tran-mini",
                                is_open=False,
                                style={'font-size': '11px'},
                                target="popover-target-tran-mini",
                            ),
                            html.Div(
                                [
                                    dash_table.DataTable(
                                        id='datatable-interactivity',
                                        columns=[
                                            {"name": i, "id": i, "deletable": False, "selectable": False} for i
                                            in
                                            data.columns
                                        ],
                                        data=data.to_dict('records'),
                                        editable=True,
                                        filter_action="native",
                                        sort_action="native",
                                        sort_mode="multi",
                                        column_selectable="single",
                                        row_deletable=False,
                                        selected_columns=[],
                                        page_action="native",
                                        page_current=0,
                                        page_size=10,

                                        style_table={'overflowX': 'scroll'},
                                        style_cell={
                                            'font-size': '11px',
                                            'font-family': 'Raleway, HelveticaNeue, Helvetica Neue,Helvetica, Arial, sans-serif',
                                            'text-align': 'center',
                                            # 'minWidth': '50px', 'width': '180px', 'maxWidth': '180px',
                                            'overflow': 'hidden',
                                            'textOverflow': 'ellipsis',
                                        },
                                        style_data_conditional=[
                                            {
                                                'if': {'row_index': 'odd'},
                                                'backgroundColor': 'rgb(248, 248, 248)'
                                            }
                                        ],
                                        style_header={
                                            'backgroundColor': '#ffffff',
                                            'fontWeight': 'bold',
                                            'color': 'black',
                                        }

                                    ),
                                    html.Div(id='datatable-interactivity-container')
                                ],
                                style={"overflow-x": "auto"},
                            ),
                        ],
                        className="twelve columns",
                    )
                ],
                className="row flex-display",
            ),
        ],
        className="sub_page_max",
    ),


def build_transactions_all(transactions: DataFrame,  app: dash.Dash):

    data = transactions[
        ['Amount', 'Date', 'Merchant', 'Category', 'Provider', 'Description', 'Currency', 'Address']]

    return html.Div(
        [
            # Row 1
            html.Div(
                [
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Div(
                                        html.Div(className='div-div-legend', children=[
                                                    html.Img(src=app.get_asset_url("tick.png")),
                                                    html.P("This table is linked to main filter on report page",
                                                           style={'float': 'left'}),
                                                ]),
                                        className="mini_container_legend",
                                    ),
                                    html.Div(
                                        html.Div(className='div-div-legend', children=[
                                            html.Img(src=app.get_asset_url("tick.png")),
                                            html.P("Enter > 5000 in Amount column to search",
                                                   style={'float': 'left'}),
                                        ]),
                                        className="mini_container_legend",
                                    ),
                                    html.Div(
                                        html.Div(className='div-div-legend', children=[
                                            html.Img(src=app.get_asset_url("tick.png")),
                                            html.P("Search in all other columns is case sensitive",
                                                   style={'float': 'left'}),
                                        ]),
                                        className="mini_container_legend",
                                    ),
                                    html.Div(
                                        html.Div(className='div-div-legend', children=[
                                            html.Img(src=app.get_asset_url("tick.png")),
                                            html.P("To download all transaction press on download csv icon",
                                                   style={'float': 'left'}),
                                        ]),
                                        className="mini_container_legend",
                                    ),
                                    html.Div(
                                        html.Div(className='div-div-legend', children=[
                                            html.A([
                                                html.Img(
                                                    src=app.get_asset_url("download_small.png"),
                                                )
                                            ], href='/api/financial-report/transaction/csv',
                                                ),
                                        ]),
                                        className="mini_container_legend",
                                    ),
                                ],
                                className="row container-display",
                            ),
                            html.Div(
                                [
                                    dash_table.DataTable(
                                        id='datatable-interactivity_all',
                                        columns=[
                                            {"name": i, "id": i, "deletable": False, "selectable": False} for i
                                            in
                                            data.columns
                                        ],
                                        data=data.to_dict('records'),
                                        editable=True,
                                        filter_action="native",
                                        sort_action="native",
                                        sort_mode="multi",
                                        column_selectable="single",
                                        row_deletable=False,
                                        selected_columns=[],
                                        page_action="native",
                                        page_current=0,
                                        page_size=15,

                                        style_table={'overflowX': 'scroll'},
                                        style_cell={
                                            'font-size': '11px',
                                            'font-family': 'Raleway, HelveticaNeue, Helvetica Neue,Helvetica, Arial, sans-serif',
                                            'text-align': 'center',
                                            'overflow': 'hidden',
                                            'textOverflow': 'ellipsis',
                                        },
                                        style_data_conditional=[
                                            {
                                                'if': {'row_index': 'odd'},
                                                'backgroundColor': 'rgb(248, 248, 248)'
                                            }
                                        ],
                                        style_header={
                                            'backgroundColor': '#1E2130',
                                            'fontWeight': 'bold',
                                            'color': 'white',
                                        }

                                    ),
                                    html.Div(id='datatable-interactivity-container-all')
                                ],
                                style={"overflow-x": "auto"},
                            ),
                            html.A([
                                html.Img(
                                    src=app.get_asset_url("download1.png"),
                                )
                            ], href='/api/financial-report/transaction/csv',
                                style={'display': 'inline-block', 'font-size': '11px', }),

                        ],
                        className="twelve columns",
                    )
                ],
                className="row flex-display",
            ),
        ],
        className="sub_page_min",
    ),

