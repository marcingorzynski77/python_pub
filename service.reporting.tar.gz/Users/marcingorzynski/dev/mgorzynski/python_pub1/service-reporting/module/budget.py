# Import required libraries
import os
import pathlib

import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_daq as daq
import dash_html_components as html
import logging
import plotly.graph_objs as go
import pandas as pd
from model_view.index_vm import IndexView
import model_view.budget_callback as budget
from storage.cache import SessionCache

log = logging.getLogger(__name__)


def build_target_options(iv: IndexView):
    options = [{"label": "Saving Target ", "value": "saving"}, {"label": "Spending Target ", "value": "spending"}]
    return options


def build_tab3(iv: IndexView):
    return [html.Div(
        [
            dcc.Store(id="value-setter-store", data=budget.init_value_setter_store(iv.periods_plus_latest()[0])),
            dcc.Store(id="value-setter-store-period"),
            dcc.Store(id="value-setter-store-spending"),
            dcc.Store(id="value-setter-store-limit-value"),
            budget.generate_modal(),

            html.Div(
                [
                    html.Div(
                        [
                            html.Div(
                                id="value-setter-menu2",
                                children=[
                                    dbc.Button(
                                        "Info", id="popover-limit-filter", color="info",
                                        className="bg-primary badge mr-1"
                                    ),
                                    dbc.Popover(
                                        [
                                            dbc.PopoverHeader("Filtering", style={'font-size': '11px'}),
                                            dbc.PopoverBody(
                                                "Adjust your spending target by selecting percentage of your average spend. We will set up limits based on your selection."),
                                        ],
                                        id="popover-limit",
                                        is_open=False,
                                        style={'font-size': '11px'},
                                        target="popover-limit-filter",
                                    ),

                                    html.Div("Adjust spending target manually as % of 3m spending average",
                                             style={"margin-left": "10px"}),
                                    daq.Knob(
                                        id='metric-knob-spending',
                                        size=120,
                                        min=0,
                                        max=30,
                                        color={"gradient": True,
                                               "ranges": {"green": [0, 10], "yellow": [10, 20], "red": [20, 30]}},
                                        value=budget.get_spending_knob(),
                                        labelPosition='bottom',
                                    ),

                                    html.P(
                                        "Select period to analyse budget settings",
                                        className="control_label",
                                    ),
                                    html.Br(),
                                    dcc.Dropdown(
                                        id="metric-select-dropdown",
                                        options=list(
                                            {"label": param.strftime("%B-%Y"), "value": param} for param in
                                            iv.periods_plus_latest()
                                        ),
                                        value=iv.periods_plus_latest()[0],
                                        style={"width": "200px", "margin-left": "5px"}
                                        # className="dcc_control",
                                    ),
                                    daq.BooleanSwitch(
                                        id="auto_recalculate",
                                        label={"label": "Recalculate new spending target",
                                               "style": {"font-size": "10px"}},
                                        on=budget.init_recalculate_on(),
                                        style={"float": "right", "margin-left": "20px"}
                                    ),
                                    # html.Div(style={"clear": "right"}),
                                    # html.Div(style={"clear": "left"}),
                                    # html.P(
                                    #     "Turn on/off mobile notifications",
                                    #     className="",
                                    #     style={"float": "left", "margin-left": "10px", "margin-top": "5px"}
                                    # ),
                                    daq.BooleanSwitch(
                                        id="mobile_notifications",
                                        label={"label": "Turn on/off mobile notifications",
                                               "style": {"font-size": "10px", "margin-top": "10px"}},
                                        on=SessionCache.get_budget_data(None).customer_info["goalsNotificationEnabled"],
                                        style={"float": "right", "margin-left": "200px"}
                                    ),
                                    # daq.BooleanSwitch(
                                    #     id="mobile_notifications",
                                    #     on=SessionCache.get_budget_data(None).customer_info["goalsNotificationEnabled"],
                                    #     style={"float": "left", "margin-left": "20px"}
                                    # ),
                                    html.Div("", style={"clear": "left"}),
                                    html.Button("Save Changes", id="value-setter-set-btn", n_clicks=0,
                                                style={"margin-top": "10px"}),


                                ],
                            ),
                        ],
                        className="pretty_container four columns",
                        id="cross-filter-options1",
                    ),
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Div(
                                        [html.H6(id="avgIncome"), html.P("3 months Average Income")],
                                        id="numberOfTransactions",
                                        className="mini_container",
                                    ),
                                    html.Div(
                                        [html.H6(id="avgSpending"), html.P("3 months Average Spending")],
                                        id="numberOfTransactions",
                                        className="mini_container",
                                    ),
                                    html.Div(
                                        [html.H6(id="avgSaving"), html.P("3 months Average Saving")],
                                        id="numberOfTransactions",
                                        className="mini_container",
                                    ),
                                ],
                                id="info-container",
                                className="row container-display",
                            ),

                            html.Div(
                                [
                                    html.Div(
                                        [
                                            daq.LEDDisplay(
                                                id='daq-ld-income',
                                                color="#3a8f27",
                                                label={"label": "Income",
                                                       "style": {"font-size": "14px"}},
                                                size=20,
                                                style={}
                                            ),

                                            daq.LEDDisplay(
                                                id='daq-ld-spend',
                                                color="#FF5E5E",
                                                label={"label": "Spending",
                                                       "style": {"font-size": "14px"}},
                                                size=20,
                                                style={"margin-top": "30px"}
                                            ),

                                            daq.LEDDisplay(
                                                id='daq-ld-save',
                                                color="#277a8f",
                                                label={"label": "Saving",
                                                       "style": {"font-size": "14px"}},
                                                size=20,
                                                style={"margin-top": "30px"}
                                            ),
                                        ],
                                        id="saving",
                                        className="mini_container",
                                    ),
                                    html.Div(
                                        [
                                            dbc.Button(
                                                "Info", id="popover-limit-target-knob", color="info",
                                                className="bg-primary badge mr-1"
                                            ),
                                            dbc.Popover(
                                                [
                                                    dbc.PopoverHeader("Target", style={'font-size': '11px'}),
                                                    dbc.PopoverBody(
                                                        "View your target and track your goal progress."),
                                                ],
                                                id="popover-target-knob",
                                                is_open=False,
                                                style={'font-size': '11px'},
                                                target="popover-limit-target-knob",
                                            ),

                                            html.Div(id="target_status"),
                                            daq.Gauge(
                                                id="gauge_spending",
                                                showCurrentValue=True,
                                                style={"margin-left": "75px"}
                                            ),

                                            html.Div(children="Difficulty target level set to ​ ​",
                                                     style={"font-weight": "bold", "float": "left"}),
                                            html.Div(id="difficulty_level",
                                                     style={"color": "red", "font-weight": "bold", "float": "left"}),
                                            html.Div(children=", ​ ​",
                                                     style={"float": "left"}),
                                            html.Div(id="limit_level",
                                                     style={"float": "left"})

                                        ],
                                        id="spending",
                                        className="mini_container",
                                    ),

                                ],
                                id="info-container1",
                                className="row container-display",
                            ),

                        ],
                        id="right-column",
                        className="eight columns",
                    ),
                ],
                className="row flex-display",
            ),

            html.Div(
                [
                    html.Div(
                        id="banner_mini_category_limit",
                        children=
                        [dcc.Tabs(
                            id="mini-tabs-utilisation",
                            children=[
                                dcc.Tab(
                                    id="Specs-tab-utilisation",
                                    label=f'Utilisation breakdown in {iv.reporting_currency_symbol}',
                                    selected_className="custom-tab--selected",
                                    children=[
                                        dcc.Loading(
                                            id="loading-utilisation",
                                            children=[html.Div(
                                                [
                                                    dbc.Button(
                                                        "Info", id="popover-target-limit-utilisation", color="info",
                                                        className="bg-primary badge mr-1"
                                                    ),
                                                    dbc.Popover(
                                                        [
                                                            dbc.PopoverHeader(
                                                                "Credit Utilisation",
                                                                style={'font-size': '11px'}),
                                                            dbc.PopoverBody(
                                                                "Track your limit utilisation progress and set up your own individual limits."),
                                                        ],
                                                        id="popover-target-limit-util",
                                                        is_open=False,
                                                        style={'font-size': '11px'},
                                                        target="popover-target-limit-utilisation",
                                                    ),

                                                    budget.build_top_panel()
                                                ],
                                            )],
                                            type="default",
                                        )
                                    ],
                                ),
                                dcc.Tab(
                                    id="Specs-tab-transaction",
                                    label="Transactions",
                                    selected_className="custom-tab--selected",
                                    children=[
                                        dcc.Loading(
                                            id="loading-transaction-category-table",
                                            children=[
                                                dbc.Button(
                                                    "Info", id="popover-category-transactions-list", color="info",
                                                    className="bg-primary badge mr-1"
                                                ),
                                                dbc.Popover(
                                                    [
                                                        dbc.PopoverHeader("Transactions",
                                                                          style={'font-size': '11px'}),
                                                        dbc.PopoverBody(
                                                            "View your transactions."),
                                                    ],
                                                    id="popover-category-transactions",
                                                    is_open=False,
                                                    style={'font-size': '11px'},
                                                    target="popover-category-transactions-list",
                                                ),
                                                budget.build_transaction_table(iv.periods_plus_latest()[0])
                                            ],
                                            type="default",
                                        )
                                    ],
                                ),
                            ],
                        )],
                        className="pretty_container eight columns",
                    ),
                    html.Div(
                        id="banner_mini",
                        children=
                        [dcc.Tabs(
                            id="mini-tabs",
                            children=[
                                dcc.Tab(
                                    id="Specs-tab-category-trend",
                                    label="Category Predicted Trend",
                                    selected_className="custom-tab--selected",
                                    children=[
                                        dcc.Loading(
                                            id="loading-category-trend",
                                            children=[
                                                dbc.Button(
                                                    "Info", id="popover-target-category-trend", color="info",
                                                    className="bg-primary badge mr-1"
                                                ),
                                                dbc.Popover(
                                                    [
                                                        dbc.PopoverHeader("Category spending trend",
                                                                          style={'font-size': '11px'}),
                                                        dbc.PopoverBody(
                                                            "Shows you prediction of your spending. Check when you are likely to go over your target."),
                                                    ],
                                                    id="popover-category-trend",
                                                    is_open=False,
                                                    style={'font-size': '11px'},
                                                    target="popover-target-category-trend",
                                                ),
                                                budget.build_chart_panel(),
                                            ],
                                            type="default",
                                        )
                                    ],
                                ),
                            ],
                        )],
                        className="pretty_container five columns",
                    ),
                ],
                className="row flex-display",
            ),
        ],
        id="budgetContainer",
        style={"display": "flex", "flex-direction": "column"},
    )]
