# hook file for pyinstaller to copy required test_filkes from flask_restplus lib

import os
import importlib


package_imports = {'flask_restplus': {'templates': 'templates', 'swaggerui/bower': 'static/bower'}}

datas = []
for package, resources in package_imports.items():
    package_root = os.path.dirname(importlib.import_module(package).__file__)
    for destination, source in resources.items():
        datas.append((os.path.join(package_root, source),destination))
