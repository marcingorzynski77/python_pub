# -*- coding: utf-8 -*-
from flask_qrcode import QRcode


qr_code = None


def initialized_qr_code(code):
    global qr_code
    qr_code = code

