import dash_html_components as html
import logging
import dash_core_components as dcc
from utils import Header

logging = logging.getLogger(__name__)


def auth_button():
    return html.Div([
        dcc.Link(
            "Start Authorization",
            href="/authorization",
            className="button no-print",
        ),
    ])


def create_layout(app):
    return html.Div(
        [
            # page 2
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H5("Login Required"),
                                    html.Br([]),
                                    html.H6(
                                        "\
                                        You are two steps away from seeing your personalized financial information."
                                        ,
                                        style={"color": "#ffffff"},
                                        className="row",
                                    ),
                                    html.H6(
                                        "\
                                        Please follow the instructions below.",
                                        style={"color": "#ffffff"},
                                        className="row",
                                    ),
                                ],
                                className="message-panel",
                            ),

                        ],
                        className="row",
                    ),
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6("1. Login to your mobile application and go to QR scanner"),
                                ],
                            ),
                            html.Div(
                                [
                                    html.Img(src=app.get_asset_url("phone.gif"),
                                             style={'height': '50%', 'width': '50%'}),

                                ], style={'textAlign': 'center'}
                            ),
                            html.Div(
                                [
                                    html.H6("2. When ready start authorization process by clicking on the below button"),
                                ],
                            ),

                            html.Div(
                                [
                                    html.Br([]),
                                    html.Br([]),
                                    html.Br([]),
                                    auth_button(),

                                ], style={'textAlign': 'center'}
                            ),

                        ],
                        className="row",
                    ),

                ],
                className="sub_page",
            ),
        ],
        className="page",
    )
