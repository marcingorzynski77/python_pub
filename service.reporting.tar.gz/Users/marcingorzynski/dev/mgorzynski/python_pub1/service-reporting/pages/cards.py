import pandas as pd
import currency
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import logging

from model import Customer
from storage.cache import SessionCache
from utils import Header

logging = logging.getLogger(__name__)


def display_cards(data):
    grid_layout = []
    for index, card in data.cards.iterrows():
        grid_layout.append(create_card(card, data))
    return grid_layout


def create_card(card, data):
    # Row 1
    return html.Div(
        [
            html.Div(
                [
                    html.Div(
                        [
                            html.H6(
                                ["Card Key Information"], className="subtitle padded"
                            ),
                            html.Table(make_dash_table(card_to_frame(card))),
                        ],
                        className="six columns",
                    ),
                    html.Div(
                        [
                            html.H6(
                                ["Monthly spending"], className="subtitle padded"
                            ),
                            dcc.Graph(
                                id="graph-" + card['accountId'],
                                figure={
                                    "data": [
                                        go.Bar(
                                            x=data.data1y.balances_by_account.query(
                                                f'accountId=="{card["accountId"]}"')['month_desc'],
                                            y=data.data1y.balances_by_account.query(
                                                f'accountId=="{card["accountId"]}"')['totalSpend'],
                                            marker={
                                                "color": "#0d6519",
                                                "line": {
                                                    "color": "rgb(255, 255, 255)",
                                                    "width": 2,
                                                },
                                            },
                                            name=data.data1y.period_desc,
                                        ),
                                        go.Bar(
                                            x=data.data2y.balances_by_account.query(
                                                f'accountId=="{card["accountId"]}"')['month_desc'],
                                            y=data.data2y.balances_by_account.query(
                                                f'accountId=="{card["accountId"]}"')['totalSpend'],
                                            marker={
                                                "color": "#dddddd",
                                                "line": {
                                                    "color": "rgb(255, 255, 255)",
                                                    "width": 2,
                                                },
                                            },
                                            name=data.data2y.period_desc,
                                        ),
                                    ],
                                    "layout": go.Layout(
                                        autosize=True,
                                        bargap=0.35,
                                        font={"family": "Raleway", "size": 10},
                                        height=230,
                                        hovermode="closest",
                                        legend={
                                            "x": -0.0228945952895,
                                            "y": -0.189563896463,
                                            "orientation": "h",
                                            "yanchor": "top",
                                        },
                                        margin={
                                            "r": 0,
                                            "t": 20,
                                            "b": 10,
                                            "l": 30,
                                        },
                                        showlegend=True,
                                        title="",

                                        xaxis={
                                            "autorange": True,
                                            "range": [-0.5, 4.5],
                                            "showline": True,
                                            "title": "",
                                            "type": "category",
                                        },
                                        yaxis={
                                            "autorange": True,
                                            "range": [0, 22.9789473684],
                                            "showgrid": True,
                                            "showline": True,
                                            "title": "",
                                            "tickprefix": data.reporting_currency_symbol,
                                            "type": "linear",
                                            "zeroline": False,
                                        },
                                    ),
                                },
                                config={"displayModeBar": False},
                            )
                        ],
                        className="six columns",
                    ),
                ],
                className="row",
                style={"margin-bottom": "5px"},
            ),
        ]
    )


def create_layout(app, user_id: str):
    data: Customer = SessionCache.get_customer(user_id)

    # Page layouts
    return html.Div(
        [
            html.Div([Header(app)]),
            html.Div(
                display_cards(data),
                className="sub_page",
            ),
        ],
        # page 1
        className="page",
    )


def card_to_frame(card):
    df = pd.DataFrame(data=[
        ['Provider', card['providerId']],
        ['type', card['type']],
        ['Balance', currency.symbol(card['currency'])+str(card['balance'])],
        ['Credit Limit', currency.symbol(card['currency'])+str(round(card['creditLimit']))],
        ['Currency', card['currency']],
        ['Card Number', card['partialCardNumber']],
    ])
    return df


def make_dash_table(df):
    """ Return a dash definition of an HTML table for a Pandas dataframe """
    table = []
    if df is not None:
        for index, row in df.iterrows():
            html_row = []
            for i in range(len(row)):
                html_row.append(html.Td([row[i]]))
            table.append(html.Tr(html_row))
    return table
