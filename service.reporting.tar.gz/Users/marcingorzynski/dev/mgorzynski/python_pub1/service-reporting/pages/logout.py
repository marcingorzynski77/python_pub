import dash_core_components as dcc
import dash_html_components as html
import logging
from apps.app_dash_index import app
from dash.dependencies import Input, Output
from storage.cache import SessionCache

logging = logging.getLogger(__name__)


def create_layout():
    SessionCache.reset()
    return html.Div(
        [
            dcc.Location(id='url_logout', refresh=True),
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H5("User disconnected"),
                                    html.Br([]),
                                    html.H6(
                                        "\
                                        Please login to view your personalized overview again"
                                        ,
                                        className="row",
                                    ),
                                    html.Br([]),
                                    html.Button(id='back-button', children='Go back', n_clicks=0)
                                ],
                            ),

                        ],
                        className="row",
                    ),
                ],
                className="sub_page",
            ),
        ],
        className="page",
    )


# Create callbacks
@app.callback(Output('url_logout', 'pathname'),
              [Input('back-button', 'n_clicks')])
def logout_dashboard(n_clicks):
    if n_clicks > 0:
        return '/login'