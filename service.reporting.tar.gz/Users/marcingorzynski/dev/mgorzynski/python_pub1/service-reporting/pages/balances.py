import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import logging
from model import Customer
from storage.cache import SessionCache
from utils import Header, make_dash_table


logging = logging.getLogger(__name__)


def create_layout(app, user_id: str):
    data: Customer = SessionCache.get_customer(user_id)

    return html.Div(
        [
            Header(app),
            # page 3
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Balances for period " + data.data1y.period_desc
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.Div(
                                        [
                                            html.Table(
                                                make_dash_table(data.data1y.balances_by_month_table_display),
                                                className="tiny-header",
                                            )
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="six columns",
                            ),
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Period - " + data.data2y.period_desc
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.Div(
                                        [
                                            html.Table(
                                                make_dash_table(data.data2y.balances_by_month_table_display),
                                                className="tiny-header",
                                            )
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="six columns",
                            )
                        ],
                        className="row ",
                    ),
                    # Row 2
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Stats for period " + data.data1y.period_desc
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.Div(
                                        [
                                            html.Table(
                                                make_dash_table(data.data1y.calc_balances_stats_display.head(3))),
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="six columns",
                            ),
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Stats for period " + data.data2y.period_desc
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.Div(
                                        [
                                            html.Table(
                                                make_dash_table(data.data2y.calc_balances_stats_display.head(3))),
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="six columns",
                            ),
                        ],
                        className="row ",
                    ),
                    # Row 3
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Min/Max for period " + data.data1y.period_desc
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.Div(
                                        [
                                            html.Table(
                                                make_dash_table(data.data1y.calc_balances_stats_display.tail(4))),
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="six columns",
                            ),
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Min/Max for period " + data.data2y.period_desc
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.Div(
                                        [
                                            html.Table(
                                                make_dash_table(data.data2y.calc_balances_stats_display.tail(4))),
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="six columns",
                            ),
                        ],
                        className="row ",
                    ),
                    # Row 4
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Br([]),
                                    html.Strong("Total income - " +
                                                data.data1y.period_desc,
                                                style={"color": "#3a3a3a"},
                                                ),
                                    dcc.Graph(
                                        id="graph-12",
                                        figure={
                                            "data": [
                                                go.Bar(
                                                    x=["Total Income "],
                                                    y=[data.data1y.calc_balances_stats.take([3]).iloc[0][1]],
                                                    marker={"color": "#0d6519"},
                                                    name="A",
                                                ),
                                                go.Bar(
                                                    x=["Total Spend"],
                                                    y=[data.data1y.calc_balances_stats.take([4]).iloc[0][1]],
                                                    marker={"color": " #dddddd"},
                                                    name="B",
                                                ),
                                                go.Bar(
                                                    x=["Total Saving"],
                                                    y=[data.data1y.calc_balances_stats.take([5]).iloc[0][1]],
                                                    marker={"color": " #3a3a3a"},
                                                    name="C",
                                                ),
                                            ],
                                            "layout": go.Layout(
                                                annotations=[

                                                ],
                                                autosize=True,
                                                height=260,
                                                width=320,
                                                bargap=0.4,
                                                hovermode="closest",
                                                margin={
                                                    "r": 40,
                                                    "t": 20,
                                                    "b": 20,
                                                    "l": 40,
                                                },
                                                showlegend=False,
                                                title="",
                                                xaxis={
                                                    "autorange": True,
                                                    "showline": True,
                                                    "tickfont": {
                                                        "family": "Arial sans serif",
                                                        "size": 8,
                                                    },
                                                    "title": "",
                                                    "type": "category",
                                                    "zeroline": False,
                                                },
                                                yaxis={
                                                    "autorange": True,
                                                    "mirror": False,
                                                    "nticks": 3,
                                                    "showgrid": True,
                                                    "showline": True,
                                                    "tickfont": {
                                                        "family": "Arial sans serif",
                                                        "size": 10,
                                                    },
                                                    "tickprefix": data.reporting_currency_symbol,
                                                    "title": "",
                                                    "type": "linear",
                                                    "zeroline": False,
                                                },
                                            ),
                                        },
                                        config={"displayModeBar": False},
                                    ),
                                ],
                                className="six columns",
                            ),
                            html.Div(
                                [
                                    html.Br([]),
                                    html.Strong("Total income - " +
                                                data.data2y.period_desc,
                                                style={"color": "#3a3a3a"},
                                                ),
                                    dcc.Graph(
                                        id="graph-12",
                                        figure={
                                            "data": [
                                                go.Bar(
                                                    x=["Total Income "],
                                                    y=[data.data2y.calc_balances_stats.take([3]).iloc[0][1]],
                                                    marker={"color": "#0d6519"},
                                                    name="A",
                                                ),
                                                go.Bar(
                                                    x=["Total Spend"],
                                                    y=[data.data2y.calc_balances_stats.take([4]).iloc[0][1]],
                                                    marker={"color": " #dddddd"},
                                                    name="B",
                                                ),
                                                go.Bar(
                                                    x=["Total Saving"],
                                                    y=[data.data2y.calc_balances_stats.take([5]).iloc[0][1]],
                                                    marker={"color": " #3a3a3a"},
                                                    name="C",
                                                ),
                                            ],
                                            "layout": go.Layout(
                                                annotations=[

                                                ],
                                                autosize=True,
                                                height=260,
                                                width=320,
                                                bargap=0.4,
                                                hovermode="closest",
                                                margin={
                                                    "r": 40,
                                                    "t": 20,
                                                    "b": 20,
                                                    "l": 40,
                                                },
                                                showlegend=False,
                                                title="",
                                                xaxis={
                                                    "autorange": True,
                                                    "showline": True,
                                                    "tickfont": {
                                                        "family": "Arial sans serif",
                                                        "size": 8,
                                                    },
                                                    "title": "",
                                                    "type": "category",
                                                    "zeroline": False,
                                                },
                                                yaxis={
                                                    "autorange": True,
                                                    "mirror": False,
                                                    "nticks": 3,
                                                    "showgrid": True,
                                                    "showline": True,
                                                    "tickfont": {
                                                        "family": "Arial sans serif",
                                                        "size": 10,
                                                    },
                                                    "tickprefix": data.reporting_currency_symbol,
                                                    "title": "",
                                                    "type": "linear",
                                                    "zeroline": False,
                                                },
                                            ),
                                        },
                                        config={"displayModeBar": False},
                                    ),
                                ],
                                className="six columns",
                            ),
                        ],
                        className="row ",
                    ),
                ],
                className="sub_page",
            ),
        ],
        className="page",
    )
