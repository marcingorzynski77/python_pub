import dash_core_components as dcc
import dash_html_components as html
import logging
from storage.rest import ErisApi
from utils import Header
from app_qr_code import qr_code
from flask import request
from apps.app_dash_report import app
from dash.dependencies import Input, Output, State
from flask import session
from storage.cache import SessionCache


logging = logging.getLogger(__name__)
data_rest: ErisApi = ErisApi()


def login_button():
    return html.Div([
        dcc.Link(
            "Logout",
            href="/logout",
            className="button no-print",
            style={'position': "absolute", 'top': '-40', 'right': '0'}
        ),
    ])


def create_layout():
    ip = request.remote_addr
    logging.info(f'requesting token for ip {ip}')
    token = data_rest.get_auth_token(ip)
    SessionCache.set_token(token['token'])
    logging.info(f'received token {token["token"]} ')

    return html.Div(
        [
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H5("Authorization Process"),
                                    html.Br([]),
                                    html.H6(
                                        "\
                                        Please follow two steps described below"
                                        ,
                                        style={"color": "#ffffff"},
                                        className="row",
                                    ),
                                ],
                                className="message-panel",
                            ),

                        ],
                        className="row",
                    ),
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        "1. Scan the QR code with your phone"),
                                ]
                            ),
                            html.Div(
                                [
                                    html.Img(src=app.get_asset_url("qrcode_scan.gif"),
                                             style={'height': '50%', 'width': '50%'}),
                                ], style={'textAlign': 'center'}
                            ),
                            html.Div(
                                [
                                    html.Br([]),
                                    html.Br([]),
                                    html.Img(src=qr_code(SessionCache.get_token()),
                                             ),

                                ], style={'textAlign': 'center'}
                            ),
                            html.Div(
                                [
                                    html.Br([]),
                                    html.Br([]),
                                    html.H6("2. Enter code displayed in your mobile app and press login"),
                                    html.Br([]),

                                ],
                            ),
                            dcc.Location(id='url_login', refresh=True),
                            html.Div(
                                # method='Post',
                                children=[
                                    dcc.Input(
                                        placeholder='Enter code',
                                        type='text',
                                        id='uname-box',
                                        n_submit=0,
                                        style={'margin': '5px'}
                                    ),
                                    html.Button(
                                        children='Login',
                                        n_clicks=0,
                                        type='submit',
                                        disabled=False,
                                        id='login-button'
                                    ),
                                    html.Div(children='', id='output-state', style={"color": "red"})
                                ], style={'textAlign': 'center'}
                            ),

                            # html.Div(
                            #     [
                            #         html.Br([]),
                            #         html.Br([]),
                            #         html.A(['Try Again'], href='/financial-report/authorization',
                            #                className="button no-print",
                            #                )
                            #     ],
                            # ),
                        ],
                        className="row",
                    ),

                ],
                className="sub_page",
            ),
        ],
        className="page",
    )


@app.callback(Output('output-state', 'children'),
              [Input('login-button', 'n_clicks'),
               Input('uname-box', 'n_submit')],
              [State('uname-box', 'value')])
def update_output(n_clicks, n_submit, input1):
    if (n_clicks > 0 or n_submit > 0) and input1 is not None:
        res: str = data_rest.verify_auth_code(token=session.get('token'), code=input1)
        if res['response'] == "ok":
            SessionCache.set_user(res['userId'])
            SessionCache.set_token(None)
            return ''
        elif res['response'] == "code not valid":
            return 'code is not valid'
        elif res['response'] == "not found":
            return 'you have taken too long to authenticate , please refresh page and try again'
        else:
            return 'unable to authorize , please try again'
    else:
        return ''


@app.callback(Output('url_login', 'pathname'),
              [Input('login-button', 'n_clicks'),
               Input('uname-box', 'n_submit')],
              [State('uname-box', 'value')])
def success(n_clicks, n_submit, input1):
    if (n_clicks > 0 or n_submit > 0) and input1 is not None:
        res: str = data_rest.verify_auth_code(token=session.get('token'), code=input1)
        if res['response'] == "ok":
            session.permanent = True
            SessionCache.set_user(res['userId'])
            SessionCache.set_token(None)
            return '/loading'
        else:
            pass
    else:
        pass

