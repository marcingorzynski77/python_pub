import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import logging
from model import Customer
from storage.rest import ErisApi
from utils import Header, make_dash_table
from storage.cache import SessionCache

logging = logging.getLogger(__name__)
data_rest: ErisApi = ErisApi()


def create_layout(app, user_id: str):
    data: Customer = SessionCache.get_customer(user_id)

    return html.Div(
        [
            Header(app),
            # page 2
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H5("Report Summary"),
                                    html.Br([]),
                                    html.P(
                                        "\
                                        This is spending overview comparing 2 years of your financial history. " \
                                        "You are able to navigate through categories, merchants and balances comparing" \
                                        " how your spending patterns changed over the year. " \
                                        "You can also search transactions and export them to csv for further analysis " \
                                        "if required.",
                                        style={"color": "#ffffff"},
                                        className="row",
                                    ),
                                ],
                                className="product",
                            )
                        ],
                        className="row",
                    ),
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        ["Key Indicators"], className="subtitle padded"
                                    ),
                                    html.Table(make_dash_table(data.yearly_stats_display)),
                                    html.H6(
                                        "Risk Profile", className="subtitle padded"
                                    ),
                                    html.Img(
                                        src=app.get_asset_url("risk_reward_5.png"),
                                        className="risk-reward",
                                    ),
                                ],
                                className="six columns",
                            ),
                            html.Div(
                                [
                                    html.H6(
                                        "Year by year comparison",
                                        className="subtitle padded",
                                    ),
                                    dcc.Graph(
                                        id="graph-01",
                                        figure={
                                            "data": [
                                                go.Bar(
                                                    x=[
                                                        "Income",
                                                        "Spending",
                                                    ],
                                                    y=[
                                                        data.yearly_stats.loc['Total Income', 'value_y'],
                                                        data.yearly_stats.loc['Total Spend', 'value_y'],
                                                    ],
                                                    marker={
                                                        "color": "#dddddd",
                                                        "line": {
                                                            "color": "rgb(255, 255, 255)",
                                                            "width": 2,
                                                        },
                                                    },
                                                    name=data.data2y.period_desc,
                                                ),
                                                go.Bar(
                                                    x=[
                                                        "Income",
                                                        "Spending",
                                                    ],
                                                    y=[
                                                        data.yearly_stats.loc['Total Income', 'value_x'],
                                                        data.yearly_stats.loc['Total Spend', 'value_x'],
                                                    ],
                                                    marker={
                                                        "color": "#0d6519",
                                                        "line": {
                                                            "color": "rgb(255, 255, 255)",
                                                            "width": 2,
                                                        },
                                                    },
                                                    name=data.data1y.period_desc,
                                                ),
                                            ],
                                            "layout": go.Layout(
                                                autosize=False,
                                                bargap=0.35,
                                                font={"family": "Raleway", "size": 10},
                                                height=315,
                                                hovermode="closest",
                                                legend={
                                                    "x": -0.0228945952895,
                                                    "y": -0.189563896463,
                                                    "orientation": "h",
                                                    "yanchor": "top",
                                                },
                                                margin={
                                                    "r": 0,
                                                    "t": 20,
                                                    "b": 10,
                                                    "l": 50,
                                                },
                                                showlegend=True,
                                                title="",
                                                width=330,
                                                xaxis={
                                                    "autorange": True,
                                                    "range": [-0.5, 4.5],
                                                    "showline": True,
                                                    "title": "",
                                                    "type": "category",
                                                },
                                                yaxis={
                                                    "autorange": True,
                                                    "range": [0, 22.9789473684],
                                                    "showgrid": True,
                                                    "showline": True,
                                                    "tickprefix": data.reporting_currency_symbol,
                                                    "type": "linear",
                                                    "zeroline": False,
                                                },
                                            ),
                                        },
                                        config={"displayModeBar": False},
                                    ),
                                ],
                                className="six columns",
                            ),
                        ],
                        className="row",
                        style={"margin-bottom": "5px"},
                    ),
                    # Row 2
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6("Income vs Spend comparison for " + data.data1y.period_desc, className="subtitle padded"),
                                    dcc.Graph(
                                        id="graph-4",
                                        figure={
                                            "data": [
                                                go.Scatter(
                                                    x=data.data1y.balances["date"],
                                                    y=data.data1y.balances["totalIncome"],
                                                    line={"color": "#0d6519"},
                                                    mode="lines",
                                                    name="Income",
                                                ),
                                                go.Scatter(
                                                    x=data.data1y.balances["date"],
                                                    y=data.data1y.balances["totalSpend"],
                                                    line={"color": "#b5b5b5"},
                                                    mode="lines",
                                                    name="Spend",
                                                ),
                                            ],
                                            "layout": go.Layout(
                                                autosize=True,
                                                width=700,
                                                height=200,
                                                font={"family": "Raleway", "size": 10},
                                                margin={
                                                    "r": 30,
                                                    "t": 30,
                                                    "b": 30,
                                                    "l": 30,
                                                },
                                                showlegend=True,
                                                titlefont={
                                                    "family": "Raleway",
                                                    "size": 10,
                                                },
                                                xaxis={
                                                    "autorange": True,
                                                    "range": [
                                                        "2007-12-31",
                                                        "2018-03-06",
                                                    ],
                                                    "rangeselector": {
                                                        "buttons": [
                                                            {
                                                                "label": "All",
                                                                "step": "all",
                                                            },
                                                        ]
                                                    },
                                                    "showline": True,
                                                    "type": "date",
                                                    "zeroline": False,
                                                },
                                                yaxis={
                                                    "autorange": True,
                                                    "tickprefix": data.reporting_currency_symbol,
                                                    "showline": True,
                                                    "type": "linear",
                                                    "zeroline": False,
                                                },
                                            ),
                                        },
                                        config={"displayModeBar": False},
                                    ),
                                ],
                                className="twelve columns",
                            )
                        ],
                        className="row",
                    ),
                    # Row 3
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6("Income vs Spend comparison for " + data.data2y.period_desc, className="subtitle padded"),
                                    dcc.Graph(
                                        id="graph-4.1",
                                        figure={
                                            "data": [
                                                go.Scatter(
                                                    x=data.data2y.balances["date"],
                                                    y=data.data2y.balances["totalIncome"],
                                                    line={"color": "#0d6519"},
                                                    mode="lines",
                                                    name="Income",
                                                ),
                                                go.Scatter(
                                                    x=data.data2y.balances["date"],
                                                    y=data.data2y.balances["totalSpend"],
                                                    line={"color": "#b5b5b5"},
                                                    mode="lines",
                                                    name="Spend",
                                                ),
                                            ],
                                            "layout": go.Layout(
                                                autosize=True,
                                                width=700,
                                                height=200,
                                                font={"family": "Raleway", "size": 10},
                                                margin={
                                                    "r": 30,
                                                    "t": 30,
                                                    "b": 30,
                                                    "l": 30,
                                                },
                                                showlegend=True,
                                                titlefont={
                                                    "family": "Raleway",
                                                    "size": 10,
                                                },
                                                xaxis={
                                                    "autorange": True,
                                                    "range": [
                                                        "2007-12-31",
                                                        "2018-03-06",
                                                    ],
                                                    "rangeselector": {
                                                        "buttons": [
                                                            {
                                                                "label": "All",
                                                                "step": "all",
                                                            },
                                                        ]
                                                    },
                                                    "showline": True,
                                                    "type": "date",
                                                    "zeroline": False,
                                                },
                                                yaxis={
                                                    "autorange": True,
                                                    "tickprefix": data.reporting_currency_symbol,
                                                    "showline": True,
                                                    "type": "linear",
                                                    "zeroline": False,
                                                },
                                            ),
                                        },
                                        config={"displayModeBar": False},
                                    ),
                                ],
                                className="twelve columns",
                            )
                        ],
                        className="row",
                    ),

                ],
                className="sub_page",
            ),
        ],
        className="page",
    )
