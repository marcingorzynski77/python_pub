import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import logging

from model import Customer
from storage.cache import SessionCache
from utils import Header, make_dash_table


logging = logging.getLogger(__name__)


def create_layout(app, user_id: str):
    data: Customer = SessionCache.get_customer(user_id)
    # Page layouts
    return html.Div(
        [
            html.Div([Header(app)]),
            # page 1
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        ["Top 10 categories - " + data.data1y.period_desc], className="subtitle padded"
                                    ),
                                    html.Table(make_dash_table(data.data1y.categories_display.head(10))),
                                ],
                                className="six columns",
                            ),
                            html.Div(
                                [
                                    html.H6(
                                        ["Top 10 categories - " + data.data2y.period_desc], className="subtitle padded"
                                    ),
                                    html.Table(make_dash_table(data.data2y.categories_display.head(10))),
                                ],
                                className="six columns",
                            ),
                        ],
                        className="row",
                        style={"margin-bottom": "5px"},
                    ),
                    # Row 2
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        "Year by year category spend comparison",
                                        className="subtitle padded",
                                    ),
                                    dcc.Graph(
                                        id="graph-1",
                                        figure={
                                            "data": [
                                                go.Bar(
                                                    x=data.data1y.category_names_display.head(10),
                                                    y=data.data1y.category_values_display.head(10),
                                                    marker={
                                                        "color": "#0d6519",
                                                        "line": {
                                                            "color": "rgb(255, 255, 255)",
                                                            "width": 2,
                                                        },
                                                    },
                                                    name=data.data1y.period_desc,
                                                ),
                                                go.Bar(
                                                    x=data.data2y.category_names_display.head(10),
                                                    y=data.data2y.category_values_display.head(10),
                                                    marker={
                                                        "color": "#dddddd",
                                                        "line": {
                                                            "color": "rgb(255, 255, 255)",
                                                            "width": 2,
                                                        },
                                                    },
                                                    name=data.data2y.period_desc,
                                                ),
                                            ],
                                            "layout": go.Layout(
                                                autosize=True,
                                                bargap=0.35,
                                                font={"family": "Raleway", "size": 10},
                                                height=300,
                                                hovermode="closest",
                                                legend={
                                                    "x": -0.0228945952895,
                                                    "y": -0.189563896463,
                                                    "orientation": "h",
                                                    "yanchor": "top",
                                                },
                                                margin={
                                                    "r": 0,
                                                    "t": 20,
                                                    "b": 10,
                                                    "l": 30,
                                                },
                                                showlegend=True,
                                                title="",

                                                xaxis={
                                                    "autorange": True,
                                                    "range": [-0.5, 4.5],
                                                    "showline": True,
                                                    "title": "",
                                                    "type": "category",
                                                },
                                                yaxis={
                                                    "autorange": True,
                                                    "range": [0, 22.9789473684],
                                                    "showgrid": True,
                                                    "showline": True,
                                                    "title": "",
                                                    "tickprefix": data.reporting_currency_symbol,
                                                    "type": "linear",
                                                    "zeroline": False,
                                                },
                                            ),
                                        },
                                        config={"displayModeBar": False},
                                    ),
                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row",
                        style={"margin-bottom": "10px"},
                    ),
                    # Row 3
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        ["Top 10 combined category summary from " + data.data2y.period_start + " to " + data.data1y.period_end], className="subtitle padded"
                                    ),
                                    dcc.Graph(id='category_usage',
                                              figure=go.Figure(
                                                  data=[go.Pie(labels=data.categories_combined['categoryName'].head(10),
                                                               values=data.categories_combined['spend'].abs().head(10),
                                                               marker={'colors': [
                                                                 '#D8EC8F',
                                                                 '#CFF0CC',
                                                                 '#E8F48C',
                                                                 '#77DD77',
                                                                 '#03C03C',
                                                                 '#2C5F2D',
                                                                 '#309455',
                                                                 '#9cd3b3',
                                                                 '#ccef51',
                                                                 '#b8cc74',
                                                                 '#66762d',
                                                                 '#e2eac8',
                                                                 '#a1a29e',
                                                                 '#dedfdd',
                                                                 '#e8e913',
                                                                 '#c6c735',
                                                                ]
                                                            },
                                                               )
                                                        ],
                                                  layout=go.Layout(
                                                      title=''
                                                  )
                                              )),
                                ],
                                className="twelve columns",
                            ),
                        ],
                        className="row"
                    ),
                ],
                className="sub_page",
            ),
        ],
        className="page",
    )
