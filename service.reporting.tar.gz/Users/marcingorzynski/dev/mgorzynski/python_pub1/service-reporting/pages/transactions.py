import dash_html_components as html
import dash_table
import logging
from datetime import datetime as dt
from model import Customer
from storage.cache import SessionCache
from storage.rest import ErisApi
import dash_core_components as dcc

from utils import Header

logging = logging.getLogger(__name__)
data_rest: ErisApi = ErisApi()


def create_layout(app, user_id: str):
    data: Customer = SessionCache.get_customer(user_id)
    tran_data: Customer = SessionCache.get_customer_transactions(user_id)

    return html.Div(
        [
            Header(app),
            # page 3
            html.Div(
                [
                    # Row 1
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.H6(
                                        [
                                            "Transactions for period - " + data.data2y.period_start + " to " + data.data1y.period_end
                                        ],
                                        className="subtitle padded",
                                    ),
                                    html.A("Download Transactions in CSV format", href="/api/financial-report/transaction/csv"),
                                    # dcc.DatePickerRange(
                                    #     id='my-date-picker-range',
                                    #     min_date_allowed=dt(1995, 8, 5),
                                    #     max_date_allowed=dt(2017, 9, 19),
                                    #     initial_visible_month=dt(2017, 8, 5),
                                    #     end_date=dt(2017, 8, 25)
                                    # ),
                                    html.Div(
                                        [
                                            dash_table.DataTable(
                                                id='datatable-interactivity',
                                                columns=[
                                                    {"name": i, "id": i, "deletable": False, "selectable": False} for i
                                                    in
                                                    tran_data.transactions.columns
                                                ],
                                                data=tran_data.transactions.to_dict('records'),
                                                editable=False,
                                                filter_action="native",
                                                sort_action="native",
                                                sort_mode="multi",
                                                column_selectable="single",
                                                row_deletable=False,
                                                selected_columns=[],
                                                page_action="native",
                                                page_current=0,
                                                page_size=50,

                                                style_table={'overflowX': 'scroll'},
                                                style_cell={
                                                    'font-size': '10px',
                                                    'font- family': 'Raleway, HelveticaNeue, Helvetica Neue,Helvetica, Arial, sans-serif',
                                                    'text-align': 'center',
                                                    'minWidth': '50px', 'width': '180px', 'maxWidth': '180px',
                                                    'overflow': 'hidden',
                                                    'textOverflow': 'ellipsis',
                                                },
                                                style_cell_conditional=[
                                                    {
                                                        'if': {'column_id': c},
                                                        'textAlign': 'left'
                                                    } for c in ['Date', 'Region']
                                                ],
                                                style_data_conditional=[
                                                    {
                                                        'if': {'row_index': 'odd'},
                                                        'backgroundColor': 'rgb(248, 248, 248)'
                                                    }
                                                ],
                                                style_header={
                                                    'backgroundColor': 'rgb(230, 230, 230)',
                                                    'fontWeight': 'bold'
                                                }

                                            ),
                                            html.Div(id='datatable-interactivity-container')
                                        ],
                                        style={"overflow-x": "auto"},
                                    ),
                                ],
                                className="twelve columns",
                            )
                        ],
                        className="row ",
                    ),
                ],
                className="sub_page",
            ),
        ],
        className="page",
    )

#
# @app.callback(
#     Output('datatable-interactivity', 'style_data_conditional'),
#     [Input('datatable-interactivity', 'selected_columns')]
# )
# def update_styles(selected_columns):
#     return [{
#         'if': { 'column_id': i },
#         'background_color': '#D2F3FF'
#     } for i in selected_columns]
#
#
# @app.callback(
#     Output('datatable-interactivity-container', "children"),
#     [Input('datatable-interactivity', "derived_virtual_data"),
#      Input('datatable-interactivity', "derived_virtual_selected_rows")])
# def update_graphs(rows, derived_virtual_selected_rows):
#     # When the table is first rendered, `derived_virtual_data` and
#     # `derived_virtual_selected_rows` will be `None`. This is due to an
#     # idiosyncracy in Dash (unsupplied properties are always None and Dash
#     # calls the dependent callbacks when the component is first rendered).
#     # So, if `rows` is `None`, then the component was just rendered
#     # and its value will be the same as the component's dataframe.
#     # Instead of setting `None` in here, you could also set
#     # `derived_virtual_data=df.to_rows('dict')` when you initialize
#     # the component.
#     if derived_virtual_selected_rows is None:
#         derived_virtual_selected_rows = []
#
#     dff = df if rows is None else pd.DataFrame(rows)
#
#     colors = ['#7FDBFF' if i in derived_virtual_selected_rows else '#0074D9'
#               for i in range(len(dff))]
#
#     return [
#         dcc.Graph(
#             id=column,
#             figure={
#                 "data": [
#                     {
#                         "x": dff["country"],
#                         "y": dff[column],
#                         "type": "bar",
#                         "marker": {"color": colors},
#                     }
#                 ],
#                 "layout": {
#                     "xaxis": {"automargin": True},
#                     "yaxis": {
#                         "automargin": True,
#                         "title": {"text": column}
#                     },
#                     "height": 250,
#                     "margin": {"t": 10, "l": 10, "r": 10},
#                 },
#             },
#         )
#         # check if column exists - user may have deleted it
#         # If `column.deletable=False`, then you don't
#         # need to do this check.
#         for column in ["pop", "lifeExp", "gdpPercap"] if column in dff
#     ]
