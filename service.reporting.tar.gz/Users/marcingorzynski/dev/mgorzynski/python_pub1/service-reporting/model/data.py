import pandas as pd
import datetime as dt
import logging
import currency

logging = logging.getLogger(__name__)


class Customer(object):
    # storage for the instance reference
    def __init__(self):
        self.user: pd.DataFrame = None
        self.total_balance: float = 0
        self.last_updated: dt.date = None
        self.__reporting_currency: str = ''
        self.__reporting_currency_symbol: str = ''
        self.total_credit: float = 0
        self.accounts: pd.DataFrame = None
        self.cards: pd.DataFrame = None
        self.data1y: PeriodData = None
        self.data2y: PeriodData = None

        self.categories_combined: pd.DataFrame = None
        self.merchants_combined: pd.DataFrame = None
        self.yearly_stats: pd.DataFrame = None
        self.yearly_stats_display: pd.DataFrame = None
        self.transactions: pd.DataFrame = None

    @property
    def reporting_currency_symbol(self):
        return self.__reporting_currency_symbol

    @property
    def reporting_currency(self):
        return self.__reporting_currency

    @reporting_currency.setter
    def reporting_currency(self, cur: str):
        self.__reporting_currency = cur
        self.__reporting_currency_symbol = currency.symbol(cur)

    def combine_categories(self):
        combined = pd.concat([self.data1y.categories, self.data2y.categories])
        self.categories_combined = combined.groupby("categoryName").sum().reset_index()
        self.categories_combined = self.categories_combined[['categoryName', 'spend']]
        self.categories_combined = self.categories_combined.sort_values('spend')

    def combine_merchants(self):
        combined = pd.concat([self.data1y.merchants, self.data2y.merchants])
        self.merchants_combined = combined.groupby("merchantName").sum().reset_index()
        self.merchants_combined = self.merchants_combined[['merchantName', 'spend']]
        self.merchants_combined = self.merchants_combined.sort_values('spend')

    def produce_yearly_stats(self):
        y1 = self.data1y.calc_balances_stats
        y2 = self.data2y.calc_balances_stats

        y1 = y1.set_index(['type'])
        y2 = y2.set_index(['type'])

        y12 = pd.merge(y1, y2, left_on='type', right_on='type')
        y12['diff'] = y12['value_x'] - y12['value_y']
        y12['percentage'] = 0

        for index, row in y12.iterrows():
            if row['diff'] > 0:
                row['percentage'] = round((1 - (row['value_y'] / row['value_x'])) * 100)
            else:
                row['percentage'] = 1 - round((1 - (row['value_x'] / row['value_y'])) * 100)

        y12['desc'] = y12['diff'].apply(self.desc_display)
        income_desc = "Your income " + y12.loc['Total Income', 'desc'] \
                      + " " + str(int(abs(y12.loc['Total Income', 'percentage']))) + " %"

        spend_desc = "Your spend " + y12.loc['Total Spend', 'desc'] \
                     + " " + str(int(abs(y12.loc['Total Spend', 'percentage']))) + " %"

        save_desc = "Your savings " + y12.loc['Total Saving', 'desc'] \
                    + " " + str(int(abs(y12.loc['Total Saving', 'percentage']))) + " %"

        self.yearly_stats = y12

        self.yearly_stats_display = pd.DataFrame(data=[
            [income_desc],
            [spend_desc],
            [save_desc],
        ])

    def desc_display(self, percentage):
        if percentage > 0:
            return " increased over last year by"
        else:
            return " decreased over last year by"


class PeriodData(object):
    # storage for the instance reference
    def __init__(self, reporting_currency: str):
        self.__balances: pd.DataFrame = None
        self.__balances_by_account: pd.DataFrame = None
        self.__categories: pd.DataFrame = None
        self.categories_display: pd.DataFrame = None
        self.__category_names_display = None
        self.__category_values_display = None
        self.period_desc = None
        self.__balances_by_month: pd.DataFrame = None
        self.__balances_by_month_table: pd.DataFrame = None
        self.__calc_balances_stats: pd.DataFrame = None
        self.calc_balances_stats_display: pd.DataFrame = None
        self.balances_by_month_table_display: pd.DataFrame = None
        self.reporting_currency: str = reporting_currency
        self.reporting_currency_symbol: str = currency.symbol(reporting_currency)
        self.period_start = None
        self.period_end = None

        self.__merchants: pd.DataFrame = None
        self.merchants_display: pd.DataFrame = None
        self.__merchant_names_display = None
        self.__merchant_values_display = None

        self.__transactions: pd.DataFrame = None

    @property
    def transactions(self):
        return self.__transactions

    @transactions.setter
    def transactions(self, transactions: str):
        self.__transactions = transactions.copy()[
            ['amount', 'transactionClassification', 'merchantName', 'updateTimestamp', 'providerId', 'description',
             'currency', 'accountId']]
        self.__transactions.columns = ['Amount', 'Category', 'Merchant', 'Date', 'Provider', 'Description', 'Currency',
                                       'AccountId']
        self.__transactions.loc[:, 'Date'] = self.__transactions['Date'].apply(self.date_to_full_display)

    def date_to_full_display(self, date):
        return date[:10]

    @property
    def balances(self):
        return self.__balances

    @balances.setter
    def balances(self, balances: pd.DataFrame):
        balances['day'] = 1
        balances['totalSpend'] = balances['totalSpend'].abs()
        dates = balances[['year', 'month', 'day']]
        date_series = pd.to_datetime(dates)
        balances['date'] = date_series
        balances.sort_values(by='date', inplace=True)
        balances.loc[:, 'month_desc'] = balances['date'].apply(self.date_to_month_display)

        self.__balances_by_account = balances
        self.__balances = balances[
            ['balance', 'year', 'month', 'date', 'month_desc', 'totalIncome', 'totalSpend', 'totalSaving']]
        self.__balances.loc[:, 'totalSaving'] = balances.loc[:, 'totalIncome'] - balances.loc[:, 'totalSpend']
        self.__balances = self.__balances.groupby(['year', 'month', 'date', 'month_desc']).sum().reset_index()
        self.__balances.sort_values(by='date', inplace=True, ascending=False)

        self.balances_by_month = self.__balances
        self.balances_by_month_table = self.__balances
        self.calc_balances_stats = self.__balances

    @property
    def balances_by_account(self):
        return self.__balances_by_account

    @property
    def calc_balances_stats(self):
        return self.__calc_balances_stats

    @calc_balances_stats.setter
    def calc_balances_stats(self, balances):
        mean_income = int(balances['totalIncome'].mean())
        mean_saving = int(balances['totalSaving'].mean())
        mean_spend = int(abs(balances['totalSpend'].mean()))

        sum_income = int(balances['totalIncome'].sum())
        sum_saving = int(balances['totalSaving'].sum())
        sum_spend = int(abs(balances['totalSpend'].sum()))

        max_income = int(balances['totalIncome'].max())
        max_saving = int(balances['totalSaving'].max())
        max_spend = int(abs(balances['totalSpend'].max()))
        min_spend = int(abs(balances['totalSpend'].min()))

        self.__calc_balances_stats = pd.DataFrame(data=[
            ['Average Income', mean_income],
            ['Average Spend', mean_spend],
            ['Average Saving', mean_saving],
            ['Total Income', sum_income],
            ['Total Spend', sum_spend],
            ['Total Saving', sum_saving],
            ['Max Income', max_income],
            ['Max Spend', max_spend],
            ['Max Saving', max_saving],
            ['Min Spend', min_spend],
        ], columns=['type', 'value'])

        symbol = self.reporting_currency_symbol
        self.calc_balances_stats_display = pd.DataFrame(data=[
            ['Average Income', symbol + self.format_money(mean_income)],
            ['Average Spend', symbol + self.format_money(mean_spend)],
            ['Average Saving', symbol + self.format_money(mean_saving)],
            ['Total Income', symbol + self.format_money(sum_income)],
            ['Total Spend', symbol + self.format_money(sum_spend)],
            ['Total Saving', symbol + self.format_money(sum_saving)],
            ['Max Income', symbol + self.format_money(max_income)],
            ['Max Spend', symbol + self.format_money(max_spend)],
            ['Max Saving', symbol + self.format_money(max_saving)],
            ['Min Spend', symbol + self.format_money(min_spend)],
        ], columns=['type', 'value'])

    def format_money(self, data):
        return "{:,.0f}".format(data)

    @property
    def balances_by_month_table(self):
        return self.__balances_by_month_table

    @balances_by_month_table.setter
    def balances_by_month_table(self, balances: pd.DataFrame):
        balances_by_month_table = balances.copy()[['date', 'totalIncome', 'totalSpend', 'totalSaving', 'month_desc']]
        balances_by_month_table.loc[:, 'date_display'] = balances_by_month_table['date'].apply(self.date_to_display)
        # balances_by_month_table.loc[:, 'month_desc'] = balances_by_month_table['date'].apply(self.date_to_month_display)

        self.balances_by_month_table_display = balances_by_month_table.copy()
        self.balances_by_month_table_display = self.balances_by_month_table_display.groupby(
            ['date_display', 'date']).sum().reset_index()

        self.balances_by_month_table_display['totalIncome'] = self.balances_by_month_table_display['totalIncome'].apply(
            self.value_to_currency)
        self.balances_by_month_table_display['totalSpend'] = self.balances_by_month_table_display['totalSpend'].apply(
            self.value_to_currency)
        self.balances_by_month_table_display['totalSaving'] = self.balances_by_month_table_display['totalSaving'].apply(
            self.value_to_currency)

        self.balances_by_month_table_display = self.balances_by_month_table_display[
            ['date_display', 'totalIncome', 'totalSpend', 'totalSaving', 'date']]
        self.balances_by_month_table_display.set_index(['date'])
        self.balances_by_month_table_display.sort_values(by='date', inplace=True, ascending=False)
        self.balances_by_month_table_display = self.balances_by_month_table_display[
            ['date_display', 'totalIncome', 'totalSpend', 'totalSaving']]

        row_value = ['', 'Income', 'Spend', 'Saving']
        self.__balances_by_month_table = balances_by_month_table
        self.balances_by_month_table_display = self.__insert_row(0, self.balances_by_month_table_display, row_value)

    def date_to_display(self, date):
        return date.strftime("%b-%Y")

    def date_to_month_display(self, date):
        return date.strftime("%b")

    @property
    def balances_by_month(self):
        return self.__balances_by_month

    @balances_by_month.setter
    def balances_by_month(self, balances: pd.DataFrame):
        self.__balances_by_month = balances[['date', 'totalIncome']]

    @property
    def categories(self):
        return self.__categories

    @categories.setter
    def categories(self, categories: pd.DataFrame):
        # make sure categories have positive sign

        categories_n = categories[categories.spend < 0]
        categories_n = categories_n.groupby(['categoryName']).sum().reset_index()
        categories_n = categories_n.sort_values('spend')

        categories_d = categories_n.copy()[['categoryName', 'spend']]
        categories_d.loc[:, 'spend'] = categories_d['spend'].apply(self.value_to_currency)
        row_value = ['', 'Total Spend']
        categories_d = self.__insert_row(0, categories_d, row_value)
        self.__categories = categories_n
        self.categories_display = categories_d
        self.category_names_display = categories_n['categoryName']
        self.category_values_display = categories_n['spend'].abs()

    @property
    def category_names_display(self):
        return self.__category_names_display

    @category_names_display.setter
    def category_names_display(self, category_names_display):
        self.__category_names_display = category_names_display

    @property
    def category_values_display(self):
        return self.__category_values_display

    @category_values_display.setter
    def category_values_display(self, category_values_display):
        self.__category_values_display = category_values_display

    @property
    def merchants(self):
        return self.__merchants

    @merchants.setter
    def merchants(self, merchants: pd.DataFrame):
        # make sure merchants have positive sign

        merchants_n = merchants[merchants.spend < 0]
        merchants_n = merchants_n.groupby(['merchantName']).sum().reset_index()
        merchants_n = merchants_n.sort_values('spend')

        merchants_d = merchants_n.copy()[['merchantName', 'spend']]
        merchants_d.loc[:, 'spend'] = merchants_d['spend'].apply(self.value_to_currency)
        row_value = ['', 'Total Spend']
        merchants_d = self.__insert_row(0, merchants_d, row_value)
        self.__merchants = merchants_n
        self.merchants_display = merchants_d
        self.merchant_names_display = merchants_n['merchantName']
        self.merchant_values_display = merchants_n['spend'].abs()

    @property
    def merchant_names_display(self):
        return self.__merchant_names_display

    @merchant_names_display.setter
    def merchant_names_display(self, merchant_names_display):
        self.__merchant_names_display = merchant_names_display

    @property
    def merchant_values_display(self):
        return self.__merchant_values_display

    @merchant_values_display.setter
    def merchant_values_display(self, merchant_values_display):
        self.__merchant_values_display = merchant_values_display

    def value_to_currency(self, value):
        return currency.symbol(self.reporting_currency) + "{:,.0f}".format(value)

    # Function to insert row in the dataframe
    def __insert_row(self, row_number, df, row_value):
        # Starting value of upper half
        start_upper = 0

        # End value of upper half
        end_upper = row_number

        # Start value of lower half
        start_lower = row_number

        # End value of lower half
        end_lower = df.shape[0]

        # Create a list of upper_half index
        upper_half = [*range(start_upper, end_upper, 1)]

        # Create a list of lower_half index
        lower_half = [*range(start_lower, end_lower, 1)]

        # Increment the value of lower half by 1
        lower_half = [x.__add__(1) for x in lower_half]

        # Combine the two lists
        index_ = upper_half + lower_half

        # Update the index of the dataframe
        df.index = index_

        # Insert a row at the end
        df.loc[row_number] = row_value

        # Sort the index labels
        df = df.sort_index()

        # return the dataframe
        return df
