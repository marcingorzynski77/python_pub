import pandas as pd
import logging
import currency
import datetime as dt

logging = logging.getLogger(__name__)


class CustomerTransaction(object):
    # storage for the instance reference
    def __init__(self, reporting_currency, transactions, accounts):
        self.__reporting_currency: str = ''
        self.__reporting_currency_symbol: str = ''
        self.accounts = accounts
        self.categories = None
        self.categories_top_10 = None

        self.merchants = None
        self.merchants_top_10 = None

        self.providers = None

        self.reporting_currency: str = reporting_currency
        self.period_start = None
        self.period_end = None
        self.process(transactions)

    @property
    def reporting_currency_symbol(self):
        return self.__reporting_currency_symbol

    @property
    def reporting_currency(self):
        return self.__reporting_currency

    @reporting_currency.setter
    def reporting_currency(self, cur: str):
        self.__reporting_currency = cur
        self.__reporting_currency_symbol = currency.symbol(cur)

    def process(self, transactions: pd.DataFrame):
        self.categories_top_10 = transactions.groupby(["Category"]).sum() \
            .sort_values(by=['Amount'], ascending=True).head(10) \
            .reset_index()['Category'].to_list()
        self.categories_top_10.sort()

        self.categories = transactions.Category.unique()
        self.categories.sort()

        self.merchants_top_10 = transactions.groupby(["Merchant"]).sum() \
            .sort_values(by=['Amount'], ascending=True).head(10) \
            .reset_index()['Merchant'].to_list()
        self.merchants_top_10.sort()

        self.merchants = transactions.Merchant.unique().tolist()
        self.merchants.sort()

        self.providers = transactions.Provider.unique().tolist()

