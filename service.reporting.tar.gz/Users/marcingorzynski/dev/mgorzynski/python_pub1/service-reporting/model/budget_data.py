import pandas as pd
import logging

logging = logging.getLogger(__name__)


class BudgetData(object):
    # storage for the instance reference
    def __init__(self, customer_info: pd.DataFrame, stats: pd.DataFrame, transactions: pd.DataFrame,
                 limits: pd.DataFrame):
        self.customer_info = customer_info
        self.customer_stats = stats
        self.transactions = transactions
        self.limit_data = limits

        self.spending_limit = customer_info["spendingLimit"]
        self.saving_target = customer_info["savingGoal"]

        self.percentage = 0
