from calendar import monthrange
import datetime as dt
from dateutil.rrule import rrule, MONTHLY

import logging

from pandas import DataFrame

import utils

from model.transaction_data import CustomerTransaction

logging = logging.getLogger(__name__)


class IndexView(object):
    def __init__(self, data: CustomerTransaction, transactions: DataFrame):
        self.merchants = utils.list_to_dict(data.merchants)
        self.categories = utils.list_to_dict(data.categories)
        self.accounts = data.accounts
        self.providers = utils.list_to_dict(data.providers)
        self.merchants_top_10 = utils.list_to_dict(data.merchants_top_10)
        self.categories_top_10 = utils.list_to_dict(data.categories_top_10)
        self.reporting_currency_symbol = data.reporting_currency_symbol

        # Create controls
        self.merchant_options = [
            {"label": self.merchants[key], "value": key}
            for key in self.merchants
        ]

        self.category_options = [
            {"label": self.categories[key], "value": key}
            for key in self.categories
        ]

        self.provider_options = [
            {"label": self.providers[key], "value": key}
            for key in self.providers
        ]

        self.account_options = [
            {"label": item["desc"].upper(), "value": item["accountId"]}
            for item in self.accounts
        ]

        # Load data

        self.mini = transactions["Date"].min()
        self.maxi = transactions["Date"].max()

        self.min_timestamp = dt.datetime(year=self.mini.year, month=self.mini.month, day=1)
        self.min_timestamp = self.min_timestamp.timestamp()
        self.max_timestamp = dt.datetime(year=self.maxi.year, month=self.maxi.month,
                                         day=monthrange(self.maxi.year, self.maxi.month)[1])
        self.max_timestamp = self.max_timestamp.timestamp()

        # Create global chart template
        self.mapbox_access_token = "pk.eyJ1IjoiamFja2x1byIsImEiOiJjajNlcnh3MzEwMHZtMzNueGw3NWw5ZXF5In0.fk8k06T96Ml9CLGgKmk81w"

        self.layout = dict(
            autosize=True,
            automargin=True,
            margin=dict(l=60, r=30, b=30, t=40),
            hovermode="closest",
            plot_bgcolor="#F9F9F9",
            paper_bgcolor="#F9F9F9",
            font=dict(size=11),
            # xaxis = dict(tickformat = '%d-%b-%y'),
            yaxis=dict(tickprefix=data.reporting_currency_symbol, tickformat=',.0f'),
            legend=dict(font=dict(size=10), orientation="h"),
            mapbox=dict(
                accesstoken=self.mapbox_access_token,
                style="light",
                center=dict(lon=-78.05, lat=42.54),
                zoom=7,
            ),
        )

        self.layout_empty = dict(
            autosize=True,
            automargin=True,
            showlegend=False,
            showgrid=False,
            dragmode="select",
            font=dict(size=11),
            showline=False,
            margin=dict(l=30, r=30, b=20, t=40),
            yaxis=dict(tickprefix=data.reporting_currency_symbol, tickformat=',.0f'),
            hovermode="closest",
            plot_bgcolor="#F9F9F9",
            paper_bgcolor="#F9F9F9",
            annotation=dict(
                text="No data available",
                align="center",
                showarrow=False,
                xref="paper",
                yref="paper",
            ),
            legend=dict(font=dict(size=10), orientation="h")
        )

    def to_currency_symbol(self, value):
        return f'{self.reporting_currency_symbol}{int(value):,}'

    def to_currency(self, value):
        return f'{int(value):,}'

    def periods(self):
        dates = [date for date in rrule(MONTHLY, dtstart=self.mini, until=self.maxi)]
        dates.sort(reverse=True)
        return dates

    def periods_plus_latest(self):
        dates = [date for date in rrule(MONTHLY, dtstart=self.mini, until=self.maxi)]
        today = dt.datetime.now()
        dates.append(dt.datetime(year=today.year, month=today.month, day=1))
        dates.sort(reverse=True)
        return dates
