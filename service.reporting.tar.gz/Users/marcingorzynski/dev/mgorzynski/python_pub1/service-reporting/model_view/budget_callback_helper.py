import os
import pathlib

import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_daq as daq
from dateutil.parser import parse
import copy
import logging

import dash_table
import numpy as np
from time import strptime

from dateutil import relativedelta
import plotly.graph_objs as go
from calendar import monthrange
import plotly.express as px
import datetime as dt
import pandas as pd
from dash.dependencies import Input, Output, State, ClientsideFunction
from app_dash import app
from model import Customer
from model.budget_data import BudgetData
from model_view.index_vm import IndexView
from storage.cache import SessionCache

logging = logging.getLogger(__name__)

suffix_row = "_row"
suffix_button_id = "_button"
suffix_sparkline_graph = "_sparkline_graph"
suffix_count = "_count"
suffix_ooc_n = "_OOC_number"
suffix_ooc_g = "_OOC_graph"
suffix_indicator = "_indicator"


def populate_ooc(data, ucl, lcl):
    ooc_count = 0
    ret = []
    for i in range(len(data)):
        if data[i] >= ucl or data[i] <= lcl:
            ooc_count += 1
            ret.append(ooc_count / (i + 1))
        else:
            ret.append(ooc_count / (i + 1))
    return ret


def build_category_targets(iv: IndexView):
    options = [build_value_setter_line(
        "value-setter-panel-header",
        "Category",
        "Set new target",
    )]

    for cat in iv.categories:
        options.append(build_value_setter_line(
            "id_" + cat,
            cat,
            daq.NumericInput(id="input_" + cat, className="setting-input", size=200, max=9999999),
        ))

    return options


def build_value_setter_line(line_num, label, col3):
    return html.Div(
        id=line_num,
        children=[
            html.Label(label, className="four columns"),
            html.Div(col3, className="four columns"),
        ],
        className="row value-setter-panel",
    )


def generate_section_banner(title):
    return html.Div(className="section-banner", children=title)


# Build header
def generate_metric_list_header():
    return generate_metric_row(
        "limit_header",
        {"height": "3rem", "margin": "1rem 0", "textAlign": "center"},
        {"id": "m_header_1", "children": html.Div("Category", style={"margin-top": "10px"}, )},
        {"id": "m_header_2", "children": html.Div("Spend")},
        {"id": "m_header_3", "children": html.Div("Limit", style={"margin-top": "10px"})},
        {"id": "m_header_4", "children": html.Div("Target")},
        {"id": "m_header_5", "children": html.Div("%Utilisation", style={"margin-top": "5px"})},
        {"id": "m_header_6", "children": html.Div("On Track")},
    )


def select_transactions(period):
    data: BudgetData = SessionCache.get_budget_data(None)
    dff: pd.DateFrame = SessionCache.get_customer_transactions(None).transactions

    end = dt.datetime(year=period.year, month=period.month, day=monthrange(period.year, period.month)[1])
    if period.year == dt.datetime.now().year and period.month == dt.datetime.now().month:
        transactions = data.transactions
    else:
        transactions = dff[(dff["Date"] >= period) & (dff["Date"] <= end)]

    return data, dff, transactions


def generate_levels(period, target, recalculate):
    data, dff, transactions = select_transactions(period)
    dff = dff[(dff["Category"] != "Account Transfer") & (dff["Category"] != "Excluded")]
    transactions = transactions[(transactions["Category"] != "Account Transfer") & (transactions["Category"] != "Excluded")]

    end = period
    start = end - relativedelta.relativedelta(months=3)
    dff = dff[(dff["Date"] >= start) & (dff["Date"] < end)]

    # set up easy target 5% by default
    three_month_avg_spending = round(dff[(dff["Amount"] < 0)].sum()['Amount'] / 3)
    three_month_avg_income = round(dff[(dff["Amount"] > 0)].sum()['Amount'] / 3)
    three_month_avg_saving = three_month_avg_income - abs(three_month_avg_spending)

    dff = dff[(dff["Category"] != "Income")]
    dff = dff[dff["Amount"] < 0]

    min_d = dff["Date"].min()
    max_d = dff["Date"].max()
    delta = (min_d - max_d).days
    # difference = relativedelta.relativedelta(max_d, min_d)
    # dff = dff.groupby(["Category"]).sum().reset_index()
    dff = dff.groupby('Category').agg(Amount=('Amount', 'sum'), Count=('Amount', 'count')).reset_index()
    dff["DailyAvg"] = abs(dff["Amount"] / delta)
    dff["TransactionAvg"] = dff["Count"] / 3

    total_spend = dff["Amount"].sum()
    dff["Contribution"] = abs(round((dff["Amount"] / total_spend) * 100))
    dff["MonthlyAmount"] = abs(round(dff["Amount"] / 3))
    dff["SuggestedLimit"] = round(abs(dff["MonthlyAmount"] * (1 - target)))
    dff = dff[["Category", "SuggestedLimit", "Contribution", "DailyAvg", "TransactionAvg"]]

    income = transactions[transactions["Amount"] > 0]["Amount"].sum()
    spending = transactions[transactions["Amount"] < 0]["Amount"].sum()
    saving = income - abs(spending)

    cdf = transactions.groupby("Category").sum().reset_index()
    cdf = cdf[["Category", "Amount"]]

    result = pd.merge(dff, cdf, how='right', on="Category")
    result.fillna(0)
    result.rename(columns={'Amount': 'Utilisation'}, inplace=True)

    result["Income"] = income
    result["Spending"] = spending
    result["Saving"] = saving
    result["ThreeMonthAvgSpending"] = three_month_avg_spending
    result["ThreeMonthAvgIncome"] = three_month_avg_income
    result["ThreeMonthAvgSaving"] = three_month_avg_saving
    result["Period"] = period
    result["Target"] = 0

    result["Utilisation"] = round(abs(result["Utilisation"]))

    if len(data.limit_data) > 0 and abs(data.percentage) == target:
        for index, row in result.iterrows():
            if row["Category"] in data.limit_data:
                if data.limit_data[row["Category"]] > 0:
                    result.loc[index, 'Target'] = data.limit_data[row["Category"]]
                    result.loc[index, 'SuggestedLimit'] = data.limit_data[row["Category"]]

    delta = (end - dt.datetime.utcnow()).days
    result["TimeUtilisationPercent"] = 0
    if delta > 0:
        result["TimeUtilisationPercent"] = round(100 - (delta / monthrange(period.year, period.month)[1] * 100))

    result["MoneyAvailable"] = result["SuggestedLimit"] - result["Utilisation"]
    result["UtilisationPercent"] = round(result["Utilisation"] / result["SuggestedLimit"] * 100)
    result["OnTrack"] = result.apply(
        lambda x: calc_true_false(x["UtilisationPercent"]), axis=1)

    result["Chances"] = 'low'
    result["Chances"] = result.apply(
        lambda x: calc_success_probability(x["UtilisationPercent"], x["UtilisationPercent"]), axis=1)

    result["MobileNotification"] = SessionCache.get_budget_data(None).customer_info["goalsNotificationEnabled"]

    if recalculate:
        recalculate_saving_target(result, target)
        recalculate_spending_target(result, target)
    else:
        result["SpendingTarget"] = data.spending_limit
        result["SpendingTargetPercent"] = target

    result = result[(result["Category"] != "Income") ]

    SessionCache.set_limit_data(result)

    return result


def recalculate_saving_target(result, percent):
    saving_goal = round(result["ThreeMonthAvgSaving"].iloc[0] * (1 + percent))
    result["SavingTarget"] = saving_goal
    result["SavingTargetPercent"] = percent


def recalculate_spending_target(result, percent):
    spending_limit = round(result["ThreeMonthAvgSpending"].iloc[0] * (1 - percent))
    # old = result["SpendingTarget"].iloc[0]
    result["SpendingTarget"] = spending_limit
    result["SpendingTargetPercent"] = percent

    # return old == spending_limit


def calc_true_false(value):
    if value < 100:
        return True
    else:
        return False


def calc_success_probability(time_utilisation, target_utilisation):
    if time_utilisation < target_utilisation < 100:
        return 'high'
    elif target_utilisation > 100 and time_utilisation < 50:
        return 'medium'
    else:
        return 'low'


def filter_dataframe(df_tran, category, date):
    start = date
    end = start + relativedelta.relativedelta(months=1)
    dff = df_tran[df_tran["Category"] == category]
    dff = dff[(dff["Date"] >= start) & (dff["Date"] < end)]
    return dff


def generate_metric_row_helper(index, row, symbol):
    item = row[0]["Category"]
    div_id = item + suffix_row
    button_id = item + suffix_button_id
    sparkline_graph_id = item + suffix_sparkline_graph
    count_id = item + suffix_count
    ooc_percentage_id = item + suffix_ooc_n
    ooc_graph_id = item + suffix_ooc_g
    indicator_id = item + suffix_indicator

    utilisation = 0
    suggested_limit = 0
    money_available = 0
    utilisation_percent = 0
    on_track = False

    if row[0]["Utilisation"] != 0:
        style = None
        utilisation = row[0]["Utilisation"]
        suggested_limit = row[0]["SuggestedLimit"]
        money_available = row[0]["MoneyAvailable"]
        utilisation_percent = row[0]["UtilisationPercent"]
        on_track = row[0]["OnTrack"]
    else:
        style = {"display": "none"}

    return generate_metric_row(
        div_id,
        style,
        {
            "id": item,
            "className": "metric-row-button-text",
            "children": html.Button(
                id=button_id,
                className="metric-row-button",
                children=f'{item}',
                title="Click to visualize Category",
                n_clicks=0,
            ),
        },
        {"id": count_id, "children": f'{symbol}{int(utilisation)}'},
        {
            "id": item + "_sparkline",
            "children": dcc.Input(
                type='number',
                id=sparkline_graph_id,
                value=suggested_limit,
                style={'width': '100px'},
                size=50,
            )
        },
        {"id": ooc_percentage_id, "children": f'{symbol}{int(money_available)}'},
        {
            "id": ooc_graph_id + "_container",

            "children": daq.GraduatedBar(
                id=ooc_graph_id,
                color={
                    "ranges": {
                        "#92e0d3": [0, 50],
                        "#f4d44d ": [50, 90],
                        "#f45060": [90, 100],
                    }
                },
                showCurrentValue=True,
                max=100,
                value=round(utilisation_percent),
                size=250,
            ),
        },
        {
            "id": item + "_pf",
            "children": daq.Indicator(
                id=indicator_id, value=on_track, size=12
            ),
        },
    )


# else:
#     return generate_metric_row(div_id, None, {"id": button_id, "children": []}, {"id": "", "children": []}, {"id": "", "children": []}, {"id": "", "children": []}, {"id": "", "children": []}, {"id": "", "children": []})


def generate_metric_row(id, style, col1, col2, col3, col4, col5, col6):
    if style is None:
        style = {"height": "4rem", "width": "100%", "align-content": "center"}

    return html.Div(
        id=id,
        className="row metric-row",
        style=style,
        children=[
            html.Div(
                id=col1["id"],
                className="two columns",
                children=col1["children"],
            ),
            html.Div(
                id=col2["id"],
                style={"textAlign": "center", "margin-top": "10px"},
                className="one columns",
                children=col2["children"],
            ),
            html.Div(
                id=col3["id"],
                style={"height": "100%"},
                className="two columns",
                children=col3["children"],
            ),
            html.Div(
                id=col4["id"],
                style={"margin-top": "10px"},
                className="one columns",
                children=col4["children"],
            ),
            html.Div(
                id=col5["id"],
                style={"margin-top": "5px"},
                className="four columns",
                children=col5["children"],
            ),
            html.Div(
                id=col6["id"],
                style={"display": "flex", "justifyContent": "center", "margin-top": "10px", "width": "100px"},
                className="one columns",
                children=col6["children"],
            ),
        ],
    )


def generate_category_limit_graph(category, df):
    data, dff, transactions = select_transactions(SessionCache.get_limit_data()["Period"].iloc[0])

    dff = transactions[(transactions["Category"] == category)]
    df_limit = df[(df["Category"] == category)]
    if dff.shape[0] == 0:
        return dash.no_update

    g = dff[["Amount", "Date"]]
    max_d = g["Date"].max()
    count = g["Date"].count()
    g = g.groupby("Date").sum().reset_index()
    g.index = g["Date"]
    g = g["Amount"].abs()
    g = g.sort_index()
    g = g.cumsum()
    g = g.reset_index()
    g.index = g["Date"]
    g = g[["Amount"]]
    max_amount = g["Amount"].max()

    avg = df_limit["DailyAvg"].iloc[0]
    tran_avg_count = df_limit["TransactionAvg"].iloc[0]
    delta = dt.timedelta(days=1)
    end = dt.datetime(year=max_d.year, month=max_d.month, day=monthrange(max_d.year, max_d.month)[1])

    if end.year == dt.datetime.utcnow().year and end.month == dt.datetime.utcnow().month:
        max_d = dt.datetime.utcnow()
    else:
        max_d = end

    index = 1
    if count < tran_avg_count or category in "Groceries" or category in "Shopping":
        while max_d <= end:
            max_d += delta
            g.loc[max_d] = [max_amount + (avg * index)]
            index = index + 1
    else:
        max_d = end
        g.loc[max_d] = [max_amount]

    max_amount = g["Amount"].max()
    max_index = g.index.max()
    min_index = g.index.min()
    delta = (max_index - min_index).days

    if delta == 0:
        delta = 1

    if df_limit["SuggestedLimit"].iloc[0] > max_amount:
        max_amount = df_limit["SuggestedLimit"].iloc[0]

    if end.year == dt.datetime.utcnow().year and end.month == dt.datetime.utcnow().month:
        today = dt.datetime.utcnow()
        vline_v = {
            "type": "rect",
            "xref": "x",
            "yref": "y",
            "x0": min_index,
            "y0": df_limit["SuggestedLimit"].iloc[0],
            "x1": max_index,
            "y1": max_amount,
            "fillcolor" : "#e89695",
            "opacity": 0.5,
            "line": {"color": "red", "width": 1},
        }
        today_shape = {
            "type": "line",
            "xref": "x",
            "yref": "y",
            "x0": today,
            "y0": 0,
            "x1": today,
            "y1": max_amount,
            "line": {"color": "red", "width": 1, "dash": "dot"},
        }
        today_marker = {'text': 'Today', 'textangle': 0, 'x': (today - min_index).days / delta, 'xref': 'paper',
                        'showarrow': False,
                        'ay': 0, 'ax': 0, 'ay': -10}
        spending_marker = {'text': 'Predicted spending above target', 'textangle': 0,
                           'x': ((today - min_index).days / delta), 'xref': 'paper', 'showarrow': False,
                           'y': max_amount, 'ax': 0, 'ay': -10}
    else:
        today = end
        vline_v = {
            "type": "rect",
            "xref": "x",
            "yref": "y",
            "x0": min_index,
            "y0": df_limit["SuggestedLimit"].iloc[0],
            "x1": max_index,
            "y1": max_amount,
            "fillcolor": "#e89695",
            "opacity": 0.5,
            "line": {"color": "red", "width": 1},
        }
        today_marker = None
        today_shape = None
        spending_marker = {'text': 'Spending above target', 'textangle': 0,
                           'x': ((today - min_index).days / delta), 'xref': 'paper', 'showarrow': False,
                           'y': max_amount, 'ax': 0, 'ay': -10}


    iv = SessionCache.get_index_view(None)
    layout_count = copy.deepcopy(iv.layout)

    data = [
        dict(
            type="scatter",
            x=g.index,
            y=g["Amount"],
            name="Spending",
            fill='tozeroy',
            mode='lines',
            # line={'shape': 'spline', 'smoothing': 1.3},
            # marker=dict(color=color.tolist()),
        ),
    ]

    shapes = [today_shape, vline_v]

    # layout_count["dragmode"] = "select"
    layout_count["showlegend"] = True
    layout_count["autosize"] = True
    layout_count["title"] = category
    layout_count["annotations"] = [today_marker, spending_marker]
    layout_count["shapes"] = shapes

    fig = dict(data=data, layout=layout_count)
    graph = dcc.Graph(id='category_usage_g', figure=fig)
    return graph


def generate_pie(category, df):
    labels = df["Category"].to_list()
    values = df["Contribution"].to_list()
    pull_list = []

    for i in range(0, len(labels)):
        if labels[i] == category:
            pull_list.append(0.3)
        else:
            pull_list.append(0)

        figure = go.Figure(
            data=[go.Pie(labels=labels, values=values, pull=pull_list, title="Category size vs other categories", )])

        figure.layout.plot_bgcolor = '#F9F9F9'
        figure.layout.paper_bgcolor = '#F9F9F9'

    return dcc.Graph(id='category_usage_pie', figure=figure)


def build_transaction_table(period):
    data, dff, transactions = select_transactions(period)
    # data: BudgetData = SessionCache.get_budget_data(None)
    data = transactions[['Amount', 'Date', 'Merchant', 'Category', 'Provider', 'Currency']]

    return dash_table.DataTable(
        id='datatable-interactivity-category',
        columns=[
            {"name": i, "id": i, "deletable": False, "selectable": False} for i
            in
            data.columns
        ],
        data=data.to_dict('records'),
        editable=True,
        filter_action="native",
        sort_action="native",
        sort_mode="multi",
        column_selectable="single",
        row_deletable=False,
        selected_columns=[],
        page_action="native",
        page_current=0,
        page_size=10,

        style_table={'overflowX': 'scroll'},
        style_cell={
            'font-size': '11px',
            'font-family': 'Raleway, HelveticaNeue, Helvetica Neue,Helvetica, Arial, sans-serif',
            'text-align': 'center',
            'overflow': 'hidden',
            'textOverflow': 'ellipsis',
        },
        style_data_conditional=[
            {
                'if': {'row_index': 'odd'},
                'backgroundColor': 'rgb(248, 248, 248)'
            }
        ],
        style_header={
            'backgroundColor': '#ffffff',
            'fontWeight': 'bold',
            'color': 'black',
        }

    )
