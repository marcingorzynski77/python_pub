import os
import pathlib

import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_daq as daq
from dateutil.parser import parse
import copy
import logging
from dateutil.parser import parse

import dash_table
import numpy as np
from time import strptime

from dateutil import relativedelta
import plotly.graph_objs as go
from calendar import monthrange
import plotly.express as px
import datetime as dt
import pandas as pd
from dash.dependencies import Input, Output, State, ClientsideFunction
from app_dash import app
from model import Customer
from model.budget_data import BudgetData
from model_view.index_vm import IndexView
from storage.cache import SessionCache
import model_view.budget_callback_helper as bh
from storage.rest import ErisApi

logging = logging.getLogger(__name__)


data_rest: ErisApi = ErisApi()


@app.callback(
    Output("popover-category-transactions", "is_open"),
    [Input("popover-category-transactions-list", "n_clicks")],
    [State("popover-category-transactions", "is_open")],
)
def toggle_popover_limit_transaction(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-category-trend", "is_open"),
    [Input("popover-target-category-trend", "n_clicks")],
    [State("popover-category-trend", "is_open")],
)
def toggle_popover_limit_category(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-target-limit-util", "is_open"),
    [Input("popover-target-limit-utilisation", "n_clicks")],
    [State("popover-target-limit-util", "is_open")],
)
def toggle_popover_limit_util(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-limit", "is_open"),
    [Input("popover-limit-filter", "n_clicks")],
    [State("popover-limit", "is_open")],
)
def toggle_popover_limit_filter(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-target-knob", "is_open"),
    [Input("popover-limit-target-knob", "n_clicks")],
    [State("popover-target-knob", "is_open")],
)
def toggle_popover_limit_target(n, is_open):
    if n:
        return not is_open
    return is_open


def init_recalculate_on():
    bg = SessionCache.get_budget_data(None)
    if bg.spending_limit > 0:
        return False

    return True


def init_value_setter_store(period):
    # Initialize store data
    bg = SessionCache.get_budget_data(None)
    limit = bg.spending_limit
    percent = 0.1
    if limit > 0:
        data, dff, transactions = bh.select_transactions(period)
        dff = dff[(dff["Category"] != "Account Transfer") & (dff["Category"] != "Excluded")]
        end = period
        start = end - relativedelta.relativedelta(months=3)
        dff = dff[(dff["Date"] >= start) & (dff["Date"] < end)]
        three_month_avg_spending = round(dff[(dff["Amount"] < 0)].sum()['Amount'] / 3)
        percent = round(1 - abs((limit/three_month_avg_spending)), 4)
        bg.percentage = round(percent, 4)
        if bg.percentage > 0.3:
            bg.percentage = 0.3
            percent = 0.3

        SessionCache.set_budget_data_target(bg)

    return bh.generate_levels(period, percent, bg.spending_limit == 0).to_dict()


def build_category_targets(iv: IndexView):
    options = [build_value_setter_line(
        "value-setter-panel-header",
        "Category",
        "Set new target",
    )]

    for cat in iv.categories:
        options.append(build_value_setter_line(
            "id_" + cat,
            cat,
            daq.NumericInput(id="input_" + cat, className="setting-input", size=200, max=9999999),
        ))

    return options


def build_value_setter_line(line_num, label, col3):
    return html.Div(
        id=line_num,
        children=[
            html.Label(label, className="four columns"),
            html.Div(col3, className="four columns"),
        ],
        className="row value-setter-panel",
    )


def generate_section_banner(title):
    return html.Div(className="section-banner", children=title)


def build_top_panel():
    return html.Div(
        id="top-section-container",
        className="row",
        children=[
            # Category limit summary
            html.Div(
                id="metric-summary-session",
                children=[
                    html.Div(
                        id="metric-div",
                        children=[
                            generate_metric_list_header(),
                            html.Div(
                                id="metric-rows",
                                children=[],
                            ),
                        ],
                    ),
                ],
            ),

        ],
    )


# Build header
def generate_metric_list_header():
    return bh.generate_metric_row(
        "limit_header",
        {"height": "3rem", "margin": "1rem 0", "textAlign": "center"},
        {"id": "m_header_1", "children": html.Div("Category", style={"margin-top": "10px"}, )},
        {"id": "m_header_2", "children": html.Div("Spend")},
        {"id": "m_header_3", "children": html.Div("Limit", style={"margin-top": "10px"})},
        {"id": "m_header_4", "children": html.Div("Available")},
        {"id": "m_header_5", "children": html.Div("%Utilisation", style={"margin-top": "5px"})},
        {"id": "m_header_6", "children": html.Div("On Track")},
    )


@app.callback(
    output=[Output("metric-rows", "children"), Output("value-setter-store-period", "data")],
    inputs=[Input("metric-select-dropdown", "value"), Input("metric-knob-spending", "value"), Input("auto_recalculate", "on")],
    # state=[State("value-setter-store", "data")],
)
def generate_limit_utilisation(period, target, recalculate):
    period = parse(period)
    iv = SessionCache.get_index_view(None)
    result = []
    df = bh.generate_levels(period, target / 100, recalculate)
    cat = {'Category': list(iv.categories.values())}
    cat_df = pd.DataFrame(cat, columns=['Category'])
    cat_df = pd.merge(df, cat_df, how='right', on="Category")
    cat_df = cat_df.fillna(-1)

    cat_df.loc[cat_df['SuggestedLimit'] == -1, 'SuggestedLimit'] = 0
    cat_df.loc[cat_df['Utilisation'] == -1, 'Utilisation'] = 0
    cat_df.loc[cat_df['MoneyAvailable'] == -1, 'MoneyAvailable'] = 0
    cat_df.loc[cat_df['OnTrack'] == -1, 'OnTrack'] = True
    cat_df.loc[cat_df['Chances'] == -1, 'Chances'] = 'not set'

    # for index, row in cat_df.iterrows()
    index = 0
    for row in get_categories():
        # res = cat_df[cat_df["Category"] == row]
        res = cat_df.loc[cat_df['Category'] == row]

        if len(res) == 0:
            res = [{"Category": row, "Utilisation": 0}]
        else:
            res = res.to_dict("records")

        res = bh.generate_metric_row_helper(str(index), res, iv.reporting_currency_symbol)
        if res is not None:
            result.append(res)
        index = index + 1

    return html.Div(id="limits", children=result), period


def build_chart_panel():
    return html.Div(
        id="control-chart-container",
        className="twelve columns",
    )


def get_categories():
    categories = ["Bills"]
    categories.append("Business"),
    categories.append("Entertainment"),
    categories.append("General"),
    categories.append("Groceries"),
    categories.append("Housing"),
    categories.append("Personal Care"),
    categories.append("Shopping"),
    categories.append("Charity"),
    categories.append("Education"),
    categories.append("Family"),
    categories.append("Holidays"),
    categories.append("Investments"),
    categories.append("Transport"),
    categories.append("Pension And Insurance"),
    categories.append("Eating Out"),
    categories.append("Excluded"),
    categories.append("Loan")
    return categories


def get_category_control_chart():
    inputs = [Input("value-setter-store-period", "data")]
    for cat in get_categories():
        inputs.append(Input(cat + bh.suffix_button_id, "n_clicks"))

    return inputs


def get_category_inputs():
    inputs = []
    for cat in get_categories():
        inputs.append(Input(cat + bh.suffix_button_id, "n_clicks"))

    return inputs


#  ======= update limits ============
@app.callback(
    output=Output("value-setter-store-limit-value", "data"),
    inputs=get_category_inputs(),
)
def update_limit(n1, n2, n3, n4, n5,n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16, n17, n18):
    # Find which one has been triggered
    ctx = dash.callback_context
    df = SessionCache.get_limit_data()

    if ctx.triggered:
        res = []
        # Get most recently triggered id and prop_type
        splitted = ctx.triggered[0]["prop_id"].split("_")

        if len(splitted) > 0 and len(ctx.triggered) > 0:
            val = ctx.triggered[0]["value"]
            prop_id = splitted[0]
            df.loc[df['Category'] == prop_id, ['SuggestedLimit']] = val
            SessionCache.set_limit_data(df)

        # data = SessionCache.get_budget_data(None)
        # data.spending_limit = abs(SessionCache.get_limit_data()["SpendingTarget"].iloc[0])
        # data.customer_info["goalsNotificationEnabled"] = SessionCache.get_limit_data()["MobileNotification"].iloc[0]
        #
        # SessionCache.set_budget_data_target(data)
        # data_rest.save_limit_data(SessionCache.get_limit_data(), SessionCache.get_user())


#  ======= button to choose/update figure based on click ============
@app.callback(
    output=Output("control-chart-container", "children"),
    inputs=get_category_control_chart(),
)
def update_control_chart(data, n1, n2, n3, n4, n5,n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16, n17, n18):
    # Find which one has been triggered
    ctx = dash.callback_context
    df = SessionCache.get_limit_data()

    if ctx.triggered:
        res = []
        # Get most recently triggered id and prop_type
        splitted = ctx.triggered[0]["prop_id"].split("_")
        prop_id = splitted[0]

        if prop_id == "value-setter-store-period.data":
            clicks = 0
            prop_type = "clicks"
            prop_id = df.iloc[0]['Category']
        else:
            prop_type = splitted[2]
            clicks = ctx.triggered[0]["value"]

        if clicks > 0:
            SessionCache.set_category_data(prop_id)
        else:
            cat = SessionCache.get_category_data()
            if cat is not None:
                prop_id = cat

        if prop_type == "clicks":
            res.append(bh.generate_category_limit_graph(prop_id, df))
            # res.append(bh.generate_pie(prop_id, df))
            return res

    return []


def generate_modal():
    return html.Div(
        id="markdown",
        className="modal",
        children=(
            html.Div(
                id="markdown-container",
                className="markdown-container",
                children=[
                    html.Div(
                        className="close-container",
                        children=html.Button(
                            "Close",
                            id="markdown_close",
                            n_clicks=0,
                            className="closeButton",
                        ),
                    ),
                    html.Img(id="budget_welcome", src=app.get_asset_url("budget_welcome.png"),
                             style={"width": "1200", "height": "600px", "float": "left", "margin-right": "10px",
                                    "border": "solid black 1px"}),
                    # html.Img(id="budget_welcome2", src=app.get_asset_url("budget_welcome2.png"),
                    #          style={"width": "600px", "height": "400px", "float": "left", "margin-right": "10px",
                    #                 "border": "solid black 1px"}),
                    # html.Div(
                    #     className="markdown-text",
                    #     style={"font": "12px"},
                    # #     children=dcc.Markdown(
                    # #         style={"font-size": "12px"},
                    # #         children=(
                    # #             """
                    # #     Welcome !
                    # #
                    # #     This is a budgeting dashboard where you can set up a different levels of spending targets.
                    # #
                    # #     Once you decide what limits work for you press `Save changes` button. We also recommend to enable mobile notifications to easy track your progress.
                    # #
                    # #     If for any reason automated limit settings won't work for you there is an option to adjust them manually.
                    # #
                    # #     We have set up 10% limits on your average spending , see if you can achieve that. Good Luck!
                    # #
                    # # """
                    # #         )
                    # #     ),
                    # ),

                ],
            )
        ),
    )


# ======= Callbacks for Headers =======
@app.callback(
    [Output("avgIncome", "children"), Output("avgSpending", "children"), Output("avgSaving", "children"),
     Output("daq-ld-income", "value"), Output("daq-ld-spend", "value"), Output("daq-ld-save", "value"),
     Output("target_status", "children"), Output("target_status", "style")],
    [Input("value-setter-store-period", "data")],
)
def headers(value):
    iv = SessionCache.get_index_view(None)
    df = SessionCache.get_limit_data()

    spending = abs(df["Spending"].iloc[0])
    target = abs(df["SpendingTarget"].iloc[0])

    if spending > target:
        desc = "NOT MET"
        style = {"float": "right", "background-color": "red"}
    else:
        desc = "ON TRACK"
        style = {"float": "right", "background-color": "#ffc107"}

    return iv.to_currency_symbol(df["ThreeMonthAvgIncome"].iloc[0]), iv.to_currency_symbol(
        df["ThreeMonthAvgSpending"].iloc[0]), iv.to_currency_symbol(df["ThreeMonthAvgSaving"].iloc[0]), round(
        df["Income"].iloc[0]), round(df["Spending"].iloc[0]), round(df["Saving"].iloc[0]), desc, style


@app.callback(
    Output("mobile_notifications", "style"),
    [Input("mobile_notifications", "on")],
)
def notifications(value):
    df = SessionCache.get_limit_data()
    df["MobileNotification"] = value
    SessionCache.set_limit_data(df)
    style = {"float": "left", "margin-left": "20px"}
    return style


@app.callback(
    [Output("gauge_spending", "value"), Output("gauge_spending", "max"), Output("gauge_spending", "min"),
     Output("gauge_spending", "color"), Output("gauge_spending", "label"), Output("difficulty_level", "children"), Output("limit_level", "children")],
    [Input("value-setter-store-period", "data")],
)
def spending_gauge(state):
    df = SessionCache.get_limit_data()

    target = abs(df["SpendingTarget"].iloc[0])
    color = {"gradient": True,
             "ranges": {"green": [0, int(target * 0.6)], "yellow": [int(target * 0.6), int(target * 0.8)],
                        "red": [int(target * 0.8), int(target)]}}

    label = f'Spending Target {SessionCache.get_customer(None).reporting_currency_symbol}{abs(round(SessionCache.get_limit_data()["SpendingTarget"].iloc[0]))}'
    limit = f'​Limits set to {SessionCache.get_customer(None).reporting_currency_symbol}{abs(round(SessionCache.get_limit_data()["Target"].sum()))}'

    target_percent = abs(df["SpendingTargetPercent"].iloc[0]) * 100
    if 0 <= target_percent <= 10:
        level = "EASY"
    elif 10 < target_percent <= 20:
        level = "MEDIUM"
    else:
        level = "HARD"

    level = f'{level}'
    return abs(round(df["Spending"].iloc[0])), round(target), 0, color, label, level, limit


@app.callback(
    [Output("metric-knob-spending", "label"),
     Output("value-setter-store-spending", "data"),
     Output("auto_recalculate", "on")],
    [Input("metric-knob-spending", "value")],
)
def spending_knob(value):
    # recalculate target

    label = {"label": f'Target: avg spending decreased by {value}%',
             "style": {"font-size": "11px", "width": "160px", "margin-left": "70px"}}

    df = SessionCache.get_limit_data()
    target = df["SpendingTargetPercent"].iloc[0]
    percent = round(value / 100, 4)
    bh.recalculate_spending_target(df, percent)
    return label, df.to_dict(), abs(target) != percent


def get_spending_knob():
    df = SessionCache.get_limit_data()
    current = round(abs(df["SpendingTargetPercent"].iloc[0] * 100), 4)
    return current


def build_transaction_table(period):
    return bh.build_transaction_table(period)


# ======= Callbacks for transactions =======
@app.callback(
    Output("datatable-interactivity-category", "data"),
    [Input("metric-select-dropdown", "value")],
)
def show_transactions(period):
    period = parse(period)
    data, dff, transactions = bh.select_transactions(period)
    data = transactions[['Amount', 'Date', 'Merchant', 'Category', 'Provider', 'Currency']]
    return data.to_dict('records')


# ======= Callbacks for modal popup =======
@app.callback(
    Output("markdown", "style"),
    [Input("markdown_close", "n_clicks")],
)
def show_modal_window(close_click):
    if close_click > 0 or SessionCache.has_budget_welcome():
        SessionCache.set_budget_welcome()
        if close_click > 0:
            data = SessionCache.get_budget_data(None)
            if data.spending_limit is not None or data.spending_limit == 0:
                save_db()

        return {"display": "none"}

    return {"display": "block"}


# ======= Callbacks save =======
@app.callback(
    Output("value-setter-set-btn", "style"),
    [Input("value-setter-set-btn", "n_clicks")],
)
def save(close_click):
    if close_click > 0:
        save_db()

    style = {"margin-top": "10px"}
    return style


def save_db():
    logging.info("saving limits to database")
    data = SessionCache.get_budget_data(None)
    data.spending_limit = abs(SessionCache.get_limit_data()["SpendingTarget"].iloc[0])
    data.customer_info["goalsNotificationEnabled"] = SessionCache.get_limit_data()["MobileNotification"].iloc[0]

    # update cache
    for index, row in SessionCache.get_limit_data().iterrows():
        if row["SuggestedLimit"] != row["Target"]:
            data.limit_data[row["Category"]] = row["SuggestedLimit"]
    SessionCache.set_budget_data_target(data)
    data_rest.save_limit_data(SessionCache.get_limit_data(), SessionCache.get_user())
