import dash_html_components as html
import dash_core_components as dcc
import dash_daq as daq
import copy
import logging
import numpy as np
from time import strptime

from dash import dash
from dash.exceptions import PreventUpdate
from dateutil import relativedelta
import plotly.graph_objs as go
from calendar import monthrange
import plotly.express as px
import datetime as dt
import pandas as pd
from dash.dependencies import Input, Output, State, ClientsideFunction
from app_dash import app
from storage.cache import SessionCache

logging = logging.getLogger(__name__)


@app.callback(
    Output("popover-map-tran-mini", "is_open"),
    [Input("popover-target-tran-mini", "n_clicks")],
    [State("popover-map-tran-mini", "is_open")],
)
def toggle_popover_tran_mini(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("cache", "children"),
    [Input("refresh-button", "n_clicks")],
)
def reload_button(n_clicks):
    if n_clicks > 0:
        logging.info("reload last month clicked")
        SessionCache.reload()
        return dcc.Location(id='url_redirect', pathname="/loading", refresh=True)
    else:
        pass


@app.callback(
    Output("popover-filter", "is_open"),
    [Input("popover-target-filter", "n_clicks")],
    [State("popover-filter", "is_open")],
)
def toggle_popover_count(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-count", "is_open"),
    [Input("popover-target-count", "n_clicks")],
    [State("popover-count", "is_open")],
)
def toggle_popover_count(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-merchant", "is_open"),
    [Input("popover-target-merchant", "n_clicks")],
    [State("popover-merchant", "is_open")],
)
def toggle_popover_merchant(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-category", "is_open"),
    [Input("popover-target-category", "n_clicks")],
    [State("popover-category", "is_open")],
)
def toggle_popover_category(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-heat", "is_open"),
    [Input("popover-target-heat", "n_clicks")],
    [State("popover-heat", "is_open")],
)
def toggle_popover_heat(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-map", "is_open"),
    [Input("popover-target-map", "n_clicks")],
    [State("popover-map", "is_open")],
)
def toggle_popover_map(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output("popover-map-det", "is_open"),
    [Input("popover-target-map-det", "n_clicks")],
    [State("popover-map-det", "is_open")],
)
def toggle_popover_map_det(n, is_open):
    if n:
        return not is_open
    return is_open


@app.callback(
    Output('datatable-interactivity', 'data'),
    [Input("merchants", "value"),
     Input("categories", "value"),
     Input("providers", "value"),
     Input("month_slider", "value"), ]
)
def update_tran_table(merchants, categories, providers, month_slider):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)
    return dff.to_dict('records')


# Selectors -> count graph
@app.callback(
    Output("count_graph", "figure"),
    [
        Input("merchants", "value"),
        Input("categories", "value"),
        Input("providers", "value"),
        Input("month_slider", "value"),
    ],
)
def make_count_figure(merchants, categories, providers, month_slider):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)

    if month_slider is None:
        month_slider = [iv.min_timestamp, iv.max_timestamp]

    layout_count = copy.deepcopy(iv.layout)

    start = get_start_date(month_slider)
    end = get_end_date(month_slider)

    dff = filter_dataframe(df_transactions, merchants, categories, providers, [month_slider[0], month_slider[1]])
    if dff.shape[0] == 0:
        return dash.no_update

    g = dff[["Amount", "Date"]]
    g.index = g["Date"]

    income = g[g["Amount"] > 0]
    spend = g[g["Amount"] < 0]

    banner = f' [{start.strftime("%d-%b-%Y")} to {end.strftime("%d-%b-%Y")}]'

    day_diff = (end - start).days
    if day_diff < 45:
        amounts = g["Amount"].values
        color = np.array(['rgb(255,255,255)'] * amounts.shape[0])
        color[amounts < 0] = "rgb(163, 3, 3)"
        color[amounts >= 0] = "rgb(29, 133, 48)"

        layout_count["title"] = f'{iv.reporting_currency_symbol} Daily Spending/Income {banner}'
        data = [
            dict(
                type="bar",
                x=g.index,
                y=g["Amount"],
                name="Balance",
                marker=dict(color=color.tolist()),
            ),
        ]
    elif 45 < day_diff < 90:
        layout_count["title"] = f'{iv.reporting_currency_symbol} Weekly Spending/Income {banner}'
        income = income.resample("W").sum()
        spend = spend.resample("W").sum()
        g = g.resample("W").sum()
        amounts = g["Amount"].values

        color = np.array(['rgb(255,255,255)'] * amounts.shape[0])
        color[amounts < 0] = "rgb(163, 3, 3)"
        color[amounts >= 0] = "rgb(29, 133, 48)"

        data = [
            dict(
                type="bar",
                x=g.index,
                y=g["Amount"],
                name="Balance",
                marker=dict(color=color.tolist()),
            ),
            dict(
                type="scatter",
                x=income.index,
                y=income["Amount"],
                name="Income",
                line={'shape': 'spline', 'smoothing': 1.3},
                marker=dict(color=color.tolist()),
            ),
            dict(
                type="scatter",
                x=spend.index,
                y=spend["Amount"],
                name="Spend",
                line={'shape': 'spline', 'smoothing': 1.3},
                marker=dict(color=color.tolist()),
            ),
        ]
    else:
        layout_count["title"] = f'{iv.reporting_currency_symbol} Monthly Spending/Income {banner}'
        income = income.resample("M").sum()
        spend = spend.resample("M").sum()
        g = g.resample("M").sum()
        amounts = g["Amount"].values

        color = np.array(['rgb(255,255,255)'] * amounts.shape[0])
        color[amounts < 0] = "rgb(163, 3, 3)"
        color[amounts >= 0] = "rgb(29, 133, 48)"

        data = [
            dict(
                type="bar",
                # marker={'color': 'rgb(13, 101, 25)'},
                x=g.index,
                y=g["Amount"],
                name="Balance",
                marker=dict(color=color.tolist()),
            ),
            dict(
                type="scatter",
                x=income.index,
                y=income["Amount"],
                name="Income",
                line={'shape': 'spline', 'smoothing': 1.3},
                marker=dict(color=color.tolist()),
            ),
            dict(
                type="scatter",
                x=spend.index,
                y=spend["Amount"],
                name="Spend",
                line={'shape': 'spline', 'smoothing': 1.3},
                marker=dict(color=color.tolist()),
            ),
        ]

    layout_count["dragmode"] = "select"
    layout_count["showlegend"] = True
    layout_count["autosize"] = True

    figure = dict(data=data, layout=layout_count)
    return figure


# @app.callback(
#     [Output('my-date-picker-range', 'start_date'), Output('my-date-picker-range', 'end_date'),
#      Output('month_slider_state', 'data')],
#     [Input("count_graph", "selectedData"), Input("month_slider", "value")],
#     [State("month_slider_state", "data"), State("graph_state", "data")])
# def update_date_range(count_graph_selected, month_slider, slider_state, graph_state):
#     came_from_graph = False
#     came_from_slider = False
#
#     if count_graph_selected is not None and (
#             pd.to_datetime(graph_state[0]).date() != pd.to_datetime(
#         count_graph_selected['range']['x'][0]).date() or pd.to_datetime(graph_state[1]).date() !=
#             pd.to_datetime(count_graph_selected['range']['x'][1]).date()):
#         came_from_graph = True
#     elif month_slider is not None:
#         start_date = get_start_date(month_slider)
#         end_date = get_end_date(month_slider)
#         if slider_state is None:
#             came_from_slider = True
#         elif ((pd.to_datetime(slider_state[0]).date() != pd.to_datetime(start_date).date()) or (
#                 pd.to_datetime(slider_state[1]).date() != pd.to_datetime(end_date).date())):
#             came_from_slider = True
#
#     if came_from_graph:
#         min_date = pd.to_datetime(count_graph_selected['range']['x'][0])
#         max_date = pd.to_datetime(count_graph_selected['range']['x'][1])
#     elif came_from_slider:
#         min_date = get_start_date(month_slider)
#         max_date = get_end_date(month_slider)
#     else:
#         raise PreventUpdate()
#
#     return min_date, max_date, month_slider


# # #  Graph -> Category trend
@app.callback(Output("category_trend_graph", "figure"),
              [Input("merchants", "value"),
               Input("categories", "value"),
               Input("providers", "value"),
               Input("category_volume_hm", "clickData"),
               Input("month_slider", "value"), ])
def category_trend_figure(merchants, categories, providers, heatmap_click, month_slider):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)

    layout_pie = copy.deepcopy(iv.layout_empty)

    amounts = []

    if heatmap_click is not None:
        dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)
        month = strptime(heatmap_click['points'][0]['x'], '%b').tm_mon
        category = heatmap_click['points'][0]['y']
        total = heatmap_click['points'][0]['z']
        amounts, dates = produce_category_trend(dff, category, month)

        calc = {}

        for i in range(0, len(dates)):
            if dates[i].year in calc:
                calc[dates[i].year] = calc[dates[i].year] + amounts[i]
            else:
                calc[dates[i].year] = amounts[i]

        for key, value in calc.items():
            calc[key] = int(value)
            # abs(int((value / total) * 100))

    if len(amounts) == 0:
        annotation = dict(
            text="No data - click on category heat map",
            align="center",
            x=0.5,
            y=0.5,
            showarrow=False,
            xref="paper",
            yref="paper",
        )
        layout_pie["annotations"] = [annotation]
        data = []
        pass
    else:
        data = [
            dict(
                type="pie",
                labels=list(calc.keys()),
                values=list(calc.values()),
                hoverinfo="text+percent+value",
                textinfo="label+percent+name",
                hole=0.5,
                marker=dict(colors=["#fac1b7", "#a9bb95", "#92d8d8"]),
                domain={"x": [0.2, 0.8], "y": [0.2, 0.8]},
            ),
        ]
        layout_pie["title"] = "{} - {}".format(heatmap_click['points'][0]['y'], heatmap_click['points'][0]['x'])
        layout_pie["font"] = dict(color="#777777")

    figure = dict(data=data, layout=layout_pie)
    return figure


# Selectors, merchant graph
@app.callback(
    Output("merchant_graph", "figure"),
    [
        Input("merchants", "value"),
        Input("categories", "value"),
        Input("providers", "value"),
        Input("month_slider", "value"),
        Input("category_volume_hm", "clickData"),
    ],
)
def make_merchant_figure(merchants, categories, providers, month_slider, heatmap_click):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)

    layout_tree = copy.deepcopy(iv.layout_empty)

    if heatmap_click is not None:
        dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)
        month = strptime(heatmap_click['points'][0]['x'], '%b').tm_mon
        category = heatmap_click['points'][0]['y']

        amounts, merchants = produce_merchant_trend(dff, category, month)

        treemap_trace = go.Treemap(
            labels=merchants, parents=[""] * len(merchants), values=amounts
        )
        treemap_layout = go.Layout({"margin": dict(t=10, b=10, l=5, r=5, pad=4)})
        treemap_figure = {"data": [treemap_trace], "layout": treemap_layout}
        return treemap_figure
    else:

        annotation = dict(
            text="No data - click on category heat map",
            align="center",
            showarrow=False,
            xref="paper",
            yref="paper",
        )
        layout_tree["annotations"] = [annotation]
        data = []
        return {"data": data, "layout": layout_tree}


# Radio -> multi
@app.callback(
    Output("merchants", "value"), [Input("merchant_selector", "value")]
)
def display_merch(selector):
    if selector == "all":
        return []
    elif selector == "top10":
        iv = SessionCache.get_index_view(None)
        return list(iv.merchants_top_10.keys())
    return []


# Radio -> multi
@app.callback(Output("categories", "value"), [Input("category_selector", "value")])
def display_category(selector):
    if selector == "all":
        return []
    elif selector == "top10":
        iv = SessionCache.get_index_view(None)
        return list(iv.categories_top_10.keys())
    return []


# Radio -> multi
@app.callback(Output("providers", "value"), [Input("provider_selector", "value")])
def display_provider(selector):
    if selector == "all":
        return []
    return []


# Create callbacks
app.clientside_callback(
    ClientsideFunction(namespace="clientside", function_name="resize"),
    Output("output-clientside", "children"),
    [Input("count_graph", "figure")],
)


# Slider -> count graph
@app.callback(
    [
        Output("month_slider", "marks"),
        Output("month_slider", "min"),
        Output("month_slider", "max"),
        # Output("month_slider", "step"),
        Output("month_slider", "value"),
        Output('slider_state', 'data'),
        Output('date_range_state', 'data'),
        Output('graph_state', 'data')

    ],
    [Input("count_graph", "selectedData"), Input("month_slider_selector", "value"),
     # Input("my-date-picker-range", "start_date"), Input("my-date-picker-range", "end_date")
     ],
    [State("slider_state", "data"), State("date_range_state", "data"), State("graph_state", "data")],
)
def populate_time_slider(count_graph_selected, value, state, date_range_state, graph_state):
    """
    Depending on our dataset, we need to populate the time-slider
    with different ranges. This function does that and returns the
    needed data to the time-window-slider.
    """

    came_from_graph = False
    came_from_date_range = False
    came_from_value_all = False
    came_from_value = False

    graph_state_return = [0, 0]
    date_range_state_return = [0, 0]

    if "all" in value and state != "all":
        came_from_value_all = True
    elif value is not None and value != state:
        came_from_value = True
    elif count_graph_selected is not None and (
            pd.to_datetime(graph_state[0]).date() != pd.to_datetime(
        count_graph_selected['range']['x'][0]).date() or pd.to_datetime(graph_state[1]).date() !=
            pd.to_datetime(count_graph_selected['range']['x'][1]).date()):
        came_from_graph = True
        graph_state_return = [count_graph_selected['range']['x'][0], count_graph_selected['range']['x'][1]]
        date_range_state_return = [graph_state_return[0], graph_state_return[1]]
    elif state is not None and value != state and "all" in value:
        came_from_value_all = True
    # elif start_date is not None and end_date is not None and (
    #         (pd.to_datetime(date_range_state[0]).date() != pd.to_datetime(start_date).date()) or (
    #         pd.to_datetime(date_range_state[1]).date() != pd.to_datetime(end_date).date())):
    #     came_from_date_range = True
    #     date_range_state_return = [start_date, end_date]
    #     graph_state_return = [start_date, end_date]
    # elif "all" in value and state != "all":
    #     came_from_value_all = True
    else:
        raise PreventUpdate()

    df_transactions = SessionCache.get_customer_transactions(None).transactions
    min_date = df_transactions["Date"].min()
    max_date = df_transactions["Date"].max()

    marks = make_marks_time_slider(min_date, max_date, True)
    min_epoch = list(marks.keys())[0]
    max_epoch = list(marks.keys())[-1]

    # if count_graph_selected is None:
    #     #initial load
    #     year_ago = max_date - relativedelta.relativedelta(years=1)
    #     if min_date < year_ago:
    #         min_date = year_ago
    #
    #     new_marks = make_marks_time_slider(min_date, max_date)
    #     min_range = list(new_marks.keys())[0]
    #     max_range = list(new_marks.keys())[-1]

    res = True
    if came_from_graph:
        min_date = pd.to_datetime(count_graph_selected['range']['x'][0])
        max_date = pd.to_datetime(count_graph_selected['range']['x'][1])
        new_marks = make_marks_time_slider(min_date, max_date, False)
        min_range = list(new_marks.keys())[0]
        max_range = list(new_marks.keys())[-1]

        if (max_date - min_date).days < 90:
            min_range = min_date.timestamp()
            max_range = max_date.timestamp()
    # elif came_from_date_range:
    #     min_date = pd.to_datetime(start_date)
    #     max_date = pd.to_datetime(end_date)
    #     # min_date = dt.datetime.strptime(start_date, '%Y-%m-%d')
    #     # max_date = dt.datetime.strptime(end_date, '%Y-%m-%d')
    #
    #     min_range = int(min_date.timestamp())
    #     max_range = int(max_date.timestamp())
    elif came_from_value_all:
        min_range = min_epoch
        max_range = max_epoch

        date_range_state_return = [dt.datetime.fromtimestamp(min_range), dt.datetime.fromtimestamp(max_range)]
        graph_state_return = [dt.datetime.fromtimestamp(min_range), dt.datetime.fromtimestamp(max_range)]

    elif came_from_value:
        start = dt.datetime(year=int(value), month=1, day=1)
        end = dt.datetime(year=int(value), month=12, day=31)
        if start.year == min_date.year and min_date > start:
            start = min_date

        if end.year == max_date.year and end > max_date:
            end = max_date

        new_marks = make_marks_time_slider(start, end, True)
        min_range = list(new_marks.keys())[0]
        max_range = list(new_marks.keys())[-1]

        date_range_state_return = [dt.datetime.fromtimestamp(min_range), dt.datetime.fromtimestamp(max_range)]
        graph_state_return = [dt.datetime.fromtimestamp(min_range), dt.datetime.fromtimestamp(max_range)]
    else:
        res = False

    if res:
        return (
            marks,
            min_epoch,
            max_epoch,
            # (max_epoch - min_epoch) / (len(list(marks.keys())) * 3),
            [min_range, max_range],
            # f'Your finances at a glance for period {dt.datetime.fromtimestamp(min_range).strftime("%d %b %Y")} to {dt.datetime.fromtimestamp(max_range).strftime("%d %b %Y")}',
            value,
            date_range_state_return,
            graph_state_return
        )
    else:
        raise PreventUpdate()


# Selectors -> well text
@app.callback(
    [
        Output("transactionText", "children"),
        Output("spendingText", "children"),
        Output("incomeText", "children"),
        Output("balanceText", "children"),
    ],

    [
        Input("merchants", "value"),
        Input("categories", "value"),
        Input("providers", "value"),
        Input("month_slider", "value"),
    ],
)
def update_text(merchants, categories, providers, month_slider):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)

    dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)
    count = 0
    spending = 0
    income = 0
    balance = 0

    try:
        count = dff.shape[0]
        income = dff.query("Amount>0")["Amount"].sum()
        spending = dff.query("Amount<0")["Amount"].sum()
        balance = income - abs(spending)
    except:
        return count, iv.to_currency_symbol(spending), iv.to_currency_symbol(
            income), iv.to_currency_symbol(balance)

    return count, iv.to_currency_symbol(spending), iv.to_currency_symbol(
        income), iv.to_currency_symbol(balance)


# Selectors -> main graph
@app.callback(
    Output("main_graph", "figure"),
    [
        Input("merchants", "value"),
        Input("categories", "value"),
        Input("providers", "value"),
        Input("month_slider", "value"),
        Input("location_selector", "value"),

    ],
    [State("lock_selector", "value"), State("main_graph", "relayoutData")],
)
def make_main_figure(
        merchants, categories, providers, month_slider, popular, selector, main_graph_layout
):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)
    dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)
    traces = []

    coordinates = {}

    if popular == "popular":
        dff_count = dff.groupby(['Longitude', 'Latitude']).size().reset_index(name='Counts').sort_values(by='Counts',
                                                                                                         ascending=False).head(
            30)
        for index, row in dff_count.iterrows():
            coordinates[str(row["Longitude"]) + str(row["Latitude"])] = row["Counts"]

    for position, dfff in dff.groupby(['Longitude', 'Latitude']):
        if position[0] != 0 and position[1] != 0:

            if popular == "popular":
                index = str(position[0]) + str(position[1])
                if index not in coordinates:
                    continue

            trace = dict(
                type="scattermapbox",
                lon=dfff["Longitude"],
                lat=dfff["Latitude"],
                text=dfff["Merchant"],
                showlegend=False,
                hoverinfo="text+value",
                textinfo="label+name",
                customdata=dfff["Address"],
                name=dfff["Address"],
                marker=dict(size=10, opacity=0.6),
            )
            traces.append(trace)

    # relayoutData is None by default, and {'autosize': True} without relayout action
    if main_graph_layout is not None and selector is not None and "locked" in selector:
        if "mapbox.center" in main_graph_layout.keys():
            lon = float(main_graph_layout["mapbox.center"]["lon"])
            lat = float(main_graph_layout["mapbox.center"]["lat"])
            zoom = float(main_graph_layout["mapbox.zoom"])
            iv.layout["mapbox"]["center"]["lon"] = lon
            iv.layout["mapbox"]["center"]["lat"] = lat
            iv.layout["mapbox"]["zoom"] = zoom

    else:
        # main_graph_layout is None:
        spend = dff[(dff["Amount"] < 0)]
        default = spend.groupby(["Address", "Longitude", "Latitude"]).count().reset_index()
        if not default.empty:
            most_frequent_address = spend['Address'].value_counts().head(1).reset_index()['index']
            top = spend[(spend['Address'] == most_frequent_address.to_dict()[0])].head(1)
            iv.layout["mapbox"]["center"]["lon"] = float(top['Longitude'])
            iv.layout["mapbox"]["center"]["lat"] = float(top['Latitude'])
            iv.layout["mapbox"]["zoom"] = 13

    iv.layout['title'] = ""
    figure = dict(data=traces, layout=iv.layout)
    return figure


# # Main graph -> individual graph Aggregate
@app.callback(
    Output("individual_graph", "figure"),
    [Input("merchants", "value"),
     Input("categories", "value"),
     Input("providers", "value"),
     Input("main_graph", "hoverData"),
     Input("month_slider", "value"), ])
def make_individual_figure(merchants, categories, providers, main_graph_hover, month_slider):
    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)

    layout_individual = copy.deepcopy(iv.layout_empty)
    iv.layout['title'] = "Transactions"
    dff = pd.DataFrame()
    if main_graph_hover is not None:
        chosen = [point["customdata"] for point in main_graph_hover["points"]]
        dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)
        dff = dff[(dff["Address"] == chosen[0])]

    fig = layout_individual
    if dff.empty:
        annotation = dict(
            text="No data - hover over location",
            title="Transactions",
            x=0.5,
            y=0.5,
            align="center",
            showarrow=False,
            xref="paper",
            yref="paper",
        )
        layout_individual["annotations"] = [annotation]
        data = []
        figure = dict(data=data, layout=fig)
        return figure
    else:
        dff = dff[['Date', 'Amount']]
        dff = dff.groupby(['Amount', 'Date']).sum().reset_index()
        dff['Amount'] = dff['Amount'].astype(int)
        dff['Amount'] = dff['Amount'].abs()
        fig = px.scatter(
            dff,
            x="Date",
            y="Amount",

            size="Amount",
            color="Amount",
            size_max=10,
            template="plotly_white",
            title=f'{chosen[0]}',
        )
        fig.update_traces(marker=dict(line=dict(width=1, color="Gray")))
        fig.update_xaxes(visible=True)
        fig.update_yaxes(visible=True, tickprefix=iv.reporting_currency_symbol, tickformat=',.0f')
        return fig


@app.callback(
    [Output("app-content", "children")],
    [Input("app-tabs", "value")],
)
def render_tab_content(tab_switch):
    # if tab_switch == "tab1":
    #     # return build_tab1()
    #     return []
    return (
        html.Div(
            id="status-container",
            children=[

                html.Div(
                    id="graphs-container",
                    children=[],
                ),
            ],
        ),
    )


@app.callback(
    Output("category_volume_hm", "figure"),
    [
        Input("merchants", "value"),
        Input("categories", "value"),
        Input("providers", "value"),
        Input("month_slider", "value"),
    ],
)
def update_heatmap(merchants, categories, providers, month_slider):
    # Return to original hm(no colored annotation) by resetting
    return generate_category_volume_heatmap(
        merchants, categories, providers, month_slider
    )


def generate_category_volume_heatmap(merchants, categories, providers, month_slider):
    """
    :return: Category heatmap.
    """

    df_transactions = SessionCache.get_customer_transactions(None).transactions
    iv = SessionCache.get_index_view(None)

    if month_slider is None:
        month_slider = [iv.min_timestamp, iv.max_timestamp]

    dff = filter_dataframe(df_transactions, merchants, categories, providers, month_slider)

    cats = []
    if len(categories) == 0:
        for key in iv.categories:
            cats.append(iv.categories[key])
    else:
        cats = categories

    months_choices = []
    for i in range(1, 13):
        months_choices.append((i, dt.date(2008, i, 1).strftime('%b')))
    x_axis = months_choices
    y_axis = cats

    shapes = []

    z = np.zeros((len(y_axis), len(x_axis)))
    annotations = []

    min_val = 0
    max_val = 0

    stat_item = []
    for ind_y, category in enumerate(y_axis):
        for ind_x, month in enumerate(x_axis):
            result = dff[(dff.Month == month[0]) & (dff.Category == category)]
            amount_sum = int(result["Amount"].sum())

            z[ind_y][ind_x] = amount_sum
            stat_item.append(amount_sum)
            if amount_sum < min_val:
                min_val = amount_sum

            if amount_sum > max_val:
                max_val = amount_sum

            annotation_dict = dict(
                showarrow=False,
                text="" + iv.to_currency(amount_sum) + "",
                xref="x",
                yref="y",
                x=month[1],
                y=category,
                # font=dict(family="sans-serif"),
            )
            annotations.append(annotation_dict)

    # Heatmap
    hovertemplate = "<b> %{y}  %{x} <br><br> %{z}"

    stats = pd.DataFrame(stat_item, columns=['Amount'])
    min_val = stats['Amount'].min()
    max_val = stats['Amount'].max()
    median = stats['Amount'].median()
    # std = stats['Amount'].std()
    describe = stats['Amount'].describe()
    s75 = describe['75%']
    s25 = describe['25%']

    if max_val <= 0:
        level1 = translate((0.6 * min_val) if (0.3 * min_val) < s25 else min_val, min_val, max_val, 0, 1)
        if level1 < 0:
            level1 = 0
        level2 = translate((0.3 * min_val) if (0.3 * min_val) < s25 else min_val, min_val, max_val, 0, 1)
        if level2 < level1:
            level2 = level1
        level3 = translate(s25, min_val, max_val, 0, 1)
        if level3 < level2:
            level3 = level2
        level4 = translate(median, min_val, max_val, 0, 1)
        if level4 < level3:
            level4 = level3
        level5 = translate(s75, min_val, max_val, 0, 1)
        if level5 < level4:
            level5 = level4
        level6 = translate((max_val + (0.3 * max_val)) if (max_val + (0.3 * max_val)) > s75 else max_val, min_val,
                           max_val, 0, 1)
        if level6 < level5:
            level6 = level5
        level7 = translate((max_val + (0.6 * max_val)) if (max_val + (0.3 * max_val)) > s75 else max_val, min_val,
                           max_val, 0, 1)
        if level7 < level6:
            level7 = level6

        colors = [[0, "rgb(219, 11, 11)"],
                  [level1, "rgb(252, 204, 204)"],
                  [level2, "rgb(145, 208, 250)"],
                  [level3, "rgb(232, 244, 252)"],
                  [level4, "rgb(255,255,255)"],
                  [level5, "rgb(244, 250, 230)"],
                  [level6, "rgb(217, 232, 181)"],
                  [level7, "rgb(181, 204, 124)"],
                  [1, "rgb(36, 156, 41)"]]

    else:
        level1 = translate((0.6 * min_val), min_val, max_val, 0, 1)
        if level1 < 0:
            level1 = 0
        level2 = translate((0.3 * min_val), min_val, max_val, 0, 1)
        if level2 < level1:
            level2 = level1
        level3 = translate(s25, min_val, max_val, 0, 1)
        if level3 < level2:
            level3 = level2
        level4 = translate(median, min_val, max_val, 0, 1)
        if level4 < level3:
            level4 = level3
        level5 = translate(s75, min_val, max_val, 0, 1)
        if level5 < level4:
            level5 = level4
        level6 = translate((0.3 * max_val), min_val, max_val, 0, 1)
        if level6 < level5:
            level6 = level5
        level7 = translate((0.6 * max_val), min_val, max_val, 0, 1)
        if level7 < level6:
            level7 = level6

        colors = [[0, "rgb(219, 11, 11)"],
                  [level1, "rgb(252, 204, 204)"],
                  [level2, "rgb(145, 208, 250)"],
                  [level3, "rgb(232, 244, 252)"],
                  [level4, "rgb(255,255,255)"],
                  [level5, "rgb(244, 250, 230)"],
                  [level6, "rgb(217, 232, 181)"],
                  [level7, "rgb(181, 204, 124)"],
                  [1, "rgb(36, 156, 41)"]]

    data = [
        dict(
            x=[a_tuple[1] for a_tuple in x_axis],
            y=cats,
            z=z,
            type="heatmap",
            name="",
            hovertemplate=hovertemplate,
            showscale=True,
            autocolorscale=False,
            colorscale=colors,
        )
    ]

    start = get_start_date(month_slider)
    end = get_end_date(month_slider)

    layout = dict(
        margin=dict(l=145, b=50, t=50, r=50),
        modebar={"orientation": "v"},
        font=dict(size=11),
        annotations=annotations,
        shapes=shapes,
        title=f'[{start.strftime("%d-%b-%Y")} to {end.strftime("%d-%b-%Y")}]',
        plot_bgcolor="#F9F9F9",
        paper_bgcolor="#F9F9F9",
        xaxis=dict(
            side="top",
            ticks="",
            ticklen=3,
            # tickcolor="#1E2130",
            # showticklabels=True,
            tickfont=dict(color='black', size=12)
        ),
        yaxis=dict(
            side="left", ticks="", ticksuffix=" ", tickprefix=" ", tickfont=dict(color='black', size=12)
        ),
        hovermode=True,
        showlegend=False,
    )
    return {"data": data, "layout": layout}


def translate(value, left_min, left_max, right_min, right_max):
    # Figure out how 'wide' each range is
    left_span = left_max - left_min
    right_span = right_max - right_min

    if left_span == 0:
        value_scaled = 0
    else:
        # Convert the left range into a 0-1 range (float)
        value_scaled = float(value - left_min) / float(left_span)

    # Convert the 0-1 range into a value in the right range.
    return right_min + (value_scaled * right_span)


def filter_dataframe(df_tran, merchants, categories, providers, month_slider):
    iv = SessionCache.get_index_view(None)
    if month_slider is None:
        month_slider = [iv.min_timestamp, iv.max_timestamp]

    start = get_start_date(month_slider)
    end = get_end_date(month_slider)

    dff = df_tran

    if len(categories) > 0:
        dff = dff[dff["Category"].isin(categories)]
    if len(merchants) > 0:
        dff = dff[dff["Merchant"].isin(merchants)]
    if len(providers) > 0:
        dff = dff[dff["AccountId"].isin(providers)]

    dff = dff[(dff["Date"] > start) & (dff["Date"] < end)]
    return dff


def get_start_date(month_slider):
    start = dt.datetime.fromtimestamp(month_slider[0])
    return start


def get_end_date(month_slider):
    end = dt.datetime.fromtimestamp(month_slider[1])
    return end


def produce_income(df_income):
    amounts = []
    dates = []

    try:
        res = df_income.query("Amount>0")
        res = res.sort_values(by='Date', ascending=True)
    except:
        return amounts, dates

    if res is not None:
        amounts = res['Amount'].to_list()
        dates = res['Date'].to_list()

    return amounts, dates


def produce_category_trend(df_tran, category, month):
    amounts = []
    dates = []

    try:
        dff = df_tran[
            # (df_tran["Amount"] < 0)
            (df_tran["Month"] == month)
            & (df_tran["Category"] == category)
            ]
        res = dff.sort_values(by='Date', ascending=True)
        # res["Amount"] = res["Amount"] * -1
        res["Amount"] = res["Amount"].abs()
    except:
        return amounts, dates

    if res is not None:
        amounts = res['Amount'].to_list()
        dates = res['Date'].to_list()

    return amounts, dates


def produce_merchant_trend(df_tran, category, month):
    amounts = []
    merchants = []

    try:
        dff = df_tran[
            # (df_tran["Amount"] < 0)
            (df_tran["Month"] == month)
            & (df_tran["Category"] == category)
            ]
        res = dff.sort_values(by='Date', ascending=True)
        res = res.groupby(['Merchant']).sum().reset_index()
        res["Amount"] = res["Amount"].abs()
    except:
        return amounts, merchants

    if res is not None:
        amounts = res['Amount'].to_list()
        merchants = res['Merchant'].to_list()

    return amounts, merchants


def get_days_in_month(year, month):
    return monthrange(year, month)[1]


def make_marks_time_slider(mini, maxi, adjust: bool):
    """
    A helper function to generate a dictionary that should look something like:
    {1420066800: '2015', 1427839200: 'Q2', 1435701600: 'Q3', 1443650400: 'Q4',
    1451602800: '2016', 1459461600: 'Q2', 1467324000: 'Q3', 1475272800: 'Q4',
     1483225200: '2017', 1490997600: 'Q2', 1498860000: 'Q3', 1506808800: 'Q4'}
    """
    return make_marks_time_slider_monthly(mini, maxi, adjust)


def make_marks_time_slider_monthly(mini, maxi, adjust: bool):
    step = relativedelta.relativedelta(months=+1)
    if not adjust:
        start = mini
        end = maxi
    else:
        start = dt.datetime(year=mini.year, month=mini.month, day=1)
        end = dt.datetime(year=maxi.year, month=maxi.month, day=get_days_in_month(maxi.year, maxi.month))

    if end < maxi:
        end = maxi

    return slider(start, end, step)


def slider(start, end, step):
    ret = {}

    current = start
    while current <= end:
        if current.month == end.month and current.year == end.year:
            current_str = int(end.timestamp())
        else:
            current_str = int(current.timestamp())
        if current.month == 1:
            ret[current_str] = {
                "label": str(current.year),
                "style": {"font-weight": "bold"},
            }
        elif current.month == 4:
            ret[current_str] = {
                "label": "Q2",
                "style": {"font-weight": "lighter", "font-size": 7},
            }
        elif current.month == 7:
            ret[current_str] = {
                "label": "Q3",
                "style": {"font-weight": "lighter", "font-size": 7},
            }
        elif current.month == 10:
            ret[current_str] = {
                "label": "Q4",
                "style": {"font-weight": "lighter", "font-size": 7},
            }
        else:
            if current.month == end.month and current.year == end.year:
                current_str = int(end.timestamp())
                if 1 <= current.month <= 3:
                    ret[current_str] = {
                        "label": "Q2",
                        "style": {"font-weight": "bold"},
                    }
                elif 4 <= current.month <= 6:
                    ret[current_str] = {
                        "label": "Q3",
                        "style": {"font-weight": "lighter", "font-size": 7},
                    }
                elif 7 <= current.month <= 9:
                    ret[current_str] = {
                        "label": "Q4",
                        "style": {"font-weight": "lighter", "font-size": 7},
                    }
                elif current.month >= 10:
                    ret[current_str] = {
                        "label": str(current.year + 1),
                        "style": {"font-weight": "lighter", "font-size": 7},
                    }

            elif current.month == start.month and current.year == start.year:
                if 1 <= current.month <= 3:
                    ret[current_str] = {
                        "label": str(current.year),
                        "style": {"font-weight": "bold"},
                    }
                elif 4 <= current.month <= 6:
                    ret[current_str] = {
                        "label": "Q2",
                        "style": {"font-weight": "lighter", "font-size": 7},
                    }
                elif 7 <= current.month <= 9:
                    ret[current_str] = {
                        "label": "Q3",
                        "style": {"font-weight": "lighter", "font-size": 7},
                    }
                elif current.month >= 10:
                    ret[current_str] = {
                        "label": "Q4",
                        "style": {"font-weight": "lighter", "font-size": 7},
                    }

            pass
        current += step
    return ret
