# -*- coding: utf-8 -*-
import sys

import flask
import werkzeug
from flask import Flask
from flask_session import Session
from datetime import timedelta
from flask_qrcode import QRcode
werkzeug.cached_property = werkzeug.utils.cached_property
from common.util.args import AppStart
import version
import redis


server: Flask = None


def main(argv):
    args = AppStart()
    # parse arguments received from console
    args.parse_args(argv)
    # set up logging if log file is available otherwise use defaul set up
    args.setup_logging()
    # initiate global configuration and metric collection
    # after this line you can import stats from common.util.metric
    # after this line you can import config from common.config

    from local_config import ReportingConfiguration
    args.configure_app(config=ReportingConfiguration())

    from common.config import config
    # after this line you can work with shared_data by importing it

    from app_global import instantiate_app
    from common.rest.start_module import Startup
    from rest.api import ns as rep_namespace
    from rest.api import rest_api
    from messaging import event_sink

    app = Startup(args)
    from app_qr_code import initialized_qr_code
    qr_code = QRcode(app.app)
    initialized_qr_code(qr_code)
    sess = Session()

    import logging
    logger = logging.getLogger(__name__)
    if config.session_type == "file":
        logger.info("setting up file backed session")
        app.app.secret_key = 'redis-password'
        app.app.config['SESSION_TYPE'] = 'filesystem'
    else:
        logger.info("setting up redis backed session")
        app.app.secret_key = 'redis-password'
        app.app.config['SESSION_TYPE'] = 'redis'
        app.app.config['SESSION_REDIS'] = redis.from_url(config.redis_server)
        # app.app.config['SESSION_REDIS'] = redis.from_url('redis://:uBeV1ejZTE@sentry-sentry-redis-master.devops:6379')
        # app.app.config['SESSION_REDIS'] = redis.from_url('redis://:uBeV1ejZTE@redis-master.devops:6379')
        app.app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=5)

    sess.init_app(app.app)
    logger.info("session is set to {0} days".format(app.app.permanent_session_lifetime.days))

    app.print_header(version.__version__)
    instantiate_app(app.app)

    from index import app as app1

    # configure flask and res api, start mq
    app.initialize_app(rep_namespace, rest_api, event_sink.EventSink)
    # start metric end point and cherrypi wsgi server
    app.start()


if __name__ == "__main__":
    print("executing main")
    main(sys.argv[1:])



