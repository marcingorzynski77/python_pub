import logging
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Output, Input
from app_dash import app
from storage.cache import SessionCache

logging = logging.getLogger(__name__)


def display_page():
    return html.Div(
        id="big-app-container",
        children=[
            build_banner(),
            html.Div(
                id="app-container",
                children=[
                    html.Div(
                        [
                            html.Div(id='cache', style={'display': 'none'}),
                            html.H6(id='server-time',
                                    children=["We are loading your data, please bare with us for a moment "]),
                            html.Img(src=app.get_asset_url("loading.gif")),
                            # dcc.Interval(id='interval', interval=5*1000, n_intervals=0)

                        ], style={'textAlign': 'center', 'height': 'calc(100vh - 145px)',
                                  'display': 'flex', 'justify-content': 'center', 'align-items': 'center'}
                    ),
                    # Main app
                    html.Div(id="app-content"),
                ],
            ),
            build_footer(),
        ],
    )


def build_banner():
    return html.Div(
        id="banner",
        className="banner",
        children=[
            html.Div(
                id="banner-text",
                children=[
                    html.H5("Personal Finance Dashboard"),
                    html.H6("Your finances at a glance"),
                ],
            ),
            html.Div(
                id="banner-logo",
                children=[
                    dcc.Location(id='url_redirect', refresh=True),
                    build_report(),
                    html.Img(id="logo", src=app.get_asset_url("logo_700.png")),
                ],
            ),
        ],
    )


def build_report():
    return html.A(id="learn-more-button", children=['LEARN MORE'], href='https://gosavex.com',
                  className="button no-print")


def build_footer():
    return html.Div(
        id="footer",
        className="banner",
        children=[
            html.Div(
                id="footer-text",
                children=[
                    html.Div("Copyright Gosavex Ltd."),
                ],
            ),
        ],
    )


# using serverside callback
@app.callback(Output('server-time', 'children'),
              [Input('cache', 'children')])
def update_timer(_):
    logging.info("loading transaction data")
    SessionCache.get_customer_transactions(SessionCache.get_user())
    logging.info("loading customer data")
    SessionCache.get_customer(SessionCache.get_user())
    logging.info("loading index data")
    SessionCache.get_index_view(SessionCache.get_user())
    logging.info("loading budget data")
    SessionCache.get_budget_data(SessionCache.get_user())

    return dcc.Location(id='url_redirect',pathname="/index", refresh=True)

