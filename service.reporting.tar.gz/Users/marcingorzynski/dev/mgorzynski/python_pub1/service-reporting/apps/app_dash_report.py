# -*- coding: utf-8 -*-
import dash
import logging
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
from app_global import server
from storage.cache import SessionCache
from app_dash import app

logging = logging.getLogger(__name__)

# external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
# app = dash.Dash(
#     __name__, server=server, external_stylesheets=external_stylesheets,
#     meta_tags=[{"name": "viewport", "content": "width=device-width"}]
# )
#
# app.config.suppress_callback_exceptions = True
#
# # Describe the layout/ UI of the app
# app.layout = html.Div(
#     [dcc.Location(id="url", refresh=False), html.Div(id="page-content")]
# )

from pages import (
    overview,
    category,
    merchant,
    balances,
    accounts,
    cards,
    # transactions,
    # login,
    # logout,
    # authorization
)


# @app.callback(
#     Output('user-name', 'children'),
#     [Input('page-content', 'children')])
# def cur_user(input1):
#     return html.A('Login', href='/login')


# @app.callback(
#     Output('logout', 'children'),
#     [Input('page-content', 'children')])
# def user_logout(input1):
#     return html.A('Logout', href='/financial-report/logout')

#
# # Update page
# @app.callback(Output("page-content", "children"), [Input("url", "pathname")])

def display_page(pathname, user_id):
    if pathname == "/financial-report/overview":
        return overview.create_layout(app, user_id)
    # elif pathname == "/financial-report/logout":
    #     return logout.create_layout(app, user_id)
    elif pathname == "/financial-report/categories":
        return category.create_layout(app, user_id)
    elif pathname == "/financial-report/merchants":
        return merchant.create_layout(app, user_id)
    elif pathname == "/financial-report/balances":
        return balances.create_layout(app, user_id)
    elif pathname == "/financial-report/accounts":
        return accounts.create_layout(app, user_id)
    elif pathname == "/financial-report/cards":
        return cards.create_layout(app, user_id)
    # elif pathname == "/financial-report/transactions":
    #     return transactions.create_layout(app, user_id)
    elif pathname == "/financial-report/full-view":
        return (
            overview.create_layout(app, user_id),
            balances.create_layout(app, user_id),
            category.create_layout(app, user_id),
            merchant.create_layout(app, user_id),
            accounts.create_layout(app, user_id),
            cards.create_layout(app, user_id),
            # transactions.create_layout(app, user_id),
        )
    else:
        logging.info(f'invoking overview')
        return overview.create_layout(app, user_id)
