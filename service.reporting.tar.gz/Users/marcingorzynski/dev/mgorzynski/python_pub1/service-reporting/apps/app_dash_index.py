# Import required libraries
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
import logging
from model_view.index_vm import IndexView
from module.transaction import build_transactions, build_transactions_all
from storage.cache import SessionCache
from app_dash import app
from pages import login, logout, authorization
import module.budget as budget

# import model_view.budget_callback as budget

log = logging.getLogger(__name__)


def build_year_options(iv: IndexView):
    options = [{"label": "All ", "value": "all"}]
    for y in range(iv.mini.year, iv.maxi.year + 1):
        options.append({"label": str(y) + " ", "value": str(y)})

    return options


def build_tab1(iv: IndexView):
    # Create app layout
    return [html.Div(
        [
            dcc.Store(id='slider_state'),
            dcc.Store(id='date_range_state'),
            dcc.Store(id='graph_state'),
            dcc.Store(id="aggregate_data"),
            dcc.Store(id="month_slider_state"),

            # empty Div to trigger javascript file for graph resizing
            html.Div(id="output-clientside"),
            # html.Div(id='slider-cache', style={'display': 'none'}),
            html.Div(
                [
                    html.Div(
                        [
                            dbc.Button(
                                "Info", id="popover-target-filter", color="info",
                                className="bg-primary badge mr-1"
                            ),
                            dbc.Popover(
                                [
                                    dbc.PopoverHeader("Filtering", style={'font-size': '11px'}),
                                    dbc.PopoverBody(
                                        "We are fetching transaction for full month only, which means that the latest transactions will be the for the previous month. If you want to see transactions from current month please use mobile app ."),
                                ],
                                id="popover-filter",
                                is_open=False,
                                style={'font-size': '11px'},
                                target="popover-target-filter",
                            ),
                            html.P(
                                "Filter by transaction date (or select range in histogram):",
                                className="control_label",
                            ),
                            # dcc.DatePickerRange(
                            #     id='my-date-picker-range',
                            #     className="dcc_control",
                            #     display_format='DD-MMM-YYYY',
                            #     start_date_placeholder_text='MMMM Y, DD',
                            #     # min_date_allowed=dt(1995, 8, 5),
                            #     # max_date_allowed=dt(2017, 9, 19),
                            #     # initial_visible_month=dt(2017, 8, 5),
                            #     # end_date=dt(2017, 8, 25).date()
                            #     style={'font-size': '11px', 'width': '100%'},
                            # ),
                            # html.Div(id='output-container-date-picker-range'),
                            dcc.RadioItems(
                                id="month_slider_selector",
                                options=build_year_options(iv),
                                value="all",
                                labelStyle={"display": "inline-block"},
                                className="dcc_control",
                            ),
                            dcc.RangeSlider(
                                id="month_slider",
                                className="dcc_control",
                            ),
                            html.P("Filter by merchant:", className="control_label"),
                            dcc.RadioItems(
                                id="merchant_selector",
                                options=[
                                    {"label": "All ", "value": "all"},
                                    {"label": "Top 10 ", "value": "top10"},
                                ],
                                value="all",
                                labelStyle={"display": "inline-block"},
                                className="dcc_control",
                            ),
                            dcc.Dropdown(
                                id="merchants",
                                options=iv.merchant_options,
                                multi=True,
                                value=iv.merchants,
                                className="dcc_control",
                            ),
                            dcc.Checklist(
                                id="lock_selector",
                                options=[{"label": "Lock map camera in place", "value": "locked"}],
                                className="dcc_control",
                                value=[],
                            ),
                            html.P("Filter by category:", className="control_label"),
                            dcc.RadioItems(
                                id="category_selector",
                                options=[
                                    {"label": "All ", "value": "all"},
                                    {"label": "Top 10 ", "value": "top10"},
                                ],
                                value="all",
                                labelStyle={"display": "inline-block"},
                                className="dcc_control",
                            ),
                            dcc.Dropdown(
                                id="categories",
                                options=iv.category_options,
                                multi=True,
                                value=iv.categories,
                                className="dcc_control",
                            ),

                            html.P("Filter by provider:", className="control_label"),
                            dcc.RadioItems(
                                id="provider_selector",
                                options=[
                                    {"label": "All ", "value": "all"},
                                ],
                                value="all",
                                labelStyle={"display": "inline-block"},
                                className="dcc_control",
                            ),
                            dcc.Dropdown(
                                id="providers",
                                options=iv.account_options,
                                multi=True,
                                value=[v["accountId"] for v in iv.accounts],
                                className="dcc_control",
                            ),
                        ],
                        className="pretty_container four columns",
                        id="cross-filter-options",
                    ),
                    html.Div(
                        [
                            html.Div(
                                [
                                    html.Div(
                                        [html.H6(id="transactionText"), html.P("No. of Transactions")],
                                        id="numberOfTransactions",
                                        className="mini_container",
                                    ),
                                    html.Div(
                                        [html.H6(id="spendingText"), html.P("Spending")],
                                        id="spending",
                                        className="mini_container",
                                    ),
                                    html.Div(
                                        [html.H6(id="incomeText"), html.P("Income")],
                                        id="income",
                                        className="mini_container",
                                    ),
                                    html.Div(
                                        [html.H6(id="balanceText"), html.P("Saving")],
                                        id="balance",
                                        className="mini_container",
                                    ),
                                ],
                                id="info-container",
                                className="row container-display",
                            ),
                            # html.Div(id='slider_state', style={'display': 'none'}).
                            html.Div(
                                [
                                    dbc.Button(
                                        "Info", id="popover-target-count", color="info",
                                        className="bg-primary badge mr-1"
                                    ),
                                    dbc.Popover(
                                        [
                                            dbc.PopoverHeader("Overview", style={'font-size': '11px'}),
                                            dbc.PopoverBody(
                                                "One graph to see your spending, income and balances. If in a given month your spending was greater than your income this will show balance in red as negative otherwise green as positive."),
                                        ],
                                        id="popover-count",
                                        is_open=False,
                                        style={'font-size': '11px'},
                                        target="popover-target-count",
                                    ),
                                    dcc.Graph(id="count_graph")],
                                id="countGraphContainer",
                                className="pretty_container",
                            ),
                        ],
                        id="right-column",
                        className="eight columns",
                    ),
                ],
                className="row flex-display",
            ),
            html.Div(
                [
                    html.Div(
                        id="banner_mini_heat",
                        children=
                        [dcc.Tabs(
                            id="mini-tabs-heat",
                            children=[
                                dcc.Tab(
                                    id="Specs-tab-heatmap",
                                    label=f'Category Heat Map in {iv.reporting_currency_symbol}',
                                    selected_className="custom-tab--selected",
                                    children=[
                                        dcc.Loading(
                                            id="loading-heatmap",
                                            children=[html.Div(
                                                [
                                                    dbc.Button(
                                                        "Info", id="popover-target-heat", color="info",
                                                        className="bg-primary badge mr-1"
                                                    ),
                                                    dbc.Popover(
                                                        [
                                                            dbc.PopoverHeader(
                                                                "Spend overview by month across full period",
                                                                style={'font-size': '11px'}),
                                                            dbc.PopoverBody(
                                                                "By default it will sum monthly spending across all selected years. It helps you realize which months are your hot spots. It figures out your normal spending or income and then by colour scale shows you when you are going away from that normality. For instance if your median spending acrosss categories is -200 the more you deviate the scale will change to blue and then red.   "),
                                                        ],
                                                        id="popover-heat",
                                                        is_open=False,
                                                        style={'font-size': '11px'},
                                                        target="popover-target-heat",
                                                    ),

                                                    dcc.Graph(id="category_volume_hm")
                                                ],
                                            )],
                                            type="default",
                                        )
                                    ],
                                ),
                                dcc.Tab(
                                    id="Specs-tab-tran",
                                    label=f'Underlying Transactions',
                                    selected_className="custom-tab--selected",
                                    children=build_transactions(
                                        SessionCache.get_customer_transactions(None).transactions, app)
                                ),
                            ],
                        )],
                        className="pretty_container eight columns",
                    ),
                    html.Div(
                        id="banner_mini",
                        children=
                        [dcc.Tabs(
                            id="mini-tabs",
                            children=[
                                dcc.Tab(
                                    id="Specs-tab-merchant",
                                    label="Merchants",
                                    selected_className="custom-tab--selected",
                                    children=[
                                        dcc.Loading(
                                            id="loading-treemap",
                                            children=[
                                                dbc.Button(
                                                    "Info", id="popover-target-merchant", color="info",
                                                    className="bg-primary badge mr-1"
                                                ),
                                                dbc.Popover(
                                                    [
                                                        dbc.PopoverHeader("Merchant break down by category and month",
                                                                          style={'font-size': '11px'}),
                                                        dbc.PopoverBody(
                                                            "See where is your money going in a given month and category. The bigger the spending the bigger the size of the merchsant will be. Hover over the merchant to see how much you have spend. "),
                                                    ],
                                                    id="popover-merchant",
                                                    is_open=False,
                                                    style={'font-size': '11px'},
                                                    target="popover-target-merchant",
                                                ),
                                                dcc.Graph(id="merchant_graph")
                                            ],
                                            type="default",
                                        )
                                    ],
                                ),
                                dcc.Tab(
                                    id="Specs-tab-category",
                                    label="Category Comparison",
                                    selected_className="custom-tab--selected",
                                    children=[
                                        dcc.Loading(
                                            id="loading-trend-graph",
                                            children=[
                                                dbc.Button(
                                                    "Info", id="popover-target-category", color="info",
                                                    className="bg-primary badge mr-1"
                                                ),
                                                dbc.Popover(
                                                    [
                                                        dbc.PopoverHeader("Category comparison",
                                                                          style={'font-size': '11px'}),
                                                        dbc.PopoverBody(
                                                            "See how did you spend in a given month in each year."),
                                                    ],
                                                    id="popover-category",
                                                    is_open=False,
                                                    style={'font-size': '11px'},
                                                    target="popover-target-category",
                                                ),
                                                dcc.Graph(id="category_trend_graph")
                                            ],
                                            type="default",
                                        )
                                    ],
                                ),
                            ],
                        )],
                        className="pretty_container four columns",
                    ),
                ],
                className="row flex-display",
            ),
            html.Div(
                [
                    html.Div(
                        id="banner_mini_map",
                        children=
                        [dcc.Tabs(
                            id="mini-tabs-map",
                            children=[
                                dcc.Tab(
                                    id="Specs-tab-map",
                                    label=f'Transaction Locations',
                                    selected_className="custom-tab--selected",
                                    children=[
                                        html.Div([
                                            html.Div(
                                                [
                                                    # dbc.Button(
                                                    #     "Experimental", id="popover-target-map", color="info",
                                                    #     className="bg-primary-exp badge mr-1"
                                                    # ),
                                                    # dbc.Popover(
                                                    #     [
                                                    #         dbc.PopoverHeader(
                                                    #             "Locate on the map places that you have spend your money",
                                                    #             style={'font-size': '11px'}),
                                                    #         dbc.PopoverBody(
                                                    #             "Your online spending often will be assigned to merchant headquarters. This is experimental feature and might be inaccuarte occasionally. "),
                                                    #     ],
                                                    #     id="popover-map",
                                                    #     is_open=False,
                                                    #     style={'font-size': '11px'},
                                                    #     target="popover-target-map",
                                                    # ),
                                                    dcc.RadioItems(
                                                        id="location_selector",
                                                        options=[
                                                            {"label": "Most Popular ", "value": "popular"},
                                                            {"label": "All ", "value": "all"},
                                                        ],
                                                        value="popular",
                                                        labelStyle={"display": "inline-block"},
                                                        className="dcc_control",
                                                    ),
                                                    dcc.Graph(id="main_graph")],
                                                className="pretty_container seven columns",
                                            ),
                                            html.Div(
                                                [
                                                    dbc.Button(
                                                        "Experimental", id="popover-target-map-det", color="info",
                                                        className="bg-primary-exp badge mr-1"
                                                    ),
                                                    dbc.Popover(
                                                        [
                                                            dbc.PopoverHeader("Spending history per location",
                                                                              style={'font-size': '11px'}),
                                                            dbc.PopoverBody(
                                                                "This is showing all transactions that we have recorded at a given place. Point your coursor at the place on the map and wait few seconds while we bringing your transactions to be plotted on this graph."),
                                                        ],
                                                        id="popover-map-det",
                                                        is_open=False,
                                                        style={'font-size': '11px'},
                                                        target="popover-target-map-det",
                                                    ),
                                                    dcc.Graph(id="individual_graph")],
                                                className="pretty_container five columns",
                                            ),
                                        ],
                                            className="row flex-display",
                                        ),
                                    ],
                                ),

                            ],
                        )],
                        className="pretty_container twelve columns",
                    ),
                ],
                className="row flex-display",
            ),

            # html.Div(
            #     [
            #         html.Div(
            #             id="banner_mini_tran",
            #             children=
            #             [dcc.Tabs(
            #                 id="mini-tabs-tran",
            #                 children=[
            #                     dcc.Tab(
            #                         id="Specs-tab-tran",
            #                         label=f'Transactions',
            #                         selected_className="custom-tab--selected",
            #                         children=build_transactions(
            #                             SessionCache.get_customer_transactions(None).transactions, app)
            #                     ),
            #                 ],
            #             )],
            #             className="pretty_container twelve columns",
            #         ),
            #     ],
            #     className="row flex-display",
            # ),
        ],
        id="mainContainer",
        style={"display": "flex", "flex-direction": "column"},
    )]


def build_banner():
    return html.Div(
        id="banner",
        className="banner",
        children=[
            html.Div(
                id="banner-text",
                children=[
                    html.H5(id="banner-text-main", children="Personal Finance Dashboard"),
                    # html.Div(id='banner-cache', style={'display': 'none'}),
                    # dcc.Store(id='banner-cache-state'),
                    html.H6(id="banner-text", children="Your finances at a glance", style={'color': '#1fc436'}),
                ],
            ),
            html.Div(
                id="banner-logo",
                children=[
                    html.Div(id='cache', style={'display': 'none'}),
                    dcc.Location(id='url_redirect', refresh=True),
                    build_report(),
                    build_refresh(),
                    html.Img(id="logo", src=app.get_asset_url("logo_700.png")),
                    build_logout(),
                ],
            ),
        ],
    )


def build_refresh():
    if SessionCache.has_user():
        return html.A(id="refresh-button", children=['RELOAD DATA'], href='#', className="")
    else:
        pass


def build_logout():
    if SessionCache.has_user():
        return html.A(id="logout-button", children=['LOGOUT'], href='/logout', className="")
    else:
        pass


def build_report():
    if SessionCache.has_user():
        return html.A(id="learn-more-button", children=['PRINTABLE REPORT'], href='/financial-report',
                      className="")
    else:
        return html.A(id="learn-more-button", children=['LEARN MORE'], href='https://gosavex.com',
                      className="")


def build_footer():
    return html.Div(
        id="footer",
        className="banner",
        children=[
            html.Div(
                id="footer-text",
                children=[
                    html.Div("Copyright Gosavex Ltd."),
                ],
            ),
        ],
    )


def build_tabs(iv: IndexView):
    if SessionCache.has_user_report_tab():
        tab1 = SessionCache.get_user_report_tab()
    else:
        tab1 = build_tab1(iv)
        # SessionCache.set_user_report_tab(tab1)

    if SessionCache.has_user_transaction_tab():
        tab2 = SessionCache.get_user_transaction_tab()
    else:
        tab2 = build_transactions_all(SessionCache.get_customer_transactions(None).transactions, app)
        # SessionCache.set_user_transaction_tab(tab2)

    tab3 = budget.build_tab3(iv)

    return html.Div(
        id="tabs",
        className="tabs",
        children=[
            dcc.Tabs(
                id="app-tabs",
                value="tab1",
                className="custom-tabs",
                children=[
                    dcc.Tab(
                        id="Specs-tab",
                        label="Reports",
                        value="tab1",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        children=tab1
                    ),
                    dcc.Tab(
                        id="Specs-tab-budget",
                        label="Budget",
                        value="tab3",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        children=tab3
                    ),
                    dcc.Tab(
                        id="Specs-tab-transaction",
                        label="Transactions",
                        value="tab2",
                        className="custom-tab",
                        selected_className="custom-tab--selected",
                        children=tab2
                    ),
                ],
            )
        ],
    )


def display_page(pathname, user_id):
    if pathname == "/login":
        body = login.create_layout(app)
    elif pathname == "/logout":
        body = logout.create_layout()
    elif pathname == "/authorization":
        body = authorization.create_layout()
    else:

        success = True
        try:
            data: IndexView = SessionCache.get_index_view(user_id)
        except Exception as ex:
            success = False
            body = redirect(ex)

        if success:
            try:
                body = build_tabs(data)
            except Exception as ex:
                body = redirect(ex)

    from model_view import Index_callback

    return html.Div(
        id="big-app-container",
        children=[
            build_banner(),
            html.Div(
                id="app-container",
                children=[
                    body,
                    # Main app
                    html.Div(id="app-content"),
                ],
            ),
            build_footer(),
        ],
    )


def redirect(ex):
    log.error("error while reading object from session", ex)
    SessionCache.reset()
    body = login.create_layout(app)
    log.info("redirecting to login page")
    return body
