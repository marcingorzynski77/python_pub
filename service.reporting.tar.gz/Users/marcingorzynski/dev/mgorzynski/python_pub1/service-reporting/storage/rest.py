import pandas as pd
import logging
import datetime as dt
import numpy as np
from concurrent.futures import ThreadPoolExecutor, wait
import dateutil.relativedelta

from common.config import Configuration
from common.util.metric import MetricCollector
from model.budget_data import BudgetData
from model.data import Customer, PeriodData
from storage.rest_helper import ErisApiBase
from common.config import config

# from common import config
logging = logging.getLogger(__name__)


class ErisApi(ErisApiBase):

    # storage for the instance reference
    # def __init__(self, config: Configuration, stats: MetricCollector):
    def __init__(self):
        # self.config = config
        # self.stats = stats
        pass

    def save_limit_data(self, data, user_id):
        super(ErisApi, self).save_limit_data(data, user_id)

    def get_budget_data(self, user_id: str, customer: Customer) -> BudgetData:
        budget_data = self.__get_budget_data(user_id, customer)

        budget_data.transactions['Month'] = budget_data.transactions['Date'].apply(self.date_month)
        budget_data.transactions["Date"] = pd.to_datetime(budget_data.transactions["Date"])
        return budget_data

    def get_data(self, user_id: str) -> Customer:
        customer = self.__get_data(user_id)
        return customer

    def get_data_transactions(self, user_id: str, customer: Customer) -> Customer:
        customer = self.__get_data_transactions(user_id, customer)
        customer.transactions = pd.concat([customer.data1y.transactions, customer.data2y.transactions])

        customer.transactions['Month'] = customer.transactions['Date'].apply(self.date_month)
        customer.transactions["Date"] = pd.to_datetime(customer.transactions["Date"])
        return customer

    def get_reporting_currency(self, user_id: str):
        data = super(ErisApi, self).get_rest_data(f'{config.client_tran_service}/client/overview/{user_id}')
        overview = pd.json_normalize(data)
        return overview.loc[:, 'reportingCurrency'].get(0)

    def date_month(self, date):
        return int(date[5:7])

    def enrich_data_transactions_with_location(self, customer: Customer):
        logging.info("get location information")

        desc_list = customer.transactions["Description"].unique()
        data_request = []
        for item in desc_list:
            data_request.append({"description": item})
        data = super(ErisApi, self).get_post_rest_data(f'{config.location_service}/location/addresses',

                                                       data_request)
        locations = []
        for row in data:
            if row["address"] != "":
                locations.append(row)

        customer.transactions['Address'] = None
        customer.transactions['Latitude'] = np.nan
        customer.transactions['Longitude'] = np.nan
        for item in locations:
            customer.transactions.loc[customer.transactions['Description'] == item['description'], 'Address'] = item[
                'address']
            customer.transactions.loc[customer.transactions['Description'] == item['description'], 'Latitude'] = item[
                'latitude']
            customer.transactions.loc[customer.transactions['Description'] == item['description'], 'Longitude'] = item[
                'longitude']

    def __get_data_transactions(self, user_id: str, customer: Customer) -> Customer:
        tran_customer = Customer()
        period1y = PeriodData(customer.reporting_currency)
        period2y = PeriodData(customer.reporting_currency)
        tran_customer.data1y = period1y
        tran_customer.data2y = period2y

        self.__process_transaction_period_data(tran_customer.data1y, customer.accounts, customer.cards, user_id, 1, 13)
        self.__process_transaction_period_data(tran_customer.data2y, customer.accounts, customer.cards, user_id, 13, 25)

        return tran_customer

    def __get_budget_data(self, user_id: str, customer: Customer) -> BudgetData:
        data = super(ErisApi, self).get_rest_data(f'{config.client_service}/client/info/{user_id}')
        stats_data = super(ErisApi, self).get_rest_data(f'{config.client_service}/client/credit/score/{user_id}')
        limits_data = super(ErisApi, self).get_rest_data(f'{config.client_service}/client/goal/spending/limits/{user_id}')
        limits = {}
        for item in limits_data:
            limits[item["categoryName"]] = item["target"]

        tran_customer = Customer()
        tran_customer.data1y = PeriodData(customer.reporting_currency)
        self.__process_transaction_period_data(tran_customer.data1y, customer.accounts, customer.cards, user_id,
                                               0, 1)
        bg = BudgetData(data, stats_data, tran_customer.data1y.transactions, limits)

        return bg

    def get_basic(self, user_id):
        customer = Customer()
        data = super(ErisApi, self).get_rest_data(f'{config.client_service}/client/info/{user_id}')
        super(ErisApi, self).process_user_data(customer, data)
        data = super(ErisApi, self).get_rest_data(f'{config.client_tran_service}/client/overview/{user_id}')
        super(ErisApi, self).process_overview_data(customer, data)
        period1y = PeriodData(customer.reporting_currency)
        period2y = PeriodData(customer.reporting_currency)
        customer.data1y = period1y
        customer.data2y = period2y
        now = dt.datetime.now()
        period1y.period_start = (now - dateutil.relativedelta.relativedelta(months=12)).strftime("%b-%Y")
        period1y.period_end = (now - dateutil.relativedelta.relativedelta(months=1)).strftime("%b-%Y")
        period1y.period_desc = f'{period1y.period_start} to {period1y.period_end}'
        period2y.period_start = (now - dateutil.relativedelta.relativedelta(months=24)).strftime("%b-%Y")
        period2y.period_end = (now - dateutil.relativedelta.relativedelta(months=13)).strftime("%b-%Y")
        period2y.period_desc = f'{period2y.period_start} to {period2y.period_end}'
        return customer, period1y, period2y

    def __get_data(self, user_id: str) -> Customer:
        customer, period1y, period2y = self.get_basic(user_id)

        self.__process_period_data(period1y, customer, user_id, 1, 13)
        self.__process_period_data(period2y, customer, user_id, 13, 25)

        customer.combine_categories()
        customer.combine_merchants()
        customer.produce_yearly_stats()

        return customer

    def __process_period_data(self, period: PeriodData, customer: Customer, user_id: str, from_month: int,
                              to_month: int):
        # data to be sent to api

        balances_res = []
        categories_res = []
        merchants_res = []

        balances_async = []
        categories_async = []
        merchants_async = []

        logging.info("start asking for data")
        with ThreadPoolExecutor(max_workers=30) as executor:
            for index, account in customer.accounts.iterrows():
                balances_async.append(
                    executor.submit(self.process_details_balances, account['accountId'], account['providerId'],
                                    from_month, to_month, user_id))
                categories_async.append(
                    executor.submit(self.process_details_categories, account['accountId'], account['providerId'],
                                    from_month, to_month, user_id))
                merchants_async.append(
                    executor.submit(self.process_details_merchants, account['accountId'], account['providerId'],
                                    from_month, to_month, user_id))

            for index, card in customer.cards.iterrows():
                balances_async.append(
                    executor.submit(self.process_details_balances, card['accountId'], card['providerId'],
                                    from_month, to_month, user_id))
                categories_async.append(
                    executor.submit(self.process_details_categories, card['accountId'], card['providerId'],
                                    from_month, to_month, user_id))
                merchants_async.append(
                    executor.submit(self.process_details_merchants, account['accountId'], card['providerId'],
                                    from_month, to_month, user_id))

            wait(balances_async)
            for item in balances_async:
                try:
                    res = item.result()
                    balances_res.append(res)
                except Exception as e:
                    logging.exception(e)

            wait(categories_async)
            for item in categories_async:
                try:
                    res = item.result()
                    categories_res.append(res)
                except Exception as e:
                    logging.exception(e)

            wait(merchants_async)
            for item in merchants_async:
                try:
                    res = item.result()
                    merchants_res.append(res)
                except Exception as e:
                    logging.exception(e)

        logging.info("finished asking for data")

        super(ErisApi, self).process_balances(period, balances_res)
        super(ErisApi, self).process_categories(period, categories_res)
        super(ErisApi, self).process_merchants(period, merchants_res)

    def __process_transaction_period_data(self, period: PeriodData, accounts, cards, user_id: str, from_month: int,
                                          to_month: int):
        # data to be sent to api

        tran_res = []
        tran_async = []

        logging.info("start asking for tran data")
        with ThreadPoolExecutor(max_workers=30) as executor:
            for index, account in accounts.iterrows():
                tran_async.append(
                    executor.submit(self.process_details_transactions, account['accountId'], account['providerId'],
                                    from_month, to_month, user_id))

            for index, card in cards.iterrows():
                tran_async.append(
                    executor.submit(self.process_details_transactions, card['accountId'], card['providerId'],
                                    from_month, to_month, user_id))

            wait(tran_async)
            for item in tran_async:
                try:
                    res = item.result()
                    tran_res.append(res)
                except Exception as e:
                    logging.exception(e)

        logging.info("finished asking for tran data")
        super(ErisApi, self).process_transaction_data(period, tran_res)

    def process_details_balances(self, account, provider, from_month, to_month, user_id):
        logging.info("processing balances")
        req = self.get_requests(account, provider, from_month, to_month, user_id)
        data = super(ErisApi, self).get_post_rest_data(f'{config.client_tran_service}/client/balance/keys',
                                                       req)
        return data

    def process_details_categories(self, account, provider, from_month, to_month, user_id):
        logging.info("processing categories")
        req = self.get_requests(account, provider, from_month, to_month, user_id)
        data = super(ErisApi, self).get_post_rest_data(f'{config.client_tran_service}/client/category/keys',
                                                       req)
        return data

    def process_details_merchants(self, account, provider, from_month, to_month, user_id):
        logging.info("processing merchants")
        req = self.get_requests(account, provider, from_month, to_month, user_id)
        data = super(ErisApi, self).get_post_rest_data(f'{config.client_tran_service}/client/merchant/keys',
                                                       req)
        return data

    def process_details_transactions(self, account, provider, from_month, to_month, user_id):
        logging.info("transactions balances")
        req = self.get_requests(account, provider, from_month, to_month, user_id)
        data_request = {"keys": req, "limit": 10000}
        data = super(ErisApi, self).get_post_rest_data(f'{config.client_tran_service}/client/transaction/keys',
                                                       data_request)
        return data

    def get_requests(self, account, provider, from_month, to_month, user_id):
        data = []
        now = dt.datetime.now()
        for x in range(from_month, to_month):
            date = now - dateutil.relativedelta.relativedelta(months=x)
            data_request = {"accountId": f'{account}', "month": date.month, "providerId": f'{provider}',
                            "userId": f'{user_id}', "year": date.year}
            data.append(data_request)
        return data

    def get_auth_token(self, ip: str):
        logging.info("auth token")
        data = super(ErisApi, self).get_post_empty_data(
            f'{config.auth_service}/oauth/financial-report/token?ip=' + ip)
        return data

    def get_auth_code(self, token: str):
        logging.info("auth code")
        data = super(ErisApi, self).get_post_empty_data(
            f'{config.auth_service}/oauth/financial-report/code?token=' + token)
        return data

    def verify_auth_code(self, token: str, code: str):
        logging.info("verify auth code")
        data = super(ErisApi, self).get_post_empty_data(
            f'{config.auth_service}/oauth/financial-report/verify?code=' + code + '&token=' + token)
        return data
