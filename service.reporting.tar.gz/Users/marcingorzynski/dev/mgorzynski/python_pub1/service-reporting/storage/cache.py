import logging
import datetime as dt
import uuid
import pandas as pd
from flask import session
import pandas as pd
from common.config import Configuration
from common.util.metric import MetricCollector
from model.budget_data import BudgetData
from model.data import Customer
from model.transaction_data import CustomerTransaction
from model_view.index_vm import IndexView
from storage.rest import ErisApi

logging = logging.getLogger(__name__)
data_rest: ErisApi = ErisApi()

user_report_tab = None
user_transaction_tab = None


class SessionCache(object):

    # storage for the instance reference
    # def __init__(self, config: Configuration, stats: MetricCollector):
    def __init__(self):
        # self.config = config
        # self.stats = stats
        pass

    @staticmethod
    def get_limit_data() -> pd.DataFrame:
        data: pd.DataFrame = SessionCache.__get_limit_data()
        if data is None:
            logging.info(f'limit data not in cache ')
        else:
            logging.info(f'getting limit data from cache for user')

        return data

    @staticmethod
    def set_limit_data(data):
        SessionCache.__set_limit_data(data)

    @staticmethod
    def set_category_data(data):
        SessionCache.__set_category_data(data)

    @staticmethod
    def get_category_data() -> str:
        data: str = SessionCache.__get_category_data()
        if data is None:
            logging.info(f'category data not in cache ')
        else:
            logging.info(f'getting category data from cache for user')

        return data

    @staticmethod
    def set_budget_data_target(target):
        SessionCache.__set_budget_data(target)

    @staticmethod
    def get_budget_data(user_id: str) -> BudgetData:
        data: Customer = SessionCache.__get_budget_data()

        if data is None or (dt.datetime.utcnow() - SessionCache.__get_budget_data_insert_time()).total_seconds() > 3600:
            if user_id is None:
                user_id = SessionCache.get_user()
            logging.info(f'budget data not in cache user {user_id}, requesting')
            res_data = data_rest.get_budget_data(user_id, SessionCache.get_data())
            SessionCache.__set_budget_data(res_data)
            data = res_data
        else:
            logging.info(f'getting data from cache for user {user_id}')
        return data

    @staticmethod
    def get_customer(user_id: str) -> Customer:
        data: Customer = SessionCache.get_data()
        if data is None:
            if user_id is None:
                user_id = SessionCache.get_user()
            logging.info(f'data not in cache user {user_id}, requesting')
            res_data = data_rest.get_data(user_id)
            SessionCache.set_user_data(res_data)
            data = res_data
        else:
            logging.info(f'getting data from cache for user {user_id}')
        return data

    @staticmethod
    def get_customer_transactions(user_id: str) -> Customer:
        data: Customer = SessionCache.get_data_tran()

        if user_id is None:
            user_id = SessionCache.get_user()

        user: Customer = SessionCache.get_data()
        if user is None:
            user = SessionCache.get_customer(user_id)

        if data is None:
            logging.info(f'transaction data not in cache user {user_id}, requesting')
            customer_with_data_tran = data_rest.get_data_transactions(user_id, user)
            data_rest.enrich_data_transactions_with_location(customer_with_data_tran)
            customer_with_data_tran.reporting_currency = data_rest.get_reporting_currency(user_id)
            SessionCache.set_user_data_tran(customer_with_data_tran)
            data = customer_with_data_tran
        else:
            logging.info(f'getting transaction data from cache for user {user_id}')
        return data

    @staticmethod
    def get_index_view(user_id: str) -> IndexView:
        data: IndexView = SessionCache.__get_index_view()

        if user_id is None:
            user_id = SessionCache.get_user()

        if data is None:
            logging.info(f'index view not in cache {user_id}, building')
            customer_with_data_tran = SessionCache.get_customer_transactions(user_id)

            cust: Customer = SessionCache.get_customer(user_id)

            if cust.accounts.shape[0] > 0:
                cust.accounts["desc"] = cust.accounts["providerId"] + " " + cust.accounts["accountNumber"]
                accounts = cust.accounts[["accountId", "desc"]]
            else:
                accounts = pd.DataFrame()

            if cust.cards.shape[0] > 0:
                cust.cards["desc"] = cust.cards["providerId"] + " " + cust.cards["type"] + " " + cust.cards["partialCardNumber"]
                cards = cust.cards[["accountId", "desc"]]
            else:
                cards = pd.DataFrame()

            df = pd.concat([accounts, cards])

            ct: CustomerTransaction = CustomerTransaction(customer_with_data_tran.reporting_currency,
                                                          customer_with_data_tran.transactions, df.to_dict('records'))

            iv: IndexView = IndexView(ct, customer_with_data_tran.transactions)

            SessionCache.__set_index_view(iv)
            data = iv
        else:
            logging.info(f'getting index view data from cache for user {user_id}')
        return data

    @staticmethod
    def reset():
        session['user'] = None
        session['token'] = None
        session['user_data'] = None
        session['user_data_insert_time'] = None
        session['user_data_tran'] = None
        session['user_data_tran_insert_time'] = None
        session['vm_index_view'] = None
        session['user_budget_data'] = None
        session['user_budget_data_insert_time'] = None
        session['user_budget_welcome_insert_time'] = None


    @staticmethod
    def reload():
        session['user_data'] = None
        session['user_data_insert_time'] = None
        session['user_data_tran'] = None
        session['user_data_tran_insert_time'] = None
        session['vm_index_view'] = None
        session['user_budget_data'] = None
        session['user_budget_data_insert_time'] = None

    @staticmethod
    def get_count():
        return session.get('page_count')

    @staticmethod
    def reset_count():
        session['page_count'] = 0
        session.modified = True

    @staticmethod
    def get_session():
        count = session.get('session')
        if count is None:
            session['session'] = str(uuid.uuid4())
        return count

    @staticmethod
    def increase_count():
        SessionCache.lock.acquire()
        count = session.get('page_count')
        if count is None:
            session['page_count'] = 1
            session.modified = True
            session.should_save
        else:
            session['page_count'] = count + 1
            session.modified = True
        SessionCache.lock.release()

    @staticmethod
    def get_token():
        return session.get('token')

    @staticmethod
    def has_token() -> bool:
        return session.get('token') is not None

    @staticmethod
    def set_token(token):
        session['token'] = token

    @staticmethod
    def get_user():
        return session.get('user')

    @staticmethod
    def has_user() -> bool:
        return session.get('user') is not None

    @staticmethod
    def set_user(user):
        session['user'] = user

    @staticmethod
    def get_data():
        return session.get('user_data')

    @staticmethod
    def has_user_data() -> bool:
        return session.get('user_data') is not None

    @staticmethod
    def set_user_data(user):
        session['user_data'] = user
        session['user_data_insert_time'] = dt.datetime.utcnow()

    @staticmethod
    def __get_budget_data():
        return session.get('user_budget_data')

    @staticmethod
    def __get_budget_data_insert_time():
        return session.get('user_budget_data_insert_time')

    @staticmethod
    def __has_budget_data() -> bool:
        return session.get('user_budget_data') is not None

    @staticmethod
    def __set_budget_data(user):
        session['user_budget_data'] = user
        session['user_budget_data_insert_time'] = dt.datetime.utcnow()

    @staticmethod
    def set_user_report_tab(tab):
        user_transaction_tab = tab

    @staticmethod
    def set_user_transaction_tab(tab):
        user_transaction_tab = tab

    @staticmethod
    def get_user_report_tab():
        return user_transaction_tab

    @staticmethod
    def get_user_transaction_tab():
        return user_transaction_tab

    @staticmethod
    def has_user_report_tab():
        return user_report_tab is not None

    @staticmethod
    def has_user_transaction_tab():
        return user_transaction_tab is not None

    @staticmethod
    def get_user_data_insert_time_delta_min():
        t = session.get('user_data_insert_time')
        if t is None:
            return 0
        minute_dif = (dt.datetime.utcnow() - t).min
        return minute_dif

    @staticmethod
    def get_data_tran():
        return session.get('user_data_tran')

    @staticmethod
    def has_user_data_tran() -> bool:
        return session.get('user_data_tran') is not None

    @staticmethod
    def set_user_data_tran(user):
        session['user_data_tran'] = user
        session['user_data_tran_insert_time'] = dt.datetime.utcnow()

    @staticmethod
    def get_user_data_tran_insert_time_delta_min():
        t = session.get('user_data_tran_insert_time')
        if t is None:
            return 0
        minute_dif = (dt.datetime.utcnow() - t).min
        return minute_dif

    @staticmethod
    def __get_index_view():
        return session.get('vm_index_view')

    @staticmethod
    def has_index_view() -> bool:
        return session.get('vm_index_view') is not None

    @staticmethod
    def __set_index_view(iv):
        session['vm_index_view'] = iv

    @staticmethod
    def __get_limit_data():
        return session.get('user_limit_data')

    @staticmethod
    def __has_limit_data() -> bool:
        return session.get('user_limit_data') is not None

    @staticmethod
    def __set_limit_data(data):
        session['user_limit_data'] = data

    @staticmethod
    def __get_category_data():
        return session.get('user_category_data')

    @staticmethod
    def __set_category_data(data):
        session['user_category_data'] = data

    @staticmethod
    def has_budget_welcome() -> bool:
        return session.get('user_budget_welcome_insert_time') is not None

    @staticmethod
    def set_budget_welcome():
        session['user_budget_welcome_insert_time'] = dt.datetime.utcnow()


