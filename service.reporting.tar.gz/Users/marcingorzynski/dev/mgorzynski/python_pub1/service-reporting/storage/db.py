import pandas as pd
import logging
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import dict_factory

from common.config import Configuration
from common.util.metric import MetricCollector
from model.data import Customer

logging = logging.getLogger(__name__)


class CassandraDb(object):
    # storage for the instance reference
    # def __init__(self, config: Configuration, stats: MetricCollector):
    def __init__(self):
        # self.config = config
        # self.stats = stats
        self.cluster: Cluster = None
        self.session = self.create_session()

    def __del__(self):
        self.cluster.shutdown()

    def create_session(self):
        auth_provider = PlainTextAuthProvider(username="cassandra", password="cassandra")
        self.cluster = Cluster(['192.168.1.128'], auth_provider=auth_provider)
        session = self.cluster.connect("eris")
        return session

    # noinspection PyTypeChecker
    def get_session(self):
        return self.session

    def get_data(self, user_id: str) -> Customer:
        customer = Customer()
        session = self.cluster.connect("eris")
        session.row_factory = dict_factory
        user_data = pd.DataFrame(self.get_session().execute(
            "SELECT userId, reportingcurrency, savinggoal, spendinglimnit FROM eris.users WHERE userId=?", user_id,
            timeout=None))
        customer.user = user_data

        provider_data = pd.DataFrame(
            self.get_session().execute("SELECT userId, providerId FROM eris.user_provider_settings WHERE userId=?",
                                       user_id, timeout=None))
        customer.providers = provider_data

        accounts_data = None
        for row in provider_data.iterrows():
            if accounts_data is None:
                accounts_data = pd.DataFrame(self.get_session().execute(
                    "SELECT userId, providerId, accountId, currency, current, ovedraft, sortcode, savinggoal, spendinglimit FROM eris.user_accounts WHERE userId=? and providerId=?",
                    user_id, row['providerId'], timeout=None))
            else:
                accounts_data.append(pd.DataFrame(self.get_session().execute(
                    "SELECT userId, providerId FROM eris.user_accounts WHERE userId=? and providerId=?",
                    user_id, row['providerId'], timeout=None)))
        customer.accounts = accounts_data

        cards_data = None
        for row in provider_data.iterrows():
            if cards_data is None:
                cards_data = pd.DataFrame(self.get_session().execute(
                    "SELECT userId, providerId, accountsId, currency FROM eris.user_provider_settings WHERE userId=? and providerId=?",
                    user_id, row['providerId'], timeout=None))
            else:
                accounts_data.append(pd.DataFrame(self.get_session().execute(
                    "SELECT userId, providerId FROM eris.user_provider_settings WHERE userId=? and providerId=?",
                    user_id, row['providerId'], timeout=None)))
        customer.cards = cards_data


        # for row in session.execute(sql_query):
        #     df = df.append(pd.DataFrame(row, index=[0]))
        #
        # df = df.reset_index(drop=True).fillna(pd.np.nan)
        return customer
