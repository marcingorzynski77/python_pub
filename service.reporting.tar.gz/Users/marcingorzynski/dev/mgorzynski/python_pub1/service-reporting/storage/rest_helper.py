from model.data import Customer, PeriodData
import requests
import json
import pandas as pd
import logging
from typing import List
from common.config import config

log = logging.getLogger(__name__)


class ErisApiBase(object):

    def __init__(self):
        pass

    def get_rest_data(self, url: str):
        resp = requests.get(url)
        data = resp.json()
        return data

    def get_post_rest_data(self, url: str, inputs: str):
        resp = requests.post(url, json=inputs, headers={'Content-type': 'application/json'})
        data = resp.json()
        return data

    def get_post_empty_data(self, url: str):
        resp = requests.post(url, headers={'Content-type': 'application/json'}, auth=('webadmin', 'cambridge19'))
        data = resp.json()
        return data

    def save_limit_data(self, data: pd.DataFrame, user_id: str):
        input_data = []
        for index, row in data.iterrows():
            if row["SuggestedLimit"] != row["Target"]:
                item = {'categoryName': row["Category"], 'userId': user_id, 'target': row["SuggestedLimit"]}
                input_data.append(item)

        req = json.dumps(input_data)
        try:
            resp = requests.post(f'{config.client_tran_service}/client/goal/spending/limit/update', headers={'Content-type': 'application/json'}, auth=('webadmin', 'cambridge19'),
                                 data=req)
        except:
            logging.error(f'error saving limits for user {user_id}')

        try:
            item = {'goal': abs(row["SpendingTarget"]), 'userId': user_id}
            req = json.dumps(item)
            resp = requests.post(f'{config.client_tran_service}/client/goal/spending/update', headers={'Content-type': 'application/json'}, auth=('webadmin', 'cambridge19'),
                                 data=req)
        except:
            logging.error(f'error saving target for user {user_id}')

        try:
            item = {'enabled': row["MobileNotification"], 'userId': user_id, 'notification': 'goals'}
            req = json.dumps(item)
            resp = requests.post(f'{config.client_tran_service}/client/notification/update',
                                 headers={'Content-type': 'application/json'}, auth=('webadmin', 'cambridge19'),
                                 data=req)
        except:
            logging.error(f'error saving mobile notification for user {user_id}')


    def process_stats(self, customer: Customer):
        customer.combine_categories()
        customer.combine_merchants()
        customer.produce_yearly_stats()

    def process_overview_data(self, customer: Customer, overview_data):
        overview = pd.json_normalize(overview_data)
        customer.total_balance = overview.loc[:, 'totalBalance'].get(0)
        customer.total_credit = overview.loc[:, 'totalCredit'].get(0)
        customer.reporting_currency = overview.loc[:, 'reportingCurrency'].get(0)

        cards = pd.json_normalize(overview_data['cards'])
        accounts = pd.json_normalize(overview_data['accounts'])

        customer.cards = cards
        customer.accounts = accounts

    def process_user_data(self, customer: Customer, user_data):
        user = pd.json_normalize(user_data)
        customer.user = user

    def process_transaction_data(self, period: PeriodData, data: List):
        df = []
        for d in data:
            trans = pd.json_normalize(d)
            df.append(trans)

        trans = pd.concat(df)
        period.transactions = trans

    def process_categories(self, period: PeriodData, data: List):
        df = []
        for d in data:
            categories = pd.json_normalize(d)
            df.append(categories)

        categories = pd.concat(df)
        period.categories = categories

    def process_merchants(self, period: PeriodData, data: List):
        df = []
        for d in data:
            merchants = pd.json_normalize(d)
            df.append(merchants)

        merchants = pd.concat(df)
        period.merchants = merchants

    def process_balances(self, period: PeriodData, data: List):
        df = []
        for d in data:
            balances = pd.json_normalize(d)
            df.append(balances)

        balances = pd.concat(df)
        period.balances = balances
