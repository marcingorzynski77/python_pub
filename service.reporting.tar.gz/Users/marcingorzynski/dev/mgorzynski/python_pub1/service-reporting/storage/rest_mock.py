import logging
import os
import json

from model.data import Customer, PeriodData
from model.transaction_data import CustomerTransaction
from storage.rest_helper import ErisApiBase

logging = logging.getLogger(__name__)


class ErisApiMock(ErisApiBase):
    def __init__(self):
        pass

    def get_data(self) -> Customer:
        customer = self.__get_overview_data()
        customer.data1y = self.__get_data_1y()
        customer.data2y = self.__get_data_2y()

        customer.combine_categories()
        customer.combine_merchants()
        customer.produce_yearly_stats()

        return customer

    def get_transaction_data(self) -> CustomerTransaction:
        customer = self.__get_overview_data()
        transactions = CustomerTransaction("GBP")
        transactions.transactions = customer.transactions
        transactions.period_start = "FEB 2018"
        transactions.period_end = "FEB 2020"
        return transactions

    def __get_overview_data(self) -> Customer:
        customer = Customer()

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'user.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_user_data(customer, data)

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'overview.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_overview_data(customer, data)

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'transactions.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_transaction_data(customer, data)

        return customer

    def __get_data_1y(self) -> PeriodData:
        period = PeriodData('GBP')
        period.period_desc = "Mar 2019 to Mar 2020"
        period.period_start = "Mar 2019"
        period.period_end = "Mar 2020"

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'balance1y.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_balances(period, data)

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'categories1y.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_categories(period, data)

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'merchants1y.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_merchants(period, data)
        return period

    def __get_data_2y(self) -> PeriodData:
        period = PeriodData('GBP')
        period.period_desc = "Feb 2018 to Feb 2019"
        period.period_start = "Feb 2018"
        period.period_end = "Feb 2019"

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'balance2y.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_balances(period, data)

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'categories2y.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_categories(period, data)

        file_path = os.path.join(os.path.dirname(__file__), '../test/test_files', 'merchants2y.json')
        with open(file_path) as json_file:
            data = json.load(json_file)

        super(ErisApiMock, self).process_merchants(period, data)
        return period
