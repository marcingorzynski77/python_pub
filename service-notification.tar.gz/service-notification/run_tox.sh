#!/usr/bin/env bash
tox -- -f -s

