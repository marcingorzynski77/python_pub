#!/usr/bin/env bash
python -m service -c config.yml -l logging.yml