#!/usr/bin/env python
""" Mirage Notificaion module"""
import os
from setuptools import setup

REQUIREMENTS = [
    line.strip() for line in open(os.path.join(os.path.dirname(__file__),
                                               'requirements.txt')).readlines()]

version = {}
with open("notification/version.py") as fp:
    exec(fp.read(), version)


setup(
    name='service-notification',
    version=version['__version__'],
    packages=['notification', 'notification.endpoints'],
    description='Notification service Python implementation',
    author='Business Application Delivery team',
    license='LLoyds Banking Group',
    author_email='CB-BusinessApplicationDelivery@LloydsBanking.com',
    install_requires=REQUIREMENTS,
    include_package_data=True,
    keywords='notification service responsible for alerting users',
    classifiers=[
	'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
)
