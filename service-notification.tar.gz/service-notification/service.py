"""metric service"""
import sys
from notification import app


if __name__ == "__main__":
    app.main(sys.argv[1:])
