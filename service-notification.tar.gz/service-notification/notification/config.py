""" configuration module"""
import logging
from common.config import Configuration

config = None
class NotificationConfiguration(Configuration):

    def __init__(self):
        """ class holding application settings"""
        self.port = ""
        self.smtp = ""
        self.sender = ""
        self.rrr_recon_recipient = ""
        self.service_triage_endpoint = ""
        self.service_metric_endpoint = ""
        super(NotificationConfiguration, self).__init__()

    def load_default(self):
        """ load default configuration"""
        super(NotificationConfiguration, self).load_default()

    def load(self, configfile):
        """ load configuration from the provided file, if not provided defaults will be used"""
        super(NotificationConfiguration, self).load(configfile)
        if configfile:
            self.port = self.app_settings['port']
            self.smtp = self.app_settings['smtp']
            self.sender = self.app_settings['sender']
            self.rrr_recon_recipient = self.app_settings['rrr_recon_recipient']
            self.service_triage_endpoint = self.app_settings['service_triage_endpoint']
            self.service_metric_endpoint = self.app_settings['service_metric_endpoint']
        else:
            self.load_default()

config: NotificationConfiguration
