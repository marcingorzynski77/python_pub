""" responsible for handling global events"""
import logging
import requests
from common.messaging.rabbitmq_api import EventSinkActor, EventProducer
from common.messaging.models import Event
from notification import const
from notification.builder import Controller
from notification.rrr_recon import Email as RRRTemplate
from notification.rrr_status import Email as RRRStatus


log = logging.getLogger(__name__)


class EventSink(EventSinkActor):
    """ handler for all global event messages on the service bus """
    def __init__(self):
        super(EventSink, self).__init__()
        log.info("initializing event sink")
        self.mq_producer = EventProducer()
        self.messages = {}
        self.rrr_run_id = None

    def process_event(self, event, template):
        log.info("initialising notification for template: %s", template)
        controller = Controller(template)
        controller.run(event,self.rrr_run_id)

    def on_receive(self, message):
        if "global_event" in message:
            if isinstance(message['global_event'], Event):
                event = message['global_event']
                self.handle_event(event)
            else:
                log.info("expected event type but received: %s", type(message))
        else:
            log.info("expected global event but received: %s", message)

    def handle_event(self, event):

        if event.event_name == const.SERVICE_TRIAGE_DATA_RRR_AVAILABLE:
            log.info("received global_event message: %s", event.event_name)

            # go and fatch payload
            self.process_event(event, RRRTemplate(event))

            log.info("sending global event: %s", const.SERVICE_NOTIFICATION_DATA_RRR_SENT)
            self.mq_producer.create_and_send_event(const.SERVICE_NOTIFICATION_DATA_RRR_SENT, event.bus_date)
        elif event.event_name == const.SERVICE_RRR_STATUS_REQUEST:
            log.info("received global_event message: %s", event.event_name)

            # go and fatch payload
            self.process_event(event, RRRStatus(event.bus_date.strftime('%Y-%m-%d')))

            log.info("sending global event: %s", const.SERVICE_NOTIFICATION_DATA_RRR_SENT)
            self.mq_producer.create_and_send_event(const.SERVICE_NOTIFICATION_DATA_RRR_SENT, event.bus_date)
        elif event.event_name == const.SERVICE_RRR_CALCULATION_START:
            self.rrr_run_id = event.correlated_message_id
            log.info("run_id saved as: %s", self.rrr_run_id)
        else:
            log.debug("not interested in message: %s", event.event_name)
        return

#3a0a27b0-8037-4221-8ed1-a9832f2ef963

        #service = controller.builder()
      #  for json_payload in res.iter_lines():
       #     if json_payload:
        #        Controller





