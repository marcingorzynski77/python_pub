import datetime
import json
import logging
import requests
import dateutil.parser
import pyodbc
from notification.config import config
from common.models.trade import TradeSchema
from common.models.hierarchy import Hierarchy

log = logging.getLogger(__name__)

def get_json(event):
    url = "{0}{1}{2}{3}/{4}".format('http://', config.service_triage_endpoint,
                                    '/api/triage/v1/stream/',
                                    event.bus_date.strftime('%Y-%m-%d'),
                                    event.correlated_message_id)
    log.info("connecting to %s", url)

    res = requests.get(url, stream=True)

    if res.status_code != 200:
        raise ValueError('GET /api/v1/stream/{0}'.format(res.status_code))  #

    return res


def get_metrics(event, correlation_id, category):

    url = "http://{0}/api/metric/v1/stream/{1}/{2}/{3}".format(config.service_metric_endpoint,
                                                               event.bus_date.strftime('%Y-%m-%d'), correlation_id, category)
    log.info("connecting to %s", url)
    res = requests.get(url, stream=True)
    if res.status_code != 200:
        raise ValueError('GET /api/v1/stream/{0}'.format(res.status_code))

    metrics = {}
    for item in res.iter_lines():
        if item:
            load = json.loads(item)
            metrics.update(load)
    return metrics
