# This is the template for the RRR Reconciliation
import logging
import dateutil.parser

log = logging.getLogger(__name__)


class Email(object):
    def __init__(self, bus_date):
        self.bus_date = bus_date
        self.info = None
        self.body = "This is a rrr_recon email"

    def build_html(self, res_static, res_sensitivities, res_sensitivities_started):
        """Builds and sends a html based email by using the data parsed from the JSON payload."""
        
        log.info("build HTML body for email")

        html = f"""<html> 
                    <table>
                    <tr><td width=500>
                    <font face="segoe ui" color="limegreen"  size = "6">RRR: </font>
                    <font face="segoe ui" color="MediumSeaGreen"  size = "5">Missing Static Files</font>
                    </td><td width=500 align="right"><font face="segoe ui" color="limegreen"  size = "6">COB: </font>
                    <font face="segoe ui" color="MediumSeaGreen"  size = "5">{self.bus_date}</font></td></tr>
                    </table>
                    <br>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>              
                      
                    <font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=225>File</th>
                            <th bgcolor="#FFC57E" width=225 align="center">Last Checked</th>
                        </tr>"""

        if res_static:
            for item in res_static:
                html = html + f"""<tr align="center"><td>{item}</td><td>
                                {dateutil.parser.parse(res_static[item]).strftime('%Y-%m-%d %H:%M:%S')}</td></tr>"""
        else:
            html = html + """<tr align="center"><td>No files received yet</td><td></td></tr>"""

        html = html + """  
        
                    </font>
                    </table>                    
                    <br>                    				
                    <p><font face="segoe ui" color="limegreen"  size = "6">RRR: </font>
                    <font face="segoe ui" color="MediumSeaGreen"  size = "5">Missing/Processing Sensitivity Files</font>
                    </p>                    
                    <br>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                    <font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=225>File</th>                            
                            <th bgcolor="#FFC57E" width=225 align="center">Started Processing</th>
                        </tr>"""

        if res_sensitivities:
            for item in res_sensitivities:

                if item in res_sensitivities_started:
                    start = dateutil.parser.parse(res_sensitivities_started[item]).strftime('%Y-%m-%d %H:%M:%S')
                else:
                    start = ""

                html = html + f"""<tr align="center"><td>{item}</td><td>{start}</td></tr>"""
        else:
            html = html + """<tr align="center"><td>No files received yet</td><td></td></tr>"""

        html += """  
                    
                    </font>
                    </table>
                </table>
        </html>"""

        return html
