"""Metric module"""
import logging


log = logging.getLogger(__name__)


class ServiceMetric:
    error_messages = []
    """Gather all relevant metrics for this service"""
    def __init__(self):
        pass

    @staticmethod
    def clear():
        log.info("clearing metrics")
        ServiceMetric.error_messages = []
