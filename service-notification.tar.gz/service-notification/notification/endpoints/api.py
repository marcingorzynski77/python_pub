"""Trade Rest module"""
import logging
from flask_restplus import Resource
from notification.restplus import api

log = logging.getLogger(__name__)

ns = api.namespace('trade', description='Operations related to notification service. Business date is required in format dd-MM-yyyy ')


@ns.route('/v1/stream/<string:busdate>')
class NotificationCollection(Resource):
    def get(self, busdate):
         return {'message': "Not supported"}, 500
