""" entry module"""
import sys
from common.util.args import AppStart
import notification.config as service_config
from notification import version


def main(argv):
    args = AppStart()
    args.parse_args(argv)
    args.setup_logging()
    service_config.config = service_config.NotificationConfiguration()
    args.configure_app(service_config.config)

    from common.rest.start_module import Startup
    from notification.endpoints.api import ns as notification_namespace
    from notification.restplus import api
    from notification import event_sink

    app = Startup(args)
    app.print_header(version.__version__)
    app.initialize_app(notification_namespace, api, event_sink)
    app.start()


if __name__ == "__main__":
    main(sys.argv[1:])

