"""Contero..."""
import datetime
import json
import logging
import smtplib
from notification import const
from notification.request import get_json
from notification.request import get_metrics
from notification.config import config
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# from notification.rrr_recon import Email as RRRTemplate

log = logging.getLogger(__name__)


class Controller(object):
    def __init__(self, template):
        self.bus_date = ""
        self.json_data = None
        self.data_map = ""
        self.email_settings = ""
        self.template_settings = ""
        self.email = ""
        self.template = template

    # Control
    def run(self, event, run_id):
        """Source data for email"""

        if event.event_name == const.SERVICE_TRIAGE_DATA_RRR_AVAILABLE:
            self.run_triage_json(event)
        else:
            if run_id != "":
                self.run_rrr_status(event, run_id)
            else:
                log.info('No run_id and so unable to produce Status email. This occurs if RRR has yet to start.')

    def run_triage_json(self, event):
        res = get_json(event)

        for json_payload in res.iter_lines():
            log.info("Checking payload")
            if json_payload:
                self.json_data = json.loads(json_payload)
                if 'info' in self.json_data:
                    info = self.json_data['info']
                    html = self.build_email(info)

                    if html != "":
                        self.send_email(html)
                    else:
                        log.info('No html generated and so email not sent')
                elif 'error' in self.json_data:
                    log.info(self.json_data['error'])
                else:
                    log.info(self.json_data)
            else:
                log.warning("No payload received")

        log.info("Done parsing JSON")

    def build_email(self, info):
        """Open the relevant template, parse the JSON, build the email in HTML."""
        html = ""

        if self.template:
            log.info("Parsing JSON")
            self.template.parse_json(info)
            log.info("Generating HTML")
            html = self.template.build_html()
        else:
            log.info("No template detected")

        return html

    def run_rrr_status(self, event, run_id):
        log.info("Getting RRR_STATUS_STATIC_WAITING")
        res_static_waiting = get_metrics(event, run_id, const.RRR_STATUS_STATIC_WAITING)
        log.debug("RRR_STATUS_STATIC_WAITING. Len: {0}, Values: {1}", len(res_static_waiting), res_static_waiting)

        log.info("Getting RRR_STATUS_STATIC_PROCESSED")
        res_static_processed = get_metrics(event, run_id, const.RRR_STATUS_STATIC_PROCESSED)
        log.debug("RRR_STATUS_STATIC_PROCESSED. Len: {0}, Values: {1}", len(res_static_processed), res_static_processed)

        log.info("Getting RRR_STATUS_SENSITIVITY_WAITING")
        res_sensitivities_waiting = get_metrics(event, run_id, const.RRR_STATUS_SENSITIVITY_WAITING)
        log.debug("RRR_STATUS_SENSITIVITY_WAITING. Len: {0}, Values: {1}", len(res_sensitivities_waiting),
                  res_sensitivities_waiting)

        log.info("Getting RRR_TIMELINESS_INPUTFILEPROCESS_FINISH")
        res_sensitivities_processed = get_metrics(event, run_id, const.RRR_TIMELINESS_INPUTFILEPROCESS_FINISH)
        log.debug("RRR_TIMELINESS_INPUTFILEPROCESS_FINISH. Len: {0}, Values: {1}", len(res_sensitivities_processed),
                  res_sensitivities_processed)

        log.info("Getting RRR_TIMELINESS_INPUTFILEPROCESS_START")
        res_sensitivities_started = get_metrics(event, run_id, const.RRR_TIMELINESS_INPUTFILEPROCESS_START)
        log.debug("RRR_TIMELINESS_INPUTFILEPROCESS_START. Len: {0}, Values: {1}", len(res_sensitivities_started),
                  res_sensitivities_started)

        # Match and deduce what files are still waiting
        for key in list(res_static_waiting.keys()):
            for key_processed in list(res_static_processed.keys()):
                if key == key_processed:
                    del res_static_waiting[key]

        for key in list(res_sensitivities_waiting.keys()):
            for key_processed in list(res_sensitivities_processed.keys()):
                if key == key_processed:
                    del res_sensitivities_waiting[key]

        # Handle when still waiting
        if 'error' in res_sensitivities_waiting.keys():
            res_static_waiting["Checks pending"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        elif len(res_static_waiting) == 0:
            res_static_waiting["All files received"] = max(res_static_processed.values())

        # Handle when still waiting
        if 'error' in res_sensitivities_processed.keys():
            res_sensitivities_waiting["Checks pending"] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        elif len(res_sensitivities_waiting) == 0:
            res_sensitivities_waiting["All files received"] = max(res_sensitivities_processed.values())

        log.info("Senstivities waiting {0}", res_sensitivities_waiting)

        # Generate the email
        html = self.template.build_html(res_static_waiting, res_sensitivities_waiting, res_sensitivities_started)

        # Send the email
        self.send_email(html)

    @staticmethod
    def send_email(html):

        # Create message container - the correct MIME type is multipart/alternative.
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "RRR Trade Reconciliation"
        msg['From'] = config.sender
        msg['To'] = config.rrr_recon_recipient

        # Attach parts into message container.
        body = MIMEText(html, 'html')
        msg.attach(body)

        log.info(msg.as_string())
        log.info("Sent RRR Trade Reconciliation email from %s to %s", config.sender,
                 config.rrr_recon_recipient)

        # Send the message via SMTP server.
        s = smtplib.SMTP(config.smtp, config.port)
        s.send_message(msg)
        s.quit()
