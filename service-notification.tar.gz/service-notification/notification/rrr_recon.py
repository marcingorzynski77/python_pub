# This is the template for the RRR Reconciliation
import datetime as dt
import logging

log = logging.getLogger(__name__)


class Email(object):
    def __init__(self, event):
        self.bus_date = event.bus_date.strftime('%Y-%m-%d')
        self.run_id = event.correlated_message_id
        self.rrr_id = ''
        self.mars_id = ''
        self.info = None
        self.body = "This is a rrr_recon email"
        self.count_expected_rrr_Results = []
        self.count_sensitivities = []
        self.count_distinct_trades_per_file = []
        self.count_expected_rrr_Results = []
        self.excluded_trades = []
        self.list_excluded_trades = []
        self.count_excluded_trades = []
        self.failed_validation_trades = []
        self.list_failed_validation_trades = []
        self.count_failed_validation_trades = []
        self.trades_with_unexpected_errors = []
        self.list_trades_with_unexpected_errors = []
        self.count_trades_with_unexpected_errors = []
        self.count_ComputedRrrResults = []
        self.count_RrrTradeResultsReceivedInRawMars = []
        self.count_RrrTradeResultsPersistedInTargetInMars = []
        self.count_RrrAggResultsReceivedInRawMars = []
        self.count_RrrAggResultsPersistedInTargetInMars = []
        self.count_unknown_counterparties = []
        self.list_unknown_counterparties = []
        self.count_unknown_books = []
        self.list_unknown_books = []
        self.count_unknown_instrument_type = []
        self.list_unknown_instrument_type = []
        self.processing = []
        self.grossAggregation = []
        self.netAggregation = []
        self.marsImportProcessing = []
        self.expectedTradesNotFoundInMars = []
        self.expectedTradesNotFoundInRRR = []
        self.booksForExpectedTradesNotFoundInMars = []
        self.count_unknown_counterparties = []
        self.count_unknown_books = []
        self.count_unknown_instrument_type = []
        self.marsImportProcessing = []
        self.netAggregation = []
        self.processing = []
        self.grossAggregation = []
        self.expectedTradesNotFoundInMars = []
        self.booksForExpectedTradesNotFoundInMars = []
        self.booksForExpectedTradesNotFoundInRRR = []

    def build_html(self):
        """Builds and sends a html based email by using the data parsed from the JSON payload."""

        start = ''
        finish = ''

        log.info('build HTML body for email')

        html = f'''<html>                  
                    <table>
                    <tr><td width=625>
                    <font face="segoe ui" color="limegreen"  size = "6">RRR: </font><font face="segoe ui" 
                        color="MediumSeaGreen"  size = "5">Timeliness Checks</font>
                    <p> All expected files received and processed</p>
                    </td><td width=625 align="right"><font face="segoe ui" color="limegreen"  size = "6">COB: </font>
                        <font face="segoe ui" color="MediumSeaGreen"  size = "5">{self.bus_date}</font>                    
                    </td></tr>
                    </table>
                    <br>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                        <font size=2.5>
                          <tr align="center">
                            <th bgcolor="#FFC57E" width=190>Process</th>
                            <th bgcolor="#FFC57E" width=190>Start</th>                                    
                            <th bgcolor="#FFC57E" width=190>Finish</th>
                            <th bgcolor="#FFC57E" width=190>RunTime</th>
                            <th bgcolor="#FFC57E" width=190>Target</th>
                          </tr>'''

        for item in self.processing:
            file = self.processing[item]

            start = format_date(file["start"])
            finish = format_date(file["finish"])
            if start != "N/A" and finish != "N/A":
                runtime = finish - start
            else:
                runtime = "N/A"

            html = html + f'''<tr align="center">
                              <td>{format_source_file(item.lower())}</td>
                              <td>{start}</td>
                              <td>{finish}</td>
                              <td>{runtime}</td>
                              <td></td>
                              </tr>'''

        # grossAggregation
        print(start)
        print(finish)
        start = format_date(self.grossAggregation['start'])
        finish = format_date(self.grossAggregation['finish'])
        print(start)
        print(finish)
        if start != "N/A" and finish != "N/A":
            runtime = finish - start
        else:
            runtime = "N/A"

        html = html + f'''<tr align="center"><td>gross_Aggregation</td><td>{start}</td><td>{finish}</td><td>{runtime}
                        </td><td></td></tr>'''

        # netAggregation
        start = format_date(self.netAggregation['start'])
        finish = format_date(self.netAggregation['finish'])
        if start != "N/A" and finish != "N/A":
            runtime = finish - start
        else:
            runtime = "N/A"

        html = html + f'''<tr align="center"><td>net_Aggregation</td><td>{start}</td><td>{finish}</td><td>{runtime}</td>
                        <td></td></tr>'''

        # marsImportProcessing
        start = format_date(self.marsImportProcessing['start'])
        finish = format_date(self.marsImportProcessing['finish'])
        if start != "N/A" and finish != "N/A":
            runtime = finish - start
        else:
            runtime = "N/A"

        html = html + f'''<tr align="center"><td>mars_Import_Processing</td><td>{start}</td><td>{finish}</td><td>{runtime}
                        </td><td></td></tr>'''

        html = html + '''  
                       </font>
                    </table>   
                     <br>
                    <br>     
                    <p><font face="segoe ui" color="limegreen"  size = "6">RRR: </font><font face="segoe ui" 
                        color="MediumSeaGreen"  size = "5">Processing Checks</font></p>
                    <table>
                    <tr>
                    <td valign="top">
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Actual input : </font>
                    <p>Number of sensitivities in source files</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                        <font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=190>Sensitivities File</th><th bgcolor="#FFC57E" 
                                width=190>Row Count</th>
                        </tr>'''

        for item in self.count_sensitivities:
            html = html + f'''<tr align="center"><td>{format_source_file(item.lower())}</td>
                            <td>{self.count_sensitivities[item]}</td></tr>'''

        html = html + '''              
                        </font>
                    </table>                                
                    </td>
                    <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                    <td valign="top">
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Expected Sensitivities : </font>
                    <p>Expected number of RRR results</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=190>Sensitivities File</th><th bgcolor="#FFC57E" width=190>
                                Expected Count</th>
                        </tr>'''

        for item in self.count_expected_rrr_Results:
            html = html + f'''<tr align="center"><td>{format_source_file(item.lower())}</td>
                            <td>{self.count_expected_rrr_Results[item]}</td></tr>'''

        html = html + '''
                        </font>
                    </table>
                    </td>
                    <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                    <td valign="top">                                
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Distinct Trades : </font>
                    <p>Number of distinct trades per risk measure</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                       <tr>
                            <th bgcolor="#FFC57E" width=190>Risk Measure</th><th bgcolor="#FFC57E" width=190>
                                Distinct Count</th>
                        </tr>'''

        for item in self.count_distinct_trades_per_file:
            html = html + f'''<tr align="center"><td>{clean_source_file(item.lower())}</td><td>
                            {self.count_distinct_trades_per_file[item]}</td></tr>'''

        html = html + '''
                        </font>
                    </table>
                    </td>
                    </tr></table>
                    <br>
                    <br>                    
                    <table>
                    <tr>
                    <td valign="top">  
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Actual input : </font>                  
                    <p>Results computed in RRR</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=190>Risk Measure</th><th bgcolor="#FFC57E" width=190>Row Count
                                </th>
                        </tr>'''

        for item in self.count_ComputedRrrResults:
            html = html + f'''<tr align="center"><td>{format_source_file(item.lower())}</td><td>
                            {self.count_ComputedRrrResults[item]}</td></tr>'''

        html = html + '''
                        </font>
                    </table>                                
                    </td>
                    <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                    <td valign="top">        
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Raw Count : </font>            
                    <p>Trade level results submitted to Mars</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=190>Risk Measure</th><th bgcolor="#FFC57E" width=190>Row Count
                                </th>
                        </tr>'''

        for item in self.count_RrrTradeResultsReceivedInRawMars:
            html = html + f'''<tr align="center"><td>{item.lower()}</td><td>
                            {self.count_RrrTradeResultsReceivedInRawMars[item]}</td></tr>'''

        html = html + '''
                        </font>
                    </table>
                    </td>
                    <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                    <td valign="top">
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Target Count : </font>
                    <p>Trade level results presented by Mars</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                       <tr>
                            <th bgcolor="#FFC57E" width=190>Risk Measure</th><th bgcolor="#FFC57E" width=190>
                                Row Count</th>
                        </tr>'''

        for item in self.count_RrrTradeResultsPersistedInTargetInMars:
            if item in self.count_RrrTradeResultsReceivedInRawMars:
                if self.count_RrrTradeResultsPersistedInTargetInMars[item] == \
                        self.count_RrrTradeResultsReceivedInRawMars[item]:
                    html = html + f'''<tr align="center"><td>{item.lower()}</td><td>
                                    {self.count_RrrTradeResultsPersistedInTargetInMars[item]}</td></tr>'''
                else:
                    html = html + f'''<tr align="center"><td>{item.lower()}</td><td bgcolor=#FF5930>
                                    {self.count_RrrTradeResultsPersistedInTargetInMars[item]}</td></tr>'''
            else:
                html = html + f'''<tr align="center"><td>{item.lower()}</td><td bgcolor=#FF5930>
                                {self.count_RrrTradeResultsPersistedInTargetInMars[item]}</td></tr>'''

        html = html + '''                        </font>
                    </table>
                    </td>
                    </tr>                                        
                    <tr>
                    <td valign="top"> 
                    <br>                   
                    <p></p>
                    <table cellpadding="1" cellspacing="0"><font size=2.5>
                        <tr>
                            <th width=190></th><th width=190></th>
                        </tr>
                        <tr align="center">
                            
                        </tr>
                        <tr align="center">
                            
                        </tr>
                        <tr align="center">
                            
                        </tr>
                        <tr align="center">
                            
                        </tr>
                        <tr align="center">
                            
                        </tr>
                        <tr align="center">                        
                        </tr>
                        </font>
                    </table>                                
                    </td>
                    <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                    <td valign="top">     
                    <br>               
                    <p>Aggregated results submitted to Mars</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=190>Sensitivities File</th><th bgcolor="#FFC57E" width=190>
                                Row Count</th>
                        </tr>'''

        for item in self.count_RrrAggResultsReceivedInRawMars:
            html = html + f'''<tr align="center"><td>{item.lower()}</td><td>
                            {self.count_RrrAggResultsReceivedInRawMars[item]}</td></tr>'''

        html = html + '''
                        </font>
                    </table>                                
                    </td>
                    <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                    <td valign="top">        
                    <br>            
                    <p>Aggregated results presented by Mars</p>
                    <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro"><font size=2.5>
                        <tr>
                            <th bgcolor="#FFC57E" width=190>Sensitivities File</th><th bgcolor="#FFC57E" width=190>
                                Row Count</th>
                        </tr>'''

        for item in self.count_RrrAggResultsPersistedInTargetInMars:
            if item in self.count_RrrAggResultsReceivedInRawMars:
                if self.count_RrrAggResultsPersistedInTargetInMars[item] \
                        == self.count_RrrAggResultsReceivedInRawMars[item]:
                    html = html + f'''<tr align="center"><td>{item.lower()}</td><td>
                                    {self.count_RrrAggResultsPersistedInTargetInMars[item]}</td></tr>'''
                else:
                    html = html + f'''<tr align="center"><td>{item.lower()}</td><td bgcolor=#FF5930>
                                    {self.count_RrrAggResultsPersistedInTargetInMars[item]}</td></tr>'''
            else:
                html = html + f'''<tr align="center"><td>{item.lower()}</td><td bgcolor=#FF5930>
                                {self.count_RrrAggResultsPersistedInTargetInMars[item]}</td></tr>'''

        html = html + '''
                        </font>
                    </table>
                    </td>
                    </tr>
                    </table>                      
                    <br>
                    <br>                               
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Excluded Records : </font>
                    <br>
                    <br>
                    <table >
                        <tr>
                            <td size=3>Trades that were excluded</td>           
                            <td><font face="segoe ui" color="White"  size = "3">...........</font></td>                 
                            <td size=3>Trades that failed validation</td>                                    
                            <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                            <td size=3>Trades with unexpected errors</td>
                        </tr>     
                        <tr></tr>
                        <tr>
                            <td valign="top">
                                <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr align="center">
                                            <th bgcolor="#FFC57E" width=190>Trades</th>
                                            <th bgcolor="#FFC57E" width=190>Count</th>
                                        </tr>'''

        for item in self.count_excluded_trades:
            html = html + f'''<tr align="center"><td>{item.lower()}</td><td>{self.count_excluded_trades[item]}</td>
                            </tr>'''

        html = html + '''                          
                                    </font>
                                </table>
                            </td>      
                            <td></td>                                  
                            <td valign="top">
                             <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Trades</th>
                                            <th bgcolor="#FFC57E" width=190 align="center">Count</th>
                                        </tr>'''

        for item in self.count_failed_validation_trades:
            html = html + f'''<tr align="center"><td>{item.lower()}</td><td>{self.count_failed_validation_trades[item]}
                            </td></tr>'''

        html = html + '''  
                                    </font>
                                </table>
                            </td>      
                            <td></td>                              
                            <td valign="top">
                             <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Trades</th>
                                            <th bgcolor="#FFC57E" width=190 align="center">Count</th>
                                        </tr>'''

        for item in self.count_trades_with_unexpected_errors:
            html = html + f'''<tr align="center"><td>{item.lower()}</td><td>
                            {self.count_trades_with_unexpected_errors[item]}</td></tr>'''

        html = html + '''
                                    </font>
                                </table>
                            </td>
                        </tr>
                        </font>                         
                    </table>
                    
                    <br>
                    <br>                                                           
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Trade Reconciliation : </font>
                    <br>
                    <br>
                    <table >
                        <tr>
                            <td width=190 size=3>'''

        if self.expectedTradesNotFoundInRRR["count"] >= 100:
            html = html + f'''Top 100 of <b>{self.expectedTradesNotFoundInRRR["count"]}</b> 
                            expected trades not found in RRR</td>'''
        else:
            html = html + f'''Top <b>{self.expectedTradesNotFoundInRRR["count"]}</b> 
                            expected trades not found in RRR</td>'''

        html = html + '''</td>
                        <td width=190></td>
                        <td width=40></td>
                        <td width=190 size=3>'''

        if self.expectedTradesNotFoundInMars["count"] >= 100:
            html = html + f'''Top 100 of <b>{self.expectedTradesNotFoundInMars["count"]}</b> 
                            expected trades not found in Mars</td>'''
        else:
            html = html + f'''Top <b>{self.expectedTradesNotFoundInMars["count"]}</b> 
                            expected trades not found in Mars</td>'''

        html = html + '''</td>
                        <tr></tr>
                        </tr>     
                        <tr></tr>
                        <tr>
                            <td valign="top">
                                <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Trade Reference</th> 
                                        </tr>'''

        rec = self.expectedTradesNotFoundInRRR["list"][:100]

        for item in rec:
            html = html + f'''<tr align="center"><td>{item.lower()}</td></tr>'''

        html = html + '''  
                                    </font>
                                </table>
                            </td>     
                            <td width=190></td>
                            <td width=40></td>		
                            <td valign="top">
                                <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Trade Reference</th> 
                                        </tr>'''

        rec = self.expectedTradesNotFoundInMars["list"][:100]

        for item in rec:
            html = html + f'''<tr align="center"><td>{item.lower()}</td></tr>'''

        html = html + '''  
                                    </font>
                                </table>
                            </td>       
                          </tr>
                        </font>                         
                    </table>  
                    <br>
                    <br>                                                           
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> RRR Trade Reconciliation : </font><br><br><table>
                        <tr>
                            <td size=3>'''

        if self.booksForExpectedTradesNotFoundInRRR["count"] >= 100:
            html = html + f'''Top 100 of <b>{self.booksForExpectedTradesNotFoundInRRR["count"]}</b> 
                            books for expected trades not found in RRR</td>'''
        else:
            html = html + f'''Top <b>{self.booksForExpectedTradesNotFoundInRRR["count"]}</b> 
                            books for expected trades not found in RRR</td>'''

        html = html + '''</tr>     
                        <tr></tr>
                        <tr>                                                       
                            <td valign="top">
                             <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Book</th>        
                                            <th bgcolor="#FFC57E" width=190>Count</th>        
                                            <th bgcolor="#FFC57E" width=870>Hierarchy Path</th>                                                                                        
                                        </tr>'''

        rec = self.booksForExpectedTradesNotFoundInRRR["list"][:100]

        for item in rec:
            book = str(item[0])
            path = str(item[1])
            count = str(item[2])
            html = html + f'''<tr><td align="center">{book}</td><td align="center">{count}</td><td align="left">{path}
                            </td></tr>'''

        html = html + '''  
                                    </font>
                                </table>
                            </td>   
                        </tr>
                        </font>                         
                    </table>    
                    <br>
                    <br>                                                           
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Mars Trade Reconciliation : </font>
                    <br>
                    <br>    
                    <table >
                        <tr>
                            <td size=3> '''

        if self.booksForExpectedTradesNotFoundInMars["count"] >= 100:
            html = html + f'''Top 100 of <b>{self.booksForExpectedTradesNotFoundInMars["count"]}</b> 
                            books for expected trades not found in Mars</td>'''
        else:
            html = html + f'''Top <b>{self.booksForExpectedTradesNotFoundInMars["count"]}</b> 
                            books for expected trades not found in Mars</td>'''

        html = html + '''
                        </tr>     
                        <tr></tr>
                        <tr>                                                       
                            <td valign="top">
                             <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Book</th>        
                                            <th bgcolor="#FFC57E" width=190>Count</th>        
                                            <th bgcolor="#FFC57E" width=870>Hierarchy Path</th>                                                                                        
                                        </tr>'''

        rec = self.booksForExpectedTradesNotFoundInMars["list"][:100]

        for item in rec:
            book = str(item[0])
            path = str(item[1])
            count = str(item[2])
            html = html + f'''<tr><td align="center">{book}</td><td align="center">{count}</td><td align="left">{path}
                            </td></tr>'''

        html = html + f'''  
                                    </font>
                                </table>
                            </td>   
                        </tr>
                        </font>                         
                    </table>    
                    <br>
                    <br>                                                            
                    <font face="segoe ui" color="MediumSeaGreen"  size = "3"> Static Issues : </font>
                    <br>
                    <br>
                    <table >
                        <tr>
                            <td size=3><b>{len(self.count_unknown_counterparties)}</b> Unknown counterparties</td>           
                            <td><font face="segoe ui" color="White"  size = "3">...........</font></td>                 
                            <td size=3><b>{len(self.count_unknown_books)}</b> Unknown books</td>                                    
                            <td><font face="segoe ui" color="White"  size = "3">...........</font></td>
                            <td size=3><b>{len(self.count_unknown_instrument_type)}</b> Unknown instrument types</td>
                        </tr>     
                        <tr></tr>
                        <tr>
                            <td valign="top">
                                <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Counterparties</th>
                                            <th bgcolor="#FFC57E" width=190 align="center">Count</th>
                                        </tr>'''

        for item in self.count_unknown_counterparties:
            html = html + f'''<tr align="center"><td>{item[0].lower()}</td><td>{item[1]}</td></tr>'''

        html = html + '''  
                                    </font>
                                </table>
                            </td>      
                            <td></td>                                  
                            <td valign="top">
                             <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Books</th>
                                            <th bgcolor="#FFC57E" width=190 align="center">Count</th>
                                        </tr>'''

        for item in self.count_unknown_books:
            html = html + f'''<tr align="center"><td>{item[0].lower()}</td><td>{item[1]}</td></tr>'''

        html = html + '''  
                                    </font>
                                </table>
                            </td>      
                            <td></td>                              
                            <td valign="top">
                             <table cellpadding="1" cellspacing="0" border="1" bordercolor="gainsboro">
                                    <font size=2.5>
                                        <tr>
                                            <th bgcolor="#FFC57E" width=190>Instrument Types</th>
                                            <th bgcolor="#FFC57E" width=190 align="center">Count</th>
                                        </tr>'''

        for item in self.count_unknown_instrument_type:
            html = html + f'''<tr align="center"><td>{item[0].lower()}</td><td>{item[1]}</td></tr>'''

        html = html + f'''  
                                    </font>
                                </table>
                            </td>
                        </tr>
                        </font>                         
                    </table>        
                    <p><font> rrr id: {self.rrr_id}</font></p>
                    <p><font> mars id: {self.mars_id}</font></p>
                    <p><font> triage id: {self.run_id}</font></p>
                  </html>'''

        return html

    def parse_json(self, info):

        self.info = info

        log.info("parse JSON at granular level")
        self.rrr_processing()
        self.rrr_timeliness()
        self.run_ids()


    def run_ids(self):

        if 'rrrCorrelationId' in self.info:
            self.rrr_id = self.info['rrrCorrelationId']

        if 'marsCorrelationId' in self.info:
            self.mars_id = self.info['marsCorrelationId']


    def rrr_processing(self):
        """Strips out the RRR processing data from the Triage JSON file"""
        # rrrProcessing
        if 'rrrProcessing' in self.info:
            rrr_processing = self.info['rrrProcessing']

            if 'actualInput' in rrr_processing:
                actual_input = rrr_processing['actualInput']
                if 'countSensitivities' in actual_input:
                    self.count_sensitivities = actual_input['countSensitivities']

            # expectedCounts
            if 'expectedCounts' in rrr_processing:
                expected_counts = rrr_processing['expectedCounts']
                if 'countDistinctTradesPerFile' in expected_counts:
                    self.count_distinct_trades_per_file = expected_counts['countDistinctTradesPerFile']

                if 'countExpectedRrrResults' in expected_counts:
                    self.count_expected_rrr_Results = expected_counts['countExpectedRrrResults']

            # excludedRecords
            if 'excludedRecords' in rrr_processing:

                excluded_records = rrr_processing['excludedRecords']

                if 'excludedTrades' in excluded_records:
                    excluded_trades = excluded_records['excludedTrades']

                    if 'list' in excluded_trades:
                        self.list_excluded_trades = excluded_trades['list']

                    if 'count' in excluded_trades:
                        self.count_excluded_trades = excluded_trades['count']

                if 'failedValidationTrades' in excluded_records:
                    failed_validation_trades = excluded_records['failedValidationTrades']

                    if 'list' in failed_validation_trades:
                        self.list_failed_validation_trades = failed_validation_trades['list']

                    if 'count' in failed_validation_trades:
                        self.count_failed_validation_trades = failed_validation_trades['count']

                if 'tradesWithUnexpectedErrors' in excluded_records:
                    trades_with_unexpected_errors = excluded_records['tradesWithUnexpectedErrors']

                    if 'list' in trades_with_unexpected_errors:
                        self.list_trades_with_unexpected_errors = trades_with_unexpected_errors['list']

                    if 'count' in trades_with_unexpected_errors:
                        self.count_trades_with_unexpected_errors = trades_with_unexpected_errors['count']

            # actualResults
            if 'actualResults' in rrr_processing:
                actual_results = rrr_processing['actualResults']

                if 'countComputedRrrResults' in actual_results:
                    self.count_ComputedRrrResults = actual_results['countComputedRrrResults']

                if 'countRrrTradeResultsReceivedInRawMars' in actual_results:
                    self.count_RrrTradeResultsReceivedInRawMars = actual_results[
                        'countRrrTradeResultsReceivedInRawMars']

                if 'countRrrTradeResultsPersistedInTargetInMars' in actual_results:
                    self.count_RrrTradeResultsPersistedInTargetInMars = actual_results[
                        'countRrrTradeResultsPersistedInTargetInMars']

                if 'countRrrAggResultsReceivedInRawMars' in actual_results:
                    self.count_RrrAggResultsReceivedInRawMars = actual_results['countRrrAggResultsReceivedInRawMars']

                if 'countRrrAggResultsPersistedInTargetInMars' in actual_results:
                    self.count_RrrAggResultsPersistedInTargetInMars = actual_results[
                        'countRrrAggResultsPersistedInTargetInMars']

            # staticIssues
            if 'staticIssues' in rrr_processing:
                static_issues = rrr_processing['staticIssues']

                if 'unknownCounterparties' in static_issues:
                    self.count_unknown_counterparties = static_issues['unknownCounterparties']
                self.list_unknown_counterparties = []  # self.unknown_counterparties['list']

                if 'unknownBooks' in static_issues:
                    self.count_unknown_books = static_issues['unknownBooks']
                self.list_unknown_books = []  # self.unknown_books['list']

                if 'unknownInstrumentTypes' in static_issues:
                    self.count_unknown_instrument_type = static_issues['unknownInstrumentTypes']
                self.list_unknown_instrument_type = []  # self.unknown_instrument_type['list']

    def rrr_timeliness(self):
        """Strips out the RRR timeliness data from the Triage JSON file"""

        # rrrTimeliness
        if 'rrrTimeliness' in self.info:
            rrr_timelines = self.info['rrrTimeliness']

            if 'processing' in rrr_timelines:
                self.processing = rrr_timelines['processing']

            # grossAggregation
            if 'grossAggregation' in rrr_timelines:
                self.grossAggregation = rrr_timelines['grossAggregation']

            # netAggregation
            if 'netAggregation' in rrr_timelines:
                self.netAggregation = rrr_timelines['netAggregation']

            # processing
            if 'marsImportProcessing' in rrr_timelines:
                self.marsImportProcessing = rrr_timelines['marsImportProcessing']

        # trade recon
        if 'rrrTradeRecon' in self.info:
            rrr_trade_recon = self.info['rrrTradeRecon']

            if 'expectedTradesNotFoundInMars' in rrr_trade_recon:
                self.expectedTradesNotFoundInMars = rrr_trade_recon['expectedTradesNotFoundInMars']

            if 'expectedTradesNotFoundInRRR' in rrr_trade_recon:
                self.expectedTradesNotFoundInRRR = rrr_trade_recon['expectedTradesNotFoundInRRR']

            if 'booksForExpectedTradesNotFoundInRRR' in rrr_trade_recon:
                self.booksForExpectedTradesNotFoundInRRR = rrr_trade_recon['booksForExpectedTradesNotFoundInRRR']
                print("Books For Expected Trades Not Found In RRR")

                for item in self.booksForExpectedTradesNotFoundInRRR["list"]:
                    print(str(item[0]))

            if 'booksForExpectedTradesNotFoundInMars' in rrr_trade_recon:
                self.booksForExpectedTradesNotFoundInMars = rrr_trade_recon['booksForExpectedTradesNotFoundInMars']
                print("Books For Expected Trades Not Found In Mars")

                for item in self.booksForExpectedTradesNotFoundInMars["list"]:
                    print(str(item[0]))


def format_source_file(source_file):
    if source_file[:5].upper() == "SIMRA":
        source_file = "Simra_" + source_file[5:]
    elif source_file[:5].upper() == "PARIS":
        source_file = "Paris_" + source_file[5:]

    return source_file


def clean_source_file(source_file):
    if source_file[:5].upper() == "SIMRA":
        source_file = source_file[5:]
    elif source_file[:5].upper() == "PARIS":
        source_file = source_file[5:]

    return source_file


def format_date(s_date):
    if s_date != 'N/A':
        s_date = dt.datetime.strptime(s_date.replace('T', ' ')[:19], '%Y-%m-%d %H:%M:%S')

    return s_date
