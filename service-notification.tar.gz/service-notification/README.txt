Business Application Delivery
========

Notification micro service

Set up environment :
mkvirtualenv -p python3 notification
pip install -r requirements.txt